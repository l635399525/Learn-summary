
dest_path = r"D:\data"
RAW_FINAL_FORMAT_FILE               = dest_path + "/RAW_FINAL_FORMAT"
RAW_FINAL_FORMAT_CLOSE_FILE         = dest_path + "/RAW_FINAL_FORMAT_CLOSE"
RAW_FINAL_FORMAT_HL_FILE            = dest_path + "/RAW_FINAL_FORMAT_HL"
RAW_FINAL_FORMAT_MIN_FILE           = dest_path + "/RAW_FINAL_FORMAT_MIN"
RAW_FINAL_FORMAT_TRAIN              = dest_path + "/RAW_FINAL_FORMAT_TRAIN"
RAW_FINAL_FORMAT_ANALYSIS           = dest_path + "/RAW_FINAL_FORMAT_ANALYSIS"

dest_summary_path = r'D:\data\summary_db'
RAW_NET_WORK_FILE = dest_summary_path + "/RAW_NETWORK_DATA"
RAW_HLS_WORK_FILE = dest_summary_path  + "/RAW_HLWAVES_DATA"
RAW_HLS_WORK_FILE_HIST = dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORY"
RAW_HLS_WORK_FILE_HIST_TRAIN = dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORY_TRAIN"
RAW_HLS_WORK_FILE_HIST_TRAIN_CZSC = dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORY_TRAIN_CZSC"

RAW_NET_WORK_FILE_TMP = dest_summary_path + "/RAW_NETWORK_DATA_TMP"

RAW_NET_WORK_FILE_TMP_SH = dest_summary_path + "/RAW_NETWORK_DATA_TMP_SH"
RAW_NET_WORK_FILE_TMP_SZ = dest_summary_path + "/RAW_NETWORK_DATA_TMP_SZ"
