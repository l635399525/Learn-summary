import numpy as np
token = "833f66768633bd4349ca487fd6b26697616a4e35d6622ebefa7d03f6"

def doSplit(listTemp, n):
    for i in range(0, len(listTemp), n):
        yield listTemp[i:i + n]

def cross(q,s):
    p_bull = 1 if q[0] - s[0] > 0 else 0
    lst = [q[0],s[0],0,0,0,0,0,0,0,0]
    bull_count = 0
    bulls = np.zeros()
    bull_avg_count = 10
    bull_ma_total_count = 0
    cross_count = 0
    for i in range(1,len(q)):
        qp = q[i]
        sp = s[i]
        minus = qp - sp
        minus_rate = round(minus*100/sp,3)
        c_bull = 1 if qp - sp > 0 else 0
        bulls[i] = c_bull
        cross = 0 if c_bull == p_bull else 1
        p_bull = c_bull
        bull_count = bull_count + 1 if c_bull == 1 else bull_count
        bull_log = "%s/%s" %(bull_count,len(lst)+1)
        if i > bull_avg_count - 1:
            bull_ma_total_count = sum(bulls[i - bull_avg_count + 1 : i+1])
        bull_rate = round(bull_count*100/(len(lst)+1))
        if cross == 1:
            cross_count = cross_count + 1
        lst.append([qp,sp,c_bull,cross,minus,minus_rate,bull_log,bull_rate,bull_ma_total_count,cross_count])
    return lst
from datetime import *
def getToday():
    if datetime.now().hour < 16:
        now = (datetime.now() + timedelta(days=-1))
    else:
        now = datetime.now()

    today = now.strftime("%Y-%m-%d")

    week = now.strftime("%w")
    if week == '6':
        today = (now + timedelta(days=-1)).strftime("%Y-%m-%d")
    elif week == '0':
        today = (now + timedelta(days=-2)).strftime("%Y-%m-%d")
    return today

def getNextDays(datestr,day = 1):
    # today = datetime.datetime.now()
    datetime_str = datetime.strptime(datestr, "%Y-%m-%d")
    # 计算偏移量
    offset = timedelta(days=day)
    # 获取想要的日期的时间
    re_date = (datetime_str + offset).strftime('%Y-%m-%d')
    return re_date

def getHYGNCodes(from_local=True,update=True):
    from com.DbTool import getConn,drop
    from com.models.loader.HYGNLoaderFromNet import getHYCodes,getGNCodes,conf_file,tables_conf
    lines = []
    if update and not from_local:
        conf_conn = getConn(conf_file)
        drop(conf_conn,tables_conf["HYGNCONF"])
    h = getHYCodes(from_local=from_local,update=update)
    g = getGNCodes(from_local=from_local,update=update)
    lines.extend(h)
    lines.extend(g)
    return lines

def getHYGNFromLocal(type="all"):
    from com.Const import hygn_raw_folder
    import glob
    if type == "all":
        files = glob.glob("%s/%s"%(hygn_raw_folder,"*.db"))
    else:
        files = glob.glob("%s/*%s.db"%(hygn_raw_folder,type))
    lines = list(map(lambda x:[x.split("/")[-1].split(".")[0],x],files))
    return lines
def calAngle(stept,pct):
    import math
    rate = 1
    if pct < 0:
        rate = -1
    a = abs(pct)
    b = stept
    c = math.sqrt(pow(a,2) + pow(b,2))
    angle = math.asin((a/c))
    angle_val = round(math.degrees(angle),3)
    return angle_val * rate
def _ma(series, n):
    """
    移动平均
    """
    #series = series.sort_index(ascending=False)
    #res = series.rolling(n,min_periods=1).mean().sort_index(ascending=False).round(decimals=3)

    res = series.rolling(n, min_periods=1).mean().round(decimals=3)
    return res

def _sum(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).sum().sort_index(ascending=False).round(decimals=3)
    return res

def _max(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).max().sort_index(ascending=False).round(decimals=3)
    return res

def _min(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).max().sort_index(ascending=False).round(decimals=3)
    return res
