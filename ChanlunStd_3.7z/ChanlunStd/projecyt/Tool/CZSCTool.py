from typing import List

from czsc import NewBar, envs
from czsc.analyze import remove_include, check_fx, check_fxs, check_bi
from czsc.enum import Mark, Direction
from czsc.objects import FX, BI, ZS
import numpy as np

from czsc.utils import kline_pro


def getNewBars(bars):
    bars1 = []
    for bar in bars:
        if len(bars1) < 2:
            bars1.append(NewBar(symbol=bar.symbol, id=bar.id, freq=bar.freq,
                                dt=bar.dt, open=bar.open,
                                close=bar.close, high=bar.high, low=bar.low,
                                vol=bar.vol, elements=[bar]))
        else:
            k1, k2 = bars1[-2:]
            has_include, k3 = remove_include(k1, k2, bar)
            if has_include:
                bars1[-1] = k3
            else:
                bars1.append(k3)

    fxs = []
    for i in range(1, len(bars1) - 1):
        fx = check_fx(bars1[i - 1], bars1[i], bars1[i + 1])
        if isinstance(fx, FX):
            fxs.append(fx)
    return bars1, fxs

def getBIs(bars):
    bi_list = []
    bars_ubi = []
    for i in range(len(bars)):
        bar = bars[i]
        bars_ubi.append(bar)
        if len(bars_ubi) < 3:
            continue
        # 查找笔
        if not bi_list:
            # 第一个笔的查找
            fxs = check_fxs(bars_ubi)
            if not fxs:
                continue
            fx_a = fxs[0]
            fxs_a = [x for x in fxs if x.mark == fx_a.mark]
            for fx in fxs_a:
                if (fx_a.mark == Mark.D and fx.low <= fx_a.low) \
                        or (fx_a.mark == Mark.G and fx.high >= fx_a.high):
                    fx_a = fx
            ana_fxs = fxs_a
            bars_ubi = [x for x in bars_ubi if x.dt >= fx_a.elements[0].dt]

            bi, bars_ubi_ = check_bi(bars_ubi)
            if isinstance(bi, BI):
                bi_list.append(bi)
            bars_ubi = bars_ubi_
            continue
        last_bi = bi_list[-1]
        # 如果上一笔被破坏，将上一笔的bars与bars_ubi进行合并
        if (last_bi.direction == Direction.Up and bars_ubi[-1].high > last_bi.high) \
                or (last_bi.direction == Direction.Down and bars_ubi[-1].low < last_bi.low):
            bars_ubi_a = last_bi.bars[:-1] + [x for x in bars_ubi if x.dt >= last_bi.bars[-1].dt]
            bi_list.pop(-1)
        else:
            bars_ubi_a = bars_ubi
        if envs.get_bi_change_th() > 0.5 and len(bi_list) >= 5:
            benchmark = min(last_bi.power_price, np.mean([x.power_price for x in bi_list[-5:]]))
        else:
            benchmark = None

        bi, bars_ubi_ = check_bi(bars_ubi_a, benchmark)
        bars_ubi = bars_ubi_
        if isinstance(bi, BI):
            bi_list.append(bi)
    return bi_list

def get_zs_seq(bis: List[BI]) -> List[ZS]:
    """获取连续笔中的中枢序列

    :param bis: 连续笔对象列表
    :return: 中枢序列
    """
    zs_list = []
    if not bis:
        return []

    for bi in bis:
        if not zs_list:
            zs_list.append(ZS(symbol=bi.symbol, bis=[bi]))
            continue

        zs = zs_list[-1]
        if not zs.bis:
            zs.bis.append(bi)
            zs_list[-1] = zs
        else:
            if (bi.direction == Direction.Up and bi.high < zs.zd) \
                    or (bi.direction == Direction.Down and bi.low > zs.zg):
                zs_list.append(ZS(symbol=bi.symbol, bis=[bi]))
            else:
                zs.bis.append(bi)
                zs_list[-1] = zs
    return zs_list

def drawImage(c,file=None):
    if file is None:
        file_html = r"D:\codes\chanlun_bis_charts\%s.html" % (c.symbol)
    else:
        file_html = file
    kline = [x.__dict__ for x in c.bars_raw]
    bi = [{'dt': x.fx_a.dt, "bi": x.fx_a.fx} for x in c.bi_list] + \
         [{'dt': c.bi_list[-1].fx_b.dt, "bi": c.bi_list[-1].fx_b.fx}]
    chart = kline_pro(kline, bi=bi, title="{} - {}".format(c.symbol, c.freq))
    chart.render(file_html)