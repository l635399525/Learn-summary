def _ma(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    #print(series.tolist())
    res = series.rolling(n,min_periods=1).mean().sort_index(ascending=False).round(decimals=3)
    #print(res.tolist())
    return res

def _sum(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).sum().sort_index(ascending=False).round(decimals=3)
    return res
def _dif(series1,series2):
    import numpy as np
    s1 = np.asarray(series1,dtype=float)[:-1]
    s2 = np.asarray(series2,dtype=float)[1:]
    return np.round((s1 - s2)*100/s2,3)

def _ema(series, n):
    """
    指数平均数
    """
    return series.ewm(ignore_na=False, span=n, min_periods=0, adjust=False).mean()

import pandas as pd
def _maboll(series, n):
    """
    移动平均
    """
    return series.rolling(n).mean()

def _md(series, n):
    """
    标准差MD
    """
    return series.rolling(n).std(ddof=0)  # 有时候会用ddof=1

def macd(df, n=12, m=26, k=9):
    """
    平滑异同移动平均线(Moving Average Convergence Divergence)
    今日EMA（N）=2/（N+1）×今日收盘价+(N-1)/（N+1）×昨日EMA（N）
    DIFF= EMA（N1）- EMA（N2）
    DEA(DIF,M)= 2/(M+1)×DIF +[1-2/(M+1)]×DEA(REF(DIF,1),M)
    MACD（BAR）=2×（DIF-DEA）
    return:
          osc: MACD bar / OSC 差值柱形图 DIFF - DEM
          diff: 差离值
          dea: 讯号线
    """
    _macd = pd.DataFrame()
    _macd['date'] = df['date']
    _macd['diff'] = round(_ema(df.close, n) - _ema(df.close, m),3)
    _macd['dea'] = round(_ema(_macd['diff'], k),3)
    _macd['macd'] = round((_macd['diff'] - _macd['dea'])*2,3)
    return _macd

def boll(df, n=26, k=2):
    """
    布林线指标BOLL boll(26,2)	MID=MA(N)
    标准差MD=根号[∑（CLOSE-MA(CLOSE，N)）^2/N]
    UPPER=MID＋k×MD
    LOWER=MID－k×MD
    """
    _boll = pd.DataFrame()
    _boll['date'] = df.date
    _boll['mid'] = round(_maboll(df.close, n),3)
    _mdd = _md(df.close, n)
    _boll['up'] = round(_boll.mid + k * _mdd,3)
    _boll['low'] = round(_boll.mid - k * _mdd,3)
    return _boll

def _max(series, n):
    """
    移动平均
    """
    #series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).max().round(decimals=3)
    return res

def _min(series, n):
    """
    移动平均
    """
    #series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).min().round(decimals=3)
    return res


def xingaoxindi(df):
    """
    布林线指标BOLL boll(26,2)	MID=MA(N)
    标准差MD=根号[∑（CLOSE-MA(CLOSE，N)）^2/N]
    UPPER=MID＋k×MD
    LOWER=MID－k×MD
    """
    minmaxVals = [5,10,20,60,120,240,500000]
    key_map = {"close":minmaxVals,"open":minmaxVals,"high":minmaxVals
              ,"low":minmaxVals,"ma5":minmaxVals,"ma10":minmaxVals,
               "ma20":minmaxVals,"ma60":minmaxVals,"ma120":minmaxVals,"ma240":minmaxVals}
    import numpy as np
    #_xgxd = pd.DataFrame()
    _xgxd = df[["code","date"]]
    _xgxd = _xgxd.copy()
    #_xgxd['code'] = df.code
    #_xgxd['date'] = df.date

    # _xgxd['close'] = df.close.astype(float)
    # _xgxd['high'] = df.high.astype(float)
    # _xgxd['low'] = df.low.astype(float)

    for k,v in key_map.items():
        _xgxd["%s" % (k)] = df[k].astype(float)
        for ma in v:
            series = df[k].sort_index(ascending=True)
            max_series = _max(series, ma)
            max_series = max_series.sort_index(ascending=True)
            _xgxd["%s_%s_%s" %(k,ma,"max")] = max_series
            min_series = _min(series, ma)
            min_series = min_series.sort_index(ascending=True)
            _xgxd["%s_%s_%s" % (k, ma, "min")] = min_series
    #
    # _xgxd['close_xingao'] = _max(df.close,5000)
    # _xgxd['close_xindi'] = _min(df.close,5000)
    # _xgxd['high_xingao'] = _max(df.high, 5000)
    # _xgxd['low_xindi'] = _min(df.low, 5000)
    # clst = np.round(_xgxd['close'].values - _xgxd['close_xingao'].values,3)
    # cxg_lst = list(map(lambda x:1 if x>=0 else 0,clst))
    # _xgxd['c_is_xg'] = cxg_lst
    #
    # clst = np.round(_xgxd['close'].values - _xgxd['close_xindi'].values,3)
    # cxd_lst = list(map(lambda x:1 if x<=0 else 0,clst))
    # _xgxd['c_is_xd'] = cxd_lst
    #
    # clst = np.round(_xgxd['high'].values - _xgxd['close_xingao'].values,3)
    # hxg_lst = list(map(lambda x:1 if x>=0 else 0,clst))
    # _xgxd['h_is_xg'] = hxg_lst
    #
    # clst = np.round(_xgxd['low'].values - _xgxd['close_xindi'].values,3)
    # lxd_lst = list(map(lambda x:1 if x<=0 else 0,clst))
    # _xgxd['l_is_xd'] = lxd_lst

    return _xgxd

def ma100(df,lst):
    pre = df[:-1]
    next = df[1:]
    rdf = next.copy()
    ks = []
    for k,v in lst.items():
        lines = list(next[k].values - pre[k].values)
        scores = list(map(lambda x:v if x > 0 else 0,lines))
        rdf["%s_scores" %(k)] = scores
        ks.append("%s_scores" %(k))
    rdf["sum"] = rdf[ks].sum(axis=1)
    return rdf

def getValByKey(key):
    if key == MAS.MA5.value:
        return 5
    elif key == MAS.MA10.value:
        return 10
    elif key == MAS.MA20.value:
        return 20
    elif key == MAS.MA60.value:
        return 60
    elif key == MAS.MA120.value:
        return 120
    elif key == MAS.MA240.value:
        return 240

import operator
def maDistance(df,lst):
    import json
    ks = []
    rdf = df.copy()
    lines = json.loads(df.to_json(orient='records'))
    nlines = []
    json_res = {}
    scores_lst = []
    sort_ma_lst = []
    dist3_lst = []
    dist3_desc_lst = []
    dist4_lst = []
    dist4_desc_lst = []
    dist5_lst = []
    dist5_desc_lst = []

    for i in range(len(lst)):
        json_res["%s_idx" % (i)] = []

    for line in lines:
        #print(line)
        data = []
        for k,v in lst.items():
            data.append([line[k],k])
        data.sort(key=operator.itemgetter(0))
        for i in range(len(data)):
            #line["%s_idx" %(i)] = data[i][1]
            json_res["%s_idx" %(i)].append(data[i][1])
        t_lst = list(map(lambda x:getValByKey(x[1]),data))
        scores = 0
        sort_ma = "ma5,ma10,ma20,ma60,ma120,ma240"
        try:
            res = calScoreByline(t_lst)
            sort_ma = res["src"]
            scores = res["sum_scores"]
        except:
            pass
        #line["sort_ma"] = sort_ma
        #line["score"] = scores
        scores_lst.append(scores)
        sort_ma_lst.append(sort_ma)
        #line_6 = data[0][0] - data[5][0]
        line_3 = getDistanceByLineCount(data,3)
        line_4 = getDistanceByLineCount(data,4)
        line_5 = getDistanceByLineCount(data,5)
        # line["dist_3"] = line_3[0]
        # line["dist_3_desc"] = line_3[1]
        #
        # line["dist_4"] = line_4[0]
        # line["dist_4_desc"] = line_4[1]
        #
        # line["dist_5"] = line_5[0]
        # line["dist_5_desc"] = line_5[1]

        #line["dist_6"] = line_6
        dist3_lst.append(line_3[0])
        dist3_desc_lst.append(line_3[1])
        dist4_lst.append(line_4[0])
        dist4_desc_lst.append(line_4[1])
        dist5_lst.append(line_5[0])
        dist5_desc_lst.append(line_5[1])
        nlines.append(line)
    json_res["score"] = scores_lst
    json_res["sort_ma"] = sort_ma_lst
    json_res["dist_3"] = dist3_lst
    json_res["dist_3_desc"] = dist3_desc_lst
    json_res["dist_4"] = dist4_lst
    json_res["dist_4_desc"] = dist4_desc_lst
    json_res["dist_5"] = dist5_lst
    json_res["dist_5_desc"] = dist5_desc_lst
    for k,v in json_res.items():
        rdf[k] = v
    #ndf = pd.DataFrame(nlines)
    return rdf
# lst = [1,2,3,4,5,6,7,8,9]
# size = 3
def getDistanceByLineCount(lst,size):
    tmps = []
    import numpy as np
    lines = getPermutationNoRepeating(lst,size)
    for line in lines:
        line = list(line)
        line.sort(key=operator.itemgetter(0))
        line_arrgs = np.asarray(list(map(lambda x:x[0],line)))
        line_diffs = np.abs(np.diff(line_arrgs))
        sums = np.sum(line_diffs)
        tmps.append([sums,line])
    tmps.sort(key=operator.itemgetter(0))
    res = tmps[0]
    sum = round(res[0],3)
    des = ",".join(list(map(lambda x:x[1],res[1])))
    return [sum,des]

#lst = [[9,"a"],[12,"a"],[7,"b"]]
#lst.sort(key=operator.itemgetter(0))
#print(lst)

def getPermutationNoRepeating(lst,size):
    from itertools import combinations
    all = combinations(lst,size)
    return list(all)
def getFullLstPermutation(lst):
    from itertools import permutations
    all = permutations(lst)
    return all
lst = [5,10,20,60,120,240]
lst = getFullLstPermutation(lst)
from project.com.Const import *
def calMaScore(key,jsonline):
    position = goldenJsonMaSortLst[key]
    left_lst = goldenMaSortLst[:position]
    right_lst = goldenMaSortLst[position + 1:]
    score_sum = 0
    c_position = jsonline[key]
    score_unit = getMaScoreVal(key)
    for p in left_lst:
        l_position = jsonline[p]
        if c_position > l_position:
            #print("%s %s" %(p,score_unit))
            score_sum = score_sum + score_unit
    for p in right_lst:
        r_position = jsonline[p]
        if c_position < r_position:
            #print("%s %s" %(p,score_unit))
            score_sum = score_sum + score_unit
    #print("%s--------%s" %(key,score_sum))
    return score_sum
def calScores():
    r = lst
    reses = []
    for line in r:
        json_line = {}
        for i in range(len(line)):
            a = line[i]
            json_line[a] = i
        res = {}
        sums = 0
        for k,v in json_line.items():
            scores = calMaScore(k,json_line)
            res[getMaVal(k)] = scores
            res["src"] = line
            sums = sums + scores
        res["sum_scores"] = sums
        reses.append(res)
    return reses
def calScoreByline(line):
    json_line = {}
    for i in range(len(line)):
        a = line[i]
        json_line[a] = i
    res = {}
    sums = 0
    for k,v in json_line.items():
        scores = calMaScore(k,json_line)
        res[getMaVal(k)] = scores
        maline = list(map(lambda x:getMaVal(x),line))
        res["src"] = ",".join(maline)
        sums = sums + scores
    res["sum_scores"] = sums
    return res

def crossInception(a,b):
    from shapely.geometry import LineString
    a = LineString([(0, 10.55), (1, 10.64),(2, 8)])
    b = LineString([(0, 10.7), (1, 10.61),(2, 9)])
    x = a.intersection(b)
    print(list(x))
if __name__ == '__main__':
    # lines = calScores()
    # for line in lines:
    #     print(line)
    crossInception(None,None)