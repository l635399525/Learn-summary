import requests
from project.com.Const import urls
headers = {"Content-Type":"application/json"}#指定提交的是json
def post(line):
    import json
    url_key,data = line
    url = urls[url_key]
    r = requests.post(url,data=json.dumps(data),headers=headers)
    return r

if __name__ == '__main__':
    print(1)
    #line = ["getmergefiles", {"data":{'name': ['letian', 'letian2'], 'password': '123'}}]
    #r = post(line).json()
    #for line in r:
    #    print(line)