from project import app,jsonify,request
from project.offline.func import getStartEndFromRequest
@app.route('/analysisMas',methods=['POST','GET'])
def analysisMas():
    print(1)
    content = request.json
    code = content["code"]
    start,end = getStartEndFromRequest(content)
    from project.models.GetFileFuncs import getConnByCode,query
    conn = getConnByCode(code)
    kpi_type = content["kpi_type"]
    date_condition = " and date(date)>date('%s') date(date)<=date('%s')" %(start,end)
    sql = "%s %s %s %s"%(content["sql_head"],content["src_table"],content["condition"],date_condition)
    #sql = "select * from history_hygn_group"
    raw_df = query(sql,conn)

    '''
   select
       code,date,close,ma5,ma20,hist_max,
       round((close - ma20)*100/ma20,3) as current_rate,
       round((ma5 - ma20)*100/ma20,3) as short_rate,
       round((ma20 - hist_max)*100/hist_max,3) as long_rate,
       case
            when close > ma20 then 1
           else 0
            end as current_bull,
       case
            when ma5 > ma20 then 1
           else 0
            end as short_bull,
       case
            when ma20 > hist_max then 1
           else 0
            end as long_bull,
       case hist_max
           when ma60 then 60
           when ma90 then 90
           when ma120 then 120
        else 240 end as maxDate,
        volume,v_ma5,v_ma20,hist_max_volume,
       round((volume - v_ma20)*100/v_ma20,3) as current_v_rate,
       round((v_ma5 - v_ma20)*100/v_ma20,3) as short_v_rate,
       round((v_ma20 - hist_max_volume)*100/hist_max_volume,3) as long_v_rate,
        case
            when volume > v_ma20 then 1
           else 0
            end as current_volume_bull,
       case
            when v_ma5 > v_ma20 then 1
           else 0
            end as short_volume_bull,
       case
            when v_ma20 > hist_max_volume then 1
           else 0
            end as long_volume_bull,
       case hist_max_volume
           when v_ma60 then 60
           when v_ma90 then 90
           when v_ma120 then 120
        else 240 end as maxVolumeDate
from (select
             b.code,b.close,a.date,c.volume,
             a.ma5,a.ma20,a.ma60,a.ma90,a.ma120,a.ma240,
             max(a.ma60,a.ma90,a.ma120,a.ma240) as hist_max
            ,c.v_ma5,c.v_ma20,c.v_ma60,c.v_ma90,c.v_ma120,c.v_ma240
            ,max(c.v_ma60,c.v_ma90,c.v_ma120,c.v_ma240) as hist_max_volume

from raw_00_CURRENT_MA_d_data a,raw_data_d b,raw_02_CURRENT_MA_VOLUME_d_data c
where a.code = b.code and a.date = b.date and c.code = b.code and c.date = b.date ) order by date desc
     '''

    return jsonify(content)