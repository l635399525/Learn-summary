from project import app,jsonify,request
from project.offline.func import getStartEndFromRequest

@app.route('/crossPoints',methods=['POST','GET'])
def getCrossPoints():
    sql = "select"