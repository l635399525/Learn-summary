from project.offline import *
from project.offline.func import *
def test01(code):

    for k,v in analysis_conf_kpis.items():
        line = v
        line["code"] = code
        analysis_parameter = ["analysisMas", line]
        r = post(analysis_parameter)

        print(r.text)

if __name__ == '__main__':
    code = getHYGNCodes()[0]
    test01(code)