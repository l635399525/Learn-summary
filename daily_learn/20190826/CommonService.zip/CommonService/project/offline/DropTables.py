from project.com.Const import kpis,daily_folder,sysmbol,hygn_raw_folder,kpis_delete
import glob
from project.com.DbTool import drop,getConn
if __name__ == '__main__':
    files = glob.glob(daily_folder + sysmbol + "*.db")
    #files = glob.glob(hygn_raw_folder + sysmbol + "*.db")
    for file in files:
        conn = getConn(file)
        for kpi in kpis_delete:
           table = "raw_%s_d_data" %(kpi)
           drop(conn,table)
        #table = "raw_data_d_bs"
        #drop(conn, table)
        print(file)