sysmbol = "/"
import glob
home = "/Users/lili/data/prod/raw_data"
daily_folder = home + sysmbol + "codes_daily"
tmp_folder = "/Users/lili/data/prod/raw_data/tmp"
merge_db_file = tmp_folder + sysmbol + "merge_file.db"
src_merge_folder = tmp_folder + sysmbol + "tomergefiles"
code_file_path = daily_folder + sysmbol + "*.db"
code_files = glob.glob(code_file_path)
db_files = glob.glob(tmp_folder + sysmbol + "raw_*")
tables = {
    "RAWDATAD":"raw_data_d"
    ,"RAWDATAW":"raw_data_w"
    , "RAWDATAM": "raw_data_m"
    , "RAWDATADMIN15": "raw_data_m15"
}
port = 5000
dev_url = "http://127.0.0.1:%s/" %(port)
urls = {
    "getmergefiles":"%s%s" %(dev_url,"getmergefiles")
    ,"getCodeList":"%s%s" %(dev_url,"getCodeList")
    ,"getMaxDate":"%s%s" %(dev_url,"getMaxDate")
    ,"gethygnlst":"%s%s" %(dev_url,"gethygnlst")
    ,"getRawDataByDate":"%s%s" %(dev_url,"getRawDataByDate")
    ,"getMaDataByDate":"%s%s" %(dev_url,"getMaDataByDate")
    ,"getKpiDataByDate":"%s%s" %(dev_url,"getKpiDataByDate")
}
bs_config_file_name = "golden_hygn_bs.db"
golden_bs_config_file = home + sysmbol + "config/%s" %(bs_config_file_name)
all_config_file_name = "golden_hygn_all.db"
golden_all_config_file = home + sysmbol + "config/%s" %(all_config_file_name)
golden_hygn_config_file = home + sysmbol + "config/%s" %("hygn_config.db")
golden_hygn_config_table = "hygn_mapping_data"

CURRENT_MA = "0_CURRENT_MA"
PRE_MA = "1_PRE_MA"
CURRENT_MA_VOLUME = "2_CURRENT_MA_VOLUME"
CURRENT_SUM_PCT = "3_CURRENT_SUM_PCT"
CURRENT_AVG_PCT = "4_CURRENT_AVG_PCT"
CURRENT_AVG_HLMINUSRATE = "5_CURRENT_AVG_HLMINUSRATE"
CURRENT_AVG_OCMINUSRATE = "6_CURRENT_AVG_OCMINUSRATE"
CURRENT_AVG_HCMINUSRATE = "7_CURRENT_AVG_HCMINUSRATE"
CURRENT_AVG_LCMINUSRATE = "8_CURRENT_AVG_LCMINUSRATE"
CURRENT_SUM_OCMINUSRATE = "9_CURRENT_SUM_OCMINUSRATE"
CURRENT_DIF_HLMINUSRATE = "10_CURRENT_DIF_HLMINUSRATE"




#kpis = [CURRENT_MA,PRE_MA,CURRENT_MA_VOLUME,CURRENT_SUM_PCT,CURRENT_AVG_PCT]
kpis = [CURRENT_AVG_PCT,CURRENT_AVG_HLMINUSRATE,CURRENT_AVG_OCMINUSRATE,CURRENT_AVG_HCMINUSRATE,CURRENT_AVG_LCMINUSRATE,CURRENT_SUM_OCMINUSRATE,CURRENT_DIF_HLMINUSRATE]
kpis = [CURRENT_DIF_HLMINUSRATE]
append_current_ma = {"ma30":30,"ma60":60,"ma90":90,"ma120":120,"ma240":240}
append_pre_ma = {"ma4":4,"ma9":9,"ma19":19,"ma29":29,"ma60":59,"ma89":89,"ma119":119,"ma239":239}
append_ma_volume = {"v_ma30":30,"v_ma60":60,"v_ma90":90,"v_ma120":120,"v_ma240":240}
append_pct_sums = {"sum5":5,"sum10":10,"sum20":20,"sum60":60,"sum120":120,"sum_all":100000}
append_pct_avgs = {"avg5":5,"avg10":10,"avg20":20,"avg60":60,"avg120":120,"avg_all":100000}
append_avgs = {"avg5":5,"avg10":10,"avg20":20,"avg60":60,"avg120":120,"avg_all":100000}
append_sums = {"sum5":5,"sum10":10,"sum20":20,"sum60":60,"sum120":120,"sum_all":100000}

def get_append_ma(ma_type=CURRENT_MA):
    append_ma = append_pre_ma
    if ma_type.startswith(CURRENT_MA):
        append_ma = append_current_ma
    return append_ma
tables_ma = {
    "%s_D" %(CURRENT_MA):"raw_current_ma_d_data"
    ,"%s_D" %(PRE_MA):"raw_pre_ma_d_data"
}

tables_kpi = {
    "%s_D" % (CURRENT_MA): {
        "src_table": tables["RAWDATAD"]
        ,"dest_table":"raw_%s_d_data" %(CURRENT_MA)
        ,"function":"ma"
        ,"lst":append_current_ma
        ,"columns":"code,date,close,ma5,ma10,ma20"
        ,"key_column":"close"
    }
    ,"%s_D" % (PRE_MA): {
        "src_table": tables["RAWDATAD"],
        "dest_table":"raw_%s_d_data" %(PRE_MA)
        ,"function":"ma"
        ,"lst":append_pre_ma
        , "columns": "code,date,close"
        , "key_column": "close"

    }
    ,"%s_D" % (CURRENT_MA_VOLUME): {
        "src_table": tables["RAWDATAD"],
        "dest_table":"raw_%s_d_data" %(CURRENT_MA_VOLUME)
        ,"function":"ma"
        ,"lst":append_ma_volume
        ,"columns":"code,date,volume,v_ma5,v_ma10,v_ma20"
        , "key_column": "volume"

    }
    ,"%s_D" % (CURRENT_SUM_PCT): {
        "src_table": tables["RAWDATAD"],
        "dest_table":"raw_%s_d_data" %(CURRENT_SUM_PCT)
        ,"function":"sum"
        ,"lst":append_pct_sums
        , "columns": "code,date,p_change"
        , "key_column": "p_change"

    }
    , "%s_D" % (CURRENT_AVG_PCT): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_PCT)
        , "function": "ma"
        , "lst": append_pct_avgs
        , "columns": "code,date,p_change"
        , "key_column": "p_change"

    }
, "%s_D" % (CURRENT_AVG_HCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_HCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(high*100/(close - price_change) - closw*100/(close - price_change),4) as hc_minus_rate"
        , "key_column": "hc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_LCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_LCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(low*100/(close - price_change) - close*100/(close - price_change),4) as lc_minus_rate"
        , "key_column": "lc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_OCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_OCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(close*100/(close - price_change) - open*100/(close - price_change),4) as oc_minus_rate"
        , "key_column": "oc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_HLMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(high*100/(close - price_change) - low*100/(close - price_change),4) as hl_minus_rate"
        , "key_column": "hl_minus_rate"
    }
, "%s_D" % (CURRENT_DIF_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_HLMINUSRATE)
        , "function": "diff"
        , "lst": append_avgs
        , "columns":"code,date,high,low"
        , "key_column": "high,low"
    }
, "%s_D" % (CURRENT_SUM_OCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_SUM_OCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(close*100/(close - price_change) - open*100/(close - price_change),4) as oc_minus_rate"
        , "key_column": "oc_minus_rate"
    }

}