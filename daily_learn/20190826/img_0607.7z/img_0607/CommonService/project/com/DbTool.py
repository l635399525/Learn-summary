import pandas as pd
import sqlite3
import json
from project.com import *
def getConn(path):
    conn = sqlite3.connect(path)
    return conn

def query(sql,conn):
    df = pd.read_sql_query(sql,conn)
    return df

class MyConn:
    def getConn(self):
        split = getSysSplit()
        self.path = "%s%s%s%s%s%scodes%s%s" %(moveHome,split,self.home_path,split,self.type,split,split,self.db_name)

        if self.type == "rawdata":
            self.path = "%s%s%s%s%s%s%s" % (moveHome, split, self.home_path, split, self.type, split, self.db_name)
        #print(self.path)
        conn = getConn(self.path)
        return conn

def getConnFromConfDb(tableName,code):
    codeFull = code
    code = code.split(".")[-1]
    confDb = getConn(confDB)
    sql = "select * from %s where table_name = '%s' and code = '%s'" %(confTable,tableName,code)
    df = query(sql,confDb)
    try:
        myConn = MyConn()
        myConn.__dict__ = json.loads(df.iloc[0].to_json())
        if codeFull == "sh.000001":
            myConn.db_name = codeFull + ".db"
        elif codeFull == "sz.000001":
            myConn.db_name = codeFull + ".db"

        conn = myConn.getConn()
    except:
        pass
    return conn

def insert(df,conn,tableName,opType = "replace"):
    pd.io.sql.to_sql(df, tableName, conn, if_exists=opType)

def buildIndex(conn,sql):
    try:
        c = conn.cursor()
        c.execute(sql)
    except:
        pass

def update(conn,sql,values):
    try:
        c = conn.cursor()
        c.execute(sql,values)
    except Exception as e:
        print(str(e))

def drop(conn, table):
    try:
        c = conn.cursor()
        sql = "drop table %s;" %(table)
        c.execute(sql)
        conn.commit()
        print("droped %s" %(table))
    except Exception as e:
        print(str(e))

def getFullCode(code):
    if str(code).startswith("6"):
        code = "sh." + code
    elif str(code).startswith("0"):
        code = "sz." + code
    return code
def getRawCodes(path="%sgupiao%srawdata%s*.db" %(moveHome,split,split)):
    import glob
    files = glob.glob(path)
    codes = list(map(lambda x:str(x.split("\\")[-1]).replace(".db",""),files))
    return codes
def getSBCodes(path="%sgupiaosummary%ssb%scodes%s*.db" %(moveHome,split,split,split)):
    import glob
    files = glob.glob(path)
    codes = list(map(lambda x:str(x.split(split)[-1]).replace(".db",""),files))
    return codes
def getConnByCodePath(code,path = None):
    if path is None:
        return None
    code = getFullCode(code)
    db_file = path + split + code + ".db"
    conn = getConn(db_file)
    return conn