def _ma(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).mean().sort_index(ascending=False).round(decimals=3)
    return res

def _sum(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).sum().sort_index(ascending=False).round(decimals=3)
    return res
def _dif(series1,series2):
    import numpy as np
    s1 = np.asarray(series1)[:-1]
    s2 = np.asarray(series2)[1:]
    return np.round((s1 - s2)*100/s2,3)