from project.com.DbTool import *
from project.com.Const import *
def getMaxDate(tables,code):
    db = getConnByCode(code)
    date_map = {}
    for table in tables:
        sql = "select code,max(date) as maxdate from %s where code = '%s'" %(table,code)
        try:
            df = query(sql, db)
            date = df["maxdate"].tolist()[0]
        except:
            date = None
        date_map[table] = date
    return {code:date_map}
code_conn_pool = {}
def getConnByCode(code):
    code_file = daily_folder + getSysSplit() + code + ".db"
    import os
    if not os.path.exists(code_file):
        return None
    try:
        conn = code_conn_pool[code]
    except:
        conn = getConn(code_file)
        code_conn_pool[code] = conn
    return conn

def getRawDataByCode(content,table,code,colums="*"):
    try:
        end_date = content["end_date"]
    except:
        end_date = "2030-01-01"
    try:
        start_date = content["start_date"]
        sql = "select %s from %s where date(date) > date('%s') and date(date) <= date('%s') order by date desc" %(colums,table,start_date,end_date)
    except:
        sql = "select %s from %s where date(date) <= date('%s') order by date desc" %(colums,table,end_date)
    from project.models.GetFileFuncs import getConnByCode
    conn = getConnByCode(code)
    df = query(sql,conn)
    return df

