__version__ = '0.1'

from flask import Flask,jsonify,request
app = Flask('project')
app.config['SECRET_KEY'] ='random'
import project.controllers
from project.com.Const import *