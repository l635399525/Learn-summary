from project import app,jsonify,request
from project.com.Const import *
from project.com.DbTool import query
@app.route('/getmergefiles',methods=['POST','GET'])
def getmergefiles():
    #print(src_merge_folder)
    #content = request.json
    src_merge_files = glob.glob(src_merge_folder + sysmbol + "raw_*")
    #print(data)
    return jsonify(src_merge_files)

@app.route('/getCodeList',methods=['POST','GET'])
def getCodeList():
    #print(src_merge_folder)
    #content = request.json
    src_merge_files = glob.glob(src_merge_folder + sysmbol + "raw_*")
    codes = list(map(lambda x:[x.split(sysmbol)[-1].replace(".db",""),x],code_files))
    #print(data)
    return jsonify(codes)

@app.route('/getMaxDate',methods=['POST','GET'])
def getMaxDate():
    content = request.json
    code = content["code"]
    tables = content["tables"]
    from project.models.GetFileFuncs import getMaxDate
    res = getMaxDate(tables,code)
    return jsonify(res)

@app.route('/gethygnlst',methods=['POST','GET'])
def getHYGNList():
    import json
    from project.com.DbTool import getConn,query
    sql = '''
    select  a.code,a.pcode,a.type,b.cn_pcode from money_normal_detail_gn_hy_data_final a
    left outer join
    money_normal_gn_hy_data_final_daily b
on a.pcode = b.code
    '''
    print(golden_all_config_file)
    conn = getConn(golden_all_config_file)

    df = query(sql,conn)
    lines = json.loads(df.to_json(orient='records'))
    print(lines)
    return jsonify(lines)

@app.route('/getRawDataByDate',methods=['POST','GET'])
def getRawDataByDate():
    content = request.json
    code = content["code"]
    try:
        table = content["table"]
    except:
        table = tables["RAWDATAD"]
    from project.models.GetFileFuncs import getRawDataByCode
    df = getRawDataByCode(content,table,code)
    import json
    lines = json.loads(df.to_json(orient='records'))
    return jsonify(lines)

@app.route('/getMaDataByDate',methods=['POST','GET'])
def getMaDataByDate():
    content = request.json
    code = content["code"]
    try:
        table = content["table"]
    except:
        table = tables["RAWDATAD"]
    try:
        ma_type = content["ma_type"]
    except:
        ma_type = CURRENT_MA
    try:
        ma_key = content["ma_key"]
    except:
        ma_key = "close"
    from project.com.funcs import _ma
    mas = content["mas"]
    if ma_type == CURRENT_MA:
        columns = "code,date,close,ma5,ma10,ma20"
    elif ma_type == PRE_MA:
        columns = "code,date,close"

    from project.models.GetFileFuncs import getRawDataByCode
    df = getRawDataByCode(content,table,code,colums=columns)
    for k,v in mas.items():
        df[k] = _ma(df[ma_key],v)
    import json
    lines = json.loads(df.to_json(orient='records'))
    return jsonify(lines)

@app.route('/getKpiDataByDate',methods=['POST','GET'])
def getKpiDataByDate():
    content = request.json
    code = content["code"]

    from project.models.GetFileFuncs import getMaxDate

    src_table = content["src_table"]
    dest_table = content["dest_table"]
    function = content["function"]
    lst = content["lst"]
    columns = content["columns"]
    key_column = content["key_column"]
    res = getMaxDate([dest_table], code)
    max_date = res[code][dest_table]
    if max_date is not None:
        content["start_date"] = max_date
    from project.com.funcs import _ma,_sum,_dif
    from project.models.GetFileFuncs import getRawDataByCode
    df = getRawDataByCode(content,src_table,code,colums=columns)
    if function == "diff":
        key1, key2 = key_column.split(",")
        diffs = _dif(df[key1], df[key2])
        ndf = df[:-1]
        ndf["diff"] = diffs.tolist()
        key_column = "diff"
        df = ndf
    for k,v in lst.items():
        if function == "ma":
            df[k] = _ma(df[key_column],v)
        elif function == "sum":
            df[k] = _sum(df[key_column],v)
        else:
            df[k] = _ma(df[key_column],v)
            df = ndf

    import json
    lines = json.loads(df.to_json(orient='records'))
    return jsonify(lines)


# def getRawDataByDate():
#     content = request.json
#     code = content["code"]
#     try:
#         table = content["table"]
#     except:
#         table = tables["RAWDATAD"]
#
#     try:
#         start_date = content["date"]
#         sql = "select * from %s where date(date) > date('%s')" %(table,start_date)
#     except:
#         sql = "select * from %s" %(table)
#     from project.models.GetFileFuncs import getConnByCode
#     conn = getConnByCode(code)
#     df = query(sql,conn)
#     import json
#     lines = json.loads(df.to_json(orient='records'))
#     return jsonify(lines)

