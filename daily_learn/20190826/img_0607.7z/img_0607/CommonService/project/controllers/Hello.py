from project import app

@app.route('/')
def hello_world():
    return 'Hello World!'
