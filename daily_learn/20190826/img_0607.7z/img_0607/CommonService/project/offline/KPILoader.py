from project.com.Post_tool import *
from project.com.Const import tables,merge_db_file,tables_ma,kpis,tables_kpi,CURRENT_AVG_PCT
from project.com.DbTool import *
def getCodes():
    code_lst_parameter = ["getCodeList", None]
    r = post(code_lst_parameter).json()
    return r
def drop():
    from project.models.GetFileFuncs import getConnByCode
    from project.com.DbTool import drop
    codes = getCodes()
    num = 0
    for code in codes:

        code = code[0]
        conn = getConnByCode(code)
        table = tables_kpi[CURRENT_AVG_PCT+"_D"]["dest_table"]
        drop(conn,table)
        num = num + 1
        print("%s %s %s/%s" % (code,table, num, len(codes)))
def run():
    from project.models.GetFileFuncs import getConnByCode
    codes = getCodes()
    num = 0
    for code in codes:
        code = code[0]
        conn = getConnByCode(code)
        for kpi in kpis:
            try:
                line = tables_kpi[kpi + "_D"].copy()
                line["code"] = code
                p = ["getKpiDataByDate", line]
                r = post(p).json()
                df = pd.DataFrame(r)
                dest_table = line["dest_table"]
                insert(df,conn,dest_table,opType="append")
            except:
                import traceback
                traceback.print_exc()
        num = num + 1
        print("%s %s %s/%s" %(code,len(df),num,len(codes)))
if __name__ == '__main__':
    run()