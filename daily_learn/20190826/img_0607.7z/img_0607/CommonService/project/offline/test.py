from project.com.Post_tool import *
from project.com.Const import tables,merge_db_file,tables_ma,kpis,tables_kpi
from project.com.DbTool import *
def merge():
    merge_parameter = ["getmergefiles", None]
    r = post(merge_parameter).json()
    for line in r:
        file = line
        for k,v in tables.items():
           appendMergeData(v,file)
def appendDailyDatasFromMergeTables():
    code_lst_parameter = ["getCodeList", None]
    r = post(code_lst_parameter).json()
    num = 0
    for line in r:
        code,file = line
        code_maxdate_parameter = ["getMaxDate",{"code":code,"file":file,"tables":list(tables.values())}]
        r = post(code_maxdate_parameter).json()
        appendDailyDataFromMergeTable(code,file,r)
        num = num + 1
        print("%s %s" %(num,len(r)))
def appendDailyDataFromMergeTable(code,file,line):
    dest_conn = getConn(file)
    src_conn = getConn(merge_db_file)
    data = line[code]
    for table,date in data.items():
        try:
            sql_head = "select  date, code, symbol, code_name, open, high, close, low, volume, price_change, p_change, ma5, ma10, ma20, v_ma5, v_ma10, v_ma20  from %s where code = '%s'" %(table,code)
            sql = sql_head
            if date is not None:
                sql = "%s and date(date) > date('%s')" %(sql_head,date)
            sql = sql + " group by code,date"
            df = query(sql,src_conn)
            insert(df,dest_conn,table,opType="append")
            print("%s %s %s" %(code,table,len(df)))
        except:
            import traceback
            traceback.print_exc()
            pass

def appendMergeData(table,file):
    try:
        sql = "select * from %s" %(table)
        conn = getConn(file)
        df = query(sql,conn)
        merge_db = getConn(merge_db_file)
        insert(df,merge_db,table,opType="append")
        print("%s  %s %s" %(table,file,len(df)))
    except:
        pass

def updateHYGNConfigTable():
    hygn_parameter = ["gethygnlst", None]
    r = post(hygn_parameter).json()
    import pandas as pd
    from project.com.Const import golden_hygn_config_file,golden_hygn_config_table
    df = pd.DataFrame(r)
    dest_conn = getConn(golden_hygn_config_file)
    insert(df,dest_conn,golden_hygn_config_table,opType="replace")
    print("Done")
    '''
    update hygn_mapping_data set cn_pcode = '航天航空' where pcode = 'BK0480'
    update hygn_mapping_data set cn_pcode = '生物医药' where pcode = 'BK0427'
    update hygn_mapping_data set cn_pcode = '玻璃陶瓷' where pcode = 'BK0546'
    update hygn_mapping_data set cn_pcode = '装修装饰' where pcode = 'BK0725'
    update hygn_mapping_data set cn_pcode = '食品饮料' where pcode = 'BK0438'
    update hygn_mapping_data set cn_pcode = '石油行业' where pcode = 'BK0464'
    update hygn_mapping_data set cn_pcode = '有色金属' where pcode = 'BK0478'
    update hygn_mapping_data set cn_pcode = '电信运营' where pcode = 'BK0736'
    update hygn_mapping_data set cn_pcode = '保险' where pcode = 'BK0474'
    update hygn_mapping_data set cn_pcode = '机械行业' where pcode = 'BK0545'
    update hygn_mapping_data set cn_pcode = '农牧饲渔(' where pcode = 'BK0433'
    '''
def getCodes():
    code_lst_parameter = ["getCodeList", None]
    r = post(code_lst_parameter).json()
    return r
def getMaxDate():
    codes = getCodes()[:10]
    table_lst = list(tables_ma.values())
    for code in codes:
        code = code[0]
        p = ["getMaxDate",{"code":code,"tables":table_lst}]
        r = post(p).json()
        print(r)
    return codes
def getRawData():
    codes = getCodes()[:2]
    for code in codes:
        code = code[0]
        p = ["getRawDataByDate", {"code": code,"start_date":"2020-04-21","end_date":"2020-05-01"}]
        p = ["getRawDataByDate", {"code": code}]

        r = post(p).json()
        print(r)
def getMaData():
    from project.com.Const import PRE_MA,CURRENT_MA,get_append_ma
    codes = getCodes()[:2]
    for code in codes:
        code = code[0]
        ma_type = CURRENT_MA
        mas = get_append_ma(ma_type)
        p = ["getMaDataByDate", {"code": code, "mas": mas, "ma_type":ma_type}]
        r = post(p).json()
        print(r)
def getKpis():
    codes = getCodes()[:2]
    for code in codes:
        code = code[0]
        for kpi in kpis:
            line = tables_kpi[kpi + "_D"].copy()
            line["code"] = code
            p = ["getKpiDataByDate", line]
            r = post(p).json()
            df = pd.DataFrame(r)


if __name__ == '__main__':
    #merge()
    #appendDailyDatasFromMergeTables()
    #updateHYGNConfigTable()
    getKpis()