from project.offline.KPILoader import *
from project.com.Const_raw import *
from project.models.GetFileFuncs import getConnByCode


def getRunTables():
    table_infos = []
    for k,v in tables_summary_raw.items():
        if v["ktype"] in summary_raw_kpis:
            table_infos.append(v)
    table_infos.sort(key=lambda x: x["ktype"])
    return table_infos
def runSummary():
    codes = getCodes()
    tis = getRunTables()

    for code in codes:

        #print(code)
        code = code[0]
        if not "600536" in code:
            continue
        continue_flag = True

        if str(code).startswith("00") or str(code).startswith("60"):
            continue_flag = False
        if continue_flag:
            continue
        conn = getConnByCode(code)
        for table_info in tis:
            try:
                #print(table_info)
                line = table_info.copy()
                line["code"] = code
                p = ["getSummaryKpiRaws", line]
                r = post(p,"bykey").json()
                if r is not None:
                    df = pd.DataFrame(r)
                    dest_table = line["dest_table"]
                    insert(df, conn, dest_table, opType="append")
                    print("%s %s %s" % (code, table_info["ktype"], len(df)))
            except:
                import traceback
                traceback.print_exc()

if __name__ == '__main__':
    runSummary()