from project.offline import *
def getCodes():
    code_lst_parameter = ["getCodeList", None]
    r = post(code_lst_parameter).json()
    return r
def getHYGNCodes():
    code_lst_parameter = ["getHYGNCodes", None]
    r = post(code_lst_parameter).json()
    return r

def getStartEndFromRequest(content):
    try:
        start = content["start"]
    except:
        start = "2000-01-01"
    try:
        end = content["end"]
    except:
        end = "2030-12-31"
    return start,end
