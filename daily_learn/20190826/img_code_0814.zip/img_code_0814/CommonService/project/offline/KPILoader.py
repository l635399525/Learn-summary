from project.offline import *
def getCodes():
    code_lst_parameter = ["getCodeList", None]
    r = post(code_lst_parameter).json()
    return r
def drop():
    from project.models.GetFileFuncs import getConnByCode
    from project.com.DbTool import drop
    codes = getCodes()
    num = 0
    ks = kpis_b
    for code in codes:

        code = code[0]
        conn = getConnByCode(code)
        for k in ks:
            table = tables_kpi[k+"_D"]["dest_table"]
            drop(conn,table)
        num = num + 1
        print("%s %s %s/%s" % (code,table, num, len(codes)))
def run(angle=False,cross=False):
    from project.models.GetFileFuncs import getConnByCode
    from project.models.DeepAnalysisFuncs import getCrossPoints,getAngle
    codes = getCodes()
    num = 0
    for code in codes:
        code = code[0]
        #if not "002409" in code:
        #    continue
        if not code.startswith("30") and not code.startswith("00") and not code.startswith("60"):
            print(code + " continue")
            continue
        conn = getConnByCode(code)
        for kpi in kpis:
            #continue
            try:
                line = tables_kpi[kpi + "_D"].copy()
                line["code"] = code
                p = ["getKpiDataByDate", line]
                r = post(p).json()
                if r is not None:
                    df = pd.DataFrame(r)
                    dest_table = line["dest_table"]
                    insert(df,conn,dest_table,opType="append")
                    print("%s %s %s" % (code,kpi ,len(df)))
            except:
                import traceback
                traceback.print_exc()
        try:
            if cross:
                getCrossPoints(code)
            #print(code)
        except:
            import traceback
            traceback.print_exc()
        try:
            if angle:
                getAngle(code)
        except:
            import traceback
            traceback.print_exc()
        num = num + 1
        print("%s %s/%s" %(code,num,len(codes)))
def getHYGNCodes():
    code_lst_parameter = ["getHYGNCodes", None]
    r = post(code_lst_parameter).json()
    return r
def run_hygn():
    from project.models.HYGNFuncs import getConnByHYGNCode
    codes = getHYGNCodes()
    num = 0
    for code in codes:
        num = num + 1
        conn = getConnByHYGNCode(code)
        for kpi in kpis:
            try:
                if kpi == CURRENT_AVG_MA_DISTANCE or kpi == CURRENT_MA_NEW or kpi == CURRENT_COUNT_XINHAOXINDI or kpi == CURRENT_MA_100 or kpi == CURRENT_AVG_HL :
                    continue
                line = tables_conf_kpi[kpi + "_D"].copy()
                line["code"] = code
                p = ["getKpiDataByDate", line]
                r = post(p).json()
                if r is not None:
                    df = pd.DataFrame(r)
                    dest_table = line["dest_table"]
                    insert(df,conn,dest_table,opType="append")
                    print("%s %s %s" % (code,kpi ,len(df)))
            except:
                import traceback
                traceback.print_exc()
        print("%s %s/%s" %(code,num,len(codes)))
def runDeep():
    from project.models.GetFileFuncs import getConnByCode
    codes = getCodes()
    num = 0
    for code in codes:
        code = code[0]
        # if not "601827" in code:
        #     continue
        if not code.startswith("30") and not code.startswith("00") and not code.startswith("60"):
            print(code + " continue")
            continue
        conn = getConnByCode(code)
        for kpi in kpis_e:
            try:
                line = tables_kpi[kpi + "_D"].copy()
                line["code"] = code
                p = ["getKpiDataByDate", line]
                r = post(p).json()
                if r is not None:
                    df = pd.DataFrame(r)
                    dest_table = line["dest_table"]
                    insert(df,conn,dest_table,opType="append")
                    print("%s %s %s" % (code,kpi ,len(df)))
            except:
                import traceback
                traceback.print_exc()
        num = num + 1
        print("%s %s/%s" %(code,num,len(codes)))
if __name__ == '__main__':
    #run_hygn()
    print("-------------Done01")
    run()
    print("-------------Done02")
    #runDeep()
    print("-------------Done03")

    #drop()