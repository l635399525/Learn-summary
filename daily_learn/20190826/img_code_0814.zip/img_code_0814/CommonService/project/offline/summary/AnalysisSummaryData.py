from project.models.SummaryFuncs import *
from project.com.DbTool import *
def analysisCandleShape():
    dest_file = "raw_db_20200727"
    dest_file = home + sysmbol + dest_file
    dest_table = "summary_cshape_data"
    conn = getConn(dest_file)
    sql = "select * from raw_data_d_bs order by code,date desc"
    df = query(sql,conn)
    ndf = calCandleShape(df)
    insert(ndf,conn,dest_table,opType="append")
    print(len(ndf))
if __name__ == '__main__':
    analysisCandleShape()