from project.com.DbTool import *
from project.models.GetFileFuncs import getConnByCode
from project.com.Const import sysmbol,code_files
from project.com.Const_raw import *
from project.com.Const_merge import *
import numpy as np
def getCodes():
    codes = list(map(lambda x:[x.split(sysmbol)[-1].replace(".db",""),x],code_files))
    return codes
def getCandle_Shape_maps(shape_nums,size=5,key_col = "shape_grp",optype= "join"):
    lines = []
    for i in range(len(shape_nums) - size + 1):
        start = i
        end = i + size
        lst = []
        for j in range(size):
            lst.append(shape_nums[start:end-j])
        lines.append(lst)
    out_count = len(lines)
    out = {}
    for lst in lines:

        for line in lst:
            count = len(line)
            key = "%s_%s" %(key_col,count)
            try:
                tlst = out[key]
            except:
                tlst = []
            if optype == "sum":
                line_str = round(np.sum(line),3)
            else:
                line_str =  ",".join(list(line.astype(str)))
            tlst.append(line_str)
            out[key] = tlst
    #out = list(map(lambda x:",".join(list(x.astype(str))),lines))
    return out,out_count


import numpy as np
def getCandle_Shape_maps_reverse(shape_nums,size=5,key_col = "shape_grp",optype= "join"):
    lines = []
    shape_nums = shape_nums[::-1]
    for i in range(len(shape_nums) - size + 1):
        start = i
        end = i + size
        lst = []
        for j in range(size):
            lst.append(shape_nums[start:end-j])
        lines.append(lst)
    out_count = len(lines)
    out = {}
    a = []
    zeros = np.zeros(size)
    for j in range(1,size):
        tline=[]
        for m in range(size):
            tline.append(zeros[0:(size-m)])
            #tline = [np.asarray([0])] * (size)
        #tline = np.asarray(tline)
        lst = shape_nums[-1*j:]
        for k in range(len(lst)):
            tline[-1*(k+1)] = lst[-1*(k+1):]
        #tline[j-1] = lst
        a.append(tline)
    b = lines[size-1:]
    b.reverse()

    a.extend(b)
    #sum_lst = np.asarray(a)
    #reversed(a)
    lines = a
    num = 0

    for lst in lines:
        num = num + 1

        for line in lst:
            #print(line)
            # try:
            #     count = len(line)
            # except:
            #     line = [line]
            count = len(line)
                #print(line)
            key = "%s_%s" %(key_col,count)
            try:
                tlst = out[key]
            except:
                tlst = []
            if optype == "sum":
                line_str = round(np.sum(line),3)
            else:
                line_str =  ",".join(list(line.astype(str)))
            tlst.append(line_str)
            #print("%s %s" %(num,len(tlst)))
            out[key] = tlst
    #out = list(map(lambda x:",".join(list(x.astype(str))),lines))
    return out,out_count

def mergeCandle_shape(code):
    conn = getConnByCode(code)
    sql = "select max(date) as mdate from %s " % (table_merge_summary[CANDLE_SHAPE_SUMMARY])
    start = "2000-01-01"
    # try:
    #     df = query(sql, conn)
    #     start = df["mdate"][0]
    # except:
    #     pass
    sql = "select code,date,close,round(p_change,3) as p_change,shape_num,candle_pct_type || '#' ||candle_shape_type || '#' || candle_line_type as shape_type from %s where date(date) > date('%s') order by date" % (table_maps[CURRENT_CANDLE_SHAPE], start)
    sql = '''
    select a.code,a.date,a.close,a.high,a.low,a.open,h.volume,h.volume_ma5,h.volume_ma89,
       g.close_ma5,g.close_ma10,g.close_ma20,g.close_ma60,g.close_ma120,g.close_ma240,
       round(a.p_change,3) as p_change,
       a.shape_num,a.candle_pct_type || '#' ||a.candle_shape_type || '#' || a.candle_line_type as shape_type
       ,b.sum as ma100_score,c.sort_ma,c.score as madist_score
       ,d.kdj_k,d.kdj_d,d.kdj_j,d.m_diff,d.m_dea,d.m_macd
       ,e.YANG_13,e.YANG_21,round(e.rsi_13,3) as rsi13,round(e.rsi_21,3) as rsi21
     ,round(e.wr_13,3) as wr13,round(e.wr_21,3) as wr21
    ,f.max_close_mm55,f.min_close_mm55,f.max_high_mm55,f.min_low_mm55
from
    raw_08_CANDLE_SHAPE_d_data a
    ,raw_09_MA100_DEEP_d_data b
    ,raw_10_MADISTANCE_DEEP_d_data c
    ,raw_07_MACD_KDJ_d_data d
    ,raw_11_CURRENT_RSI_WR_d_data e
    ,raw_06_MIN_MAX_d_data f
    ,raw_00_CURRENT_MA_NORMAL_d_data g
    ,raw_03_CURRENT_VOLUME_MA_d_data h
where date(a.date) > date('2000-01-01')
    and a.code = b.code
    and a.date = b.date
    and a.code = c.code
    and a.date = c.date
    and b.type = 'close'
    and c.type = 'close'
    and a.code = d.code
    and a.date = d.date
    and a.code = e.code
    and a.date = e.date
    and a.code = f.code
    and a.date = f.date
    and a.code = g.code
    and a.date = g.date
    and a.code = h.code
    and a.date = h.date
order by a.date


    '''
    #print(sql)
    df = query(sql, conn)
    shape_nums = df.shape_num.values
    pct_lst = df.p_change.values
    pct_lst_pre = df.p_change.values
    shape_groups,shape_count_count = getCandle_Shape_maps(shape_nums)
    shape_pre_groups,shape_pre_count = getCandle_Shape_maps_reverse(shape_nums,key_col="shape_pre_grp")

    pct_groups,pct_count = getCandle_Shape_maps(pct_lst,key_col="pct_grp",optype="sum")
    pct_pre_groups,pct_count = getCandle_Shape_maps_reverse(pct_lst_pre,key_col="pct_pre_grp",optype="sum")

    ndf = df[0:shape_count_count].copy()

    for k,v in shape_groups.items():
        ndf[k] = v
    for k,v in shape_pre_groups.items():
        ndf[k] = v
    for k,v in pct_groups.items():
        ndf[k] = v
    for k,v in pct_pre_groups.items():
        ndf[k] = v
    if len(ndf) > 0:
        # if len(ndf) > 350:
        #     ndf = ndf[len(ndf)-200:]
        insert(ndf, dest_conn, table_merge_summary[CANDLE_SHAPE_SUMMARY], opType="append")
    print("%s %s" %(code,len(ndf)))

if __name__ == '__main__':
    codes = getCodes()
    #dest_conn = getConn(dest_file)

    dest_file1 = home + sysmbol + "summary_merge_00.db"
    dest_file2 = home + sysmbol + "summary_merge_01.db"
    dest_file3 = home + sysmbol + "summary_merge_02.db"
    dest_file4 = home + sysmbol + "summary_merge_03.db"
    dest_file5 = home + sysmbol + "summary_merge_04.db"
    dest_files  = [dest_file1,dest_file2,dest_file3,dest_file4,dest_file5]
    sum = 0
    file_num = 0
    dest_file = home + sysmbol + "summary_merge_0%s" % (file_num)
    dest_conn = getConn(dest_file)
    codes = ["600536.SH"]
    for line in codes:

        code = line[0]
        if str(code).startswith("688") or str(code).startswith("30"):
            continue
        try:
            sum = sum + 1
            mergeCandle_shape(code)
            print(sum)
        except:
            print(code)
            import traceback
            traceback.print_exc()
            #pass
        if sum%50000 == 0:
            file_num = file_num + 1
            print("%s %s" %(file_num,code))
            dest_file = home + sysmbol + "summary_merge_00%s" % (file_num)
            dest_conn = getConn(dest_file)