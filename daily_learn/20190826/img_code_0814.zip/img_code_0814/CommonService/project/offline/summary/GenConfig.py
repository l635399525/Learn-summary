from project.com.DbTool import *
from project.com.Const_raw import all_map_types
import pandas as pd
from project.com.Const import *
import numpy as np
if __name__ == '__main__':
    dest_file = home + sysmbol + "summary_merge_0%s" % (0)
    conn = getConn(dest_file)
    json_line = {}
    #for k,v in all_map_types.items():
    json_line["shape_num"] = list(all_map_types.values())
    keys = list(all_map_types.keys())
    key_args = np.asarray(list(map(lambda x:x.split("#"),keys)))
    json_line["bts"] = key_args[:,0]
    json_line["kts"] = key_args[:,1]
    json_line["lts"] = key_args[:,2]
    json_line["shape_val"] = list(all_map_types.keys())
    df = pd.DataFrame(json_line)
    insert(df,conn,"code_maps_data",opType="replace")