from project.com.DbTool import *
from project.com.Const import *
def getMaxDate(tables,code,date_key="date",conditions = None):
    db = getConnByCode(code)
    date_map = {}
    for table in tables:
        sql = "select code,max(%s) as maxdate from %s where code = '%s'" %(date_key,table,code)
        if conditions is not None:
            sql = "select code,max(%s) as maxdate from %s where code = '%s' %s" % (date_key, table, code,conditions)

        try:
            df = query(sql, db)
            date = df["maxdate"].tolist()[0]
        except:
            import traceback
            traceback.print_exc()
            date = None
        date_map[table] = date
    return {code:date_map}
code_conn_pool = {}
def getConnByCode(code):
    if (str(code).startswith("BK")):
        from project.models.HYGNFuncs import getConnByHYGNCode
        return getConnByHYGNCode(code)
    code_file = daily_folder + getSysSplit() + code + ".db"
    import os
    if not os.path.exists(code_file):
        return None
    try:
        conn = code_conn_pool[code]
    except:
        conn = getConn(code_file)
        code_conn_pool[code] = conn
    return conn
def getRawDataWithMa(content,table,code):
    colums = "a.code,a.date,a.close,a.open,a.high,a.low,b.ma5,b.ma10,b.ma20,b.ma60,b.ma120,b.ma240"

    try:
        end_date = content["end_date"]
    except:
        end_date = "2030-01-01"
    try:
        start_date = content["start_date"]
        sql = "select * from (" \
              "select %s from %s a,raw_00_CURRENT_MA_d_data b where a.code = b.code and a.date = b.date) " \
              "c where date(date) > date('%s') and date(date) <= date('%s') order by date asc" % (colums, table,start_date,end_date)

    except:
        sql = "select * from (" \
              "select %s from %s a,raw_00_CURRENT_MA_d_data b where a.code = b.code and a.date = b.date) " \
              "c where date(date) <= date('%s') order by date asc" % (
              colums, table, end_date)
    from project.models.GetFileFuncs import getConnByCode
    if str(code).startswith("BK"):
        from project.models.HYGNFuncs import getConnByHYGNCode
        conn = getConnByHYGNCode(code)
    else:
        conn = getConnByCode(code)
    df = query(sql, conn)
    return df


def getRawDataByCode(content,table,code,colums="*",conditions = None):
    try:
        end_date = content["end_date"]
    except:
        end_date = "2030-01-01"
    try:
        start_date = content["start_date"]
        sql = "select %s from %s where date(date) > date('%s') and date(date) <= date('%s') order by date desc" %(colums,table,start_date,end_date)
        if conditions is not None:
            sql = "select %s from %s where date(date) > date('%s') and date(date) <= date('%s') %s order by date desc" % (
            colums, table, start_date, end_date,conditions)

    except:
        sql = "select %s from %s where date(date) <= date('%s') order by date desc" %(colums,table,end_date)
        if conditions is not None:
            sql = "select %s from %s where date(date) <= date('%s') %s order by date desc" % (colums, table, end_date,conditions)

    from project.models.GetFileFuncs import getConnByCode
    if str(code).startswith("BK"):
        from project.models.HYGNFuncs import getConnByHYGNCode
        conn = getConnByHYGNCode(code)
    else:
        conn = getConnByCode(code)
    df = query(sql,conn)
    return df
