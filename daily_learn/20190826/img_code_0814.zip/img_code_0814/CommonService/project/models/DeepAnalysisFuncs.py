from project.com.Const import CURRENT_MA,CURRENT_MA_NEW,tables,CURRENT_CROSSINCEPTION,CURRENT_MAANGLE
from project.com.funcs import getPermutationNoRepeating
from project.models.GetFileFuncs import getRawDataByCode
from project.com.DbTool import query,insert
from collections import OrderedDict

crossinception_golden_json = {
    'code':[]
    ,'cross_date':[]
    , 'q_line': []
    , 's_line': []
    , 'cross_diff': []
    , 'cross_value': []
}
def crossInception(a,b):
    from shapely.geometry import LineString
    a = LineString(a)
    b = LineString(b)
    x = a.intersection(b)
    return list(x)
def _getConnByCode(code):
    if str(code).startswith("BK"):
        from project.models.HYGNFuncs import getConnByHYGNCode
        conn = getConnByHYGNCode(code)
    else:
        from project.models.GetFileFuncs import getConnByCode
        conn = getConnByCode(code)
        return conn

def getAngle(code):
    import numpy as np
    import math

    conn = _getConnByCode(code)
    dest_table = "raw_%s_d_data" %(CURRENT_MAANGLE)


    from project.models.GetFileFuncs import getMaxDate

    res = getMaxDate([dest_table], code)
    max_date = res[code][dest_table]
    print("%s %s" % (dest_table, max_date))

    sql = '''
    select
       code,date,
       close,close_5_min close_10_min,close_20_min,close_60_min close_120_min,close_240_min,close_500000_min
       ,ma5,ma5_20_min,ma5_60_min,ma5_500000_min
       ,ma10,ma10_20_min,ma10_60_min,ma10_500000_min
       ,ma20,ma20_20_min,ma20_60_min,ma20_500000_min
        from raw_19_CURRENT_COUNT_XINHAOXINDI_d_data order by date desc
    '''
    #if max_date is not None:
    #    sql = sql + "where date(date) >= date('%s')" %(max_date)
    json_lines = {
        "ma5":  ["ma5_20_min","ma5_60_min","ma5_500000_min"]
        ,"ma10": ["ma10_20_min", "ma10_60_min", "ma10_500000_min"]
        ,"ma20": ["ma20_20_min", "ma20_60_min", "ma20_500000_min"]

    }

    df = query(sql,conn)
    if len(df) == 0:
        return
    df = df.copy()
    dates = df["date"]

    idexes = range(len(dates))
    date_indexes = OrderedDict(list(zip(idexes, dates)))
    indexed_date = OrderedDict(list(zip(dates,idexes)))
    for k,v in json_lines.items():
        mas = df[k].values
        ma_positions = list(map(lambda x: indexed_date[x], dates))

        for key in v:
            print(key)
            values = df[key]
            #value =  values.values
            date_value_json = {}
            for value in values:
                #print(value)
                date = df[df[k] == value]["date"].values[0]
                date_value_json[value] = date
            #end_points =
            diffs = np.round((df[k] - df[key])*100/df[key],3)
            min_positions = list(map(lambda x:indexed_date[date_value_json[x]],values))
            x_positions = np.round(np.abs(np.asarray(min_positions) - np.asarray(ma_positions)),3)
            angles = list(map(lambda x:round(math.degrees(math.atan2(x[0], x[1])),3),list(zip(diffs,x_positions))))
            #math.atan2(y2 - y1, x2 - x1);
            df["%s_y" %(key)] = diffs
            df["%s_x" % (key)] = x_positions
            df["%s_angles" % (key)] = angles
    insert(df[:240], conn, dest_table, opType="replace")
    print("%s %s" % (dest_table, len(df)))
def getCrossPoints(code):
    conn = _getConnByCode(code)
    import math
    import numpy as np
    ma1 = ["ma5","ma10","ma20","ma30","ma60","ma90","ma120","ma240"]
    ma2 = ["ma5","ma13","ma21","ma34","ma55","ma89","ma144","ma233"]
    tables_map = {"raw_%s_d_data" %(CURRENT_MA):ma1,"raw_%s_d_data" %(CURRENT_MA_NEW):ma2}
    dest_table = "raw_%s_d_data" %(CURRENT_CROSSINCEPTION)
    import pandas as pd
    from project.models.GetFileFuncs import getMaxDate

    res = getMaxDate([dest_table], code,date_key="cross_date")
    max_date = res[code][dest_table]
    print("%s %s" % (dest_table, max_date))

    for k,v in tables_map.items():
        sql = "select * from %s where code = '%s' order by date asc" % (k,code)
        df = query(sql, conn)
        cross_lst = getPermutationNoRepeating(v,2)
        rdf = pd.DataFrame()
        pd_json = {
    'code':[]
    ,'cross_date':[]
    , 'q_line': []
    , 's_line': []
    , 'q_value': []
    , 's_value': []
    , 'cross_diff': []
    , 'cross_value': []
}
        dates = df["date"]
        idexes = range(len(dates))
        date_indexes = OrderedDict(list(zip(idexes,dates)))
        for line in cross_lst:
            quick_key,slow_key = line
            quick_line,slow_line = df[quick_key].values,df[slow_key].values
            quick_list,slow_list = quick_line,slow_line
            diff_line = quick_line - slow_line
            quick_points = list(zip(idexes,quick_line))
            slow_points = list(zip(idexes,slow_line))
            diff_points = np.round(diff_line,3)
            res = crossInception(quick_points,slow_points)
            for line in res:
                if not line.type == "LineString":
                    x = math.ceil(line.x)
                    y = line.y
                else:
                    x = math.ceil(line.centroid.x)
                    y = line.centroid.y
                diff = diff_points[x]
                quick_point = quick_list[x]
                slow_point = slow_list[x]

                date = date_indexes[x]
                value = round(y,3)
                pd_json["code"].append(code)
                pd_json["cross_date"].append(date)
                pd_json["q_line"].append(quick_key)
                pd_json["s_line"].append(slow_key)
                pd_json["q_value"].append(quick_point)
                pd_json["s_value"].append(slow_point)

                pd_json["cross_diff"].append(diff)
                pd_json["cross_value"].append(value)
            #print(line)
        for k,v in pd_json.items():
            rdf[k] = v
    if max_date is not None:
        rdf = rdf[rdf["cross_date"] > max_date]
    insert(rdf,conn,dest_table,opType="append")
    print("%s %s" %(dest_table,len(rdf)))
if __name__ == '__main__':
    #getCrossPoints("000001.SZ")
    getAngle("000001.SZ")