from project.com.DbTool import *
from project.com.Const import *
def getHYCodes():
    conf_conn = getConn(conf_file)
    sql = "select * from %s where type = 'HY'" %(tables_conf["HYGNCONF"])
    df = query(sql,conf_conn)
    lines = list(df.values)
    return lines

def getGNCodes():

    conf_conn = getConn(conf_file)
    sql = "select * from %s where type = 'GN'" %(tables_conf["HYGNCONF"])
    df = query(sql,conf_conn)
    lines = list(df.values)
    return lines

def getHYGNCodes():
    lines = []
    h = getHYCodes()
    g = getGNCodes()
    lines.extend(h)
    lines.extend(g)
    return lines


def getHYGNBYCode(code):
    conf_conn = getConn(conf_file)
    sql = "select * from %s where f12 = '%s'" % (tables_conf["HYGNGEGUCONF"],code)
    df = query(sql, conf_conn)
    return df.values


def getConnByHYGNCode(hcode):
    conf_conn = getConn(conf_file)
    sql = "select * from %s where f12 = '%s'" % (tables_conf["HYGNCONF"], hcode)
    df = query(sql, conf_conn)
    line = df[["f12","TYPE"]].values[0]
    ".".join(line)
    path = hygn_raw_folder + sysmbol + ".".join(line) + ".db"
    conn = getConn(path)
    return conn


if __name__ == '__main__':
    lines = getHYGNBYCode("600584")
    conn = getConnByHYGNCode("BK0727")
    sql = "select * from %s" %(tables_hygn["HYGNRAWD"])
    df = query(sql,conn)
    print(df)
    print(lines)
    lines = getHYGNCodes()
    for line in lines[:1]:
        print(line)