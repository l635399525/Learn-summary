from project.com.funcs import _ma,_sum,_min,_max,macd,kdj
from project.com.Const_raw import *
from project.com.funcs import operator,getValByKey,calScoreByline,getDistanceByLineCount
def calMaDistance(df,lst,head):
    import json
    rdf = df.copy()
    lines = json.loads(df.to_json(orient='records'))
    nlines = []
    json_res = {}
    scores_lst = []
    sort_ma_lst = []
    dist3_lst = []
    dist3_desc_lst = []
    dist4_lst = []
    dist4_desc_lst = []
    dist5_lst = []
    dist5_desc_lst = []
    types = []
    for i in range(len(lst)):
        json_res["%s_idx" % (i)] = []

    for line in lines:
        # print(line)
        #l#ine = {}
        #line["code"] =
        types.append(head)
        data = []
        for k, v in lst.items():
            key = "%s_%s" %(head,k)
            data.append([line[k], k])
        data.sort(key=operator.itemgetter(0))
        for i in range(len(data)):
            # line["%s_idx" %(i)] = data[i][1]
            json_res["%s_idx" % (i)].append(data[i][1])
        t_lst = list(map(lambda x: getValByKey(x[1]), data))
        scores = 0
        sort_ma = "ma5,ma10,ma20,ma60,ma120,ma240"
        try:
            res = calScoreByline(t_lst)
            sort_ma = res["src"]
            scores = res["sum_scores"]
        except:
            pass
        scores_lst.append(scores)
        sort_ma_lst.append(sort_ma)
        line_3 = getDistanceByLineCount(data, 3)
        line_4 = getDistanceByLineCount(data, 4)
        line_5 = getDistanceByLineCount(data, 5)
        dist3_lst.append(line_3[0])
        dist3_desc_lst.append(line_3[1])
        dist4_lst.append(line_4[0])
        dist4_desc_lst.append(line_4[1])
        dist5_lst.append(line_5[0])
        dist5_desc_lst.append(line_5[1])
        nlines.append(line)
    json_res["score"] = scores_lst
    json_res["sort_ma"] = sort_ma_lst
    json_res["dist_3"] = dist3_lst
    json_res["dist_3_desc"] = dist3_desc_lst
    json_res["dist_4"] = dist4_lst
    json_res["dist_4_desc"] = dist4_desc_lst
    json_res["dist_5"] = dist5_lst
    json_res["dist_5_desc"] = dist5_desc_lst
    json_res["type"] = types
    #del json_res[head]
    for k, v in json_res.items():
        if k == head:
            continue
        rdf[k] = v
    return rdf
def calMa100(df,lst,head):
    next = df[:-1]
    pre = df[1:]
    rdf = next.copy()
    ks = []
    types = [head]*len(rdf)
    import pandas as pd
    rrdf = pd.DataFrame()
    rrdf["code"] = rdf["code"]
    rrdf["date"] = rdf["date"]
    rrdf["type"] = types

    for k, v in lst.items():
        key = "%s_%s" %(head,k)
        key = k
        lines = list(next[key].values - pre[key].values)
        scores = list(map(lambda x: v if x > 0 else 0, lines))
        rrdf[k] = rdf[key]
        rrdf["%s_scores" % (k)] = scores
        ks.append("%s_scores" % (k))
    rrdf["sum"] = rrdf[ks].sum(axis=1)
    return rrdf
def calMas(df,key_column,lst):
    key_cols = key_column.split(",")
    ndf = df.copy()
    for col in key_cols:
        for k,v in lst.items():
            colume_name = "%s_%s" %(col,k)
            ndf[colume_name] = _ma(ndf[col],v)
    return ndf
def calSums(df,key_column,lst):
    key_cols = key_column.split(",")
    ndf = df.copy()
    for col in key_cols:
        for k,v in lst.items():
            colume_name = "%s_%s" %(col,k)
            ndf[colume_name] = _sum(ndf[col],v)
    return ndf
def calPDays(df,key_column,lst):
    key_cols = key_column.split(",")
    ndf = df.copy()
    tlst = [None] * len(ndf)
    for col in key_cols:
        for k,v in lst.items():
            colume_name = "%s_%s" %(col,k)
            cval = tlst.copy()
            nlst = ndf[col].values[v-1:]
            cval[:len(nlst)] = nlst
            ndf[colume_name] = cval
    return ndf
def calMaxMins(df,key_column,lst):
    key_cols = key_column.split(",")
    ndf = df.copy()
    for col in key_cols:
        for k, v in lst.items():
            if col == "close":
                colume_name = "max_%s_%s" % (col, k)
                ndf[colume_name] = _max(ndf[col], v)
                colume_name = "min_%s_%s" % (col, k)
                ndf[colume_name] = _min(ndf[col], v)
            elif col == "low":
                colume_name = "min_%s_%s" % (col, k)
                ndf[colume_name] = _min(ndf[col], v)
            elif col == "high":
                colume_name = "max_%s_%s" % (col, k)
                ndf[colume_name] = _max(ndf[col], v)
    return ndf

def calMacdKdjs(df):
    df = df.reindex(index=df.index[::-1])
    ndf = df.copy()
    df = macd(ndf)
    df = kdj(df)
    return df
import numpy as np
def cast_lst_to_float(line):
    nline = []
    for l in line:
        try:
            d = float(l)
        except:
            d = 0
        nline.append(d)
    return nline
def calCandleShape(df):
    ndf = df.copy()
    lines = ndf[["close","open","high","low","p_change","preclose"]].values
    ktypes = []
    shape_types = []
    subtypes = []
    bodys         = []
    bodys_type    = []
    body_rates    = []
    uplines       = []
    uplines_rates = []
    downlines     = []
    downline_rates = []
    shape_nums = []
    zfs_rate = []
    for line in lines:

        try:
            line = cast_lst_to_float(line)
            line = np.asarray(line).astype(float)
        except:
            print(line)
        ktype,btype,subtype,body, upline, downline, body_type,body_rate,upline_rate,downline_rate,zf_rate = getKtypeByFeatures(line)
        pct_types, shape_types, prop_types
        ktypes.append(ktype)
        shape_types.append(btype)
        subtypes.append(subtype)
        shape_num = all_map_types["%s#%s#%s" %(ktype,btype,subtype)]
        shape_nums.append(shape_num)
        bodys.append(body)
        bodys_type.append(body_type)
        body_rates.append(body_rate)
        uplines.append(upline)
        uplines_rates.append(upline_rate)
        downlines.append(downline)
        downline_rates.append(downline_rate)
        zfs_rate.append(zf_rate)
    ndf["body"] = bodys
    ndf["body_type"] = bodys_type
    ndf["body_rate"] = body_rates
    ndf["upline"] = uplines
    ndf["upline_rate"] = uplines_rates
    ndf["downline"] = downlines
    ndf["downline_rate"] = downline_rates
    ndf["zf_rate"] = zfs_rate
    ndf["candle_shape_type"] = shape_types
    ndf["candle_pct_type"] = ktypes
    ndf["candle_line_type"] = subtypes
    ndf["shape_num"] = shape_nums

    return ndf


def getKTypes(line):
    #c,o,h,l,pct,pclose = line
    body, upline, downline, body_type,body_rate,pct_rate  = getCandleProperties(line)
    b_type = None
    for k,v in k_spec_body.items():
        ucl = v["ucl"]
        lcl = v["lcl"]
        if ucl > body_rate >= lcl:
            b_type = k

    p_type = None
    for k,v in k_pct.items():
        ucl = v["ucl"]
        lcl = v["lcl"]
        if ucl > pct_rate >= lcl:
            p_type = k

    return b_type,p_type,body, upline, downline, body_type,body_rate,pct_rate
def getCandleProperties(line):
    c,o,h,l,pct,pclose = line
    body = c - o
    upline = h - c
    downline = o - l
    body_type = "positive"
    if c - o < 0:
        body_type = "negative"
        upline = h - o
        downline = c - l
    body_rate = round((c - o)*100/pclose,3)
    pct_rate = round((c - pclose)*100/pclose,3)
    upline_rate = round(upline*100/pclose,3)
    downline_rate = round(downline*100/pclose,3)

    return body,upline_rate,downline_rate,body_type,body_rate,pct_rate


def getKtypeByFeatures(line):
    btype,ptype,body, upline, downline, body_type,body_rate,pct_rate = getKTypes(line)
    if upline == 0 and downline == 0:
        subtype = ALLF
    elif upline == 0 and downline > 0:
        subtype = HEADF
    elif upline > 0 and downline == 0:
        subtype = FOOTF
    else:
        #updown_minus_rate = abs(upline) - abs(downline)

        if 1.1 > abs(upline) / abs(downline) > 0.9:
            subtype = HFEQL
        elif abs(upline) > abs(downline):
            subtype = HEADL
        elif abs(upline) < abs(downline):
            subtype = FOOTL
    body_rate = round(body*100/line[0],3)
    #upline_rate = round(upline*100/line[0],3)
    #downline_rate = round(downline*100/line[0])
    zf_rate = round((line[2] - line[3])*100/line[0],3)

    return code_maps[ptype],code_maps[btype],code_maps[subtype],body, upline, downline, body_type,body_rate,upline,downline,zf_rate

from project.com.funcs import *
def calWRRSIYinYangDays(df, lst):
    out = df.copy()
    out["close"] = out.close.astype(float)
    pcts = cast_lst_to_float(list(out.p_change.values))
    #out.p_change.astype(float)
    #out["p_change"] = out.p_change.astype(float)
    out["p_change"] = pcts
    #df = df.reindex(index=df.index[::-1])
    #out = df.copy()
    import numpy as np

    for k, v in lst.items():
        closes = out.p_change.values
        rlsts = rolling_window(closes, v)
        h,w = rlsts.shape
        pline = np.asarray([0]*len(out))
        nline = np.asarray([0]*len(out))

        for i in range(h):
            line = rlsts[i]
            pcount = np.argwhere(line >= 0).size
            ncount = np.argwhere(line < 0).size
            pline[i] = pcount
            nline[i] = ncount
        out["%s_%s" %("YIN",v)] = nline
        out["%s_%s" % ("YANG",v)] = pline
    df = out.reindex(index=df.index[::-1])
    ndf = df.copy()
    for k, v in lst.items():
        wr_df = wr(ndf,v)
        rsi_df = rsi(wr_df,v)
        ndf = rsi_df.copy()
    return ndf

def test_code_num_line(line):
    ktype,btype,subtype,body, upline, downline, body_type,body_rate,upline_rate,downline_rate,zf_rate = getKtypeByFeatures(line)
    shape_num = all_map_types["%s#%s#%s" % (ktype, btype, subtype)]
    key = "%s#%s#%s" % (ktype, btype, subtype)
    print("%s %s" %(shape_num,key))

if __name__ == '__main__':
    #c,o,h,l,pct,pclose = line
    c,o,h,l,pclose = [48.85,47.58,50.6,46.73,48.18]
    pct = round((c-pclose)*100/pclose,3)
    line = [c,o,h,l,pct,pclose]
    # 今开47
    # .58
    # 昨收48
    # .18
    # 最高50
    # .60
    # 最低46
    # .73
    test_code_num_line(line)