# from project.models.GetFileFuncs import *
# a = {"a":"b"}
# list(a.values(),a.keys())
# print(list(map(lambda x:{x[0]:x[1]},a.items())))