sql = '''
select
       a.code,a.date,a.close,a.preclose,a.p_change,a.low,a.high,b.hl_minus_rate,
       c.diff as hl_diff,c.avg5 as hl_avg5,c.avg10 as hl_avg10,c.avg120 as hl_avg120,
       round((c.diff + c.avg5 + c.avg10 + c.avg120)/4,3) as hl_avg,
       d.diff as lc_diff,d.avg5 as lc_avg5,d.avg10 as lc_avg10,d.avg120 as lc_avg120,
       round((d.diff + d.avg5 + d.avg10 + d.avg120)/4,3) as lc_avg,
       e.diff as oc_diff,e.avg5 as oc_avg5,e.avg10 as lc_avg10,e.avg120 as lc_avg120,
       round((e.diff + e.avg5 + e.avg10 + e.avg120)/4,3) as oc_avg
from
     raw_data_d_bs a,
     raw_05_CURRENT_AVG_HLMINUSRATE_d_data b,
     raw_10_CURRENT_DIF_AVG_HLMINUSRATE_d_data c,
     raw_15_CURRENT_DIF_AVG_LCMINUSRATE_d_data d,
     raw_17_CURRENT_DIF_AVG_OCMINUSRATE_d_data e
where a.code = b.code and a.date = b.date
     and a.code = c.code and a.date = c.date
     and a.code = d.code and a.date = d.date
     and a.code = e.code and a.date = e.date
order by a.date desc
'''

from project.com.DbTool import getConnByCodePath,query

from project.models.DeepAnalysisFuncs import _getConnByCode

def predictByHL(code):
    import numpy as np
    conn = _getConnByCode(code)
    df = query(sql,conn).copy()
    #print(df[["date","hl_diff","hl_avg"]])
    dates = df["date"]
    hl_diff = df["hl_avg"].values
    closes = df["close"].values
    low = df["low"].values
    # (high - low)*100/closes = hl_diff
    predict_highs = np.round((hl_diff * closes + 100*low)/100,3)
    print(predict_highs)
    lc_avg = df["lc_avg"].values
    #(low - close)*100/close = lc_diff
    predict_lows = np.round((lc_avg * closes + 100*closes)/100,3)
    print(predict_lows)
if __name__ == '__main__':
    code = "600268.SH"
    predictByHL(code)
    #15.43 14.91
    #9.95 9.15