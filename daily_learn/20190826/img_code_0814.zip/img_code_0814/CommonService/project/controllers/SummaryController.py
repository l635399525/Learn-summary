from project import app,jsonify,request
from project.com.Const import *
from project.com.Const_raw import *
from project.com.DbTool import query
from project.models.SummaryFuncs import *
@app.route('/getSummaryKpiRaws',methods=['POST','GET'])
def getSummaryKpiRaws():
    content = request.json
    code = content["code"]

    from project.models.GetFileFuncs import getMaxDate
    src_table = content["src_table"]
    dest_table = content["dest_table"]
    function = content["function"]
    lst = content["lst"]
    columns = content["columns"]
    key_column = content["key_column"]
    kpi_type = content["ktype"]
    conditions = None
    if function == ma100_func_type or function == ma_distance_func_type:
        if kpi_type == MA100_SCORES_CLOSE_DEEP or kpi_type == MA_DISTANCE_CLOSE_DEEP:
            head = "close"
        elif kpi_type == MA100_SCORES_HIGH_DEEP or kpi_type == MA_DISTANCE_HIGH_DEEP:
            head = "high"
        elif kpi_type == MA100_SCORES_LOW_DEEP or kpi_type == MA_DISTANCE_LOW_DEEP:
            head = "low"
        conditions = "and type = '%s'" % (head)
    res = getMaxDate([dest_table], code,conditions=conditions)
    max_date = res[code][dest_table]
    print("%s %s" %(dest_table,max_date))
    minus_dates = None
    from project.models.GetFileFuncs import getRawDataByCode

    if max_date is not None:
        tcontent = content.copy()
        tcontent["start_date"] = max_date
        tdf = getRawDataByCode(tcontent, src_table, code, colums="*")
        minus_dates = tdf["date"].tolist()
    rdf = getRawDataByCode(content, src_table, code, colums=columns)
    df = None
    if function == ma_func_type:
        df = calMas(rdf,key_column,lst)
    elif function == sum_func_type:
        df = calSums(rdf,key_column,lst)
    elif function == pday_func_type:
        df = calPDays(rdf,key_column,lst)
    elif function == minmax_func_type:
        df = calMaxMins(rdf,key_column,lst)
    elif function == macdkdj_func_type:
        df = calMacdKdjs(rdf)
    elif function == candle_func_type:
        df = calCandleShape(rdf)
    elif function == ma100_func_type:
        df = calMa100(rdf,lst,head)
    elif function == ma_distance_func_type:
        df = calMaDistance(rdf,lst,head)
    elif function == rsiwr_func_type:
        df = calWRRSIYinYangDays(rdf,lst)
    import json
    import pandas as pd
    lines = None
    if minus_dates is None:
        lines = json.loads(df.to_json(orient='records'))
    elif len(minus_dates) > 0:
        dfs = []
        for date in minus_dates:
            ndf = df[df["date"] == date]
            dfs.append(ndf)
        if len(dfs) > 0:
            ndf = pd.concat(dfs)
            lines = json.loads(ndf.to_json(orient='records'))
    return jsonify(lines)
