from project import app,jsonify,request
from project.com.Const import *
from project.com.DbTool import query
from project.models.HYGNFuncs import *
@app.route('/getHYGNCodes',methods=['POST','GET'])
def getHYGNCodesLst():
    codes = getHYGNCodes()
    codes = list(map(lambda x:x[1],codes))
    return jsonify(codes)
