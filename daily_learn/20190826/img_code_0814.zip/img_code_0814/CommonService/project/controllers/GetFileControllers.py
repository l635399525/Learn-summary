from project import app,jsonify,request
from project.com.Const import *
from project.com.DbTool import query
@app.route('/getmergefiles',methods=['POST','GET'])
def getmergefiles():
    #print(src_merge_folder)
    #content = request.json
    src_merge_files = glob.glob(src_merge_folder + sysmbol + "raw_*")
    #print(data)
    return jsonify(src_merge_files)

@app.route('/getCodeList',methods=['POST','GET'])
def getCodeList():
    #print(src_merge_folder)
    #content = request.json
    src_merge_files = glob.glob(src_merge_folder + sysmbol + "raw_*")
    codes = list(map(lambda x:[x.split(sysmbol)[-1].replace(".db",""),x],code_files))
    #print(data)
    return jsonify(codes)

@app.route('/getMaxDate',methods=['POST','GET'])
def getMaxDate():
    content = request.json
    code = content["code"]
    tables = content["tables"]
    from project.models.GetFileFuncs import getMaxDate
    res = getMaxDate(tables,code)
    return jsonify(res)

@app.route('/gethygnlst',methods=['POST','GET'])
def getHYGNList():
    import json
    from project.com.DbTool import getConn,query
    sql = '''
    select  a.code,a.pcode,a.type,b.cn_pcode from money_normal_detail_gn_hy_data_final a
    left outer join
    money_normal_gn_hy_data_final_daily b
on a.pcode = b.code
    '''
    print(golden_all_config_file)
    conn = getConn(golden_all_config_file)

    df = query(sql,conn)
    lines = json.loads(df.to_json(orient='records'))
    print(lines)
    return jsonify(lines)

@app.route('/getRawDataByDate',methods=['POST','GET'])
def getRawDataByDate():
    content = request.json
    code = content["code"]
    try:
        table = content["table"]
    except:
        table = tables["RAWDATAD"]
    from project.models.GetFileFuncs import getRawDataByCode
    df = getRawDataByCode(content,table,code)
    import json
    lines = json.loads(df.to_json(orient='records'))
    return jsonify(lines)

@app.route('/getMaDataByDate',methods=['POST','GET'])
def getMaDataByDate():
    content = request.json
    code = content["code"]
    try:
        table = content["table"]
    except:
        table = tables["RAWDATAD"]
    try:
        ma_type = content["ma_type"]
    except:
        ma_type = CURRENT_MA
    try:
        ma_key = content["ma_key"]
    except:
        ma_key = "close"
    from project.com.funcs import _ma
    mas = content["mas"]
    if ma_type == CURRENT_MA:
        columns = "code,date,close,ma5,ma10,ma20"
    elif ma_type == PRE_MA:
        columns = "code,date,close"

    from project.models.GetFileFuncs import getRawDataByCode
    df = getRawDataByCode(content,table,code,colums=columns)
    for k,v in mas.items():
        df[k] = _ma(df[ma_key],v)
    import json
    lines = json.loads(df.to_json(orient='records'))
    return jsonify(lines)

@app.route('/getKpiDataByDate',methods=['POST','GET'])
def getKpiDataByDate():
    content = request.json
    code = content["code"]

    from project.models.GetFileFuncs import getMaxDate
    src_table = content["src_table"]
    dest_table = content["dest_table"]
    function = content["function"]
    lst = content["lst"]
    columns = content["columns"]
    key_column = content["key_column"]
    res = getMaxDate([dest_table], code)
    max_date = res[code][dest_table]
    print("%s %s" %(dest_table,max_date))
    minus_dates = None
    from project.com.funcs import _ma, _sum, _dif,macd,boll,xingaoxindi,ma100,maDistance
    from project.models.GetFileFuncs import getRawDataByCode,getRawDataWithMa

    if max_date is not None:
        tcontent = content.copy()
        tcontent["start_date"] = max_date
        tdf = getRawDataByCode(tcontent, src_table, code, colums="*")
        minus_dates = tdf["date"].tolist()
    if function == "xingaoxindi":
        df = getRawDataWithMa(content,src_table,code)
    else:
        df = getRawDataByCode(content,src_table,code,colums=columns)
    if function == "diff":
        key1, key2 = key_column.split(",")
        diffs = _dif(df[key1], df[key2])
        ndf = df[:-1].copy()
        ndf["diff"] = diffs.tolist()
        key_column = "diff"
        df = ndf
    elif function == "macd":
        df = df.reindex(index=df.index[::-1])
        df = macd(df)
        df["code"] = code
        df = df[30:]
        df = df.reindex(index=df.index[::-1])

    elif function == "boll":
        df = df.reindex(index=df.index[::-1])
        df = boll(df)
        df["code"] = code
        df = df[30:]
        df = df.reindex(index=df.index[::-1])

    elif function == "xingaoxindi":
        df = df.reindex(index=df.index[::-1])
        df = xingaoxindi(df)
        df["code"] = code
        #df = df[30:]
        df = df.reindex(index=df.index[::-1])

    elif function == "ma100":
        df = df.reindex(index=df.index[::-1])
        df = ma100(df,lst)
        #df["code"] = code
        df = df[30:]
        df = df.reindex(index=df.index[::-1])

    elif function == "madistance":
        df = df.reindex(index=df.index[::-1])
        df = df[30:]

        df = maDistance(df,lst)
        ndf = df.sort_values(by="date", ascending=False)
        df = ndf.copy()
        #df["code"] = code
    for k,v in lst.items():
        if CURRENT_MA_100 in dest_table:
            v = getMaValBYMaType(k)
        #getMaVal()
        if function == "ma":
            df[k] = _ma(df[key_column],v)
        elif function == "sum":
            df[k] = _sum(df[key_column],v)
        else:
            if "_SUM_" in dest_table:
                for kc in key_column.split(","):
                    if function == "diff":
                        df["%s" %(k)] = _sum(df[kc],v)
                    else:
                        df["%s_%s" %(k,kc)] = _sum(df[kc],v)
                    #df = ndf
            elif "_AVG_" in dest_table:
                for kc in key_column.split(","):
                    if function == "diff":
                        df["%s" % (k)] = _ma(df[kc],v)
                    else:
                        df["%s_%s" %(k,kc)] = _ma(df[kc],v)
                        #print(df[["code","date", kc, "%s_%s" %(k,kc)]][-20:])

            # elif "_COUNT_" in dest_table:
            #     for kc in key_column.split(","):
            #         if function == "diff":
            #             df["%s" % (k)] = _ma(df[kc], v)
            #         else:
            #             df["%s_%s" % (k, kc)] = _sum(df[kc], v)
                    #df = ndf
    import json
    import pandas as pd
    lines = None
    if minus_dates is None:
        lines = json.loads(df.to_json(orient='records'))
    elif len(minus_dates) > 0:
        dfs = []
        for date in minus_dates:
            ndf = df[df["date"] == date]
            dfs.append(ndf)
        if len(dfs) > 0:
            ndf = pd.concat(dfs)
            lines = json.loads(ndf.to_json(orient='records'))
    return jsonify(lines)


# def getRawDataByDate():
#     content = request.json
#     code = content["code"]
#     try:
#         table = content["table"]
#     except:
#         table = tables["RAWDATAD"]
#
#     try:
#         start_date = content["date"]
#         sql = "select * from %s where date(date) > date('%s')" %(table,start_date)
#     except:
#         sql = "select * from %s" %(table)
#     from project.models.GetFileFuncs import getConnByCode
#     conn = getConnByCode(code)
#     df = query(sql,conn)
#     import json
#     lines = json.loads(df.to_json(orient='records'))
#     return jsonify(lines)

