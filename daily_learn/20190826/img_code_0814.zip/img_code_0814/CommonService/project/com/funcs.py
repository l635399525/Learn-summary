def _ma(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    #print(series.tolist())
    res = series.rolling(n,min_periods=1).mean().sort_index(ascending=False).round(decimals=3)
    #print(res.tolist())
    return res

def _sum(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).sum().sort_index(ascending=False).round(decimals=3)
    return res

def _dif(series1,series2):
    import numpy as np
    s1 = np.asarray(series1,dtype=float)[:-1]
    s2 = np.asarray(series2,dtype=float)[1:]
    return np.round((s1 - s2)*100/s2,3)

def _ema(series, n):
    """
    指数平均数
    """
    return series.ewm(ignore_na=False, span=n, min_periods=0, adjust=False).mean()

import pandas as pd
def _maboll(series, n):
    """
    移动平均
    """
    return series.rolling(n).mean()

def _md(series, n):
    """
    标准差MD
    """
    return series.rolling(n).std(ddof=0)  # 有时候会用ddof=1

def macd(df, n=12, m=26, k=9):
    """
    平滑异同移动平均线(Moving Average Convergence Divergence)
    今日EMA（N）=2/（N+1）×今日收盘价+(N-1)/（N+1）×昨日EMA（N）
    DIFF= EMA（N1）- EMA（N2）
    DEA(DIF,M)= 2/(M+1)×DIF +[1-2/(M+1)]×DEA(REF(DIF,1),M)
    MACD（BAR）=2×（DIF-DEA）
    return:
          osc: MACD bar / OSC 差值柱形图 DIFF - DEM
          diff: 差离值
          dea: 讯号线
    """
    _macd = df.copy()
    #_macd['date'] = df['date']
    _macd["close"] = _macd.close.astype(float)
    _macd["high"] = _macd.high.astype(float)
    _macd["low"] = _macd.low.astype(float)

    _macd['m_diff'] = round(_ema(df.close, n) - _ema(df.close, m),3)
    _macd['m_dea'] = round(_ema(_macd['m_diff'], k),3)
    _macd['m_macd'] = round((_macd['m_diff'] - _macd['m_dea'])*2,3)
    return _macd

def sma(a, n, m=1):
    """
    平滑移动指标 Smooth Moving Average
    """
    ''' # 方法一，此方法有缺陷
    _sma = []
    for index, value in enumerate(a):
        if index == 0 or pd.isna(value) or np.isnan(value):
            tsma = 0
        else:
            # Y=(M*X+(N-M)*Y')/N
            tsma = (m * value + (n - m) * tsma) / n
        _sma.append(tsma)
    return pd.Series(_sma)
    '''
    ''' # 方法二

    results = np.nan_to_num(a).copy()
    # FIXME this is very slow
    for i in range(1, len(a)):
        results[i] = (m * results[i] + (n - m) * results[i - 1]) / n
        # results[i] = ((n - 1) * results[i - 1] + results[i]) / n
    # return results
    '''
    # b = np.nan_to_num(a).copy()
    # return ((n - m) * a.shift(1) + m * a) / n

    a = a.fillna(0)
    b = a.ewm(min_periods=0, ignore_na=False, adjust=False, alpha=m/n).mean()
    return b

def kdj(df, n=9):
    """
    随机指标KDJ
    N日RSV=（第N日收盘价-N日内最低价）/（N日内最高价-N日内最低价）×100%
    当日K值=2/3前1日K值+1/3×当日RSV=SMA（RSV,M1）
    当日D值=2/3前1日D值+1/3×当日K= SMA（K,M2）
    当日J值=3 ×当日K值-2×当日D值
    """
    #_kdj = pd.DataFrame()
    _kdj = df.copy()
    _kdj["close"] = _kdj.close.astype(float)
    _kdj["high"] = _kdj.high.astype(float)
    _kdj["low"] = _kdj.low.astype(float)

    rsv = (df.close - df.low.rolling(n).min()) / (df.high.rolling(n).max() - df.low.rolling(n).min()) * 100
    _kdj['kdj_k'] = round(sma(rsv, 3),4)
    _kdj['kdj_d'] = round(sma(_kdj.kdj_k, 3),4)
    _kdj['kdj_j'] = round(3 * _kdj.kdj_k - 2 * _kdj.kdj_d,4)
    return _kdj
def boll(df, n=26, k=2):
    """
    布林线指标BOLL boll(26,2)	MID=MA(N)
    标准差MD=根号[∑（CLOSE-MA(CLOSE，N)）^2/N]
    UPPER=MID＋k×MD
    LOWER=MID－k×MD
    """
    _boll = pd.DataFrame()
    _boll['date'] = df.date
    _boll['mid'] = round(_maboll(df.close, n),3)
    _mdd = _md(df.close, n)
    _boll['up'] = round(_boll.mid + k * _mdd,3)
    _boll['low'] = round(_boll.mid - k * _mdd,3)
    return _boll

def _max(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).max().sort_index(ascending=False).round(decimals=3)
    return res

def _min(series, n):
    """
    移动平均
    """
    series = series.sort_index(ascending=False)
    res = series.rolling(n,min_periods=1).min().sort_index(ascending=False).round(decimals=3)
    return res


def xingaoxindi(df):
    """
    布林线指标BOLL boll(26,2)	MID=MA(N)
    标准差MD=根号[∑（CLOSE-MA(CLOSE，N)）^2/N]
    UPPER=MID＋k×MD
    LOWER=MID－k×MD
    """
    minmaxVals = [5,10,20,60,120,240,500000]
    key_map = {"close":minmaxVals,"open":minmaxVals,"high":minmaxVals
              ,"low":minmaxVals,"ma5":minmaxVals,"ma10":minmaxVals,
               "ma20":minmaxVals,"ma60":minmaxVals,"ma120":minmaxVals,"ma240":minmaxVals}
    import numpy as np
    #_xgxd = pd.DataFrame()
    _xgxd = df[["code","date"]]
    _xgxd = _xgxd.copy()
    #_xgxd['code'] = df.code
    #_xgxd['date'] = df.date

    # _xgxd['close'] = df.close.astype(float)
    # _xgxd['high'] = df.high.astype(float)
    # _xgxd['low'] = df.low.astype(float)

    for k,v in key_map.items():
        _xgxd["%s" % (k)] = df[k].astype(float)
        for ma in v:
            series = df[k].sort_index(ascending=True)
            max_series = _max(series, ma)
            max_series = max_series.sort_index(ascending=True)
            _xgxd["%s_%s_%s" %(k,ma,"max")] = max_series
            min_series = _min(series, ma)
            min_series = min_series.sort_index(ascending=True)
            _xgxd["%s_%s_%s" % (k, ma, "min")] = min_series
    #
    # _xgxd['close_xingao'] = _max(df.close,5000)
    # _xgxd['close_xindi'] = _min(df.close,5000)
    # _xgxd['high_xingao'] = _max(df.high, 5000)
    # _xgxd['low_xindi'] = _min(df.low, 5000)
    # clst = np.round(_xgxd['close'].values - _xgxd['close_xingao'].values,3)
    # cxg_lst = list(map(lambda x:1 if x>=0 else 0,clst))
    # _xgxd['c_is_xg'] = cxg_lst
    #
    # clst = np.round(_xgxd['close'].values - _xgxd['close_xindi'].values,3)
    # cxd_lst = list(map(lambda x:1 if x<=0 else 0,clst))
    # _xgxd['c_is_xd'] = cxd_lst
    #
    # clst = np.round(_xgxd['high'].values - _xgxd['close_xingao'].values,3)
    # hxg_lst = list(map(lambda x:1 if x>=0 else 0,clst))
    # _xgxd['h_is_xg'] = hxg_lst
    #
    # clst = np.round(_xgxd['low'].values - _xgxd['close_xindi'].values,3)
    # lxd_lst = list(map(lambda x:1 if x<=0 else 0,clst))
    # _xgxd['l_is_xd'] = lxd_lst

    return _xgxd

def ma100(df,lst):
    pre = df[:-1]
    next = df[1:]
    rdf = next.copy()
    ks = []
    for k,v in lst.items():
        lines = list(next[k].values - pre[k].values)
        scores = list(map(lambda x:v if x > 0 else 0,lines))
        rdf["%s_scores" %(k)] = scores
        ks.append("%s_scores" %(k))
    rdf["sum"] = rdf[ks].sum(axis=1)
    return rdf

def getValByKey(key):
    key = key.split("_")[-1]
    if key == MAS.MA5.value:
        return 5
    elif key == MAS.MA10.value:
        return 10
    elif key == MAS.MA20.value:
        return 20
    elif key == MAS.MA60.value:
        return 60
    elif key == MAS.MA120.value:
        return 120
    elif key == MAS.MA240.value:
        return 240

import operator
def maDistance(df,lst):
    import json
    ks = []
    rdf = df.copy()
    lines = json.loads(df.to_json(orient='records'))
    nlines = []
    json_res = {}
    scores_lst = []
    sort_ma_lst = []
    dist3_lst = []
    dist3_desc_lst = []
    dist4_lst = []
    dist4_desc_lst = []
    dist5_lst = []
    dist5_desc_lst = []

    for i in range(len(lst)):
        json_res["%s_idx" % (i)] = []

    for line in lines:
        #print(line)
        data = []
        for k,v in lst.items():
            data.append([line[k],k])
        data.sort(key=operator.itemgetter(0))
        for i in range(len(data)):
            #line["%s_idx" %(i)] = data[i][1]
            json_res["%s_idx" %(i)].append(data[i][1])
        t_lst = list(map(lambda x:getValByKey(x[1]),data))
        scores = 0
        sort_ma = "ma5,ma10,ma20,ma60,ma120,ma240"
        try:
            res = calScoreByline(t_lst)
            sort_ma = res["src"]
            scores = res["sum_scores"]
        except:
            pass
        #line["sort_ma"] = sort_ma
        #line["score"] = scores
        scores_lst.append(scores)
        sort_ma_lst.append(sort_ma)
        #line_6 = data[0][0] - data[5][0]
        line_3 = getDistanceByLineCount(data,3)
        line_4 = getDistanceByLineCount(data,4)
        line_5 = getDistanceByLineCount(data,5)
        # line["dist_3"] = line_3[0]
        # line["dist_3_desc"] = line_3[1]
        #
        # line["dist_4"] = line_4[0]
        # line["dist_4_desc"] = line_4[1]
        #
        # line["dist_5"] = line_5[0]
        # line["dist_5_desc"] = line_5[1]

        #line["dist_6"] = line_6
        dist3_lst.append(line_3[0])
        dist3_desc_lst.append(line_3[1])
        dist4_lst.append(line_4[0])
        dist4_desc_lst.append(line_4[1])
        dist5_lst.append(line_5[0])
        dist5_desc_lst.append(line_5[1])
        nlines.append(line)
    json_res["score"] = scores_lst
    json_res["sort_ma"] = sort_ma_lst
    json_res["dist_3"] = dist3_lst
    json_res["dist_3_desc"] = dist3_desc_lst
    json_res["dist_4"] = dist4_lst
    json_res["dist_4_desc"] = dist4_desc_lst
    json_res["dist_5"] = dist5_lst
    json_res["dist_5_desc"] = dist5_desc_lst
    for k,v in json_res.items():
        rdf[k] = v
    #ndf = pd.DataFrame(nlines)
    return rdf
# lst = [1,2,3,4,5,6,7,8,9]
# size = 3
def getDistanceByLineCount(lst,size):
    tmps = []
    import numpy as np
    lines = getPermutationNoRepeating(lst,size)
    for line in lines:
        line = list(line)
        line.sort(key=operator.itemgetter(0))
        line_arrgs = np.asarray(list(map(lambda x:x[0],line)))
        line_diffs = np.abs(np.diff(line_arrgs))
        sums = np.sum(line_diffs)
        tmps.append([sums,line])
    tmps.sort(key=operator.itemgetter(0))
    res = tmps[0]
    sum = round(res[0],3)
    des = ",".join(list(map(lambda x:x[1],res[1])))
    return [sum,des]

#lst = [[9,"a"],[12,"a"],[7,"b"]]
#lst.sort(key=operator.itemgetter(0))
#print(lst)

def getPermutationNoRepeating(lst,size):
    from itertools import combinations
    all = combinations(lst,size)
    return list(all)
def getFullLstPermutation(lst):
    from itertools import permutations
    all = permutations(lst)
    return all
lst = [5,10,20,60,120,240]
lst = getFullLstPermutation(lst)
from project.com.Const import *
def calMaScore(key,jsonline):
    position = goldenJsonMaSortLst[key]
    left_lst = goldenMaSortLst[:position]
    right_lst = goldenMaSortLst[position + 1:]
    score_sum = 0
    c_position = jsonline[key]
    score_unit = getMaScoreVal(key)
    for p in left_lst:
        l_position = jsonline[p]
        if c_position > l_position:
            #print("%s %s" %(p,score_unit))
            score_sum = score_sum + score_unit
    for p in right_lst:
        r_position = jsonline[p]
        if c_position < r_position:
            #print("%s %s" %(p,score_unit))
            score_sum = score_sum + score_unit
    #print("%s--------%s" %(key,score_sum))
    return score_sum
def calScores():
    r = lst
    reses = []
    for line in r:
        json_line = {}
        for i in range(len(line)):
            a = line[i]
            json_line[a] = i
        res = {}
        sums = 0
        for k,v in json_line.items():
            scores = calMaScore(k,json_line)
            res[getMaVal(k)] = scores
            res["src"] = line
            sums = sums + scores
        res["sum_scores"] = sums
        reses.append(res)
    return reses
def calScoreByline(line):
    json_line = {}
    for i in range(len(line)):
        a = line[i]
        json_line[a] = i
    res = {}
    sums = 0
    for k,v in json_line.items():
        scores = calMaScore(k,json_line)
        res[getMaVal(k)] = scores
        maline = list(map(lambda x:getMaVal(x),line))
        res["src"] = ",".join(maline)
        sums = sums + scores
    res["sum_scores"] = sums
    return res

def crossInception(a,b):
    from shapely.geometry import LineString
    a = LineString([(0, 10.55), (1, 10.64),(2, 8)])
    b = LineString([(0, 10.7), (1, 10.61),(2, 9)])
    x = a.intersection(b)
    print(list(x))

def rolling_window(a, window):
    import numpy as np
    shape = a.shape[:-1] + (a.shape[-1] - window + 1, window)
    strides = a.strides + (a.strides[-1],)
    # ValueError: negative
    # dimensions
    # are
    # not allowed
    try:
        return np.lib.stride_tricks.as_strided(a, shape=shape, strides=strides)
    except:
        print(a)
        return None
def wr(df, n=14):
    """
    威廉指标 w&r
    WR=[最高值（最高价，N）-收盘价]/[最高值（最高价，N）-最低值（最低价，N）]×100%
    """
    _wr = df.copy()
    _wr["close"] = _wr.close.astype(float)
    _wr["high"] = _wr.high.astype(float)
    _wr["low"] = _wr.low.astype(float)

    #_wr = pd.DataFrame()
    #_wr['date'] = df['date']
    higest = df.high.rolling(n).max()
    _wr['wr_%s' %(n)] = (higest - df.close) / (higest - df.low.rolling(n).min()) * 100
    return _wr
def rsi(df, n=6):
    """
    相对强弱指标（Relative Strength Index，简称RSI
    LC= REF(CLOSE,1)
    RSI=SMA(MAX(CLOSE-LC,0),N,1)/SMA(ABS(CLOSE-LC),N1,1)×100
    SMA（C,N,M）=M/N×今日收盘价+(N-M)/N×昨日SMA（N）
    """
    # pd.set_option('display.max_rows', 1000)
    _rsi = df.copy()
    _rsi["close"] = _rsi.close.astype(float)
    _rsi["high"] = _rsi.high.astype(float)
    _rsi["low"] = _rsi.low.astype(float)

    px = df.close - df.close.shift(1)
    px[px < 0] = 0
    _rsi['rsi_%s' %(n)] = sma(px, n) / sma((df['close'] - df['close'].shift(1)).abs(), n) * 100
    # def tmax(x):
    #     if x < 0:
    #         x = 0
    #     return x
    # _rsi['rsi'] = sma((df['close'] - df['close'].shift(1)).apply(tmax), n) / sma((df['close'] - df['close'].shift(1)).abs(), n) * 100
    return _rsi

if __name__ == '__main__':
    # lines = calScores()
    # for line in lines:
    #     print(line)
    crossInception(None,None)