CURRENT_MA_DISTANCE_SCORE = "22_CURRENT_MA_DISTANCE"
deep_kpis = [CURRENT_MA_DISTANCE_SCORE]
from project.com.Const import CURRENT_AVG_MA_DISTANCE
tables_deep_kpis = {
    "%s_D" % (CURRENT_MA_DISTANCE_SCORE): {
        "src_table": "raw_%s_d_data" % (CURRENT_AVG_MA_DISTANCE)
        ,"dest_table":"raw_%s_d_data" %(CURRENT_MA_DISTANCE_SCORE)
        ,"function":"distance_score"
        ,"lst":None
        ,"columns":"code,date,ma5,"
        ,"key_column":"close"
    }
}
