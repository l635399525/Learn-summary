from project.com.Const import tables,CURRENT_MA
append_current_ma = {"ma5":5,"ma10":10,"ma20":20,"ma30":30,"ma60":60,"ma90":90,"ma120":120,"ma240":240}
append_pre_ma = {"ma4":4,"ma9":9,"ma19":19,"ma29":29,"ma60":59,"ma89":89,"ma119":119,"ma239":239}
append_current_new_ma = {"ma5":5,"ma13":13,"ma21":21,"ma34":34,"ma55":55,"ma89":89,"ma144":144,"ma233":233}
append_volume_mas = {"ma5":5,"ma21":21,"ma34":34,"ma89":89}
append_sums = {"sum3":3,"sum5":5,"sum8":8,"sum13":13,"sum21":21,"sum34":34,"sum55":55,"sum89":89,"sum144":144,"sum233":233,"sum":100000}
append_pdays = {"p3":3,"p5":5,"p8":8,"p10":10,"p13":13,"p20":20,"p21":21,"p34":34,"p55":55,"p60":60,"p89":89,"p120":120,"p144":144,"p233":233}
append_mms = {"mm3":3,"mm5":5,"mm8":8,"mm13":13,"mm21":21,"mm34":34,"mm55":55,"mm89":89,"mm144":144,"mm233":233,"mm":100000}
ma100_close_columns = ["code","date","close","high","low","close_ma5 as ma5","close_ma10 as ma10","close_ma20 as ma20","close_ma60 as ma60","close_ma120 as ma120","close_ma240 as ma240"]
ma100_high_columns =  ["code","date","close","high","low","high_ma5 as ma5","high_ma10 as ma10","high_ma20 as ma20","high_ma60 as ma60","high_ma120 as ma120","high_ma240 as ma240"]
ma100_low_columns =   ["code","date","close","high","low","low_ma5 as ma5","low_ma10 as ma10","low_ma20 as ma20","low_ma60 as ma60","low_ma120 as ma120","low_ma240 as ma240"]
ma100_lst = {"ma5":10,"ma10":10,"ma20":10,"ma60":20,"ma120":20,"ma240":30}
ma_distance_lst = {"ma5":5,"ma10":10,"ma20":20,"ma60":60,"ma120":120,"ma240":240}


MA_CURRENT_NORMAL = "00_CURRENT_MA_NORMAL"
MA_CURRENT_NEW = "01_CURRENT_MA_NEW"
MA_PRE = "02_PRE_MA_NORMAL"
VOLUME_CURRENT_MA = "03_CURRENT_VOLUME_MA"
PCT_CURRENT_SUM = "04_CURRENT_PCT_SUM"
CURRENT_PDAY = "05_CURRENT_PDAY"
CURRENT_MIN_MAX = "06_MIN_MAX"
CURRENT_MACD_KDJ = "07_MACD_KDJ"
CURRENT_CANDLE_SHAPE = "08_CANDLE_SHAPE"

MA100_SCORES_DEEP = "09_MA100_DEEP"
MA100_SCORES_CLOSE_DEEP = "09_MA100_CLOSE_DEEP"
MA100_SCORES_HIGH_DEEP = "09_MA100_HIGH_DEEP"
MA100_SCORES_LOW_DEEP = "09_MA100_LOW_DEEP"

MA_DISTANCE_DEEP = "10_MADISTANCE_DEEP"
MA_DISTANCE_CLOSE_DEEP = "10_MADISTANCE_CLOSE_DEEP"
MA_DISTANCE_HIGH_DEEP = "10_MADISTANCE_HIGH_DEEP"
MA_DISTANCE_LOW_DEEP = "10_MADISTANCE_LOW_DEEP"
CURRENT_RSI_WR = "11_CURRENT_RSI_WR"

ma_func_type = "0_ma"
sum_func_type = "1_sum"
pday_func_type = "2_pval"
minmax_func_type = "3_minmax" #
macdkdj_func_type = "4_macdkdj" #
candle_func_type = "5_candle_shpae" #
ma100_func_type = "6_ma100s" #
ma_distance_func_type = "7_madist" #
rsiwr_func_type = "8_rsiwr" #判断超买超卖
suncount_func_type = "9_suncount"
ma_lst = [
  [None,MA_CURRENT_NORMAL,tables["RAWDATAD"],append_current_ma,"code,date,close,high,low","close,high,low",ma_func_type]
, [None,MA_CURRENT_NEW,tables["RAWDATAD"],append_current_new_ma,"code,date,close,high,low","close,high,low",ma_func_type]
, [None,MA_PRE,tables["RAWDATAD"],append_pre_ma,"code,date,close","close",ma_func_type]
, [None,VOLUME_CURRENT_MA,tables["RAWDATAD"],append_volume_mas,"code,date,volume","volume",ma_func_type]
, [None,PCT_CURRENT_SUM,tables["RAWDATAD"],append_sums,"code,date,close,p_change","p_change",sum_func_type]
, [None,CURRENT_PDAY,tables["RAWDATAD"],append_pdays,"code,date,close,high,low,p_change","close,p_change",pday_func_type]
, [None,CURRENT_MIN_MAX,tables["RAWDATAD"],append_mms,"code,date,close,high,low,p_change","close,high,low",minmax_func_type]
, [None,CURRENT_MACD_KDJ,tables["RAWDATAD"],[],"code,date,close,high,low,p_change","close,high,low,p_change",macdkdj_func_type]
, [None,CURRENT_CANDLE_SHAPE,tables["RAWDATAD"],[],"code,date,close,open,high,low,p_change,preclose","close,open,high,low,p_change,preclose",candle_func_type]
, [None,CURRENT_RSI_WR,tables["RAWDATAD"],{"ma13":13,"ma21":21},"code,date,close,open,high,low,p_change,preclose","close,open,high,low,p_change,preclose",rsiwr_func_type]

]
deep_lst = [
    ["raw_%s_d_data" % (MA100_SCORES_DEEP),MA100_SCORES_CLOSE_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_close_columns), "close,high,low",ma100_func_type]
   ,["raw_%s_d_data" % (MA100_SCORES_DEEP),MA100_SCORES_HIGH_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_high_columns), "close,high,low",ma100_func_type]
   ,["raw_%s_d_data" % (MA100_SCORES_DEEP),MA100_SCORES_LOW_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_low_columns), "close,high,low",ma100_func_type]
   ,["raw_%s_d_data" % (MA_DISTANCE_DEEP), MA_DISTANCE_CLOSE_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst,",".join(ma100_close_columns), "close,high,low", ma_distance_func_type]
   ,["raw_%s_d_data" % (MA_DISTANCE_DEEP), MA_DISTANCE_HIGH_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_high_columns), "close,high,low", ma_distance_func_type]
   ,["raw_%s_d_data" % (MA_DISTANCE_DEEP), MA_DISTANCE_LOW_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst,",".join(ma100_low_columns), "close,high,low", ma_distance_func_type]

]
summary_raw_kpis = []
kpis_a = [MA_CURRENT_NORMAL,MA_CURRENT_NEW,MA_PRE,VOLUME_CURRENT_MA,PCT_CURRENT_SUM]
kpis_b = [CURRENT_PDAY,CURRENT_MIN_MAX,CURRENT_MACD_KDJ,CURRENT_CANDLE_SHAPE,CURRENT_RSI_WR]
kpis_c = [MA100_SCORES_CLOSE_DEEP,MA100_SCORES_HIGH_DEEP,MA100_SCORES_LOW_DEEP]
kpis_d = [MA_DISTANCE_CLOSE_DEEP,MA_DISTANCE_HIGH_DEEP,MA_DISTANCE_LOW_DEEP]
kpis_t = [CURRENT_MACD_KDJ,CURRENT_CANDLE_SHAPE,CURRENT_RSI_WR]
#summary_raw_kpis.extend(kpis_t)
summary_raw_kpis.extend(kpis_a)
summary_raw_kpis.extend(kpis_b)
summary_raw_kpis.extend(kpis_c)
summary_raw_kpis.extend(kpis_d)
tables_summary_raw = {}
def gen_table_summary():
    lsts = []
    lsts.extend(ma_lst)
    lsts.extend(deep_lst)
    for ma in lsts:
        dest_table,kpi_type,src_table,lst,cols,key,func = ma
        if dest_table is None:
            dest_table = "raw_%s_d_data" % (kpi_type)
        tables_summary_raw["%s_D" % (kpi_type)] = {
            "src_table": src_table
            , "dest_table": dest_table
            , "ktype" : kpi_type
            , "function": func
            , "lst": lst
            , "columns": cols
            , "key_column": key
        }

    #return tables_summary
gen_table_summary()
#print(tables_summary_raw)
# shape
STARTN    = "start_negative"
STARTP    = "start_positive"
SMALLN    = "small_negative"
SMALLP    = "small_positive"
MIDN      = "mid_negative"
MIDP      = "mid_positive"
LARGEN    = "large_negative"
LARGEP    = "large_positive"
STRONGN    = "strong_negative"
STRONGP    = "strong_positive"
SUPER1N    = "super1_negative"
SUPER2N    = "super2_negative"
SUPER3N    = "super3_negative"
SUPER1P    = "super1_positive"
SUPER2P    = "super2_positive"
SUPER3P    = "super2_positive"

#涨幅
SMALLPCTN  = "small_pct_negative"
SMALLPCTP  = "small_pct_positive"
MIDPCTN    = "mid_pct_negative"
MIDPCTP    = "mid_pct_positive"
LARGEPCTN  = "large_pct_negative"
LARGEPCTP  = "large_pct_positive"
STRONGPCTN = "strong_pct_negative"
STRONGPCTP = "strong_pct_positive"

#振幅
ZFSMALLN     = "zf_small_negative"
ZFSMALLP     = "zf_small_positive"
ZFMIDN       = "zf_mid_negative"
ZFMIDP       = "zf_mid_positive"
ZFLARGEN     = "zf_large_negative"
ZFLARGEP     = "zf_large_positive"
ZFSTRONGN    = "zf_strong_negative"
ZFSTRONGP    = "zf_strong_positive"
ZFSUPER1N    = "zf_super1_negative"
ZFSUPER2N    = "zf_super2_negative"
ZFSUPER3N    = "zf_super3_negative"
ZFSUPER1P    = "zf_super1_positive"
ZFSUPER2P    = "zf_super2_positive"
ZFSUPER3P    = "zf_super3_positive"


# #跳空 长实体 > 3.5
# STARTN_0  = "start_negative_jump_over_over_bodyspec"
# STARTP_0  = "start_positive_jump_over_over_bodyspec"
# SMALLN_0  = "small_negative_jump_over_over_bodyspec"
# SMALLP_0  = "small_positive_jump_over_over_bodyspec"
# MIDN_0  =   "mid_negative_jump_over_over_bodyspec"
# MIDP_0  =   "mid_positive_jump_over_over_bodyspec"
# LARGEN_0  = "large_negative_jump_over_over_bodyspec"
# LARGEP_0  = "large_positive_jump_over_over_bodyspec"
# # 跳空 短实体 > 3.5
# STARTN_1  = "start_negative_jump_over_less_bodyspec"
# STARTP_1  = "start_positive_jump_over_less_bodyspec"
# SMALLN_1  = "small_negative_jump_over_less_bodyspec"
# SMALLP_1  = "small_positive_jump_over_less_bodyspec"
# MIDN_1  =   "mid_negative_jump_over_less_bodyspec"
# MIDP_1  =   "mid_positive_jump_over_less_bodyspec"
# LARGEN_1  = "large_negative_jump_over_less_bodyspec"
# LARGEP_1  = "large_positive_jump_over_less_bodyspec"
# # 短实体 > 3.5
# STARTN_2  = "start_negative_over_pctspec"
# STARTP_2  = "start_positive_over_pctspec"
# SMALLN_2  = "small_negative_over_pctspec"
# SMALLP_2  = "small_positive_over_pctspec"
# MIDN_2  =   "mid_negative_over_pctspec"
# MIDP_2  =   "mid_positive_over_pctspec"
# LARGEN_2  = "large_negative_over_pctspec"
# LARGEP_2  = "large_positive_over_pctspec"
# # 长实体 不大于 3.5
# STARTN_3  = "start_negative_less_pctspec"
# STARTP_3  = "start_positive_less_pctspec"
# SMALLN_3  = "small_negative_less_pctspec"
# SMALLP_3  = "small_positive_less_pctspec"
# MIDN_3  =   "mid_negative_less_pctspec"
# MIDP_3  =   "mid_positive_less_pctspec"
# LARGEN_3  = "large_negative_less_pctspec"
# LARGEP_3  = "large_positive_less_pctspec"

# type_map = {
#      STARTN:{0:STARTN_0,1:STARTN_1,2:STARTN_2,3:STARTN_3}
#     ,STARTP:{0:STARTP_0,1:STARTP_1,2:STARTP_2,3:STARTP_3}
#     ,SMALLN:{0:SMALLN_0,1:SMALLN_1,2:SMALLN_2,3:SMALLN_3}
#     ,SMALLP:{0:SMALLP_0,1:SMALLP_1,2:SMALLP_2,3:SMALLP_3}
#     ,MIDN:{0:MIDN_0,1:MIDN_1,2:MIDN_2,3:MIDN_3}
#     ,MIDP:{0:MIDP_0,1:MIDP_1,2:MIDP_2,3:MIDP_3}
#     ,LARGEN:{0:LARGEN_0,1:LARGEN_1,2:LARGEN_2,3:LARGEN_3}
#     ,LARGEP:{0:LARGEP_0,1:LARGEP_1,2:LARGEP_2,3:LARGEP_3}
# }
# type_proprity = {
#      STARTN:"1#N"
#     ,STARTP:"1#p"
#     ,SMALLN:"2#N"
#     ,SMALLP:"2#P"
#     ,MIDN:"3#N"
#     ,MIDP:"3#P"
#     ,LARGEN:"4#N"
#     ,LARGEP:"4#P"
# }
0.382*0*618
0.618
#23.6％、38.2％、50％、61.8％、80.9
star_ucl_p ,star_ucl_n,star_lcl_p,star_lcl_n = 0.901001,0,0,-0.901
small_ucl_p,small_ucl_n,small_lcl_p,small_lcl_n = 2.36001,0,0,-2.36
mid_ucl_p  ,mid_ucl_n,mid_lcl_p,mid_lcl_n = 6.18001,-2.36001,2.36001,-6.18,
large_ucl_p,large_ucl_n,large_lcl_p,large_lcl_n = 8.54001,-6.18001,6.18001,-8.54
strong_ucl_p,strong_ucl_n,strong_lcl_p,strong_lcl_n = 10.9001,-8.54001,8.54001,-10.9
super1_ucl_p,super1_ucl_n,super1_lcl_p,super1_lcl_n = 13.7801,-10.9001,10.9001,-13.78
super2_ucl_p,super2_ucl_n,super2_lcl_p,super2_lcl_n = 16.1801,-13.7801,13.7801,-16.18
super3_ucl_p,super3_ucl_n,super3_lcl_p,super3_lcl_n = 20.0001,-16.1801,16.1801,-20



k_pct = {
   SMALLPCTN:{"ucl":small_ucl_n,"lcl":small_lcl_n}
  ,SMALLPCTP:{"ucl":small_ucl_p,"lcl":small_lcl_p}
  ,MIDPCTN:{"ucl":mid_ucl_n,"lcl":mid_lcl_n}
  ,MIDPCTP:{"ucl":mid_ucl_p,"lcl":mid_lcl_p}
  ,LARGEPCTN:{ "ucl":large_ucl_n,"lcl":large_lcl_n}
  ,LARGEPCTP:{ "ucl":large_ucl_p,"lcl":large_lcl_p}
  ,STRONGPCTN:{"ucl":strong_ucl_n,"lcl":strong_lcl_n}
  ,STRONGPCTP:{"ucl":strong_ucl_p,"lcl":strong_lcl_p}
}

k_spec_body = {
   STARTN:    {"ucl":star_ucl_n ,"lcl":star_lcl_n }
  ,SMALLN:    {"ucl":small_ucl_n,"lcl":small_lcl_n}
  ,MIDN  :    {"ucl":mid_ucl_n  ,"lcl":mid_lcl_n  }
  ,LARGEN:    {"ucl":large_ucl_n,"lcl":large_lcl_n}
  ,STARTP:    {"ucl":star_ucl_p ,"lcl":star_lcl_p }
  ,SMALLP:    {"ucl":small_ucl_p,"lcl":small_lcl_p}
  ,MIDP  :    {"ucl":mid_ucl_p  ,"lcl":mid_lcl_p  }
  ,LARGEP:    {"ucl":large_ucl_p,"lcl":large_lcl_p}
  ,STRONGPCTN:{"ucl":strong_ucl_n,"lcl":strong_lcl_n}
  ,SUPER1N   :{"ucl":super1_ucl_n,"lcl":super1_lcl_n}
  ,SUPER2N   :{"ucl":super2_ucl_n,"lcl":super2_lcl_n}
  ,SUPER3N   :{"ucl":super3_ucl_n,"lcl":super3_lcl_n}
  ,STRONGPCTP:{"ucl":strong_ucl_p,"lcl":strong_lcl_p}
  ,SUPER1P   :{"ucl":super1_ucl_p,"lcl":super1_lcl_p}
  ,SUPER2P   :{"ucl":super2_ucl_p,"lcl":super2_lcl_p}
  ,SUPER3P   :{"ucl":super3_ucl_p,"lcl":super3_lcl_p}
}

zf_spec = {
   ZFSMALLN :{"ucl":small_ucl_n,"lcl":small_lcl_n}
  ,ZFSMALLP :{"ucl":small_ucl_p,"lcl":small_lcl_p}
  ,ZFMIDN   :{"ucl":mid_ucl_n,"lcl":mid_lcl_n}
  ,ZFMIDP   :{"ucl":mid_ucl_p,"lcl":mid_lcl_p}
  ,ZFLARGEN :{ "ucl":large_ucl_n,"lcl":large_lcl_n}
  ,ZFLARGEP :{ "ucl":large_ucl_p,"lcl":large_lcl_p}
  ,ZFSTRONGN:{"ucl":strong_ucl_n,"lcl":strong_lcl_n}
  ,ZFSTRONGP:{"ucl":strong_ucl_p,"lcl":strong_lcl_p}
  ,ZFSUPER1N:{"ucl":super1_ucl_n,"lcl":super1_lcl_n}
  ,ZFSUPER2N:{"ucl":super2_ucl_n,"lcl":super2_lcl_n}
  ,ZFSUPER3N:{"ucl":super3_ucl_n,"lcl":super3_lcl_n}
  ,ZFSUPER1P:{"ucl":super1_ucl_p,"lcl":super1_lcl_p}
  ,ZFSUPER2P:{"ucl":super2_ucl_p,"lcl":super2_lcl_p}
  ,ZFSUPER3P:{"ucl":super3_ucl_p,"lcl":super3_lcl_p}
}


ctypes = []
ALLF   = "all_full"
HEADF  = "head_full"
FOOTF  = "foot_full"
HEADL  = "upline_long"
FOOTL  = "downline_long"
HFEQL  = "up_down_line_equal"

STARTN = "S1N"
STARTP = "S1P"
SMALLN = "S2N"
SMALLP = "S2P"
MIDN   = "S3N"
MIDP   = "S3P"
LARGEN = "S4N"
LARGEP = "S4P"
STRONGN= "S5N"
STRONGP= "S5P"
SUPER1N= "S6N"
SUPER2N= "S6P"
SUPER3N= "S7N"
SUPER1P= "S7P"
SUPER2P= "S8N"
SUPER3P= "S8P"


SMALLPCTN ="B1N"
SMALLPCTP ="B1P"
MIDPCTN   ="B2N"
MIDPCTP   ="B2P"
LARGEPCTN ="B3N"
LARGEPCTP ="B3P"
STRONGPCTN="B4N"
STRONGPCTP="B4P"


ZFSMALLN  = "Z1N"
ZFSMALLP  = "Z1P"
ZFMIDN    = "Z2N"
ZFMIDP    = "Z2P"
ZFLARGEN  = "Z3N"
ZFLARGEP  = "Z3P"
ZFSTRONGN = "Z4N"
ZFSTRONGP = "Z4P"
ZFSUPER1N = "Z5N"
ZFSUPER2N = "Z5P"
ZFSUPER3N = "Z6N"
ZFSUPER1P = "Z6P"
ZFSUPER2P = "Z7N"
ZFSUPER3P = "Z7P"
ALLF  = "LAF"
HEADF = "LHF"
FOOTF = "LFF"
HEADL = "LUL"
FOOTL = "LDL"
HFEQL = "LEQ"


code_maps = {
ALLF  :"LAF"    ,
HEADF :"LHF"    ,
FOOTF :"LFF"    ,
HEADL :"LUL"    ,
FOOTL :"LDL"    ,
HFEQL :"LEQ"    ,

ZFSMALLN  : "Z1N",
ZFSMALLP  : "Z1P",
ZFMIDN    : "Z2N",
ZFMIDP    : "Z2P",
ZFLARGEN  : "Z3N",
ZFLARGEP  : "Z3P",
ZFSTRONGN : "Z4N",
ZFSTRONGP : "Z4P",
ZFSUPER1N : "Z5N",
ZFSUPER2N : "Z5P",
ZFSUPER3N : "Z6N",
ZFSUPER1P : "Z6P",
ZFSUPER2P : "Z7N",
ZFSUPER3P : "Z7P",

SMALLPCTN :"P1N",
SMALLPCTP :"P1P",
MIDPCTN   :"P2N",
MIDPCTP   :"P2P",
LARGEPCTN :"P3N",
LARGEPCTP :"P3P",
STRONGPCTN:"P4N",
STRONGPCTP:"P4P",

STARTN  : "S1N",
STARTP  : "S1P",
SMALLN  : "S2N",
SMALLP  : "S2P",
MIDN    : "S3N",
MIDP    : "S3P",
LARGEN  : "S4N",
LARGEP  : "S4P",
STRONGN : "S5N",
STRONGP : "S5P",
SUPER1N : "S6N",
SUPER2N : "S6P",
SUPER3N : "S7N",
SUPER1P : "S7P",
SUPER2P : "S8N",
SUPER3P : "S8P"

}
pct_types = [
     code_maps[SMALLPCTN ]
    ,code_maps[SMALLPCTP ]
    ,code_maps[MIDPCTN   ]
    ,code_maps[MIDPCTP   ]
    ,code_maps[LARGEPCTN ]
    ,code_maps[LARGEPCTP ]
    ,code_maps[STRONGPCTN]
    ,code_maps[STRONGPCTP]
]
shape_types = [
     code_maps[STARTN ]
    ,code_maps[STARTP ]
    ,code_maps[SMALLN ]
    ,code_maps[SMALLP ]
    ,code_maps[MIDN   ]
    ,code_maps[MIDP   ]
    ,code_maps[LARGEN ]
    ,code_maps[LARGEP ]
    ,code_maps[STRONGN]
    ,code_maps[STRONGP]
    ,code_maps[SUPER1N]
    ,code_maps[SUPER2N]
    ,code_maps[SUPER3N]
    ,code_maps[SUPER1P]
    ,code_maps[SUPER2P]
    ,code_maps[SUPER3P]
]
zf_types = [
 code_maps[ZFSMALLN  ]
,code_maps[ZFSMALLP  ]
,code_maps[ZFMIDN    ]
,code_maps[ZFMIDP    ]
,code_maps[ZFLARGEN  ]
,code_maps[ZFLARGEP  ]
,code_maps[ZFSTRONGN ]
,code_maps[ZFSTRONGP ]
,code_maps[ZFSUPER1N ]
,code_maps[ZFSUPER2N ]
,code_maps[ZFSUPER3N ]
,code_maps[ZFSUPER1P ]
,code_maps[ZFSUPER2P ]
,code_maps[ZFSUPER3P ]
]
prop_types = [
    code_maps[ALLF]
   ,code_maps[HEADF]
   ,code_maps[FOOTF]
   ,code_maps[HEADL]
   ,code_maps[FOOTL]
   ,code_maps[HFEQL]
]
import itertools,collections
num = 0
all_types = list(itertools.product(prop_types,pct_types,shape_types,zf_types))
all_map_types = collections.OrderedDict(list(zip(list(map(lambda x:"#".join(x),all_types)),range(len(all_types)))))
print(len(all_map_types))
table_maps = {}
def genTables():
    lsts = []
    lsts.extend(kpis_a)
    lsts.extend(kpis_b)
    lsts.extend(kpis_c)
    lsts.extend(kpis_d)
    for kpi_type in lsts:
        table =  "raw_%s_d_data" % (kpi_type)
        table_maps[kpi_type] = table
#genTables()


# for line in all_types:
#     num = num + 1
#     print(line)
# print(num)
