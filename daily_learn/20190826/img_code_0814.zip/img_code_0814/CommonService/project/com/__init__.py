moveHome = "/Volumes/My Book/"
def getSysSplit():
    import platform
    return "\\" if (platform.system() =="Windows") else "/"
split = getSysSplit()
confHome = "%sgupiaosummary%sconf" %(moveHome,split)
confDB = "%s%s%s" %(confHome,split,"mapping.db")
confTable = "map_data"