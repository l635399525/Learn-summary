sysmbol = "/"
import glob
home = "/Users/lili/data/prod/raw_data"
ma_scores = {"ma5":10,"ma10":10,"ma20":10,"ma60":20,"ma120":20,"ma240":30}
ma_hygn_scores = {"avg5":10,"avg10":10,"avg20":10,"avg60":20,"avg120":20,"avg240":30}
ma_deep_conf = {"ma5":5,"ma10":10,"ma20":20,"ma60":60,"ma120":120,"ma240":240}

conf_file = home + sysmbol + "config.db"
hygn_home = "/Users/lili/data/prod/hygn_raw"
hygn_raw_folder = hygn_home + sysmbol + "codes_daily"

daily_folder = home + sysmbol + "codes_daily"
tmp_folder = "/Users/lili/data/prod/raw_data/tmp"
merge_db_file = tmp_folder + sysmbol + "merge_file.db"
src_merge_folder = tmp_folder + sysmbol + "tomergefiles"
code_file_path = daily_folder + sysmbol + "*.db"
code_files = glob.glob(code_file_path)
db_files = glob.glob(tmp_folder + sysmbol + "raw_*")
user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko'
headers = {'User-Agent': user_agent}
tables = {
    "RAWDATAD":"raw_data_d_bs"
    ,"RAWDATAW":"raw_data_w"
    , "RAWDATAM": "raw_data_m"
    , "RAWDATADMIN15": "raw_data_m15"
}
port = 5000
dev_url = "http://127.0.0.1:%s/" %(port)
urls = {
    "getmergefiles":"%s%s" %(dev_url,"getmergefiles")
    ,"getCodeList":"%s%s" %(dev_url,"getCodeList")
    ,"getMaxDate":"%s%s" %(dev_url,"getMaxDate")
    ,"gethygnlst":"%s%s" %(dev_url,"gethygnlst")
    ,"getRawDataByDate":"%s%s" %(dev_url,"getRawDataByDate")
    ,"getMaDataByDate":"%s%s" %(dev_url,"getMaDataByDate")
    ,"getKpiDataByDate":"%s%s" %(dev_url,"getKpiDataByDate")
    ,"getHYGNCodes":"%s%s" %(dev_url,"getHYGNCodes")
    ,"analysisMas":"%s%s" %(dev_url,"analysisMas")

}
bs_config_file_name = "golden_hygn_bs.db"
golden_bs_config_file = home + sysmbol + "config/%s" %(bs_config_file_name)
all_config_file_name = "golden_hygn_all.db"
golden_all_config_file = home + sysmbol + "config/%s" %(all_config_file_name)
golden_hygn_config_file = home + sysmbol + "config/%s" %("hygn_config.db")
golden_hygn_config_table = "hygn_mapping_data"

CURRENT_MA = "00_CURRENT_MA"
PRE_MA = "01_PRE_MA"
CURRENT_AVG_HL = "00_1_CURRENT_HL_AVG"

CURRENT_MA_VOLUME = "02_CURRENT_MA_VOLUME"
CURRENT_SUM_PCT = "03_CURRENT_SUM_PCT"
CURRENT_AVG_PCT = "04_CURRENT_AVG_PCT"
CURRENT_AVG_HLMINUSRATE = "05_CURRENT_AVG_HLMINUSRATE"
CURRENT_AVG_OCMINUSRATE = "06_CURRENT_AVG_OCMINUSRATE"
CURRENT_SUM_OCMINUSRATE = "07_CURRENT_SUM_OCMINUSRATE"
CURRENT_AVG_HCMINUSRATE = "08_CURRENT_AVG_HCMINUSRATE"
CURRENT_AVG_LCMINUSRATE = "09_CURRENT_AVG_LCMINUSRATE"
CURRENT_DIF_AVG_HLMINUSRATE = "10_CURRENT_DIF_AVG_HLMINUSRATE"
CURRENT_DIF_SUM_HLMINUSRATE = "11_CURRENT_DIF_SUM_HLMINUSRATE"



CURRENT_MACD_AVG_HLMINUSRATE = "12_CURRENT_MACD_AVG_HLMINUSRATE"
CURRENT_MACD_SUM_HLMINUSRATE = "13_CURRENT_MACD_SUM_HLMINUSRATE"
CURRENT_BOLL_AVG_HLMINUSRATE = "14_CURRENT_BOLL_AVG_HLMINUSRATE"

CURRENT_DIF_AVG_LCMINUSRATE = "15_CURRENT_DIF_AVG_LCMINUSRATE"
CURRENT_DIF_SUM_LCMINUSRATE = "16_CURRENT_DIF_SUM_LCMINUSRATE"
CURRENT_DIF_AVG_OCMINUSRATE = "17_CURRENT_DIF_AVG_OCMINUSRATE"

CURRENT_MA_NEW = "18_CURRENT_MA_NEW"
CURRENT_COUNT_XINHAOXINDI = "19_CURRENT_COUNT_XINHAOXINDI"
CURRENT_MA_100 = "20_CURRENT_AVG_MA_100"
CURRENT_AVG_MA_DISTANCE = "21_CURRENT_AVG_MA_DISTANCE"
CURRENT_CROSSINCEPTION = "22_CURRENT_CROSSINCEPTION"
CURRENT_MAANGLE = "24_CURRENT_MAANGLE"

#CURRENT_LYLY_DAYS = "22_CURRENT_LY_DAYS"
#CURRENT_MA_CROSS_SCORES = "23_CURRENT_CROSS_SCORES"
#CURRENT_MINCLOSEMA_ANGLES = "24_CURRENT_MINCLOSEMA_ANGLES"



kpis = [CURRENT_MA,PRE_MA,CURRENT_MA_VOLUME,CURRENT_SUM_PCT,CURRENT_AVG_PCT]
kpis_a = [CURRENT_MA,PRE_MA,CURRENT_MA_VOLUME,CURRENT_SUM_PCT,CURRENT_AVG_PCT,CURRENT_AVG_HLMINUSRATE,CURRENT_AVG_OCMINUSRATE,CURRENT_AVG_HCMINUSRATE,CURRENT_AVG_LCMINUSRATE,CURRENT_SUM_OCMINUSRATE,CURRENT_DIF_AVG_HLMINUSRATE,CURRENT_DIF_SUM_HLMINUSRATE]
kpis_b = [CURRENT_MACD_AVG_HLMINUSRATE,CURRENT_MACD_SUM_HLMINUSRATE,CURRENT_BOLL_AVG_HLMINUSRATE]
kpis_c = [CURRENT_DIF_AVG_LCMINUSRATE,CURRENT_DIF_SUM_LCMINUSRATE]
kpis_d = [CURRENT_DIF_AVG_OCMINUSRATE,CURRENT_MA_NEW,CURRENT_COUNT_XINHAOXINDI]
kpis_e = [CURRENT_MA_100,CURRENT_AVG_MA_DISTANCE]
kpis_f = [CURRENT_AVG_HL]

kpis_delete = [CURRENT_CROSSINCEPTION,CURRENT_MAANGLE]

kpis = []
kpis.extend(kpis_a)
kpis.extend(kpis_b)
kpis.extend(kpis_c)
kpis.extend(kpis_d)
kpis.extend(kpis_e)
kpis.extend(kpis_f)
#kpis = [CURRENT_MAANGLE]
#kpis = [CURRENT_DIF_AVG_HLMINUSRATE,CURRENT_DIF_SUM_HLMINUSRATE]
append_current_ma = {"ma5":5,"ma10":10,"ma20":20,"ma30":30,"ma60":60,"ma90":90,"ma120":120,"ma240":240}
append_current_new_ma = {"ma5":5,"ma13":13,"ma21":21,"ma34":34,"ma55":55,"ma89":89,"ma144":144,"ma233":233}

append_pre_ma = {"ma4":4,"ma9":9,"ma19":19,"ma29":29,"ma60":59,"ma89":89,"ma119":119,"ma239":239}
append_ma_volume = {"v_ma5":5,"v_ma10":10,"v_ma20":20,"v_ma30":30,"v_ma60":60,"v_ma90":90,"v_ma120":120,"v_ma240":240}
append_pct_sums = {"sum3":3,"sum5":5,"sum10":10,"sum20":20,"sum60":60,"sum120":120,"sum_all":100000}
append_pct_avgs = {"avg5":5,"avg10":10,"avg20":20,"avg60":60,"avg120":120,"avg_all":100000}
append_avgs = {"avg5":5,"avg10":10,"avg20":20,"avg60":60,"avg120":120,"avg_all":100000}
append_sums = {"sum3":3,"sum5":5,"sum10":10,"sum20":20,"sum60":60,"sum120":120,"sum_all":100000}

append_macd_sums = {"sum3":3,"sum5":5,"sum10":10,"sum20":20,"sum120":120,"sum_all":100000}
append_macd_avgs = {"avg5":5,"avg10":10,"avg20":20,"avg120":120,"avg_all":100000}
append_boll_avgs = {"avg5":5,"avg10":10,"avg20":20,"avg120":120,"avg_all":100000}

def get_append_ma(ma_type=CURRENT_MA):
    append_ma = append_pre_ma
    if ma_type.startswith(CURRENT_MA):
        append_ma = append_current_ma
    return append_ma
tables_ma = {
    "%s_D" %(CURRENT_MA):"raw_current_ma_d_data"
    ,"%s_D" %(PRE_MA):"raw_pre_ma_d_data"
}
tables_conf = {
    "HYGNCONF":"hygn_conf_table"
   ,"HYGNGEGUCONF":"hygn_gegu_conf_table"

}
tables_hygn = {
    "HYGNRAWD":"history_hygn_group"
}
tables_kpi = {
    "%s_D" % (CURRENT_MA): {
        "src_table": tables["RAWDATAD"]
        ,"dest_table":"raw_%s_d_data" %(CURRENT_MA)
        ,"function":"ma"
        ,"lst":append_current_ma
        ,"columns":"code,date,close"
        ,"key_column":"close"
    }
    ,"%s_D" % (PRE_MA): {
        "src_table": tables["RAWDATAD"],
        "dest_table":"raw_%s_d_data" %(PRE_MA)
        ,"function":"ma"
        ,"lst":append_pre_ma
        , "columns": "code,date,close"
        , "key_column": "close"

    }
    ,"%s_D" % (CURRENT_MA_VOLUME): {
        "src_table": tables["RAWDATAD"],
        "dest_table":"raw_%s_d_data" %(CURRENT_MA_VOLUME)
        ,"function":"ma"
        ,"lst":append_ma_volume
        ,"columns":"code,date,volume"
        , "key_column": "volume"

    }
    ,"%s_D" % (CURRENT_SUM_PCT): {
        "src_table": tables["RAWDATAD"],
        "dest_table":"raw_%s_d_data" %(CURRENT_SUM_PCT)
        ,"function":"sum"
        ,"lst":append_pct_sums
        , "columns": "code,date,p_change"
        , "key_column": "p_change"

    }
    , "%s_D" % (CURRENT_AVG_PCT): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_PCT)
        , "function": "ma"
        , "lst": append_pct_avgs
        , "columns": "code,date,p_change"
        , "key_column": "p_change"

    }
, "%s_D" % (CURRENT_AVG_HCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_HCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(high*100/(close - price_change) - close*100/(close - price_change),4) as hc_minus_rate"
        , "key_column": "hc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_LCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_LCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(low*100/(close - price_change) - close*100/(close - price_change),4) as lc_minus_rate"
        , "key_column": "lc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_OCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_OCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(close*100/(close - price_change) - open*100/(close - price_change),4) as oc_minus_rate"
        , "key_column": "oc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_HLMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(high*100/(close - price_change) - low*100/(close - price_change),4) as hl_minus_rate"
        , "key_column": "hl_minus_rate"
    }
, "%s_D" % (CURRENT_DIF_AVG_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_AVG_HLMINUSRATE)
        , "function": "diff"
        , "lst": append_avgs
        , "columns":"code,date,high,low"
        , "key_column": "high,low"
    }
, "%s_D" % (CURRENT_SUM_OCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_SUM_OCMINUSRATE)
        , "function": "ma"
        , "lst": append_sums
        , "columns":"code,date,round(close*100/(close - price_change) - open*100/(close - price_change),4) as oc_minus_rate"
        , "key_column": "oc_minus_rate"
    }
    , "%s_D" % (CURRENT_DIF_SUM_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_SUM_HLMINUSRATE)
        , "function": "diff"
        , "lst": append_sums
        , "columns":"code,date,high,low"
        , "key_column": "high,low"
    }
, "%s_D" % (CURRENT_MACD_AVG_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_MACD_AVG_HLMINUSRATE)
        , "function": "macd"
        , "lst": append_macd_avgs
        , "columns":"code,date,close"
        , "key_column": "macd,diff,dea"
    }
, "%s_D" % (CURRENT_MACD_SUM_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_MACD_SUM_HLMINUSRATE)
        , "function": "macd"
        , "lst": append_macd_sums
        , "columns":"code,date,close"
        , "key_column": "macd,diff,dea"
    }
, "%s_D" % (CURRENT_BOLL_AVG_HLMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_BOLL_AVG_HLMINUSRATE)
        , "function": "boll"
        , "lst": append_boll_avgs
        , "columns":"code,date,close"
        , "key_column": "mid,up,low"
    }
, "%s_D" % (CURRENT_DIF_SUM_LCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_SUM_LCMINUSRATE)
        , "function": "diff"
        , "lst": append_sums
        , "columns":"code,date,close,low"
        , "key_column": "low,close"
    }
, "%s_D" % (CURRENT_DIF_AVG_LCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_AVG_LCMINUSRATE)
        , "function": "diff"
        , "lst": append_avgs
        , "columns":"code,date,close,low"
        , "key_column": "low,close"
    }
, "%s_D" % (CURRENT_DIF_AVG_OCMINUSRATE): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_AVG_OCMINUSRATE)
        , "function": "diff"
        , "lst": append_avgs
        , "columns":"code,date,close,open"
        , "key_column": "open,close"
    }
,
"%s_D" % (CURRENT_MA_NEW): {
        "src_table": tables["RAWDATAD"]
        ,"dest_table":"raw_%s_d_data" %(CURRENT_MA_NEW)
        ,"function":"ma"
        ,"lst":append_current_new_ma
        ,"columns":"code,date,close"
        ,"key_column":"close"
    }
    ,"%s_D" % (CURRENT_COUNT_XINHAOXINDI): {
        "src_table": tables["RAWDATAD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_COUNT_XINHAOXINDI)
        , "function": "xingaoxindi"
        , "lst": append_sums
        , "columns": "code,date,close,high,low"
        , "key_column": "c_is_xg,c_is_xd,h_is_xg,l_is_xd"
    },"%s_D" % (CURRENT_MA_100): {
        "src_table": "raw_%s_d_data" % (CURRENT_MA),
        "dest_table": "raw_%s_d_data" % (CURRENT_MA_100)
        , "function": "ma100"
        , "lst": ma_scores
        , "columns": "code,date,close,%s" %(",".join(ma_scores.keys()))
        , "key_column": "ma5_scores,ma20_scores,ma60_scores,ma120_scores,sum"
    },"%s_D" % (CURRENT_AVG_MA_DISTANCE): {
        "src_table": "raw_%s_d_data" % (CURRENT_MA),
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_MA_DISTANCE)
        , "function": "madistance"
        , "lst": ma_deep_conf
        , "columns": "code,date,close,%s" %(",".join(ma_scores.keys()))
        , "key_column": "score,dist_3,dist_4"
    }
,
"%s_D" % (CURRENT_AVG_HL): {
        "src_table": tables["RAWDATAD"]
        ,"dest_table":"raw_%s_d_data" %(CURRENT_AVG_HL)
        ,"function":""
        ,"lst":append_avgs
        ,"columns":"code,date,close,high,low"
        ,"key_column":"high,low"
    }

}
append_full_avgs = {"avg5":5,"avg10":10,"avg20":20,"avg60":60,"avg90":90,"avg120":120,"avg240":240,"avg_all":100000}
append_full_sums = {"sum5":5,"sum10":10,"sum20":20,"sum60":60,"sum90":90,"sum120":120,"sum240":240,"sum_all":100000}

tables_conf_kpi = {
    "%s_D" % (CURRENT_MA): {
        "src_table": tables_hygn["HYGNRAWD"]
        ,"dest_table":"raw_%s_d_data" %(CURRENT_MA)
        ,"function":"ma"
        ,"lst":append_full_avgs
        ,"columns":"code,date,close"
        ,"key_column":"close"
    }
    ,"%s_D" % (PRE_MA): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table":"raw_%s_d_data" %(PRE_MA)
        ,"function":"ma"
        ,"lst":append_pre_ma
        , "columns": "code,date,close"
        , "key_column": "close"

    }
    ,"%s_D" % (CURRENT_MA_VOLUME): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table":"raw_%s_d_data" %(CURRENT_MA_VOLUME)
        ,"function":"ma"
        ,"lst":append_full_avgs
        ,"columns":"code,date,volumes"
        , "key_column": "volumes"

    }
    ,"%s_D" % (CURRENT_SUM_PCT): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table":"raw_%s_d_data" %(CURRENT_SUM_PCT)
        ,"function":"sum"
        ,"lst":append_pct_sums
        , "columns": "code,date,rate"
        , "key_column": "rate"

    }
    , "%s_D" % (CURRENT_AVG_PCT): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_PCT)
        , "function": "ma"
        , "lst": append_pct_avgs
        , "columns": "code,date,rate"
        , "key_column": "rate"

    }
, "%s_D" % (CURRENT_AVG_HCMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_HCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(high*100/(close - price_change) - close*100/(close - price_change),4) as hc_minus_rate"
        , "key_column": "hc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_LCMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_LCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(low*100/(close - price_change) - close*100/(close - price_change),4) as lc_minus_rate"
        , "key_column": "lc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_OCMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_OCMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(close*100/(close - price_change) - open*100/(close - price_change),4) as oc_minus_rate"
        , "key_column": "oc_minus_rate"
    }
, "%s_D" % (CURRENT_AVG_HLMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_AVG_HLMINUSRATE)
        , "function": "ma"
        , "lst": append_avgs
        , "columns":"code,date,round(high*100/(close - price_change) - low*100/(close - price_change),4) as hl_minus_rate"
        , "key_column": "hl_minus_rate"
    }
, "%s_D" % (CURRENT_DIF_AVG_HLMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_AVG_HLMINUSRATE)
        , "function": "diff"
        , "lst": append_avgs
        , "columns":"code,date,high,low"
        , "key_column": "high,low"
    }
, "%s_D" % (CURRENT_SUM_OCMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_SUM_OCMINUSRATE)
        , "function": "ma"
        , "lst": append_sums
        , "columns":"code,date,round(close*100/(close - price_change) - open*100/(close - price_change),4) as oc_minus_rate"
        , "key_column": "oc_minus_rate"
    }
    , "%s_D" % (CURRENT_DIF_SUM_HLMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_SUM_HLMINUSRATE)
        , "function": "diff"
        , "lst": append_sums
        , "columns":"code,date,high,low"
        , "key_column": "high,low"
    }
, "%s_D" % (CURRENT_MACD_AVG_HLMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_MACD_AVG_HLMINUSRATE)
        , "function": "macd"
        , "lst": append_macd_avgs
        , "columns":"code,date,close"
        , "key_column": "macd,diff,dea"
    }
, "%s_D" % (CURRENT_MACD_SUM_HLMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_MACD_SUM_HLMINUSRATE)
        , "function": "macd"
        , "lst": append_macd_sums
        , "columns":"code,date,close"
        , "key_column": "macd,diff,dea"
    }
, "%s_D" % (CURRENT_BOLL_AVG_HLMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_BOLL_AVG_HLMINUSRATE)
        , "function": "boll"
        , "lst": append_boll_avgs
        , "columns":"code,date,close"
        , "key_column": "mid,up,low"
    }
, "%s_D" % (CURRENT_DIF_SUM_LCMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_SUM_LCMINUSRATE)
        , "function": "diff"
        , "lst": append_sums
        , "columns":"code,date,close,low"
        , "key_column": "low,close"
    }
, "%s_D" % (CURRENT_DIF_AVG_LCMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_AVG_LCMINUSRATE)
        , "function": "diff"
        , "lst": append_avgs
        , "columns":"code,date,close,low"
        , "key_column": "low,close"
    }
    , "%s_D" % (CURRENT_DIF_AVG_OCMINUSRATE): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_DIF_AVG_OCMINUSRATE)
        , "function": "diff"
        , "lst": append_avgs
        , "columns": "code,date,close,open"
        , "key_column": "open,close"
    },
"%s_D" % (CURRENT_MA_NEW): {
        "src_table": tables_hygn["HYGNRAWD"]
        ,"dest_table":"raw_%s_d_data" %(CURRENT_MA_NEW)
        ,"function":"ma"
        ,"lst":append_current_new_ma
        ,"columns":"code,date,close"
        ,"key_column":"close"
    }
    ,"%s_D" % (CURRENT_COUNT_XINHAOXINDI): {
        "src_table": tables_hygn["HYGNRAWD"],
        "dest_table": "raw_%s_d_data" % (CURRENT_COUNT_XINHAOXINDI)
        , "function": "xingaoxindi"
        , "lst": append_sums
        , "columns": "code,date,close,high,low"
        , "key_column": "c_is_xg,c_is_xd,h_is_xg,l_is_xd"
    },"%s_D" % (CURRENT_MA_100): {
        "src_table": "raw_%s_d_data" % (CURRENT_MA),
        "dest_table": "raw_%s_d_data" % (CURRENT_MA_100)
        , "function": "ma100"
        , "lst": ma_hygn_scores
        , "columns": "code,date,close,%s" %(",".join(ma_hygn_scores.keys()))
        , "key_column": "avg5_scores,avg20_scores,avg60_scores,avg120_scores,sum"
    }

}
kpi_tables = {
    CURRENT_MA:"raw_%s_d_data"%(CURRENT_MA)
    ,PRE_MA:"raw_%s_d_data"%(PRE_MA)
    ,CURRENT_MA_VOLUME:"raw_%s_d_data"%(CURRENT_MA_VOLUME)
    ,CURRENT_SUM_PCT:"raw_%s_d_data"%(CURRENT_SUM_PCT)
    ,CURRENT_AVG_PCT:"raw_%s_d_data"%(CURRENT_AVG_PCT)
    ,CURRENT_AVG_HLMINUSRATE:"raw_%s_d_data"%(CURRENT_AVG_HLMINUSRATE)
    ,CURRENT_AVG_OCMINUSRATE:"raw_%s_d_data"%(CURRENT_AVG_OCMINUSRATE)
    ,CURRENT_SUM_OCMINUSRATE:"raw_%s_d_data"%(CURRENT_SUM_OCMINUSRATE)
    ,CURRENT_AVG_HCMINUSRATE:"raw_%s_d_data"%(CURRENT_AVG_HCMINUSRATE)
    ,CURRENT_AVG_LCMINUSRATE:"raw_%s_d_data"%(CURRENT_AVG_LCMINUSRATE)
    ,CURRENT_DIF_AVG_HLMINUSRATE:"raw_%s_d_data"%(CURRENT_DIF_AVG_HLMINUSRATE)
    ,CURRENT_DIF_SUM_HLMINUSRATE:"raw_%s_d_data"%(CURRENT_DIF_SUM_HLMINUSRATE)
    ,CURRENT_MACD_AVG_HLMINUSRATE:"raw_%s_d_data"%(CURRENT_MACD_AVG_HLMINUSRATE)
    ,CURRENT_MACD_SUM_HLMINUSRATE:"raw_%s_d_data"%(CURRENT_MACD_SUM_HLMINUSRATE)
    ,CURRENT_BOLL_AVG_HLMINUSRATE:"raw_%s_d_data"%(CURRENT_BOLL_AVG_HLMINUSRATE)
    ,CURRENT_DIF_AVG_LCMINUSRATE:"raw_%s_d_data"%(CURRENT_DIF_AVG_LCMINUSRATE)
    ,CURRENT_DIF_SUM_LCMINUSRATE:"raw_%s_d_data"%(CURRENT_DIF_SUM_LCMINUSRATE)

}
analysis_hygn_ma_kpi = "ANALYSIS_HYGN_MA_DATA"
analysis_gegu_ma_kpi = "ANALYSIS_GEGU_MA_DATA"
analysis_kpis = [analysis_hygn_ma_kpi,analysis_gegu_ma_kpi]
analysis_conf_kpis={
    "%s"%(analysis_hygn_ma_kpi):{
        "src_table":"%s a,%s b" %(tables_hygn["HYGNRAWD"],kpi_tables[CURRENT_MA])
        ,"condition":" where a.code = b.code and a.date = b.date"
        ,"sql_head": '''
       select a.code, a.name, a.date, a.open, a.close, 
       a.high, a.low, a.volumes, 
       a.moneys, a.rate, a.type, a.price_change,
       b.avg10, b.avg120, b.avg20, b.avg240, b.avg5, 
       b.avg60, b.avg90, b.avg_all from     
        '''
        ,"key_columns":["close"]
        ,"kpi_type":analysis_hygn_ma_kpi
    }
}

from enum import Enum
class MAS(Enum):
    MA5 = "ma5"
    MA10 = "ma10"
    MA20 = "ma20"
    MA60 = "ma60"
    MA120 = "ma120"
    MA240 = "ma240"
class MAScores(Enum):
    MA5Score = 20/8
    MA10Score = 20/8
    MA20Score = 30/8
    MA60Score = 30/8
    MA120Score = 30/8
    MA240Score = 30/8
goldenMaSortLst = [240,120,60,20,10,5]
def getGoldenMaPositions():
    json_line = {}
    for i in range(len(goldenMaSortLst)):
       json_line[goldenMaSortLst[i]] = i
    return json_line
goldenJsonMaSortLst = getGoldenMaPositions()
def getMaVal(key):
    if key == 5:
        return MAS.MA5.value
    elif key == 10:
        return MAS.MA10.value
    elif key == 20:
        return MAS.MA20.value
    elif key == 60:
        return MAS.MA60.value
    elif key == 120:
        return MAS.MA120.value
    elif key == 240:
        return MAS.MA240.value

def getMaValBYMaType(key):
    if key == MAS.MA5.value:
        return 5
    elif key == MAS.MA10.value:
        return 10
    elif key == MAS.MA20.value:
        return 20
    elif key == MAS.MA60.value:
        return 60
    elif key == MAS.MA120.value:
        return 120
    elif key == MAS.MA240.value:
        return 240


def getMaScoreVal(key):
    if key == 5:
        return MAScores.MA5Score.value
    elif key == 10:
        return MAScores.MA10Score.value
    elif key == 20:
        return MAScores.MA20Score.value
    elif key == 60:
        return MAScores.MA60Score.value
    elif key == 120:
        return MAScores.MA120Score.value
    elif key == 240:
        return MAScores.MA240Score.value

sql_temp = '''
select a.code,a.date,a.close,a.sum,b.sort_ma,b.score,b.ma5_score,b.ma20_score,b.ma60_score,b.ma120_score,b.ma240_score from
raw_20_CURRENT_AVG_MA_100_d_data a
,raw_21_CURRENT_AVG_MA_DISTANCE_d_data b
where a.code = b.code
and a.date = b.date
'''
