from project.com.Const import tables,CURRENT_MA
append_current_ma = {"ma5":5,"ma10":10,"ma20":20,"ma30":30,"ma60":60,"ma90":90,"ma120":120,"ma240":240}
append_pre_ma = {"ma4":4,"ma9":9,"ma19":19,"ma29":29,"ma60":59,"ma89":89,"ma119":119,"ma239":239}
append_current_new_ma = {"ma5":5,"ma13":13,"ma21":21,"ma34":34,"ma55":55,"ma89":89,"ma144":144,"ma233":233}
append_volume_mas = {"ma5":5,"ma21":21,"ma34":34,"ma89":89}
append_sums = {"sum3":3,"sum5":5,"sum8":8,"sum13":13,"sum21":21,"sum34":34,"sum55":55,"sum89":89,"sum144":144,"sum233":233,"sum":100000}
append_pdays = {"p3":3,"p5":5,"p8":8,"p10":10,"p13":13,"p20":20,"p21":21,"p34":34,"p55":55,"p60":60,"p89":89,"p120":120,"p144":144,"p233":233}
append_mms = {"mm3":3,"mm5":5,"mm8":8,"mm13":13,"mm21":21,"mm34":34,"mm55":55,"mm89":89,"mm144":144,"mm233":233,"mm":100000}
ma100_close_columns = ["code","date","close","high","low","close_ma5 as ma5","close_ma10 as ma10","close_ma20 as ma20","close_ma60 as ma60","close_ma120 as ma120","close_ma240 as ma240"]
ma100_high_columns =  ["code","date","close","high","low","high_ma5 as ma5","high_ma10 as ma10","high_ma20 as ma20","high_ma60 as ma60","high_ma120 as ma120","high_ma240 as ma240"]
ma100_low_columns =   ["code","date","close","high","low","low_ma5 as ma5","low_ma10 as ma10","low_ma20 as ma20","low_ma60 as ma60","low_ma120 as ma120","low_ma240 as ma240"]
ma100_lst = {"ma5":10,"ma10":10,"ma20":10,"ma60":20,"ma120":20,"ma240":30}
ma_distance_lst = {"ma5":5,"ma10":10,"ma20":20,"ma60":60,"ma120":120,"ma240":240}


MA_CURRENT_NORMAL = "00_CURRENT_MA_NORMAL"
MA_CURRENT_NEW = "01_CURRENT_MA_NEW"
MA_PRE = "02_PRE_MA_NORMAL"
VOLUME_CURRENT_MA = "03_CURRENT_VOLUME_MA"
PCT_CURRENT_SUM = "04_CURRENT_PCT_SUM"
CURRENT_PDAY = "05_CURRENT_PDAY"
CURRENT_MIN_MAX = "06_MIN_MAX"
CURRENT_MACD_KDJ = "07_MACD_KDJ"
CURRENT_CANDLE_SHAPE = "08_CANDLE_SHAPE"

MA100_SCORES_DEEP = "09_MA100_DEEP"
MA100_SCORES_CLOSE_DEEP = "09_MA100_CLOSE_DEEP"
MA100_SCORES_HIGH_DEEP = "09_MA100_HIGH_DEEP"
MA100_SCORES_LOW_DEEP = "09_MA100_LOW_DEEP"

MA_DISTANCE_DEEP = "10_MADISTANCE_DEEP"
MA_DISTANCE_CLOSE_DEEP = "10_MADISTANCE_CLOSE_DEEP"
MA_DISTANCE_HIGH_DEEP = "10_MADISTANCE_HIGH_DEEP"
MA_DISTANCE_LOW_DEEP = "10_MADISTANCE_LOW_DEEP"
CURRENT_RSI_WR = "11_CURRENT_RSI_WR"

ma_func_type = "0_ma"
sum_func_type = "1_sum"
pday_func_type = "2_pval"
minmax_func_type = "3_minmax" #
macdkdj_func_type = "4_macdkdj" #
candle_func_type = "5_candle_shpae" #
ma100_func_type = "6_ma100s" #
ma_distance_func_type = "7_madist" #
rsiwr_func_type = "8_rsiwr" #判断超买超卖
suncount_func_type = "9_suncount"
ma_lst = [
  [None,MA_CURRENT_NORMAL,tables["RAWDATAD"],append_current_ma,"code,date,close,high,low","close,high,low",ma_func_type]
, [None,MA_CURRENT_NEW,tables["RAWDATAD"],append_current_new_ma,"code,date,close,high,low","close,high,low",ma_func_type]
, [None,MA_PRE,tables["RAWDATAD"],append_pre_ma,"code,date,close","close",ma_func_type]
, [None,VOLUME_CURRENT_MA,tables["RAWDATAD"],append_volume_mas,"code,date,volume","volume",ma_func_type]
, [None,PCT_CURRENT_SUM,tables["RAWDATAD"],append_sums,"code,date,close,p_change","p_change",sum_func_type]
, [None,CURRENT_PDAY,tables["RAWDATAD"],append_pdays,"code,date,close,high,low,p_change","close,p_change",pday_func_type]
, [None,CURRENT_MIN_MAX,tables["RAWDATAD"],append_mms,"code,date,close,high,low,p_change","close,high,low",minmax_func_type]
, [None,CURRENT_MACD_KDJ,tables["RAWDATAD"],[],"code,date,close,high,low,p_change","close,high,low,p_change",macdkdj_func_type]
, [None,CURRENT_CANDLE_SHAPE,tables["RAWDATAD"],[],"code,date,close,open,high,low,p_change,preclose","close,open,high,low,p_change,preclose",candle_func_type]
, [None,CURRENT_RSI_WR,tables["RAWDATAD"],{"ma13":13,"ma21":21},"code,date,close,open,high,low,p_change,preclose","close,open,high,low,p_change,preclose",rsiwr_func_type]

]
deep_lst = [
    ["raw_%s_d_data" % (MA100_SCORES_DEEP),MA100_SCORES_CLOSE_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_close_columns), "close,high,low",ma100_func_type]
   ,["raw_%s_d_data" % (MA100_SCORES_DEEP),MA100_SCORES_HIGH_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_high_columns), "close,high,low",ma100_func_type]
   ,["raw_%s_d_data" % (MA100_SCORES_DEEP),MA100_SCORES_LOW_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_low_columns), "close,high,low",ma100_func_type]
   ,["raw_%s_d_data" % (MA_DISTANCE_DEEP), MA_DISTANCE_CLOSE_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst,",".join(ma100_close_columns), "close,high,low", ma_distance_func_type]
   ,["raw_%s_d_data" % (MA_DISTANCE_DEEP), MA_DISTANCE_HIGH_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst, ",".join(ma100_high_columns), "close,high,low", ma_distance_func_type]
   ,["raw_%s_d_data" % (MA_DISTANCE_DEEP), MA_DISTANCE_LOW_DEEP, "raw_%s_d_data" % (MA_CURRENT_NORMAL), ma100_lst,",".join(ma100_low_columns), "close,high,low", ma_distance_func_type]

]
summary_raw_kpis = []
kpis_a = [MA_CURRENT_NORMAL,MA_CURRENT_NEW,MA_PRE,VOLUME_CURRENT_MA,PCT_CURRENT_SUM]
kpis_b = [CURRENT_PDAY,CURRENT_MIN_MAX,CURRENT_MACD_KDJ,CURRENT_CANDLE_SHAPE,CURRENT_RSI_WR]
kpis_c = [MA100_SCORES_CLOSE_DEEP,MA100_SCORES_HIGH_DEEP,MA100_SCORES_LOW_DEEP]
kpis_d = [MA_DISTANCE_CLOSE_DEEP,MA_DISTANCE_HIGH_DEEP,MA_DISTANCE_LOW_DEEP]
kpis_t = [CURRENT_MACD_KDJ,CURRENT_CANDLE_SHAPE,CURRENT_RSI_WR]
#summary_raw_kpis.extend(kpis_t)
summary_raw_kpis.extend(kpis_a)
summary_raw_kpis.extend(kpis_b)
summary_raw_kpis.extend(kpis_c)
summary_raw_kpis.extend(kpis_d)
tables_summary_raw = {}
def gen_table_summary():
    lsts = []
    lsts.extend(ma_lst)
    lsts.extend(deep_lst)
    for ma in lsts:
        dest_table,kpi_type,src_table,lst,cols,key,func = ma
        if dest_table is None:
            dest_table = "raw_%s_d_data" % (kpi_type)
        tables_summary_raw["%s_D" % (kpi_type)] = {
            "src_table": src_table
            , "dest_table": dest_table
            , "ktype" : kpi_type
            , "function": func
            , "lst": lst
            , "columns": cols
            , "key_column": key
        }

    #return tables_summary
gen_table_summary()
#print(tables_summary_raw)
STARTN    = "start_negative"
STARTP    = "start_positive"
SMALLN    = "small_negative"
SMALLP    = "small_positive"
MIDN      = "mid_negative"
MIDP      = "mid_positive"
LARGEN    = "large_negative"
LARGEP    = "large_positive"

SMALLPCTN = "small_pct_negative"
SMALLPCTP = "small_pct_positive"
MIDPCTN   = "mid_pct_negative"
MIDPCTP   = "mid_pct_positive"
LARGEPCTN = "large_pct_negative"
LARGEPCTP = "large_pct_positive"

# #跳空 长实体 > 3.5
# STARTN_0  = "start_negative_jump_over_over_bodyspec"
# STARTP_0  = "start_positive_jump_over_over_bodyspec"
# SMALLN_0  = "small_negative_jump_over_over_bodyspec"
# SMALLP_0  = "small_positive_jump_over_over_bodyspec"
# MIDN_0  =   "mid_negative_jump_over_over_bodyspec"
# MIDP_0  =   "mid_positive_jump_over_over_bodyspec"
# LARGEN_0  = "large_negative_jump_over_over_bodyspec"
# LARGEP_0  = "large_positive_jump_over_over_bodyspec"
# # 跳空 短实体 > 3.5
# STARTN_1  = "start_negative_jump_over_less_bodyspec"
# STARTP_1  = "start_positive_jump_over_less_bodyspec"
# SMALLN_1  = "small_negative_jump_over_less_bodyspec"
# SMALLP_1  = "small_positive_jump_over_less_bodyspec"
# MIDN_1  =   "mid_negative_jump_over_less_bodyspec"
# MIDP_1  =   "mid_positive_jump_over_less_bodyspec"
# LARGEN_1  = "large_negative_jump_over_less_bodyspec"
# LARGEP_1  = "large_positive_jump_over_less_bodyspec"
# # 短实体 > 3.5
# STARTN_2  = "start_negative_over_pctspec"
# STARTP_2  = "start_positive_over_pctspec"
# SMALLN_2  = "small_negative_over_pctspec"
# SMALLP_2  = "small_positive_over_pctspec"
# MIDN_2  =   "mid_negative_over_pctspec"
# MIDP_2  =   "mid_positive_over_pctspec"
# LARGEN_2  = "large_negative_over_pctspec"
# LARGEP_2  = "large_positive_over_pctspec"
# # 长实体 不大于 3.5
# STARTN_3  = "start_negative_less_pctspec"
# STARTP_3  = "start_positive_less_pctspec"
# SMALLN_3  = "small_negative_less_pctspec"
# SMALLP_3  = "small_positive_less_pctspec"
# MIDN_3  =   "mid_negative_less_pctspec"
# MIDP_3  =   "mid_positive_less_pctspec"
# LARGEN_3  = "large_negative_less_pctspec"
# LARGEP_3  = "large_positive_less_pctspec"

# type_map = {
#      STARTN:{0:STARTN_0,1:STARTN_1,2:STARTN_2,3:STARTN_3}
#     ,STARTP:{0:STARTP_0,1:STARTP_1,2:STARTP_2,3:STARTP_3}
#     ,SMALLN:{0:SMALLN_0,1:SMALLN_1,2:SMALLN_2,3:SMALLN_3}
#     ,SMALLP:{0:SMALLP_0,1:SMALLP_1,2:SMALLP_2,3:SMALLP_3}
#     ,MIDN:{0:MIDN_0,1:MIDN_1,2:MIDN_2,3:MIDN_3}
#     ,MIDP:{0:MIDP_0,1:MIDP_1,2:MIDP_2,3:MIDP_3}
#     ,LARGEN:{0:LARGEN_0,1:LARGEN_1,2:LARGEN_2,3:LARGEN_3}
#     ,LARGEP:{0:LARGEP_0,1:LARGEP_1,2:LARGEP_2,3:LARGEP_3}
# }
# type_proprity = {
#      STARTN:"1#N"
#     ,STARTP:"1#p"
#     ,SMALLN:"2#N"
#     ,SMALLP:"2#P"
#     ,MIDN:"3#N"
#     ,MIDP:"3#P"
#     ,LARGEN:"4#N"
#     ,LARGEP:"4#P"
# }
0.382*0*618
0.618

star_ucl_p,star_ucl_n,star_lcl_p,star_lcl_n = 0.901001,0,-0.901
small_ucl_p,small_ucl_n,small_lcl_p,small_lcl_n = 2.36001,0,-2.36,0
mid_ucl_p,mid_ucl_n,mid_lcl_p,mid_lcl_n = 6.18001,
large_ucl_p,large_ucl_n,large_lcl_p,large_lcl_n = 2.36001,0
strong_ucl_p,strong_ucl_n,strong_lcl_p,strong_lcl_n = 2.36001,0


k_pct = {
   SMALLPCTN:{"ucl":0,"lcl":-2.36}
  ,SMALLPCTP:{"ucl":2.36001,"lcl":0}
  ,MIDPCTN:{"ucl":-2.36,"lcl":-6.18}
  ,MIDPCTP:{"ucl":6.180001,"lcl":2.36001}
  ,LARGEPCTN:{"ucl":-6.180001,"lcl":-100}
  ,LARGEPCTP:{"ucl":100,"lcl":6.180001}
}

k_spec_body = {
   STARTN:{"ucl":0,"lcl":-0.9016}  #
  ,STARTP:{"ucl":0.90163,"lcl":0}   #
  ,SMALLN:{"ucl":-0.9999,"lcl":-3.5} #
  ,SMALLP:{"ucl":3.5001,"lcl":1}   #
  ,MIDN  :{"ucl":-3.5,"lcl":-7}
  ,MIDP  :{"ucl":7,"lcl":3.5001}
  ,LARGEN:{"ucl":-6.999,"lcl":-100}
  ,LARGEP:{"ucl":100,"lcl":7}
}

limit_spec = {}


ctypes = []
ALLF   = "all_full"
HEADF  = "head_full"
FOOTF  = "foot_full"
HEADL  = "upline_long"
FOOTL  = "downline_long"
HFEQL  = "up_down_line_equal"
code_maps = {
STARTN:"A1N",
STARTP:"A1P",
SMALLN:"A2N",
SMALLP:"A2P",
MIDN  :"A3N",
MIDP  :"A3P",
LARGEN:"A4N",
LARGEP:"A4P",

SMALLPCTN:"B1N",
SMALLPCTP:"B1P",
MIDPCTN  :"B2N",
MIDPCTP  :"B2P",
LARGEPCTN:"B3N",
LARGEPCTP:"B3P",
 ALLF  :"E0"
,HEADF :"E1"
,FOOTF :"E2"
,HEADL :"E3"
,FOOTL :"E4"
,HFEQL :"E5"
}
pct_types = [
     code_maps[SMALLPCTN]
    ,code_maps[SMALLPCTP]
    ,code_maps[MIDPCTN  ]
    ,code_maps[MIDPCTP  ]
    ,code_maps[LARGEPCTN]
    ,code_maps[LARGEPCTP]
]
shape_types = [
     code_maps[STARTN]
    ,code_maps[STARTP]
    ,code_maps[SMALLN]
    ,code_maps[SMALLP]
    ,code_maps[MIDN  ]
    ,code_maps[MIDP  ]
    ,code_maps[LARGEN]
    ,code_maps[LARGEP]
]
prop_types = [
    code_maps[ALLF]
   ,code_maps[HEADF]
   ,code_maps[FOOTF]
   ,code_maps[HEADL]
   ,code_maps[FOOTL]
   ,code_maps[HFEQL]
]
import itertools,collections
num = 0
all_types = list(itertools.product(pct_types,shape_types,prop_types))
all_map_types = collections.OrderedDict(list(zip(list(map(lambda x:"#".join(x),all_types)),range(len(all_types)))))

table_maps = {}
def genTables():
    lsts = []
    lsts.extend(kpis_a)
    lsts.extend(kpis_b)
    lsts.extend(kpis_c)
    lsts.extend(kpis_d)
    for kpi_type in lsts:
        table =  "raw_%s_d_data" % (kpi_type)
        table_maps[kpi_type] = table
genTables()


# for line in all_types:
#     num = num + 1
#     print(line)
# print(num)
