from project.com.Const import conf_file,home,sysmbol
dest_file = home + sysmbol + "summary_merge_1.db"

CANDLE_SHAPE_SUMMARY = "summary_candle_shape"
summary_types = [CANDLE_SHAPE_SUMMARY]
table_merge_summary = {CANDLE_SHAPE_SUMMARY:"raw_d_%s" %(CANDLE_SHAPE_SUMMARY)}