import pandas as pd
import json
def _ma(df,type, n=10):
    if type == 'tma':
        actnum = n - 1
    elif type == 'pma':
        actnum = n
    elif type == 'nma':
        actnum = n - 2

    pv = pd.DataFrame()
    pv['code'] = df['code']
    pv['date'] = df['date']
    pv['close'] = df['close']
    pv['actnum'] = len(df) * [actnum]
    pv['type'] = len(df) * [type]
    pv['days'] = len(df) * [n]
    pv['mav'] = df.close.rolling(actnum).mean()
    return pv
def getMas(df,save=20,date=None):
    mas = {"pma":[5,10,20],"tma":[5,10,20],"nma":[5,10,20]}
    dfs = []
    for k,v in mas.items():
        for n in v:
            ndf = _ma(df,k,n)
            dfs.append(ndf)
    rdf = pd.concat(dfs)
    rdfs = list(rdf.groupby(rdf["date"]))[-1*save:]
    #rdf = pd.concat(rdfs)
    rdf = pd.concat(list(map(lambda x:x[1],rdfs)))

    if date is not None:
       rdf = rdf[rdf["date"]==date]
    return rdf

def getVal(df,column,column_val,column_name_01,colume_name_01_val,rcolumn_name):
    if rcolumn_name is not None:
        rdf = df[(df[column] == column_val)&(df[column_name_01] == colume_name_01_val)][rcolumn_name].values[0]
    else:
        rdf = df[(df[column] == column_val)][rcolumn_name].values[0]
    rdf = round(rdf,3)
    return rdf
def calCloseWithInputMa(maval,n,tma):
    predict = round(maval * n - tma * (n - 1), 3)
    return predict

def calMaWithInputClose(inval,n,tma):
    nextma = (tma * (n-1) + inval)/n
    return nextma
