from dao.kpi.models.funcs import *
class MasObj():
    def __init__(self,df):
        self.df = df
        self.close = df["close"].values[0]
        self.date = df["date"].values[0]
        self.code = df["code"].values[0]

        self.ucl = self.close * 1.1
        self.lcl = self.close * 0.9

        self.pma5 = getVal(df, "actnum", 5, "type", "pma", "mav")
        self.tma5 = getVal(df, "actnum", 4, "type", "tma", "mav")

        self.pma10 = getVal(df, "actnum", 10, "type", "pma", "mav")
        self.tma10 = getVal(df, "actnum", 9, "type", "tma", "mav")

        self.pma20 = getVal(df, "actnum", 20, "type", "pma", "mav")
        self.tma20 = getVal(df, "actnum", 19, "type", "tma", "mav")

        self.distance5to10 = (self.pma5 - self.pma10)
        self.distance5to20 = (self.pma5 - self.pma20)
        self.distance10to20 = (self.pma10 - self.pma20)
        self.log = {
            "code": self.code,
            "date": self.date,
            "close": self.close,
            "pma5": self.pma5,
            "pma10": self.pma10,
            "pma20": self.pma20,

            "distance5to10":  round(self.distance5to10,3),
            "distance5to20":  round(self.distance5to20,3),
            "distance10to20": round(self.distance10to20,3),
        }

    def predictWithInput(self,inputs):
        lines = []
        for inputline in inputs:
            date=inputline[0]
            type = inputline[1]
            input = inputline[2]

            next5 = input
            close5 = calCloseWithInputMa(next5,5,self.tma5)
            if self.lcl < close5 <self.ucl:
                line = self.log.copy()
                next10 = calMaWithInputClose(close5,10,self.tma10)
                next20 = calMaWithInputClose(close5,20,self.tma20)
                self.nextdistance5to10 = (next5 - next10)
                self.nextdistance5to20 = (next5 - next20)
                self.nextdistance10to20 = (next10 - next20)
                #self.distance5to10 - self.distance5to10
                line["nextdistance5to10"] =  round(self.nextdistance5to10,3)
                line["nextdistance5to20"] =  round(self.nextdistance5to20,3)
                line["nextdistance10to20"] = round(self.nextdistance10to20,3)
                line["xdate"] = date
                line["xtype"] = type
                line["inval"] = input
                line["predclose"] = close5

                #line["rate"] =
                a = self.distance5to10 - self.nextdistance5to10
                b = self.distance5to20 - self.nextdistance5to20
                c = self.distance10to20 - self.nextdistance10to20
                if self.nextdistance5to10 > self.distance5to10 or self.nextdistance5to20 > self.distance5to20:
                    lines.append(line)
        lines.sort(key=lambda x: x["predclose"])

        return lines
        #pma10 = getVal(df, "actnum", 10, "type", "pma", "mav")
