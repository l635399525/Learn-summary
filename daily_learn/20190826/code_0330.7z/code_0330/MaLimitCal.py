from com.DbTool import *
from const import raw_sql_with_limit
from dao.kpi.models.RawMaObjs import *
from dao.kpi.models.RObj import MasObj
if __name__ == '__main__':
    code = "603713"
    conn = getConnByCodePath(code,path="/Users/lili/data/0315/raw")
    df = query("%s order by date asc" %(raw_sql_with_limit),conn)
    from dao.kpi.models.funcs import *
    ndf = getMas(df,date="2020-03-24")
    mo = MasObj(ndf)
    closes = df["close"].tolist()
    opens = df["open"].tolist()
    highs = df["high"].tolist()
    lows = df["low"].tolist()
    dates = df["date"].tolist()
    open=["open"]*len(dates)
    close = ["close"] * len(dates)
    high = ["high"] * len(dates)
    low = ["low"] * len(dates)
    inputs = []
    inputs = inputs + list(zip(dates,close,closes))[-4:]
    inputs = inputs + list(zip(dates, open, opens))[-4:]
    inputs = inputs + list(zip(dates, high, highs))[-4:]
    inputs = inputs + list(zip(dates, low, lows))[-4:]
    inputs.append((mo.date,"tma5",mo.tma5))
    #inputs.append([(mo.date,"tma10",mo.tma10)])
    #inputs.append([(mo.date,"tma20",mo.tma20)])

    lines = mo.predictWithInput(inputs)
    for line in lines:
        print(line)
    #lines = json.loads(df.to_json(orient='records'))
    #mll = MaLimitLines(df)
    #lines = mll.m5lines.genlines()
    #for line in lines:
    #    print(line)
    #print(len(df))