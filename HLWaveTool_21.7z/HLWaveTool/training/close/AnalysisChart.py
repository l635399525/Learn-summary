import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
pn_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")

def getShowChartClose():
    sql = '''
    select a.code, a.work_date, ts,
       av1_5, av1_d_5, av1_d_deg_5, av2_5, av2_d_5, av2_d_deg_5, av3_5, av3_d_5, av3_d_deg_5, av4_5, av4_d_5, av4_d_deg_5, av5_5, av5_d_5, av5_d_deg_5,
       av1_4, av1_d_4, av1_d_deg_4, av2_4, av2_d_4, av2_d_deg_4, av3_4, av3_d_4, av3_d_deg_4, av4_4, av4_d_4, av4_d_deg_4,
       cls_a, cls_b, ny from
(select a.code, a.work_date, a.ts,
       av1 as av1_5 ,b.av1_d as av1_d_5,b.av1_d_deg as av1_d_deg_5,
       av2 as av2_5 ,b.av2_d as av2_d_5,b.av2_d_deg as av2_d_deg_5,
       av3 as av3_5 ,b.av3_d as av3_d_5,b.av3_d_deg as av3_d_deg_5,
       av4 as av4_5 ,b.av4_d as av4_d_5,b.av4_d_deg as av4_d_deg_5,
       av5 as av5_5 ,b.av5_d as av5_d_5,b.av5_d_deg as av5_d_deg_5
from
     raw_data_ana_cnts_a a,raw_data_ana_cnts_degress_normal b
where a.code = b.code and a.work_date = b.work_date) a,
(select a.code, a.work_date,
       av1 as av1_4 ,b.av1_d as av1_d_4,b.av1_d_deg as av1_d_deg_4,
       av2 as av2_4 ,b.av2_d as av2_d_4,b.av2_d_deg as av2_d_deg_4,
       av3 as av3_4 ,b.av3_d as av3_d_4,b.av3_d_deg as av3_d_deg_4,
       av4 as av4_4 ,b.av4_d as av4_d_4,b.av4_d_deg as av4_d_deg_4
from
     raw_data_ana_cnts_conv4_a a,raw_data_ana_cnts_degress_conv b
where a.code = b.code and a.work_date = b.work_date) b
, (select code, work_date,cls_a,cls_b from raw_data_ana_cnts_rate) c
,raw_data_ana_cnts_ny_H2V_nys d
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.work_date
    '''
    df = query(sql,an_conn)
    insert(df,train_conn,'raw_show_chart_close')
def getShowChartDegressPN():
    sql = '''
    select a.code, a.work_date, ts,
       av1_5, av1_d_5, av1_d_deg_5, av2_5, av2_d_5, av2_d_deg_5, av3_5, av3_d_5, av3_d_deg_5, av4_5, av4_d_5, av4_d_deg_5, av5_5, av5_d_5, av5_d_deg_5,
       av1_4, av1_d_4, av1_d_deg_4, av2_4, av2_d_4, av2_d_deg_4, av3_4, av3_d_4, av3_d_deg_4, av4_4, av4_d_4, av4_d_deg_4,
       cls_a, cls_b, ny from
(select a.code, a.work_date,
       av1 as av1_5 ,b.av1_d as av1_d_5,b.av1_d_deg as av1_d_deg_5,
       av2 as av2_5 ,b.av2_d as av2_d_5,b.av2_d_deg as av2_d_deg_5,
       av3 as av3_5 ,b.av3_d as av3_d_5,b.av3_d_deg as av3_d_deg_5,
       av4 as av4_5 ,b.av4_d as av4_d_5,b.av4_d_deg as av4_d_deg_5,
       av5 as av5_5 ,b.av5_d as av5_d_5,b.av5_d_deg as av5_d_deg_5
from
     raw_data_ana_cnts_a a,raw_data_ana_cnts_degress_normal b
where a.code = b.code and a.work_date = b.work_date) a,
(select a.code, a.work_date,
       av1 as av1_4 ,b.av1_d as av1_d_4,b.av1_d_deg as av1_d_deg_4,
       av2 as av2_4 ,b.av2_d as av2_d_4,b.av2_d_deg as av2_d_deg_4,
       av3 as av3_4 ,b.av3_d as av3_d_4,b.av3_d_deg as av3_d_deg_4,
       av4 as av4_4 ,b.av4_d as av4_d_4,b.av4_d_deg as av4_d_deg_4
from
     raw_data_ana_cnts_conv4_a a,raw_data_ana_cnts_degress_conv b
where a.code = b.code and a.work_date = b.work_date) b
, (select code, work_date,cls_a,cls_b from raw_data_ana_cnts_rate) c
,raw_data_ana_cnts_ny_H2V_nys d
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.work_date
    '''
    df = query(sql,pn_conn)
    insert(df,train_conn,'raw_show_chart_degress_PN')
def move():
    sql = '''
    select a.code, a.work_date, ny, t,b.ts from raw_data_ana_cnts_ny_H2V_nys a,raw_data_ana_cnts b
where a.code = b.code and a.work_date = b.work_date
    '''
    df = query(sql,an_conn)
    insert(df,pn_conn,'raw_data_ana_cnts_ny_H2V_nys')
if __name__ == '__main__':
    getShowChartClose()
    print("----")
    getShowChartDegressPN()
    print("----")