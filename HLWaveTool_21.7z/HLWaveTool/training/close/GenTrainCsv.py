import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
pn_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")
def genTrainCSVA():
    tables = [ 'ClsChange_ana_ab_overs_kpi_chart_Close_1'
              ,'ClsChange_ana_ab_overs_kpi_chart_Close_3'
              ,'ClsChange_ana_ab_overs_kpi_chart_Close_5'
              ,'ClsChange_ana_ab_overs_kpi_chart_Degress_1'
              ,'ClsChange_ana_ab_overs_kpi_chart_Degress_3'
              ,'ClsChange_ana_ab_overs_kpi_chart_Degress_5']
    for table in tables:
        sql = '''
       select distinct a.code, a.work_date,ts,cls_a,cls_b, ny, afr, afr3, afr4, afr5, stepts, afr_csum,ny as pny,
           afr3_csum, afr4_csum, afr5_csum, yar_csum, yar3_csum, yar4_csum, yar5_csum, ny_csum
              from  {table} a,(select code,work_date,ts from raw_data_ana_cnts_ny_H2V_nys) b
where a.code = b.code and a.work_date = b.work_date
        '''.format(table=table)
        df = query(sql,train_conn)
        dfs = df.groupby('code')
        rdfs = []
        for code,idf in dfs:
            idf = idf.sort_values(by=['work_date'])
            idf['ny'] = idf.ny.shift(-1).values
            idf = idf.dropna()
            rdfs.append(idf)
        fdf = pd.concat(rdfs)
        fdf.to_csv(r'D:\codes\data\2022\training\%saaa.csv' %(table))
        print("---%s" %(table))
def genTrainCSVB():
    tables = [ 'ClsChange_ana_ab_overs_kpi_chart_Close_1'
              ,'ClsChange_ana_ab_overs_kpi_chart_Close_3'
              ,'ClsChange_ana_ab_overs_kpi_chart_Close_5'
              ,'ClsChange_ana_ab_overs_kpi_chart_Degress_1'
              ,'ClsChange_ana_ab_overs_kpi_chart_Degress_3'
              ,'ClsChange_ana_ab_overs_kpi_chart_Degress_5']
    for table in tables:
        sql = '''
       select distinct a.code, a.work_date,ts,cls_a,cls_b, ny, afr, afr3, afr4, afr5, stepts, afr_csum,ny as pny,
           afr3_csum, afr4_csum, afr5_csum, yar_csum, yar3_csum, yar4_csum, yar5_csum, nyar_csum, nyar3_csum, nyar4_csum, nyar5_csum, ny_csum
              from  {table} a,(select code,work_date,ts from raw_data_ana_cnts_ny_H2V_nys) b
where a.code = b.code and a.work_date = b.work_date
        '''.format(table=table)
        df = query(sql,train_conn)
        dfs = df.groupby('code')
        rdfs = []
        for code,idf in dfs:
            idf = idf.sort_values(by=['work_date'])
            idf['ny'] = idf.ny.shift(-1).values
            idf = idf.dropna()
            rdfs.append(idf)
        fdf = pd.concat(rdfs)
        fdf.to_csv(r'D:\codes\data\2022\training\%sbbb.csv' %(table))
        print("---%s" %(table))
def genTrainDataShowChart():
    sql1 = '''
    select distinct code, work_date, ts, av1_5, av1_d_5, av1_d_deg_5, av2_5, av2_d_5, av2_d_deg_5, av3_5, av3_d_5, av3_d_deg_5, av4_5, av4_d_5, av4_d_deg_5, av5_5, av5_d_5, av5_d_deg_5, av1_4, av1_d_4, av1_d_deg_4, av2_4, av2_d_4, av2_d_deg_4, av3_4, av3_d_4, av3_d_deg_4, av4_4, av4_d_4, av4_d_deg_4, cls_a, cls_b, ny,ny as pny from raw_show_chart_close
    '''
    sql2 = '''
    select code, work_date, ts, av1_5, av1_d_5, av1_d_deg_5, av2_5, av2_d_5, av2_d_deg_5, av3_5, av3_d_5, av3_d_deg_5, av4_5, av4_d_5, av4_d_deg_5, av5_5, av5_d_5, av5_d_deg_5, av1_4, av1_d_4, av1_d_deg_4, av2_4, av2_d_4, av2_d_deg_4, av3_4, av3_d_4, av3_d_deg_4, av4_4, av4_d_4, av4_d_deg_4, cls_a, cls_b, ny,ny as pny from raw_show_chart_degress_PN
    '''
    df = query(sql1, train_conn)
    dfs = df.groupby('code')
    rdfs = []
    for code, idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        idf['ny'] = idf.ny.shift(-1).values
        idf = idf.dropna()
        rdfs.append(idf)
    fdf = pd.concat(rdfs)
    fdf.to_csv(r'D:\codes\data\2022\training\%s.csv' % ('raw_show_chart_close_train'))
    df = query(sql2, train_conn)
    dfs = df.groupby('code')
    rdfs = []
    for code, idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        idf['ny'] = idf.ny.shift(-1).values
        idf = idf.dropna()
        rdfs.append(idf)
    fdf = pd.concat(rdfs)
    fdf.to_csv(r'D:\codes\data\2022\training\%s.csv' % ('raw_show_chart_degress_PN_train'))


if __name__ == '__main__':
    genTrainCSVB()
    #genTrainDataShowChart()