import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
pn_conns = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
an_conns = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")

def anaNYSummary():
    sql = '''
    select distinct a.code, a.work_date, any, ny, a.t,b.cls_a,b.cls_b,c.ts from
(select a.code,a.work_date,a.ny as any
     ,case when b.ny is null then a.ny else a.ny + b.ny end as ny
     ,case when b.t  is null then 'C' else b.t end as t
 from
(select code,work_date,(nhc_t - min(hc_t_4,hc_t_3,hc_t_2,hc_t_1)) - 2 as  ny from raw_data_ana_cnts_ny_H2V) a
left outer join
(select a.code,a.date,ny + ny1 as ny,'A' as t from raw_data_ana_cnts_ny3_reverse a,(select a.code, a.work_date,
       nhc_t -  hc_t_4 AS ny,nhc_t - hc_t_3 as ny1 from raw_data_ana_cnts_ny_H2V a where  ny >= 2) b
where a.code = b.code and a.date = b.work_date
union
select code,date,a0 + a1 + a2 as ny,'B' as t from raw_data_ana_cnts_ny3_reverse where a0 + a1 + a2 = 3 and ts = 1
and code || date not in
(select code||date as key from
(select a.code,a.date from raw_data_ana_cnts_ny3_reverse a,(select a.code, a.work_date,
       nhc_t -  hc_t_4 AS ny,nhc_t - hc_t_3 as ny1 from raw_data_ana_cnts_ny_H2V a where  ny >= 2) b
where a.code = b.code and a.date = b.work_date))) b
on a.code = b.code and a.work_date=b.date) a,raw_data_ana_cnts_rate b,raw_data_ana_cnts c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date

    '''
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")

    df = query(sql,an_conn)
    insert(df,an_conn,'raw_data_ana_cnts_ny_H2V_nys_final')
    insert(df,pn_conns,'raw_data_ana_cnts_ny_H2V_nys_final')
    insert(df,train_conn,'raw_data_ana_cnts_ny_H2V_nys_final')


def _getRateClsChangePN(conn,table):
    SQL = '''
    select a.code,a.work_date,a.cls_a,a.cls_b,d.ts,cls_b_d,cls_b_d_deg,cls_a_d,cls_a_d_deg
    ,d.ny,d.t
    from raw_data_ana_cnts_rate a,raw_data_ana_cnts b
    ,raw_data_ana_cnts_degress_arate c,raw_data_ana_cnts_ny_H2V_nys_final d
    where a.code = b.code and a.work_date = b.work_date
    and a.code = c.code and a.work_date = c.work_date
    and a.code = d.code and a.work_date = d.work_date
    '''
    df = query(SQL, conn)
    dfs = df.groupby('code')
    rdfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        rdf = idf[['code','work_date','ts','t','ny','cls_a','cls_b']]
        for i in range(1,10):
            rdf['cls_a_%s' %(i)]  = idf['cls_a'].shift(i).values
            rdf['cls_b_%s' %(i)] = idf['cls_b'].shift(i).values
        rdfs.append(rdf)
        print("%s %s" %(code,len(rdfs)))
    rdf = pd.concat(rdfs)
    insert(rdf,train_conn,table)
def getRateClsChangePNClose():
    _getRateClsChangePN(an_conns,'ClsChange_Close')
def getRateClsChangePNDegress():
    _getRateClsChangePN(pn_conns,'ClsChange_Degress')
def _analysisOvers(src_table,dest_table,conn,score=3):
    sql = '''
    select 'A' as t,cls_a as cls,count(*) as acnt from {src_table} where  ny >= {score} group by cls_a
union
select 'B' as t,cls_b as cls,count(*) as acnt from {src_table} where  ny >= {score} group by cls_b
    '''.format(score=score,src_table=src_table)
    df = query(sql,conn)
    dfs = df.groupby('t')
    rdfs = []
    for t,idf in dfs:
        for i in range(len(idf)):
            line = dict(idf.iloc[i])
            tt = line['t']
            if tt == 'A':
                sql = '''
                    select cls_a as n_cls
                    ,sum(af1+af2+af3+af4+af5) as afs5
                    ,sum(af1+af2+af3+af4+af5+af6+af7) as afs7
                    ,sum(af1+af2+af3+af4+af5+af6+af7+af8+af9) as afs9
                    from
                    (select cls_a,
                       case when cls_a_1 == '{c}' then 1 else 0 end as af1,
                       case when cls_a_2 == '{c}' then 1 else 0 end as af2,
                       case when cls_a_3 == '{c}' then 1 else 0 end as af3,
                       case when cls_a_4 == '{c}' then 1 else 0 end as af4,
                       case when cls_a_5 == '{c}' then 1 else 0 end as af5, 
                       case when cls_a_6 == '{c}' then 1 else 0 end as af6,
                       case when cls_a_7 == '{c}' then 1 else 0 end as af7,
                       case when cls_a_8 == '{c}' then 1 else 0 end as af8,
                       case when cls_a_9 == '{c}' then 1 else 0 end as af9 
                       from {src_table} where  ny >= {score})
                    group by cls_a
                '''.format(c = line['cls'],score=score,src_table=src_table)
            elif tt == 'B' :
                sql = '''
                    select cls_b as n_cls
                    ,sum(af1+af2+af3+af4+af5) as afs5                
                    ,sum(af1+af2+af3+af4+af5+af6+af7) as afs7        
                    ,sum(af1+af2+af3+af4+af5+af6+af7+af8+af9) as afs9
                    from
                    (select cls_b,
                       case when cls_b_1 == '{c}' then 1 else 0 end as af1,
                       case when cls_b_2 == '{c}' then 1 else 0 end as af2,
                       case when cls_b_3 == '{c}' then 1 else 0 end as af3,
                       case when cls_b_4 == '{c}' then 1 else 0 end as af4,
                       case when cls_b_5 == '{c}' then 1 else 0 end as af5, 
                       case when cls_b_6 == '{c}' then 1 else 0 end as af6,
                       case when cls_b_7 == '{c}' then 1 else 0 end as af7,
                       case when cls_b_8 == '{c}' then 1 else 0 end as af8,
                       case when cls_b_9 == '{c}' then 1 else 0 end as af9 
                       from {src_table}  where  ny >= {score})
                    group by cls_b
                                '''.format(c=line['cls'],score=score,src_table=src_table)
            rdf = query(sql,conn)
            rdf['acnt'] = line['acnt']
            rdf['p_cls']  = line['cls']
            rdfs.append(rdf)
    df = pd.concat(rdfs)
    #insert(df, an_conn, 'ClsChange_ana_ab_over%s' %(score))
    insert(df, train_conn, dest_table)
def _analysisOversSums(conn,type):
    table3 = 'ClsChange_ana_ab_over3_%s' %(type)
    table4 = 'ClsChange_ana_ab_over4_%s' %(type)
    table5 = 'ClsChange_ana_ab_over5_%s' %(type)
    table_raw = 'ClsChange_%s' %(type)
    sql = '''
    select cls,
afs5_3, afs7_3, afs9_3,
afs5_4, afs7_4, afs9_4,
afs5_5, afs7_5, afs9_5, cnt,
ar5_3, ar7_3, ar9_3,
ar5_4, ar7_4, ar9_4,
ar5_5, ar7_5, ar9_5,
round(ar5_3*afs5_3,2) as kpi5_3, round(ar7_3*afs7_3,2) as kpi7_3, round(ar9_3*afs9_3,2) as kpi9_3,
round(ar5_4*afs5_4,2) as kpi5_4, round(ar7_4*afs7_4,2) as kpi7_4, round(ar9_4*afs9_4,2) as kpi9_4,
round(ar5_5*afs5_5,2) as kpi5_5, round(ar7_5*afs7_5,2) as kpi7_5, round(ar9_5*afs9_5,2) as kpi9_5
from
(select a.cls, afs5_3, afs7_3, afs9_3, afs5_4, afs7_4, afs9_4, afs5_5, afs7_5, afs9_5, cnt
, round(afs5_3*ar3*1.0/cnt,5) as ar5_3
, round(afs7_3*ar3*1.0/cnt,5) as ar7_3
, round(afs9_3*ar3*1.0/cnt,5) as ar9_3
, round(afs5_4*ar4*1.0/cnt,5) as ar5_4
, round(afs7_4*ar4*1.0/cnt,5) as ar7_4
, round(afs9_4*ar4*1.0/cnt,5) as ar9_4
, round(afs5_5*ar5*1.0/cnt,5) as ar5_5
, round(afs7_5*ar5*1.0/cnt,5) as ar7_5
, round(afs9_5*ar5*1.0/cnt,5) as ar9_5
from
(select p_cls as cls
      ,sum(afs5) as afs5_3
      ,sum(afs7) as afs7_3
      ,sum(afs9) as afs9_3
 from {table3} group by p_cls) a,
(select p_cls as cls
      ,sum(afs5) as afs5_4
      ,sum(afs7) as afs7_4
      ,sum(afs9) as afs9_4
 from {table4} group by p_cls) b,
(select p_cls as cls
      ,sum(afs5) as afs5_5
      ,sum(afs7) as afs7_5
      ,sum(afs9) as afs9_5
 from {table5} group by p_cls) c,
 (select a.cls,cnt,acnt3,acnt4,acnt5
     ,round(acnt3*1.0/a.cnt,3) as ar3
     ,round(acnt4*1.0/a.cnt,3) as ar4
     ,round(acnt5*1.0/a.cnt,3) as ar5
from
(select cls_a as cls,count(*) as cnt   from {table_raw} group by cls_a) a,
(select cls_a as cls,count(*) as acnt3 from {table_raw} where ny >=3 group by cls_a) b,
(select cls_a as cls,count(*) as acnt4 from {table_raw} where ny >=4 group by cls_a) c,
(select cls_a as cls,count(*) as acnt5 from {table_raw} where ny >=5 group by cls_a) d
where a.cls = b.cls and a.cls = c.cls and a.cls = d.cls
union
select a.cls,cnt,acnt3,acnt4,acnt5
     ,round(acnt3*1.0/a.cnt,3) as ar3
     ,round(acnt4*1.0/a.cnt,3) as ar4
     ,round(acnt5*1.0/a.cnt,3) as ar5
from
(select cls_b as cls,count(*) as cnt   from {table_raw} group by cls_b) a,
(select cls_b as cls,count(*) as acnt3 from {table_raw} where ny >=3 group by cls_b) b,
(select cls_b as cls,count(*) as acnt4 from {table_raw} where ny >=4 group by cls_b) c,
(select cls_b as cls,count(*) as acnt5 from {table_raw} where ny >=5 group by cls_b) d
where a.cls = b.cls and a.cls = c.cls and a.cls = d.cls) d
where a.cls = b.cls  and a.cls = c.cls and a.cls = d.cls) order by cls
    '''.format(table3=table3,table4=table4,table5=table5,table_raw=table_raw)
    print(sql)
    df = query(sql, conn)
    insert(df, conn, 'ClsChange_ana_ab_overs_%s' %(type))
def _anaSpec(conn,type):
    table = 'ClsChange_ana_ab_overs_%s' %(type)
    sql = '''
    select  kpi5_3, kpi7_3, kpi9_3, kpi5_4, kpi7_4, kpi9_4, kpi5_5, kpi7_5, kpi9_5 from {table}
    '''.format(table=table)
    df = query(sql, conn)
    columns = ['kpi5_3', 'kpi7_3', 'kpi9_3', 'kpi5_4', 'kpi7_4', 'kpi9_4', 'kpi5_5', 'kpi7_5', 'kpi9_5']
    data_map = {}
    for column in columns:
        datas = df[column].values
        datas = datas[np.argsort(datas)]
        ucl_v = datas[-34]
        specs = datas[-55]
        max_val = max(datas)
        data_map[column] = [ucl_v,specs,max_val]
    sql = '''
        select cls
           ,kpi5_3,case when kpi5_3 >= {ucl_v_5_3} then  round((({ucl_v_5_3} - {specs_5_3})/{specs_5_3})*(1+kpi5_3/{max_5_3}),3) else round((kpi5_3 - {specs_5_3})/{specs_5_3},3) end as afr5_3
           ,kpi7_3,case when kpi7_3 >= {ucl_v_7_3} then  round((({ucl_v_7_3} - {specs_7_3})/{specs_7_3})*(1+kpi7_3/{max_7_3}),3) else round((kpi7_3 - {specs_7_3})/{specs_7_3},3) end as afr7_3
           ,kpi9_3,case when kpi9_3 >= {ucl_v_9_3} then  round((({ucl_v_9_3} - {specs_9_3})/{specs_9_3})*(1+kpi9_3/{max_9_3}),3) else round((kpi9_3 - {specs_9_3})/{specs_9_3},3) end as afr9_3
           ,kpi5_4,case when kpi5_4 >= {ucl_v_5_4} then  round((({ucl_v_5_4} - {specs_5_4})/{specs_5_4})*(1+kpi5_4/{max_5_4}),3) else round((kpi5_4 - {specs_5_4})/{specs_5_4},3) end as afr5_4
           ,kpi7_4,case when kpi7_4 >= {ucl_v_7_4} then  round((({ucl_v_7_4} - {specs_7_4})/{specs_7_4})*(1+kpi7_4/{max_7_4}),3) else round((kpi7_4 - {specs_7_4})/{specs_7_4},3) end as afr7_4
           ,kpi9_4,case when kpi9_4 >= {ucl_v_9_4} then  round((({ucl_v_9_4} - {specs_9_4})/{specs_9_4})*(1+kpi9_4/{max_9_4}),3) else round((kpi9_4 - {specs_9_4})/{specs_9_4},3) end as afr9_4
           ,kpi5_5,case when kpi5_5 >= {ucl_v_5_5} then  round((({ucl_v_5_5} - {specs_5_5})/{specs_5_5})*(1+kpi5_5/{max_5_5}),3) else round((kpi5_5 - {specs_5_5})/{specs_5_5},3) end as afr5_5
           ,kpi7_5,case when kpi7_5 >= {ucl_v_7_5} then  round((({ucl_v_7_5} - {specs_7_5})/{specs_7_5})*(1+kpi7_5/{max_7_5}),3) else round((kpi7_5 - {specs_7_5})/{specs_7_5},3) end as afr7_5
           ,kpi9_5,case when kpi9_5 >= {ucl_v_9_5} then  round((({ucl_v_9_5} - {specs_9_5})/{specs_9_5})*(1+kpi9_5/{max_9_5}),3) else round((kpi9_5 - {specs_9_5})/{specs_9_5},3) end as afr9_5
    from {table}
        '''.format(
          ucl_v_5_3 = data_map['kpi5_3'][0]
        , ucl_v_7_3 = data_map['kpi7_3'][0]
        , ucl_v_9_3 = data_map['kpi9_3'][0]
        , ucl_v_5_4 = data_map['kpi5_4'][0]
        , ucl_v_7_4 = data_map['kpi7_4'][0]
        , ucl_v_9_4 = data_map['kpi9_4'][0]
        , ucl_v_5_5 = data_map['kpi5_5'][0]
        , ucl_v_7_5 = data_map['kpi7_5'][0]
        , ucl_v_9_5 = data_map['kpi9_5'][0]
        , specs_5_3 = data_map['kpi5_3'][1]
        , specs_7_3 = data_map['kpi7_3'][1]
        , specs_9_3 = data_map['kpi9_3'][1]
        , specs_5_4 = data_map['kpi5_4'][1]
        , specs_7_4 = data_map['kpi7_4'][1]
        , specs_9_4 = data_map['kpi9_4'][1]
        , specs_5_5 = data_map['kpi5_5'][1]
        , specs_7_5 = data_map['kpi7_5'][1]
        , specs_9_5 = data_map['kpi9_5'][1]
        , max_5_3=data_map['kpi5_3'][2]
        , max_7_3=data_map['kpi7_3'][2]
        , max_9_3=data_map['kpi9_3'][2]
        , max_5_4=data_map['kpi5_4'][2]
        , max_7_4=data_map['kpi7_4'][2]
        , max_9_4=data_map['kpi9_4'][2]
        , max_5_5=data_map['kpi5_5'][2]
        , max_7_5=data_map['kpi7_5'][2]
        , max_9_5=data_map['kpi9_5'][2]
        , table=table
    )
    df = query(sql, conn)
    insert(df,conn,'ClsChange_ana_ab_overs_kpi_%s' %(type))
def _anaKpiChart(score,conn,type):
    sql = '''
    select code, work_date, ny, cls_a, cls_b,
       afr5_3a, afr5_3b,
       afr7_3a, afr7_3b,
       afr9_3a, afr9_3b,
       afr5_4a, afr5_4b,
       afr7_4a, afr7_4b,
       afr9_4a, afr9_4b,
       afr5_5a, afr5_5b,
       afr7_5a, afr7_5b,
       afr9_5a, afr9_5b,
round(afr5_3a + afr5_3b,3) as afr5_3ab,
round(afr7_3a + afr7_3b,3) as afr7_3ab,
round(afr9_3a + afr9_3b,3) as afr9_3ab,
round(afr5_4a + afr5_4b,3) as afr5_4ab,
round(afr7_4a + afr7_4b,3) as afr7_4ab,
round(afr9_4a + afr9_4b,3) as afr9_4ab,
round(afr5_5a + afr5_5b,3) as afr5_5ab,
round(afr7_5a + afr7_5b,3) as afr7_5ab,
round(afr9_5a + afr9_5b,3) as afr9_5ab,
round(afr5_3a + afr5_3b + afr7_3a*0.98 + afr7_3b*0.98 + afr9_3a*0.95 + afr9_3b*0.95,3) as afr3,
round(afr5_4a + afr5_4b + afr7_4a*0.98 + afr7_4b*0.98 + afr9_4a*0.95 + afr9_4b*0.95,3) as afr4,
round(afr5_5a + afr5_5b + afr7_5a*0.98 + afr7_5b*0.98 + afr9_5a*0.95 + afr9_5b*0.95,3) as afr5,
round(afr5_3a + afr5_3b + afr7_3a*0.98 + afr7_3b*0.98 + afr9_3a*0.95 + afr9_3b*0.95 +
      afr5_4a + afr5_4b + afr7_4a*0.98 + afr7_4b*0.98 + afr9_4a*0.95 + afr9_4b*0.95 +
      afr5_5a + afr5_5b + afr7_5a*0.98 + afr7_5b*0.98 + afr9_5a*0.95 + afr9_5b*0.95,3) as afr
from
(select a.code,a.work_date,ny,a.cls_a,a.cls_b
     ,d.afr5_3 as afr5_3a,e.afr5_3 as afr5_3b
     ,d.afr7_3 as afr7_3a,e.afr7_3 as afr7_3b
     ,d.afr9_3 as afr9_3a,e.afr9_3 as afr9_3b
     ,d.afr5_4 as afr5_4a,e.afr5_4 as afr5_4b
     ,d.afr7_4 as afr7_4a,e.afr7_4 as afr7_4b
     ,d.afr9_4 as afr9_4a,e.afr9_4 as afr9_4b
     ,d.afr5_5 as afr5_5a,e.afr5_5 as afr5_5b
     ,d.afr7_5 as afr7_5a,e.afr7_5 as afr7_5b
     ,d.afr9_5 as afr9_5a,e.afr9_5 as afr9_5b
from raw_data_ana_cnts_ny_H2V_nys_final a,raw_data_ana_cnts_rate_{type} b
,ClsChange_ana_ab_overs_kpi_{type} d
,ClsChange_ana_ab_overs_kpi_{type} e
where a.code = b.code and a.work_date = b.work_date
and b.cls_a = d.cls and b.cls_b = e.cls)
    '''.format(type=type)
    df = query(sql, conn)
    dfs = df.groupby('code')
    def _getIdx(afs,ny,afr,afr3,afr4,afr5,nyar,nyar3,nyar4,nyar5):
        af_10 = np.argwhere(afs ==0)[:,0]
        dif_idx = np.argwhere(np.diff(af_10) > 1)[:,0]
        idxes =list(af_10[dif_idx])
        idxes.append(af_10[-1])
        idxes = sorted(list(set(idxes)))
        odatas= []
        p_idx = 0
        for i in range(len(idxes)):
            idx = idxes[i]
            afrs =  afr[p_idx:idx + 1]
            afr3s = afr3[p_idx:idx + 1]
            afr4s = afr4[p_idx:idx + 1]
            afr5s = afr5[p_idx:idx + 1]
            nyars  = nyar[p_idx:idx + 1]
            nyar3s = nyar3[p_idx:idx + 1]
            nyar4s = nyar4[p_idx:idx + 1]
            nyar5s = nyar5[p_idx:idx + 1]



            nys = ny[p_idx:idx + 1]
            yar = nys*afrs
            yar3= nys*afr3s
            yar4= nys*afr4s
            yar5= nys*afr5s

            afses = afs[p_idx:idx + 1]
            a_idxes  = np.argwhere(afses == 0)[:, 0]
            a_cnt    = len(a_idxes)
            a_score  = np.sum(nys[a_idxes])
            a_cnts   = np.zeros(len(afrs))
            a_scores = np.zeros(len(afrs))
            a_cnts[-1] = a_cnt
            a_scores[-1] = a_score
            stepts    = np.asarray(range(idx - p_idx+1)) + 1
            afr_csum  = np.round(np.cumsum(afrs) ,3)
            afr3_csum = np.round(np.cumsum(afr3s),3)
            afr4_csum = np.round(np.cumsum(afr4s),3)
            afr5_csum = np.round(np.cumsum(afr5s),3)
            yar_csum  = np.round(np.cumsum(yar), 3)
            yar3_csum = np.round(np.cumsum(yar3), 3)
            yar4_csum = np.round(np.cumsum(yar4), 3)
            yar5_csum = np.round(np.cumsum(yar5), 3)
            nyar_csum  = np.round(np.cumsum(nyars), 3)
            nyar3_csum = np.round(np.cumsum(nyar3s), 3)
            nyar4_csum = np.round(np.cumsum(nyar4s), 3)
            nyar5_csum = np.round(np.cumsum(nyar5s), 3)



            ny_csum   = np.round(np.cumsum(nys)  ,3)
            odatas.append([a_scores,a_cnts,stepts,afr_csum,afr3_csum,afr4_csum,afr5_csum,ny_csum,yar_csum,yar3_csum,yar4_csum,yar5_csum,nyar_csum,nyar3_csum,nyar4_csum,nyar5_csum])
            p_idx = idx + 1
            if i == len(idxes) - 1:
                yar  = ny[idx+1:] * afr[idx+1:]
                yar3 = ny[idx+1:] * afr3[idx+1:]
                yar4 = ny[idx+1:] * afr4[idx+1:]
                yar5 = ny[idx+1:] * afr5[idx+1:]


                afr_csum  = np.round(np.cumsum(afr[idx+1:])             ,3)
                afr3_csum = np.round(np.cumsum(afr3[idx+1:])            ,3)
                afr4_csum = np.round(np.cumsum(afr4[idx+1:])            ,3)
                afr5_csum = np.round(np.cumsum(afr5[idx+1:])            ,3)
                stepts    = np.round(np.asarray(range(len(afr_csum))) + 1,3)
                ny_csum   = np.round(np.cumsum(ny[idx+1:])              ,3)
                a_cnts    = np.round(np.zeros(len(stepts))               ,3)
                a_scores  = np.round(np.zeros(len(stepts))               ,3)
                yar_csum   = np.round(np.cumsum(yar )             ,3)
                yar3_csum  = np.round(np.cumsum(yar3)             ,3)
                yar4_csum  = np.round(np.cumsum(yar4)             ,3)
                yar5_csum  = np.round(np.cumsum(yar5)             ,3)
                nyar_csum  = np.round(np.cumsum(nyar[idx + 1:]), 3)
                nyar3_csum = np.round(np.cumsum(nyar3[idx + 1:]), 3)
                nyar4_csum = np.round(np.cumsum(nyar4[idx + 1:]), 3)
                nyar5_csum = np.round(np.cumsum(nyar5[idx + 1:]), 3)
                if len(a_scores) > 0:
                    odatas.append([a_scores,a_cnts,stepts,afr_csum,afr3_csum,afr4_csum,afr5_csum,ny_csum,yar_csum,yar3_csum,yar4_csum,yar5_csum,nyar_csum,nyar3_csum,nyar4_csum,nyar5_csum])
        return odatas
    rdfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        afs = idf.ny.apply(lambda x:1 if x<=score else 0).values
        afr3 = idf.afr3.values
        afr4 = idf.afr4.values
        afr5 = idf.afr5.values
        afr  =  idf.afr.values
        nyar = afs*afr
        nyar3 = afs*afr3
        nyar4 = afs*afr4
        nyar5 = afs*afr5
        try:
            odatas = _getIdx(afs,idf.ny.values,afr,afr3,afr4,afr5,nyar,nyar3,nyar4,nyar5)
            odatas = np.asarray(odatas)
            idf['a_scores ']=np.concatenate(odatas[:,0])
            idf['a_cnts']   =np.concatenate(odatas[:,1])
            idf['stepts']   =np.concatenate(odatas[:,2])
            idf['afr_csum'] =np.concatenate(odatas[:,3])
            idf['afr3_csum']=np.concatenate(odatas[:,4])
            idf['afr4_csum']=np.concatenate(odatas[:,5])
            idf['afr5_csum']=np.concatenate(odatas[:,6])
            idf['yar_csum']  = np.concatenate(odatas[:, 8])
            idf['yar3_csum'] = np.concatenate(odatas[:, 9])
            idf['yar4_csum'] = np.concatenate(odatas[:, 10])
            idf['yar5_csum'] = np.concatenate(odatas[:, 11])
            idf['nyar_csum'] =  np.concatenate(odatas[:, 12])
            idf['nyar3_csum'] = np.concatenate(odatas[:, 13])
            idf['nyar4_csum'] = np.concatenate(odatas[:, 14])
            idf['nyar5_csum'] = np.concatenate(odatas[:, 15])
            idf['ny_csum']  =np.concatenate(odatas[:,7])
        except:
            idf['a_scores '] =[0] * len(idf)
            idf['a_cnts'] =[0] * len(idf)
            idf['stepts'] =[0] * len(idf)
            idf['afr_csum']  =[0] * len(idf)
            idf['afr3_csum'] =[0] * len(idf)
            idf['afr4_csum'] =[0] * len(idf)
            idf['afr5_csum'] =[0] * len(idf)
            idf['ny_csum'] =[0] * len(idf)
            idf['yar_csum'] = [0] * len(idf)
            idf['yar3_csum'] =[0] * len(idf)
            idf['yar4_csum'] =[0] * len(idf)
            idf['yar5_csum'] =[0] * len(idf)
            idf['nyar_csum'] = [0] * len(idf)
            idf['nyar3_csum'] =[0] * len(idf)
            idf['nyar4_csum'] =[0] * len(idf)
            idf['nyar5_csum'] =[0] * len(idf)
        rdfs.append(idf)
        print("%s %s" %(code,len(rdfs)))
    rdf = pd.concat(rdfs)
    insert(rdf,conn,'ClsChange_ana_ab_overs_kpi_chart_%s_%s' %(type,score))

def anaKpiChart():
    print(1)

def analysisOvers():
    _analysisOvers('ClsChange_Close', 'ClsChange_ana_ab_over3_Close', train_conn, 3)
    _analysisOvers('ClsChange_Close', 'ClsChange_ana_ab_over4_Close', train_conn, 4)
    _analysisOvers('ClsChange_Close', 'ClsChange_ana_ab_over5_Close', train_conn, 5)
    _analysisOvers('ClsChange_Degress', 'ClsChange_ana_ab_over3_Degress', train_conn, 3)
    _analysisOvers('ClsChange_Degress', 'ClsChange_ana_ab_over4_Degress', train_conn, 4)
    _analysisOvers('ClsChange_Degress', 'ClsChange_ana_ab_over5_Degress', train_conn, 5)
def analysisOversSums():
    _analysisOversSums(train_conn,'Close')
    _analysisOversSums(train_conn, 'Degress')
def anaSpec():
    _anaSpec(train_conn,'Close')
    _anaSpec(train_conn,'Degress')
def anaKpiChart():
    _anaKpiChart(1,train_conn,'Close')
    _anaKpiChart(1,train_conn,'Degress')
    _anaKpiChart(3,train_conn,'Close')
    _anaKpiChart(3,train_conn,'Degress')
    _anaKpiChart(5,train_conn,'Close')
    _anaKpiChart(5,train_conn,'Degress')
if __name__ == '__main__':
    #anaNYSummary()
    #getRateClsChangePNClose()
    #getRateClsChangePNDegress()
    #analysisOversSums()
    #anaSpec()
    #analysisOvers()
    anaKpiChart()