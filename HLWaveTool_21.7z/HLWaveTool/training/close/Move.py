import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
pn_conns = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
an_conns = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")
def move():
    sql = '''
    select code, work_date, av1_r4, av2_r4, av3_r4, av4_r4, av1_r5, av2_r5, av3_r5, av4_r5, av5_r5, idx4_0, idx4_1, idx4_2, idx4_3, idx5_0, idx5_1, idx5_2, idx5_3, idx5_4, cls_a, cls_b, cls_a_s, cls_b_s from raw_data_ana_cnts_rate
    '''
    df_an = query(sql,an_conns)
    df_pn = query(sql,pn_conns)
    insert(df_an,train_conn,'raw_data_ana_cnts_rate_Close')
    insert(df_pn,train_conn,'raw_data_ana_cnts_rate_Degress')
    sql = '''
        select code,work_date,ny,t,ts from raw_data_ana_cnts_ny_H2V_nys
        '''
    df_nys = query(sql,pn_conns)
    insert(df_nys,train_conn,'raw_data_ana_cnts_ny_H2V_nys')
if __name__ == '__main__':
    move()
