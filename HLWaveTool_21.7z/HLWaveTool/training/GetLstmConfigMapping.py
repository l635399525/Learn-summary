import glob
jfiles = glob.glob(r'D:\codes\data\train_configs\*.json')
tdatas = glob.glob(r'D:\codes\data\train_data\*.npz')
models = glob.glob(r'D:\codes\data\train_model\*.h5')

for idx,jfile in enumerate(jfiles):

    type = "_".join(jfile.split("\\")[-1].split(".")[0].split("_")[-2:])

    test_t = type + "_test"
    train_t = type + "_train"


    rline = {'idx':idx,'jfile':jfile,'type':type
        ,'test_data':'','train_data':'','model':''}
    tds_test  = list(filter(lambda x:test_t in str(x).replace("aaa","").replace("bbb",""),tdatas))
    tds_train = list(filter(lambda x:train_t in str(x).replace("aaa","").replace("bbb",""),tdatas))
    if 'ny' not in type:
        type = '%saaa' %(type)
    else:
        type = '%sbbb' %(type)

    omodels = list(filter(lambda x:type in str(x),models))


    if len(tds_test) == 1:
        rline['test_data'] = tds_test[0]
    if len(tds_train) == 1:
        rline['train_data'] = tds_train[0]
    if len(omodels) == 1:
        rline['model'] = omodels[0]

    print(rline)