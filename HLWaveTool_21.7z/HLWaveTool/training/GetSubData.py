import glob
import pandas as pd
csvs = glob.glob(r'D:\codes\data\2022\train_result\*0714_1*')
heads = pd.read_csv(csvs[0])[['code','work_date','ny','pny','ts','cls_a','cls_b']]
heads.to_csv(r'D:\codes\data\2022\train_result\out\rdddf.csv')
for idx,csv in enumerate(csvs):
    type = csv.split("\\")[-1].split('#')[0].replace("res_","")
    df = pd.read_csv(csv)
    rdf = df[['code','work_date','r_%s' %(type)]].copy()
    fn1 =  csv.split("\\")[-1]
    fn1 = fn1.replace(".csv","#n.csv")
    rdf.to_csv(r'D:\codes\data\2022\train_result\out\%s.csv' %(fn1))

    #heads = heads.merge(rdf,on=['code','work_date'],how='outer')
    #print("%s %s" %(idx,csv))
#heads.to_csv(r'D:\codes\data\2022\train_result\out\rdddf.csv')
