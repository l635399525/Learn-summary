from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
pn_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")
point_conn = getConn(r'D:\data\summary_db\2022\RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS')
def getDatas1():
    code = 'BK0420','BK0421'
    tables = [
         'ClsChange_ana_ab_over3_Close'
        ,'ClsChange_ana_ab_over3_Degress'
        ,'ClsChange_ana_ab_over4_Close'
        ,'ClsChange_ana_ab_over4_Degress'
        ,'ClsChange_ana_ab_over5_Close'
        ,'ClsChange_ana_ab_over5_Degress'
        ,'ClsChange_ana_ab_overs_Close'
        ,'ClsChange_ana_ab_overs_Degress'
        ,'ClsChange_ana_ab_overs_kpi_Close'
        ,'ClsChange_ana_ab_overs_kpi_Degress'
    ]
    for table in tables:
        sql = '''
                select * from {table} 
                '''.format(table=table)
        df_an = query(sql, train_conn)
        # df_pn = query(sql,an_conn)
        df_an.to_csv(r'D:\home_work\2022\datas\%s.csv' % (table))
def getData2():
    tables = [
         'ClsChange_ana_ab_overs_kpi_chart_Close_1'
        ,'ClsChange_ana_ab_overs_kpi_chart_Close_3'
        ,'ClsChange_ana_ab_overs_kpi_chart_Close_5'
        ,'ClsChange_ana_ab_overs_kpi_chart_Degress_1'
        ,'ClsChange_ana_ab_overs_kpi_chart_Degress_3'
        ,'ClsChange_ana_ab_overs_kpi_chart_Degress_5'
        ,'ClsChange_Close'
        ,'ClsChange_Degress'
        ,'raw_data_ana_cnts_ny_H2V_nys'
    ]
    for table in tables:
        sql = '''
                    select * from {table} where code like 'BK04%'
                    '''.format(table=table)
        df_an = query(sql, train_conn)
        df_an.to_csv(r'D:\home_work\2022\datas\%s.csv' % (table))
def getData3():
    tables = [
         'raw_data_ana_cnts_ny'
        ,'raw_data_ana_cnts_ny3'
        ,'raw_data_ana_cnts_ny3_reverse'
        ,'raw_data_ana_cnts_ny_H2V'
    ]
    for table in tables:
        sql = '''
                    select * from {table} where code like 'BK04%'
                    '''.format(table=table)
        df_an = query(sql, an_conn)
        df_an.to_csv(r'D:\home_work\2022\datas\%s_an.csv' % (table))
    sql = '''
    select * from raw_data_ana_cnts_point  where code = 'BK0420'
    '''
    df_an = query(sql, point_conn)
    df_an.to_csv(r'D:\home_work\2022\datas\%s_an.csv' % ('raw_data_ana_cnts_point'))
if __name__ == '__main__':
    #getDatas()
    getDatas1()
    getData2()
    getData3()