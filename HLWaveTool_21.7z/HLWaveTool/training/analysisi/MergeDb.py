import numpy as np
import pandas as pd

from com.DbTool import getConn, query, insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path

pn_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")


def parseCSV2DB():
    res_Close_1 = pd.read_csv(r'D:\codes\data\2022\train_result\res_Close_1.csv')
    res_Close_2 = pd.read_csv(r'D:\codes\data\2022\train_result\res_Close_2.csv')
    res_Close_3 = pd.read_csv(r'D:\codes\data\2022\train_result\res_Close_3.csv')
    res_degress_1 = pd.read_csv(r'D:\codes\data\2022\train_result\res_degress_1.csv')
    res_degress_2 = pd.read_csv(r'D:\codes\data\2022\train_result\res_degress_2.csv')
    res_degress_3 = pd.read_csv(r'D:\codes\data\2022\train_result\res_degress_3.csv')
    dfr = pd.merge(res_Close_1, res_Close_2, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_Close_3, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_degress_1, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_degress_2, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_degress_3, on=['code', 'work_date'])
    df = dfr[['code', 'work_date', 'ny_x', 'pny_x', 'r_Close_1', 'r_Close_2', 'r_Close_3', 'r_Degress_1', 'r_Degress_2',
              'r_Degress_3']].copy()
    # df = df.T.drop_duplicates().T
    df2 = df.loc[:, ~df.T.duplicated(keep='last')]
    df2.to_csv(r'D:\codes\data\2022\train_result\res_cd.csv')
    # insert(df,train_conn,'test_res')


def parseCSV2DBAFR():
    res_Close_1 = pd.read_csv(r'D:\codes\data\2022\train_result\res_Close_1afr.csv')
    res_Close_2 = pd.read_csv(r'D:\codes\data\2022\train_result\res_Close_2afr.csv')
    res_Close_3 = pd.read_csv(r'D:\codes\data\2022\train_result\res_Close_3afr.csv')
    res_degress_1 = pd.read_csv(r'D:\codes\data\2022\train_result\res_degress_1afr.csv')
    res_degress_2 = pd.read_csv(r'D:\codes\data\2022\train_result\res_degress_2afr.csv')
    res_degress_3 = pd.read_csv(r'D:\codes\data\2022\train_result\res_degress_3afr.csv')
    dfr = pd.merge(res_Close_1, res_Close_2, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_Close_3, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_degress_1, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_degress_2, on=['code', 'work_date'])
    dfr = pd.merge(dfr, res_degress_3, on=['code', 'work_date'])
    df = dfr[['code', 'work_date', 'ny_x', 'pny_x', 'r_Close_1afr', 'r_Close_2afr', 'r_Close_3afr', 'r_Degress_1afr',
              'r_Degress_2afr', 'r_Degress_3afr']].copy()
    # df = df.T.drop_duplicates().T
    # df2 = df.loc[:, ~df.T.duplicated(keep='last')]
    df.to_csv(r'D:\codes\data\2022\train_result\res_cd_afr.csv')


def parseCSV2DBAFR1():
    res_Close_1_afr   = pd.read_csv(r'D:\codes\data\train_result\res_Close_1afr1aaa.csv')
    res_Close_2_afr   = pd.read_csv(r'D:\codes\data\train_result\res_Close_2afr1aaa.csv')
    res_Close_3_afr   = pd.read_csv(r'D:\codes\data\train_result\res_Close_3afr1aaa.csv')
    res_degress_1_afr = pd.read_csv(r'D:\codes\data\train_result\res_degress_1afr1aaa.csv')
    res_degress_2_afr = pd.read_csv(r'D:\codes\data\train_result\res_degress_2afr1aaa.csv')
    res_degress_3_afr = pd.read_csv(r'D:\codes\data\train_result\res_degress_3afr1aaa.csv')
    res_Close_1 =   pd.read_csv(r'D:\codes\data\train_result\res_Close_11aaa.csv')
    res_Close_2 =   pd.read_csv(r'D:\codes\data\train_result\res_Close_21aaa.csv')
    res_Close_3 =   pd.read_csv(r'D:\codes\data\train_result\res_Close_31aaa.csv')
    res_degress_1 = pd.read_csv(r'D:\codes\data\train_result\res_degress_11aaa.csv')
    res_degress_2 = pd.read_csv(r'D:\codes\data\train_result\res_degress_21aaa.csv')
    res_degress_3 = pd.read_csv(r'D:\codes\data\train_result\res_degress_31aaa.csv')
    # res_Close_1['key'] = res_Close_1.apply(lambda x: '%s#%s' % (x['code'], x['work_date']),axis=1)
    # res_Close_2['key'] = res_Close_2.apply(lambda x: '%s#%s' % (x['code'], x['work_date']),axis=1)
    # res_Close_3['key'] = res_Close_3.apply(lambda x: '%s#%s' % (x['code'], x['work_date']),axis=1)
    # res_degress_1['key'] = res_degress_1.apply(lambda x: '%s#%s' % (x['code'], x['work_date']),axis=1)
    # res_degress_2['key'] = res_degress_2.apply(lambda x: '%s#%s' % (x['code'], x['work_date']),axis=1)
    # res_degress_3['key'] = res_degress_3.apply(lambda x: '%s#%s' % (x['code'], x['work_date']),axis=1)
    # dfr         = res_Close_1[['code', 'work_date', 'key', 'ny', 'pny']].copy()
    # dfr_Close_1   = res_Close_1[['key', 'r_Close_1afr']].copy()
    # dfr_Close_2   = res_Close_2[['key', 'r_Close_2afr']].copy()
    # dfr_Close_3   = res_Close_3[['key', 'r_Close_3afr']].copy()
    # dfr_degress_1 = res_degress_1[['key', 'r_Degress_1afr']].copy()
    # dfr_degress_2 = res_degress_2[['key', 'r_Degress_2afr']].copy()
    # dfr_degress_3 = res_degress_3[['key', 'r_Degress_3afr']].copy()
    conn = getConn(r'D:\codes\data\2022\train_result\test.db')
    #insert(dfr,conn,'dfr')
    insert(res_Close_1  ,conn,'res_Close_1a')
    insert(res_Close_2  ,conn,'res_Close_2a')
    insert(res_Close_3  ,conn,'res_Close_3a')
    insert(res_degress_1,conn,'res_degress_1a')
    insert(res_degress_2,conn,'res_degress_2a')
    insert(res_degress_3,conn,'res_degress_3a')
    insert(res_Close_1_afr  ,conn,'res_Close_1_afra')
    insert(res_Close_2_afr  ,conn,'res_Close_2_afra')
    insert(res_Close_3_afr  ,conn,'res_Close_3_afra')
    insert(res_degress_1_afr,conn,'res_degress_1_afra')
    insert(res_degress_2_afr,conn,'res_degress_2_afra')
    insert(res_degress_3_afr,conn,'res_degress_3_afra')
    print("-------------------------------------------")
def moveData():
    conn = getConn(r'D:\codes\data\2022\train_result\test.db')
    sql = '''
    select distinct a.code,a.work_date,a.ts,a.ny,a.pny
,case when a.ny > 0 then 1 else 0 end as a
,r_Close_1,r_Close_2,r_Close_3
,r_Close_1afr,r_Close_2afr,r_Close_3afr
,r_Close_1 + r_Close_2 + r_Close_3 + r_Close_1afr + r_Close_2afr + r_Close_3afr as sums
,case when r_Close_1 > 0 then 1 else 0 end as rclose1_cnt
,case when r_Close_2 > 0 then 1 else 0 end as rclose1_cnt
,case when r_Close_3 > 0 then 1 else 0 end as rclose1_cnt
,case when r_Close_1afr > 0 then 1 else 0 end as rclose_1afr_cnt
,case when r_Close_2afr > 0 then 1 else 0 end as rclose_2afr_cnt
,case when r_Close_3afr > 0 then 1 else 0 end as rclose_3afr_cnt
from res_Close_1a a,
res_Close_2a b,res_Close_3a c,res_Close_1_afra d,
res_Close_2_afra e,res_Close_3_afra f
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.work_date
and a.code = e.code and a.work_date = e.work_date
and a.code = f.code and a.work_date = f.work_date
    '''
    df = query(sql,conn)
    df.to_csv(r'D:\codes\data\close_result.csv')
    sql = '''
    select distinct a.code,a.work_date,a.ts,a.ny,a.pny
,case when a.ny > 0 then 1 else 0 end as a
,r_Degress_1   ,r_Degress_2   ,r_Degress_3
,r_Degress_1afr,r_Degress_2afr,r_Degress_3afr
,r_Degress_1 +  r_Degress_2  + r_Degress_3
+r_Degress_1afr + r_Degress_2afr + r_Degress_3afr as sums
,case when r_Degress_1 > 0 then 1 else 0 end as rclose1_cnt
,case when r_Degress_2 > 0 then 1 else 0 end as rclose1_cnt
,case when r_Degress_3 > 0 then 1 else 0 end as rclose1_cnt
,case when r_Degress_1afr > 0 then 1 else 0 end as rclose_1afr_cnt
,case when r_Degress_2afr > 0 then 1 else 0 end as rclose_2afr_cnt
,case when r_Degress_3afr > 0 then 1 else 0 end as rclose_3afr_cnt
from res_degress_1a a,
res_degress_2a b,res_degress_3a c,res_degress_1_afra d,
res_degress_2_afra e,res_degress_3_afra f
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.work_date
and a.code = e.code and a.work_date = e.work_date
and a.code = f.code and a.work_date = f.work_date
    '''
    df = query(sql,conn)
    df.to_csv(r'D:\codes\data\degress_result.csv')

if __name__ == '__main__':
    #parseCSV2DBAFR1()
    moveData()
