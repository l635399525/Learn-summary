

dest_summary_path_OLD = r'D:\data\summary_db'
RAW_HLS_WORK_FILE_HIST_OLD = dest_summary_path_OLD  + "/RAW_HLWAVES_DATA_HISTORY"
dest_summary_path = r'D:\data\summary_db\2022'
RAW_HLS_WORK_FILE_HIST = dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYS"
RAW_HLS_WORK_FILE_HISTES = dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES"


