import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getData():
    files = ['RAW_HLWAVES_DATA_HISTORYSES','RAW_HLWAVES_DATA_HISTORYSES_SH','RAW_HLWAVES_DATA_HISTORYSES_SZ','RAW_HLWAVES_DATA_HISTORYSES_SZ1']
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    lines = []
    sql = '''
        select * from raw_merger_image_data_info_SH 
        '''
    for file in files:
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        df = query(sql,sh_conn)
        dfs = df.groupby(['code','work_date'])
        for line,idf in dfs:
            idf = idf.sort_values(by=['date'])
            ts = idf['ts'].values[-1]
            code,work_date = line
            idfs = idf.groupby(['w_ct','h_ct'])
            rline = {'code':code,'work_date':work_date,'ts':ts,
                     'c1#1':0,'c1#2':0,'c1#3':0,'c1#4':0,'c1#5':0,
                     'c2#1':0,'c2#2':0,'c2#3':0,'c2#4':0,'c2#5':0,
                     'c3#1':0,'c3#2':0,'c3#3':0,'c3#4':0,'c3#5':0,
                     'c4#1':0,'c4#2':0,'c4#3':0,'c4#4':0,'c4#5':0,
                     'c5#1':0,'c5#2':0,'c5#3':0,'c5#4':0,'c5#5':0
                     }
            for iline,iidf in idfs:
                w_ct,h_ct = iline
                rline['c%s#%s'%(w_ct,h_ct)] = len(iidf)
            lines.append(rline)
            print("%s %s %s" %(code,work_date,len(lines)))
    df = pd.DataFrame(lines)
    insert(df,an_conn,'raw_data_ana_cnts')
def getData1():
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    sql = '''
    select code, work_date, ts, v1, v2, v3, v4, v5, c1, c2, c3, c4, c5, hl1, hl2, hl3, hl4, hl5
,case when round(v1*1.0/c1,3) is null then 0 else round(v1*1.0/c1,3) end as av1, case when round((v1*1.0/c1)/c1,3) is null then 0 else round((v1*1.0/c1)/c1,3) end as sp1
,case when round(v2*1.0/c2,3) is null then 0 else round(v2*1.0/c2,3) end as av2, case when round((v2*1.0/c2)/c2,3) is null then 0 else round((v2*1.0/c2)/c2,3) end as sp2
,case when round(v3*1.0/c3,3) is null then 0 else round(v3*1.0/c3,3) end as av3, case when round((v3*1.0/c3)/c3,3) is null then 0 else round((v3*1.0/c3)/c3,3) end as sp3
,case when round(v4*1.0/c4,3) is null then 0 else round(v4*1.0/c4,3) end as av4, case when round((v4*1.0/c4)/c4,3) is null then 0 else round((v4*1.0/c4)/c4,3) end as sp4
,case when round(v5*1.0/c5,3) is null then 0 else round(v5*1.0/c5,3) end as av5, case when round((v5*1.0/c5)/c5,3) is null then 0 else round((v5*1.0/c5)/c5,3) end as sp5
from
(select code, work_date, ts,
       "c1#1"*1 + "c1#2"*2 + "c1#3"*3 + "c1#4" *4 + "c1#5" *5 as v1,
       "c2#1"*1 + "c2#2"*2 + "c2#3"*3 + "c2#4" *4 + "c2#5" *5 as v2,
       "c3#1"*1 + "c3#2"*2 + "c3#3"*3 + "c3#4" *4 + "c3#5" *5 as v3,
       "c4#1"*1 + "c4#2"*2 + "c4#3"*3 + "c4#4" *4 + "c4#5" *5 as v4,
       "c5#1"*1 + "c5#2"*2 + "c5#3"*3 + "c5#4" *4 + "c5#5" *5 as v5
, "c1#1" + "c1#2" + "c1#3" + "c1#4" + "c1#5" as c1
, "c2#1" + "c2#2" + "c2#3" + "c2#4" + "c2#5" as c2
, "c3#1" + "c3#2" + "c3#3" + "c3#4" + "c3#5" as c3
, "c4#1" + "c4#2" + "c4#3" + "c4#4" + "c4#5" as c4
, "c5#1" + "c5#2" + "c5#3" + "c5#4" + "c5#5" as c5
,max("c1#1","c1#2","c1#3","c1#4","c1#5") - min("c1#1","c1#2","c1#3","c1#4","c1#5") as hl1
,max("c2#1","c2#2","c2#3","c2#4","c2#5") - min("c2#1","c2#2","c2#3","c2#4","c2#5") as hl2
,max("c3#1","c3#2","c3#3","c3#4","c3#5") - min("c3#1","c3#2","c3#3","c3#4","c3#5") as hl3
,max("c4#1","c4#2","c4#3","c4#4","c4#5") - min("c4#1","c4#2","c4#3","c4#4","c4#5") as hl4
,max("c5#1","c5#2","c5#3","c5#4","c5#5") - min("c5#1","c5#2","c5#3","c5#4","c5#5") as hl5
from raw_data_ana_cnts)
    '''
    df = query(sql,an_conn)
    dfs = df.groupby('code')
    rdfs = []
    rdf_diffs = []
    for code,idf in dfs:
        if len(idf) <= 1:
            continue
        idf = idf.sort_values(by=['work_date'])
        rdfs.append(idf)
        cols   = list(idf.columns)[3:]
        heads  = list(idf.columns)[:3]
        f_data = idf[cols].copy().values
        rlines = []
        for i in range(1,len(f_data)):
            cline = f_data[i,:]
            pline = f_data[i-1,:]
            dif_line = (cline - pline)*100
            dif_val = np.round(dif_line/pline,3)
            z_idx = np.argwhere(pline == 0)[:,0]
            dif_val[z_idx] = 100
            rlines.append(dif_val)
        rlines = np.asarray(rlines)
        cols = list(map(lambda x:'%s_d' %(x),cols))
        dif_df = pd.DataFrame(data=rlines,columns=cols)
        for head in heads:
            dif_df[head] = idf[head].values[1:]
        rdf_diffs.append(dif_df)
        print("%s %s %s" %(code,len(rdfs),len(rdf_diffs)))
    adf = pd.concat(rdfs)
    bdf = pd.concat(rdf_diffs)
    insert(adf, an_conn, 'raw_data_ana_cnts_a')
    insert(bdf, an_conn, 'raw_data_ana_cnts_b')
'''
select a.code, a.work_date, a.ts,
       a.v1, a.v2, a.v3, a.v4, a.v5,
       a.c1, a.c2, a.c3, a.c4, a.c5,
       a.hl1, a.hl2, a.hl3, a.hl4, a.hl5,
       a.av1, a.sp1, a.av2, a.sp2, a.av3, a.sp3, a.av4, a.sp4, a.av5, a.sp5,
       b.v1_d, b.v2_d, b.v3_d, b.v4_d, b.v5_d,
       b.c1_d, b.c2_d, b.c3_d, b.c4_d, b.c5_d,
       b.hl1_d, b.hl2_d, b.hl3_d, b.hl4_d, b.hl5_d,
       b.av1_d, b.sp1_d, b.av2_d, b.sp2_d,
       b.av3_d,b.sp3_d, b.av4_d, b.sp4_d,
       b.av5_d, b.sp5_d
from raw_data_ana_cnts_a a,raw_data_ana_cnts_b b
where a.code = b.code and a.work_date = b.work_date
'''
import math
import cmath
def getDegress():
    sql = '''
    select code,work_date,av1_d, sp1_d, av2_d, sp2_d, av3_d, sp3_d, av4_d, sp4_d, av5_d, sp5_d from raw_data_ana_cnts_b
    '''
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql,an_conn)
    dfs = df.groupby('code')
    rdfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        rdf = idf.copy()
        cols = ['av1_d','av2_d','av3_d','av4_d','av5_d', 'sp5_d']

        aeses = []
        beses = []
        ceses = []
        for i in range(len(idf)):
            s_idx = 0 if i < 5 else i - 4
            e_idx = i + 1
            tdf = idf.iloc[s_idx:e_idx]
            aes = []
            bes = []
            ces = []
            for col in cols:
                dvals = tdf[col].values
                z_cnt = np.count_nonzero(dvals == 0)
                cnt = len(dvals)
                try:
                    last_val = dvals[max(np.argwhere(dvals != 0)[:,0])]
                except:
                    last_val = 0
                degress = round(math.degrees(cmath.polar(complex(len(tdf)*4, sum(dvals)))[1]), 1)
                if last_val > 0:
                    acnt = np.count_nonzero(dvals > 0)
                    a = 1
                elif last_val <0:
                    acnt = np.count_nonzero(dvals < 0)
                    a= -1
                if cnt == z_cnt:
                    zr = 1
                    ar = 0
                else:
                    ar = a*round(acnt/(cnt-z_cnt),3)
                    zr = round(z_cnt/(cnt),3)
                aes.append(degress)
                bes.append(ar)
                ces.append(zr)
            aeses.append(aes)
            beses.append(bes)
            ceses.append(ces)
        aeses = np.asarray(aeses)
        beses = np.asarray(beses)
        ceses = np.asarray(ceses)
        for i in range(len(cols)):
            col = cols[i]
            degress = aeses[:,i]
            dir = beses[:, i]
            zr = ceses[:, i]
            rdf['%s_deg' % (col) ] = degress
            rdf['%s_dir' % (col)] = dir
            rdf['%s_zr'  % (col)] = zr
        print("%s %s Done" %(code,len(rdfs)))
        rdfs.append(rdf)
    df = pd.concat(rdfs)
    insert(df, an_conn, 'raw_data_ana_cnts_degress')
def getConv4():
    a = [["c1#1", "c1#2", "c2#1", "c2#2"],
         ["c1#2", "c1#3", "c2#2", "c2#3"],
         ["c1#3", "c1#4", "c2#3", "c2#4"],
         ["c1#4", "c1#5", "c2#4", "c2#5"]]
    b = [["c2#1", "c2#2", "c3#1", "c3#2"],
         ["c2#2", "c2#3", "c3#2", "c3#3"],
         ["c2#3", "c2#4", "c3#3", "c3#4"],
         ["c2#4", "c2#5", "c3#4", "c3#5"]]
    c = [["c3#1", "c4#2", "c3#1", "c4#2"],
         ["c3#2", "c4#3", "c3#2", "c4#3"],
         ["c3#3", "c4#4", "c3#3", "c4#4"],
         ["c3#4", "c4#5", "c3#4", "c4#5"]]
    d = [["c4#1", "c5#2", "c4#1", "c5#2"],
         ["c4#2", "c5#3", "c4#2", "c5#3"],
         ["c4#3", "c5#4", "c4#3", "c5#4"],
         ["c4#4", "c5#5", "c4#4", "c5#5"]]
    ws = [a,b,c,d]
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    sql = '''
select * from raw_data_ana_cnts 
            '''
    df = query(sql,an_conn)
    olines = []
    for i in range(len(df)):
        line = df.iloc[i]
        max_idxes = []
        rline = {'code':line['code'],'date':line['work_date']}
        for w in range(len(ws)):
            hs = ws[w]
            counts = []
            for h in range(len(hs)):
                hv = hs[h]
                data = line[hv].values
                try:
                    cnts = np.sum(data)
                except:
                    cnts = 0
                counts.append(cnts)
                rline['%s#%s' %(w+1,h+1)] = cnts
            counts = np.asarray(counts)
            max_idx = max(np.argwhere(counts == max(counts))[:, 0])
            max_idxes.append(str(max_idx))
        cls = "#".join(max_idxes)
        rline['cls'] = cls
        olines.append(rline)
        print('%s %s %s %s' %(line['code'],line['work_date'],len(olines),len(df)))
    rdf = pd.DataFrame(olines)
    insert(rdf,an_conn,'raw_data_ana_cnts_conv4')

if __name__ == '__main__':
    getDegress()