import pandas as pd


def getDataSplitIdx(afs):
    oidxes = []
    idxes = []
    for i in range(len(afs) - 1):
        c_idx = i
        n_idx = i + 1
        c_v = afs[c_idx]
        n_v = afs[n_idx]
        if c_v == n_v:
            idxes.extend([c_idx, n_idx])
        else:
            if len(idxes) == 0:
                idxes.append(c_idx)
                oidxes.append(list(set(idxes)))
                idxes = []
            else:
                oidxes.append(list(set(idxes)))
                idxes = []
    if len(idxes) > 0:
        oidxes.append(list(set(idxes)))
    if n_idx not in oidxes[-1]:
        oidxes.append([n_idx])
    return oidxes
import cv2
from sklearn import preprocessing


def _draw_close(close_data,wdate_idxes,num=456, c=4,ma=True):
    import numpy as np
    fit = preprocessing.MinMaxScaler()
    closes = close_data[:,1]
    fit.fit(closes.reshape(len(closes),1))
    std_close  = fit.transform(closes.reshape(len(closes),1))[:,0]
    closes_points = np.round((440 - std_close * 405) - 15).astype(int)
    mask = np.zeros((440, 1820, 3), np.uint8) + 200
    if ma:
        ma10s = close_data[:, 2]
        ma60s = close_data[:, 3]
        ma10_close = fit.transform(ma10s.reshape(len(closes), 1))
        ma60_close = fit.transform(ma60s.reshape(len(closes), 1))
        ma10_points = np.round((440 - ma10_close * 405) - 15).astype(int)
        ma60_points = np.round((440 - ma60_close * 405) - 15).astype(int)
    x = np.asarray(range(1, num)) * c
    try:
        data = np.vstack([x, closes_points])
    except:
        if len(closes_points) < 455:
            data = np.concatenate([(np.zeros(num-len(closes_points) - 1) + closes_points[0]).astype(int),closes_points])
        data = np.vstack([x, data])

    for i in range(1,data.shape[1]):
        c = i
        p = i - 1
        cv2.line(mask, (data[0][p], data[1][p]), (data[0][c], data[1][c]), (0, 0, 0), thickness=1)
        if ma:
            cv2.circle(mask, (data[0][c], ma10_points[c]), 1, (0, 255, 255), thickness=1)
            cv2.circle(mask, (data[0][c], ma60_points[c]), 1, (0, 255, 0), thickness=1)
    print("##########")
    for i in range(0, len(wdate_idxes)):
        if i == 0:
            c = wdate_idxes[i]
            p = 0
        else:
            c = wdate_idxes[i]
            p = wdate_idxes[i - 1]
        #print("%s %s %s" %((i,data[0][c], data[1][c])))
        cv2.line(mask, (data[0][p], data[1][p]), (data[0][c], data[1][c]), (255, 0, 0), thickness=1)
        cv2.circle(mask, (data[0][c], data[1][c]), 2, (0, 0, 255), thickness=2)
        #cv2.imshow('a',mask)
        #cv2.waitKey(0)
    a = data[0]
    b = data[1]
    c = ma10_points[:,0]
    d = ma60_points[:,0]
    data = np.asarray(list(zip(a,b,c,d)))

    df = pd.DataFrame(columns=['w','h','c10','c60'],data=data[wdate_idxes])
    df['date']  = close_data[wdate_idxes][:,0]
    df['x']     = wdate_idxes
    df['close'] = close_data[wdate_idxes][:,1]
    df['ma10']  = close_data[wdate_idxes][:,2]
    df['ma60']  = close_data[wdate_idxes][:,3]

    return mask,df,data
    # cv2.imshow('a',mask)
    # cv2.waitKey(0)
def getDegreesDf(lines):
    dfs = []
    for line in lines:
        data = line['data']
        df = pd.DataFrame(columns=['date', 'close', 'ma60', 'ma10'], data=data)
        degress = line['degress']
        w_idx = line['w_idx']
        p_date = line['p_date']
        c_date = line['c_date']
        n_date = line['n_date']
        idxes  = line['idxes']
        date_type = np.zeros(len(degress))
        c_idx = np.argwhere(w_idx == idxes[1])[0][0]
        date_type[0] = 1
        date_type[c_idx] = 2
        date_type[-1] = 3
        df['p_date'] = p_date
        df['c_date'] = c_date
        df['n_date'] = n_date
        df['degress'] = degress
        df['w_idx'] = w_idx
        df['date_type'] = date_type
        dfs.append(df)
    return dfs
def _draw_degrees(lines,num=456, c=4,ma=True):
    import numpy as np
    fit = preprocessing.MinMaxScaler()
    degress = list(map(lambda x: x['degress'], lines))
    closes = []
    for close in degress:
        closes.extend(close)
    closes = np.asarray(closes)
    fit.fit(closes.reshape(len(closes), 1))
    std_close = fit.transform(closes.reshape(len(closes), 1))[:, 0]
    closes_points = np.round((440 - std_close * 405) - 15).astype(int)
    close_map = np.asarray(list(zip(closes,closes_points)))
    mask = np.zeros((440, 1820, 3), np.uint8) + 200
    z_line = int(close_map[:, 1][np.argmin(np.abs(close_map[:, 0] - 0))])
    mask[z_line,:] = 155
    dfs = getDegreesDf(lines)
    odfs = []
    for idf in dfs:
        idf.sort_values(by=['date'])
        rdf = idf.copy()
        c_idx = np.argwhere(idf['date_type'].values == 2)[0][0]
        degress = list(idf['degress'].values)
        x = list(idf['w_idx'].values * 4)
        y = list(map(lambda x:int(close_map[:,1][np.argmin(np.abs(close_map[:,0] - x))]),degress))
        rdf['x'] = x
        rdf['h'] = y
        odfs.append(rdf)
        r = np.random.randint(20, 144)
        g = np.random.randint(20, 144)
        b = np.random.randint(20, 144)
        for i in range(1, len(degress)):
            c = i
            p = i - 1
            cv2.line(mask, (x[p], y[p]), (x[c], y[c]), (r, g, b), thickness=1)
            cv2.circle(mask, (x[c], y[c]), 1, (r, g, b), thickness=2)
        cv2.circle(mask, (x[0], y[0]), 2, (0, 0, 255), thickness=2)
        cv2.circle(mask, (x[-1], y[-1]), 2, (0, 0, 255), thickness=2)
        cv2.circle(mask, (x[c_idx], y[c_idx]), 2, (0, 0, 255), thickness=2)
    mask[0,:] = 255
    fdf = pd.concat(odfs)
    return mask,fdf


def getImageSplit(n):
    mid = int(n / 2)
    step = int(n * 0.618)
    one = 0
    two = step
    three = int(n * 0.382)
    four = mid - int(step / 2)
    five = mid + int(step / 2)
    lst = sorted([one, two, three, four, five,n])
    return lst
def getClsV(v,cls):
    for i in range(1,len(cls)):
        s_idx = cls[i-1]
        e_idx = cls[i]
        if v == 0:
            return 1
        if v > s_idx and v <= e_idx:
            return i
import numpy as np
def getImageInfo(h_cls,w_cls,data,widx,wdates):
    points = data[widx]
    rlines = []
    for i in range(len(points)):
        h_cv = 440 - points[i][1]
        if i == 0:
            p_cv = 440 - data[0][1]
        else:
            p_cv = 440 - points[i-1][1]
        t = 1 if h_cv > p_cv else 0
        w_cv = points[i][0]
        h_1v = 440 - points[i][2]
        h_6v = 440 - points[i][3]
        w_ct = getClsV(w_cv,w_cls)
        h_ct = getClsV(h_cv,h_cls)
        h_1t = getClsV(h_1v,h_cls)
        h_6t = getClsV(h_6v,h_cls)
        rline = {
             'point_d':wdates[i]
            ,'point_t':t
            , 'w_cv':w_cv,'w_ct':w_ct
            , 'h_cv': h_cv, 'h_ct': h_ct
            , 'h_1v': h_1v, 'h_1t': h_1t
            , 'h_6v': h_6v, 'h_6t': h_6t
        }
        rlines.append(rline)
    return rlines
def getMergeImageInfo(h_cls,w_cls,df,ma=True,col='x'):
    ts    = []
    w_cts = []
    h_cts = []
    h_1ts = []
    h_6ts = []
    rdf = df.copy()
    for i in range(len(df)):
        cline = df.iloc[i]
        try:
            nline = df.iloc[i+1]
        except:
            pass
        pline = df.iloc[i-1]
        cc = cline['close']
        nc = nline['close']
        pc = pline['close']
        if i == 0:
            t = 0 if nc > cc else 1
        else:
            t = 1 if cc > pc else 0
        w_cv = cline[col]
        h_cv = 440 - cline['h']
        w_ct = getClsV(w_cv,w_cls)
        h_ct = getClsV(h_cv,h_cls)
        ts.append(t)
        w_cts.append(w_ct)
        h_cts.append(h_ct)
        if ma:
            h_1v = 440 - cline['c10']
            h_6v = 440 - cline['c60']
            h_1t = getClsV(h_1v, h_cls)
            h_6t = getClsV(h_6v, h_cls)
            h_1ts.append(h_1t)
            h_6ts.append(h_6t)
    rdf['ts'] = ts
    rdf['w_ct'] = w_cts
    rdf['h_ct'] = h_cts
    if ma:
        rdf['h_1t'] = h_1ts
        rdf['h_6t'] = h_6ts
    return rdf