from hl_tool.daily.AnaGetPointDataDaily import runPointDailyData
from hl_tool.daily.AnaToolDaily import runAnaSummaryClose
from hl_tool.daily.AnaToolPNDaily import runAnaSummaryDegress
from hl_tool.daily.GetAnaClsDaily import runAnaClsClose
from hl_tool.daily.GetAnaClsPNDaily import runAnaClsDegress
from hl_tool.daily.GetAnaConvDataDaily import runConvAnaClose
from hl_tool.daily.GetAnaConvDataPNDaily import runConvAnaDegress
from hl_tool.daily.GetAnaDataDaily import runAnaClose
from hl_tool.daily.GetAnaDataPNDaily import runAnaDegress
from hl_tool.daily.LoaderNpz import runLoader2NPZ

if __name__ == '__main__':
    runAnaClose()
    runAnaDegress()
    runConvAnaClose()
    runConvAnaDegress()
    runAnaClsClose()
    runAnaClsDegress()
    runAnaSummaryDegress()
    runAnaSummaryClose()
    runPointDailyData()
    runLoader2NPZ()