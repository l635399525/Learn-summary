import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getImageDataCls():
    an_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_Degress'))
    sql = '''
    select a.code, a.work_date, av1_r4, av2_r4, av3_r4, av4_r4,  av1_r5, av2_r5, av3_r5, av4_r5, av5_r5 from
    (select code,work_date,
    round(av1*1.0/(av1+av2+av3+av4),3) as av1_r4,
    round(av2*1.0/(av1+av2+av3+av4),3) as av2_r4,
    round(av3*1.0/(av1+av2+av3+av4),3) as av3_r4,
    round(av4*1.0/(av1+av2+av3+av4),3) as av4_r4
    from raw_data_ana_cnts_conv4_a) a,
    (select code,work_date,
    round(av1*1.0/(av1+av2+av3+av4+av5),3) as av1_r5,
    round(av2*1.0/(av1+av2+av3+av4+av5),3) as av2_r5,
    round(av3*1.0/(av1+av2+av3+av4+av5),3) as av3_r5,
    round(av4*1.0/(av1+av2+av3+av4+av5),3) as av4_r5,
    round(av5*1.0/(av1+av2+av3+av4+av5),3) as av5_r5
    from raw_data_ana_cnts_a) b
    where a.code = b.code and a.work_date = b.work_date 
    '''
    df = query(sql,an_conn)
    col_a = ['av1_r4', 'av2_r4', 'av3_r4', 'av4_r4']
    col_b = ['av1_r5', 'av2_r5', 'av3_r5', 'av4_r5', 'av5_r5']
    rdfs = []
    for i in range(len(df)):
        print("%s %s---" %(i,len(df)))
        idf = df.iloc[i]
        rdf = idf.copy()
        data_a = idf[col_a].values
        sort_a = np.argsort([data_a])[0]
        cls_a = []
        for j in range(len(sort_a)):
            idx4= np.argwhere(sort_a == j)[0][0]
            rdf['idx4_%s' %(j)] = idx4 + 1
            cls_a.append(str(idx4+1))
        data_b = idf[col_b].values
        sort_b = np.argsort([data_b])[0]
        cls_b = []
        for j in range(len(sort_b)):
            idx5= np.argwhere(sort_b == j)[0][0]
            rdf['idx5_%s' %(j)] = idx5 + 1
            cls_b.append(str(idx5+1))
        clsa = ''.join(cls_a)
        clsb = ''.join(cls_b)
        cls_a = np.asarray(cls_a).astype(float)
        cls_b = np.asarray(cls_b).astype(float)
        cls_a_s = sum(np.diff(cls_a))
        cls_b_s = sum(np.diff(cls_b))
        rdf['cls_a'] = clsa
        rdf['cls_b'] = clsb
        rdf['cls_a_s'] = cls_a_s
        rdf['cls_b_s'] = cls_b_s
        rdfs.append(rdf)
    fds = pd.DataFrame(rdfs)
    insert(fds,an_conn,'raw_data_ana_cnts_rate')
def getImageDataClsDif():
    an_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_Degress'))
    sql = '''
    select * from raw_data_ana_cnts_rate
    '''
    df = query(sql,an_conn)
    dfs = df.groupby('code')
    rdf_diffs = []
    work_cols = ['av1_r4', 'av2_r4', 'av3_r4', 'av4_r4', 'av1_r5', 'av2_r5', 'av3_r5', 'av4_r5', 'av5_r5','cls_a_s','cls_b_s']
    for code, idf in dfs:
        if len(idf) <= 1:
            continue
        idf = idf.sort_values(by=['work_date'])
        heads = ['code','work_date']
        f_data = idf[work_cols].copy().values
        rlines = []
        for i in range(1, len(f_data)):
            cline = f_data[i, :].astype(float)
            pline = f_data[i - 1, :].astype(float)
            dif_line = (cline - pline) * 100
            dif_val = np.round(dif_line / pline, 3)
            z_idx = np.argwhere(pline == 0)[:, 0]
            dif_val[z_idx] = 100
            rlines.append(dif_val)
        rlines = np.asarray(rlines)
        cols = list(map(lambda x: '%s_d' % (x), work_cols))
        dif_df = pd.DataFrame(data=rlines, columns=cols)
        for head in heads:
            dif_df[head] = idf[head].values[1:]
        rdf_diffs.append(dif_df)
        print("%s %s " % (code,  len(rdf_diffs)))
    bdf = pd.concat(rdf_diffs)
    insert(bdf, an_conn, 'raw_data_ana_cnts_rate_b')
def runAnaClsDegress():
    getImageDataCls()
    getImageDataClsDif()
if __name__ == '__main__':
    getImageDataCls()
    getImageDataClsDif()

