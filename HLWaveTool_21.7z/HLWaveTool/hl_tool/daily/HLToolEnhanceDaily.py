import glob

import cv2
import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
from hl_tool.FuncTool import getDataSplitIdx, _draw_close, getImageSplit, getImageInfo, _draw_degrees, getMergeImageInfo
import os

def getMergeInfos(rdf,code):
    afs = rdf.t.apply(lambda x: 1 if x == 'A' else -1).values
    idxes = getDataSplitIdx(afs)
    max_idxes = list(map(lambda x: max(x), idxes))
    rdf = rdf.iloc[max_idxes].copy()
    rdf.rename(columns={'code': 'code', 'percent': 'percent', 't': 't', 'date': 'ndate', 'c_0': 'nclose'}, inplace=True)
    rdf['cdate'] = rdf.ndate.shift(1).values
    rdf['cclose'] = rdf.nclose.shift(1).values
    rdf['pdate'] = rdf.ndate.shift(2).values
    rdf['pclose'] = rdf.nclose.shift(2).values
    rdf = rdf.dropna()
    rdf = rdf.sort_values(by=['ndate'])
    diffs = np.diff(rdf[['pclose', 'cclose', 'nclose']].values, axis=1)
    gap = diffs[:, 0] * diffs[:, 1]
    if np.count_nonzero(gap >= 0) > 0:
        print("%s ################Issue" % (code))
    wdates = list(rdf.ndate.values)
    pdate = rdf.iloc[0]['pdate']
    cdate = rdf.iloc[0]['cdate']
    wdates.append(pdate)
    wdates.append(cdate)
    wdates = sorted(wdates)
    return wdates
import math
import cmath
def _getDegressData(show_data,show_peak_idxes,show_wave_idxes):
    start = np.zeros(1)
    show_peak_idxes = np.hstack([start,show_peak_idxes])
    show_wave_idxes = np.hstack([start,show_wave_idxes])
    show_wave_idxes = np.sort(show_wave_idxes).astype(int)
    show_peak_idxes = np.sort(show_peak_idxes).astype(int)
    def _getDegVal(data,peak_idx,p_idx,n_idx):
        #raw_peak_idx = peak_idx
        peak_idx = peak_idx[np.argwhere((peak_idx >= p_idx) & (peak_idx <= n_idx))[:,0]]
        data = data[peak_idx]
        start = data[0][1]
        start_p = peak_idx[0]
        h = data[:,1]
        y = ((h - start)*100/start).astype(float)
        w = peak_idx - start_p
        lst = list(zip(w,y))
        cum_degress = list(map(lambda x: round(math.degrees(cmath.polar(complex(x[0], x[1]))[1]), 1), lst))
        line = {'data':data,'degress':cum_degress,'w_idx':peak_idx}
        return line
    line_pns = []
    line_cns = []
    for i in range(2,len(show_wave_idxes)):
        p_idx = show_wave_idxes[i - 2]
        c_idx = show_wave_idxes[i - 1]
        n_idx = show_wave_idxes[i]
        show_data[[p_idx,c_idx,n_idx]]
        #pn_data = show_data[p_idx:n_idx+1]
        #cn_data = show_data[c_idx:n_idx+1]
        line_pn = _getDegVal(show_data,show_peak_idxes,p_idx,n_idx)
        line_pn['p_date'] = show_data[p_idx][0]
        line_pn['c_date'] = show_data[c_idx][0]
        line_pn['n_date'] = show_data[n_idx][0]
        line_pn['idxes']  = [p_idx,c_idx,n_idx]
        line_cn = _getDegVal(show_data,show_peak_idxes,c_idx,n_idx)
        line_cn['p_date'] = show_data[p_idx][0]
        line_cn['c_date'] = show_data[c_idx][0]
        line_cn['n_date'] = show_data[n_idx][0]
        line_cn['idxes']  = [p_idx,c_idx,n_idx]
        line_pns.append(line_pn)
        line_cns.append(line_cn)
    return line_pns,line_cns
def getHLWavePoints():
    from datetime import datetime
    # codes = glob.glob(r'D:\data\images\final\*')
    # data_map = {}
    # for code in codes:
    #     try:
    #         jpgs = glob.glob(r'%s\*.jpg' %(code))
    #         nums = np.asarray(list(map(lambda x:str(x).split("\\")[-1].split("#")[0],jpgs))).astype(int)
    #         jpgs = np.asarray(jpgs)
    #         jpgs = jpgs[np.argsort(nums)]
    #         dates = list(map(lambda x:str(x).split("\\")[-1].split("#")[-1].split(".")[0],jpgs))
    #         code = code.split("\\")[-1]
    #         data_map[code] = dates
    #     except:
    #         pass
    conn = getConn(r'D:\data\summary_db\RAW_HLWAVES_DATA')
    sh_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_DAILY")
    sql = '''
    select distinct code,date,close,pctchg as percent,volume,open from raw_data_d where  date(date) > date('2009-01-01')
    union
    select distinct code,date,close,percent,volume,open from raw_data_d_xq_zs where  date(date) > date('2009-01-01')
    '''
    h_cls = getImageSplit(440)
    w_cls = getImageSplit(1820)
    df = query(sql,conn)
    dfs = df.groupby('code')
    odfs_a = []
    odfs_b = []
    odfs_c = []
    for code,idf in dfs:
        # if code != 'sh.600532':
        #     continue
        try:
            idf = idf[(idf['open'] != 0)&(idf['percent'] != 0)&(idf['volume'] != 0)].copy()
            edates = glob.glob(r'D:\data\images\final\%s\*.jpg' %(code))
            edates = sorted(list(map(lambda x:x.split("\\")[-1].split("#")[2].split(".")[0],edates)))
            max_date = edates[-2]
            max_date = datetime.strptime(max_date,'%Y-%m-%d')
            try:
                idf = idf.sort_values(by=['date'])
                idf['ma60'] = np.round(idf.close.rolling(60).mean().values,3)
                idf['ma10'] = np.round(idf.close.rolling(10).mean().values,3)
                idf = idf.dropna()
                idf_1 = idf[['code','date','percent']].copy()
                idf_1 = idf_1.sort_values(by=['date'])
                close_date = idf[['date', 'close','ma10','ma60']].values
                cols = []
                for i in range(13):
                    idf_1['c_%s' %(i)] = idf.close.shift(i).values
                    cols.append('c_%s' %(i))
                idf_1 = idf_1.dropna()
                datas = idf_1[cols].values
                max_idxes = np.argmax(datas,axis=1)
                min_idxes = np.argmin(datas,axis=1)
                max_idxes = np.argwhere(max_idxes == 0)[:,0]
                min_idxes = np.argwhere(min_idxes == 0)[:, 0]
                dfa = idf_1[['code', 'date', 'percent', 'c_0']].iloc[max_idxes].copy()
                dfa['t'] = 'A'
                dfb = idf_1[['code', 'date', 'percent', 'c_0']].iloc[min_idxes].copy()
                dfb['t'] = 'B'
                rdf = pd.concat([dfa,dfb])
                tmp_dates = rdf.date.values
                tmp_end_date = tmp_dates[np.argsort(tmp_dates)][-1]
                end_date = idf_1['date'].values[-1]
                if end_date != tmp_end_date:
                    dfc = idf_1[['code', 'date', 'percent', 'c_0']].iloc[[-1]].copy()
                    dfc['t'] = 'A'
                    rdf = pd.concat([dfa, dfb,dfc])
                    stock_status = 'Ongoing'
                else:
                    stock_status = 'Done'

                rdf = rdf.sort_values(by=['date'])
                wdates = getMergeInfos(rdf,code)
                peak_dates = np.sort(rdf['date'].values)

                # if end_date not in wdates:
                #     wdates.append(end_date)
                # if end_date not in peak_dates:
                #     peak_dates.append(end_date)

                #peak_dates_idxes = list(map(lambda x: np.argwhere(close_date[:, 0] == x)[0][0], peak_dates))
                wdate_idxes = list(map(lambda x: np.argwhere(close_date[:, 0] == x)[0][0], wdates))
                spec = 454
                work_idxes = list(filter(lambda x:x>spec,wdate_idxes))
                wdates = np.asarray(wdates)
                out = r'D:\data\images\final_daily\%s' %(code)
                rdfs_a = []
                rdfs_b = []
                rdfs_c = []
                for i in range(len(work_idxes)):
                    try:
                        eidx = work_idxes[i]
                        sids = eidx - spec
                        show_data = close_date[sids:eidx+1]

                        dates_tmp = datetime.strptime(show_data[-1][0],'%Y-%m-%d')
                        if dates_tmp < max_date:
                            continue
                        #
                        # if show_data[-1][0] in edates:
                        #     continue
                        show_wave_idxes = np.argwhere(np.in1d(show_data[:,0],wdates))[:,0]
                        show_peak_idxes = np.argwhere(np.in1d(show_data[:,0],peak_dates))[:,0]
                        line_pns,line_cns = _getDegressData(show_data,show_peak_idxes,show_wave_idxes)
                        mask_pn,rdf_pn = _draw_degrees(line_pns)
                        mask_cn,rdf_cn = _draw_degrees(line_cns)
                        mask,df,data = _draw_close(show_data,show_wave_idxes)
                        df['code'] = code
                        df['work_date'] = show_data[-1][0]
                        rdf_merge  = getMergeImageInfo(h_cls, w_cls, df,ma=True,col='w')
                        rdf_pn_sum = getMergeImageInfo(h_cls, w_cls, rdf_pn,ma=False,col='x')
                        rdf_cn_sum = getMergeImageInfo(h_cls, w_cls, rdf_cn,ma=False,col='x')
                        rdf_pn_sum = rdf_pn_sum.copy()
                        rdf_cn_sum = rdf_cn_sum.copy()
                        rdf_pn_sum['code'] = code
                        rdf_pn_sum['work_date'] = show_data[-1][0]
                        rdf_cn_sum['code'] = code
                        rdf_cn_sum['work_date'] = show_data[-1][0]
                        rdfs_a.append(rdf_merge)
                        rdfs_b.append(rdf_pn_sum)
                        rdfs_c.append(rdf_cn_sum)
                        if True:
                            for j in range(1,len(w_cls)-1):
                                wc = w_cls[j]
                                hc = h_cls[j]
                                mask[:,wc] = 0
                                mask[hc,:] = 0
                                mask_cn[:, wc] = 0
                                mask_cn[hc, :] = 0
                                mask_pn[:, wc] = 0
                                mask_pn[hc, :] = 0
                        all_mask = np.vstack([mask,mask_pn,mask_cn])
                        if not os.path.exists(out):
                            os.makedirs(out)
                        if True:
                            if i == len(work_idxes) - 1:
                                cv2.imwrite(r'%s\%s#%s#%s#%s.jpg' % (out, i + 1, code, show_data[-1][0],stock_status), all_mask)
                            else:
                                cv2.imwrite(r'%s\%s#%s#%s.jpg' %(out,i+1,code,show_data[-1][0]),all_mask)
                        print("%s %s %s" %(code,i,len(wdate_idxes)))
                    except:
                        pass
                rdf_a = pd.concat(rdfs_a)
                rdf_b = pd.concat(rdfs_b)
                rdf_c = pd.concat(rdfs_c)
                #odfs_a.append(rdf_a)
                #odfs_b.append(rdf_b)
                #odfs_c.append(rdf_c)
                head = str(code).split(".")[0]
                if head == 'sz':
                    head = 'SZ'
                else:
                    head = 'SH'
                if len(rdf_a) > 0:
                    odfs_a.append(rdf_a)
                if len(rdf_b) > 0:
                    odfs_b.append(rdf_b)
                if len(rdf_c) > 0:
                    odfs_c.append(rdf_c)

                # if len(odfs_a) % 500 == 0 and len(odfs_a) > 0:
                #     df_a = pd.concat(odfs_a)
                #     insert(df_a, sh_conn, 'raw_merger_image_data_info_SH_Daily', opType='append')
                #     odfs_a = []
                # if len(odfs_b) % 500 == 0 and len(odfs_b) > 0:
                #     df_b = pd.concat(odfs_b)
                #     insert(df_b, sh_conn, 'raw_merger_degress_data_pn_SH_Daily', opType='append')
                #     odfs_b = []
                # if len(odfs_c) % 500 == 0 and len(odfs_c) > 0:
                #     df_c = pd.concat(odfs_c)
                #     insert(df_c, sh_conn, 'raw_merger_degress_data_cn_SH_Daily', opType='append')
                #     odfs_c = []
                # if len(odfs_b) % 50 == 0 and len(odfs_b) > 0:
                #     df_b = pd.concat(odfs_b)
                #     insert(df_b, conn, 'raw_merger_degress_data_pn_SH', opType='append')
                #     rdf_b = []
                #
                # if len(rdf_c) % 100 == 0 and len(rdf_c) > 0:
                #     df_c = pd.concat(rdf_c)
                #     insert(df_c, dest_conn, 'raw_merger_image_data_info_SH', opType='append')
                #     rdf_c = []
                # insert(rdf_a, conn, 'raw_merger_image_data_info_%s' %(head), opType='append')
                # insert(rdf_b, conn, 'raw_merger_degress_data_pn_%s' %(head), opType='append')
                # insert(rdf_c, conn, 'raw_merger_degress_data_cn_%s' %(head), opType='append')
                print("%s %s %s %s Done" %(code,len(odfs_a),len(odfs_b),len(odfs_c)))
            except:

                pass
        except:
            pass
    if len(odfs_a) > 0:
        df_a = pd.concat(odfs_a)
        insert(df_a, sh_conn, 'raw_merger_image_data_info_SH_Daily')
        odfs_a = []
    if len(odfs_b) > 0:
        df_b = pd.concat(odfs_b)
        insert(df_b, sh_conn, 'raw_merger_degress_data_pn_SH_Daily')
        odfs_b = []
    if len(odfs_c) > 0:
        df_c = pd.concat(odfs_c)
        insert(df_c, sh_conn, 'raw_merger_degress_data_cn_SH_Daily')
        odfs_c = []
    # rdfa = pd.concat(odfs_a)
    # rdfb = pd.concat(odfs_b)
    # rdfc = pd.concat(odfs_c)

if __name__ == '__main__':
    getHLWavePoints()