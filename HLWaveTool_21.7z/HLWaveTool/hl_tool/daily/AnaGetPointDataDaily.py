import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path

degress_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_Degress'))
close_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_CLOSE'))
daily_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY'))
train_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN'))


def _calAngle(pp, cp, np):
    # a 左边 b 右边
    import math
    x1, y1 = pp[0], pp[1]
    x2, y2 = cp[0], cp[1]
    x3, y3 = np[0], np[1]
    try:
        a = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        b = math.sqrt((x2 - x3) ** 2 + (y2 - y3) ** 2)
        c = math.sqrt((x1 - x3) ** 2 + (y1 - y3) ** 2)
        A = math.degrees(math.acos((a * a - b * b - c * c) / (-2 * b * c)))
        B = math.degrees(math.acos((b * b - a * a - c * c) / (-2 * a * c)))
        C = math.degrees(math.acos((c * c - a * a - b * b) / (-2 * a * b)))
    except:
        import traceback
        traceback.print_exc()

    return a,b,c,A,B,C
import math,cmath
def getImagePointsDataDaily():
    files = ['RAW_HLWAVES_DATA_HISTORYSES_DAILY']
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS")

    for file in files:
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        sql = '''
                select distinct w, h, c10, c60, date, x, close, ma10, ma60, code, work_date, ts, w_ct, h_ct, h_1t, h_6t from raw_merger_image_data_info_SH_Daily 
                '''
        df = query(sql,sh_conn)
        dfs = df.groupby(['code','work_date'])
        odfs = []
        for line,idf in dfs:
            code,work_date = line
            try:
                idf = idf.sort_values(by=['date'])
                cdate = idf['date'].shift(1).values
                pdate = idf['date'].shift(2).values
                p1h = 440 - idf['h'].shift(1).values
                p2h = 440 - idf['h'].shift(2).values
                p1w = idf['w'].shift(1).values
                p2w = idf['w'].shift(2).values

                p1wc_t = idf['w_ct'].shift(1).values
                p2wc_t = idf['w_ct'].shift(2).values
                p1hc_t = idf['h_ct'].shift(1).values
                p2hc_t = idf['h_ct'].shift(2).values

                idf['cdate'] = cdate
                idf['pdate'] = pdate
                rdf = pd.DataFrame()

                rdf['code'] = idf['code'].values
                rdf['work_date'] = idf['work_date'].values
                rdf['pdate'] = pdate
                rdf['cdate'] = cdate
                rdf['ndate'] = idf['date'].values
                rdf['pw'] = p2w
                rdf['cw'] = p1w
                rdf['nw'] = idf['w'].values
                rdf['ph'] = p2h
                rdf['ch'] = p1h
                rdf['nh'] = 440 - idf['h'].values
                rdf['pwc_t'] = p2wc_t
                rdf['cwc_t'] = p1wc_t
                rdf['nwc_t'] = idf['w_ct'].values

                rdf['phc_t'] = p2hc_t
                rdf['chc_t'] = p1hc_t
                rdf['nhc_t'] = idf['h_ct'].values

                rdf = rdf.dropna()
                #rdf.apply(lambda x:_calAngle([x['pw'],x['ph']],[x['cw'],x['ch']],[x['nw'],x['nh']]),axis=1)
                try:
                    angle_infos = list(rdf.apply(lambda x: _calAngle([x['pw'], x['ph']], [x['cw'], x['ch']], [x['nw'], x['nh']]),axis=1).values)
                except:
                    pass
                polor_degress_c = rdf.apply(lambda x:  math.degrees(cmath.polar(complex(x['cw'] - x['pw'], x['ch'] - x['ph']))[1]), axis=1).values
                polor_degress_n = rdf.apply(lambda x:  math.degrees(cmath.polar(complex(x['nw'] - x['cw'], x['nh'] - x['ch']))[1]), axis=1).values
                rdf['d_a'] = np.round(list(map(lambda x:x[0],angle_infos)),1)
                rdf['d_b'] = np.round(list(map(lambda x:x[1],angle_infos)),1)
                rdf['d_c'] = np.round(list(map(lambda x:x[2],angle_infos)),1)
                rdf['a_A'] = np.round(list(map(lambda x:x[3],angle_infos)),1)
                rdf['a_B'] = np.round(list(map(lambda x:x[4],angle_infos)),1)
                rdf['a_C'] = np.round(list(map(lambda x:x[5],angle_infos)),1)
                rdf['polor_c'] = np.round(polor_degress_c,1)
                rdf['polor_n'] = np.round(polor_degress_n,1)
                fdf = rdf.iloc[-7:]
                odfs.append(fdf)
            except:
                import traceback
                traceback.print_exc()
                pass
            print("%s %s %s %s" %(code,work_date,len(odfs),len(dfs)))
        fdf = pd.concat(odfs)
        insert(fdf, an_conn, 'raw_data_ana_cnts_point_daily')
def getImagePointV2HData():
    def getHistData():
        dest_conn = close_conn
        an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
        sql = '''
select code, work_date, ndate, nhc_t, date_5, hc_t_5, date_4, hc_t_4, date_3, hc_t_3, date_2, hc_t_2, date_1, hc_t_1 from raw_data_ana_cnts_ny_H2V
        '''
        df = query(sql,an_conn)
        insert(df,dest_conn,'raw_data_ana_cnts_ny_H2V_hist')
    #dest_an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    srcs_an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS")
    #getHistData()
    sql = '''
select distinct code,work_date,ndate,nhc_t from raw_data_ana_cnts_point_daily 
    '''
    df = query(sql, srcs_an_conn)
    dfs = df.groupby('code')
    odfs = []
    for code, idf in dfs:
        idfs = idf.groupby('work_date')
        for work_date, iidf in idfs:

            iidf = iidf.sort_values(by=['ndate'])
            for i in range(1, 6):
                iidf['date_%s' % (6 - i)] = iidf['ndate'].shift(i).values
                iidf['hc_t_%s' % (6 - i)] = iidf['nhc_t'].shift(i).values
            line = dict(iidf.iloc[-1])
            odfs.append(line)
            print("%s %s %s" % (code, work_date, len(odfs)))
    rdf = pd.DataFrame(odfs)
    #insert(rdf, srcs_an_conn, 'raw_data_ana_cnts_ny_H2V_daily')
    #insert(rdf, daily_conn,   'raw_data_ana_cnts_ny_H2V_daily')
    insert(rdf, close_conn,   'raw_data_ana_cnts_ny_H2V_daily')
    sql = '''
    select distinct code, work_date, ndate, nhc_t, date_5, hc_t_5, date_4, hc_t_4, date_3, hc_t_3, date_2, hc_t_2, date_1, hc_t_1 from
(select  code, work_date, ndate, nhc_t, date_5, hc_t_5, date_4, hc_t_4, date_3, hc_t_3, date_2, hc_t_2, date_1, hc_t_1 from
raw_data_ana_cnts_ny_H2V_daily  where  date_3 is not null
union
select code, work_date, ndate, nhc_t, date_5, hc_t_5, date_4, hc_t_4, date_3, hc_t_3, date_2, hc_t_2, date_1, hc_t_1 from raw_data_ana_cnts_ny_H2V_hist
where   code || work_date not in (select code||work_date from raw_data_ana_cnts_ny_H2V_daily where  date_3 is not null))
order by code,work_date
    '''
    df = query(sql,close_conn)
    insert(df, close_conn, 'raw_data_ana_cnts_ny_H2V')
def getDataReverse():

    def getHistData():
        dest_conn = close_conn
        an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
        sql = '''
        select  code, date, ts, close, close_1, date_1, close_2, date_2, close_3, date_3, a_score, a0, a1, a2, b_score, b0, b1, b2 from raw_data_ana_cnts_ny3_reverse
        '''
        df = query(sql,an_conn)
        insert(df,dest_conn,'raw_data_ana_cnts_ny3_reverse_hist')
    files = ['RAW_HLWAVES_DATA_HISTORYSES_DAILY']
    #getHistData()
    #an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS")
    sql = '''
select distinct code,date,ts,close from raw_merger_image_data_info_SH_Daily  
        '''
    for file in files:
        odfs = []
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        df = query(sql,sh_conn)
        dfs = df.groupby(['code','ts'])
        for line,idf in dfs:
            code,ts = line
            idf = idf.sort_values(by=['date'])
            scores = [5,3,2]
            for i in range(1,4):
                idf['close_%s' %(i)] = idf.close.shift(i).values
                idf['date_%s' %(i)]  = idf.date.shift(i).values


            data = idf[['close_3','close_2','close_1','close']].values
            data = np.diff(data,axis=1)
            data_a = np.zeros(data.shape)
            data_a[data > 0] = 1
            data_b = np.zeros(data.shape)
            data_b[data < 0] = 1
            scores_a = data_a*scores
            scores_b = data_b*scores*-1
            a_scores = np.sum(scores_a,axis=1)
            b_scores = np.sum(scores_b,axis=1)
            idf['a_score'] = a_scores
            idf['a0'] = data_a[:,0]
            idf['a1'] = data_a[:,1]
            idf['a2'] = data_a[:,2]
            idf['b_score'] = b_scores
            idf['b0'] = data_b[:,0]
            idf['b1'] = data_b[:,1]
            idf['b2'] = data_b[:,2]
            odfs.append(idf)
            print("%s %s %s" %(code,ts,len(odfs)))
        fdf = pd.concat(odfs)
        #insert(fdf, daily_conn, 'raw_data_ana_cnts_ny3_reverse_daily')
        insert(fdf, close_conn, 'raw_data_ana_cnts_ny3_reverse_daily')
        #insert(fdf, degress_conn, 'raw_data_ana_cnts_ny3_reverse_daily')
    sql = '''
    select distinct code, date, ts, close, close_1, date_1, close_2, date_2, close_3, date_3, a_score, a0, a1, a2, b_score, b0, b1, b2 from
(select  code, date, ts, close, close_1, date_1, close_2, date_2, close_3, date_3, a_score, a0, a1, a2, b_score, b0, b1, b2 from
raw_data_ana_cnts_ny3_reverse_daily  where  close_3 is not null
union
select code, date, ts, close, close_1, date_1, close_2, date_2, close_3, date_3, a_score, a0, a1, a2, b_score, b0, b1, b2 from raw_data_ana_cnts_ny3_reverse_hist
where   code || date not in (select code||date from raw_data_ana_cnts_ny3_reverse_daily where  close_3 is not null))
    '''
    df = query(sql,close_conn)
    insert(df, close_conn, 'raw_data_ana_cnts_ny3_reverse')

def getNysFinal():
    sql = '''
    select distinct a.code, a.work_date, any, ny,t,b.ts from
(select a.code,a.work_date,a.ny as any
     ,case when b.ny is null then a.ny else a.ny + b.ny end as ny
     ,case when b.t  is null then 'C' else b.t end as t
 from
(select code,work_date,(nhc_t - min(hc_t_4,hc_t_3,hc_t_2,hc_t_1)) - 2 as  ny from raw_data_ana_cnts_ny_H2V) a
left outer join
(select a.code,a.date,ny + ny1 as ny,'A' as t from raw_data_ana_cnts_ny3_reverse a,(select a.code, a.work_date,
       nhc_t -  hc_t_4 AS ny,nhc_t - hc_t_3 as ny1 from raw_data_ana_cnts_ny_H2V a where  ny >= 2) b
where a.code = b.code and a.date = b.work_date
union
select code,date,a0 + a1 + a2 as ny,'B' as t from raw_data_ana_cnts_ny3_reverse where a0 + a1 + a2 = 3 and ts = 1
and code || date not in
(select code||date as key from
(select a.code,a.date from raw_data_ana_cnts_ny3_reverse a,(select a.code, a.work_date,
       nhc_t -  hc_t_4 AS ny,nhc_t - hc_t_3 as ny1 from raw_data_ana_cnts_ny_H2V a where  ny >= 2) b
where a.code = b.code and a.date = b.work_date))) b
on a.code = b.code and a.work_date=b.date) a,raw_data_ana_cnts_ny3_reverse b
where a.code = b.code and a.work_date = b.date
    '''
    df = query(sql,close_conn)
    insert(df, close_conn,   'raw_data_ana_cnts_ny_H2V_nys_final')
    insert(df, degress_conn, 'raw_data_ana_cnts_ny_H2V_nys_final')
    insert(df, daily_conn, 'raw_data_ana_cnts_ny_H2V_nys_final')

def _getRateClsChangePN(conn,conn_train,table,table_hist):
    def getHist(conn,conn_hist,table):
        sql = '''
        select a.code,a.work_date,a.cls_a,a.cls_b,cls_b_d,cls_b_d_deg,cls_a_d,cls_a_d_deg
    --,d.ny,d.t
    from raw_data_ana_cnts_rate a,raw_data_ana_cnts b
    ,raw_data_ana_cnts_degress_arate c
    where a.code = b.code and a.work_date = b.work_date
    and a.code = c.code and a.work_date = c.work_date
        '''
        df = query(sql,conn_hist)
        insert(df,conn,table)

    #getHist(conn,conn_train,table_hist)
    SQL = '''
            select a.code,a.work_date,a.cls_a,a.cls_b,cls_b_d,cls_b_d_deg,cls_a_d,cls_a_d_deg
        --,d.ny,d.t
        from raw_data_ana_cnts_rate a,raw_data_ana_cnts b
        ,raw_data_ana_cnts_degress_arate c
        where a.code = b.code and a.work_date = b.work_date
        and a.code = c.code and a.work_date = c.work_date
            '''
    df = query(SQL,conn)
    insert(df, conn, table)
    SQL = '''
    select a.code,a.work_date,cls_a,cls_b,cls_b_d,cls_b_d_deg,cls_a_d,cls_a_d_deg,b.ts,b.ny,b.t from
(select code,work_date,cls_a,cls_b,cls_b_d,cls_b_d_deg,cls_a_d,cls_a_d_deg  from   {table_hist}
where code||work_date not in (select code||work_date  from   {table_daily})
union
select code,work_date,cls_a,cls_b,cls_b_d,cls_b_d_deg,cls_a_d,cls_a_d_deg  from   {table_daily}
order by code,work_date) a,raw_data_ana_cnts_ny_H2V_nys_final b
where a.code = b.code and a.work_date = b.work_date
    '''.format(table_hist=table_hist,table_daily=table)

    df = query(SQL,conn)

    dfs = df.groupby('code')
    rdfs = []
    for code, idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        rdf = idf[['code', 'work_date', 'ts', 't', 'ny', 'cls_a', 'cls_b']]
        for i in range(1, 10):
            rdf['cls_a_%s' % (i)] = idf['cls_a'].shift(i).values
            rdf['cls_b_%s' % (i)] = idf['cls_b'].shift(i).values
        rdfs.append(rdf)
        print("%s %s" % (code, len(rdfs)))
    rdf = pd.concat(rdfs)
    insert(rdf, daily_conn, table)

def getRateClsChangePNClose():
    an_conns = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_Close'))
    train_conns = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    _getRateClsChangePN(an_conns,train_conns, 'ClsChange_Close_Daily', 'ClsChange_Close_Hist')

def getRateClsChangePNDegress():
    pn_conns = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_Degress'))
    train_conns = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")

    _getRateClsChangePN(pn_conns,train_conns, 'ClsChange_Degress_Daily', 'ClsChange_Degress_Hist')
def _anaKpiChart(score,daily_conn,train_conn,type):
    def getKpi(type,daily_conn,train_conn):
        sql = '''
        select * from ClsChange_ana_ab_overs_kpi_{type}
        '''.format(type=type)
        df = query(sql,train_conn)
        insert(df,daily_conn,'ClsChange_ana_ab_overs_kpi_%s' %(type))
    #getKpi(type,daily_conn,train_conn)
    #return
    sql = '''
    select code, work_date, ny, cls_a, cls_b,
       afr5_3a, afr5_3b,
       afr7_3a, afr7_3b,
       afr9_3a, afr9_3b,
       afr5_4a, afr5_4b,
       afr7_4a, afr7_4b,
       afr9_4a, afr9_4b,
       afr5_5a, afr5_5b,
       afr7_5a, afr7_5b,
       afr9_5a, afr9_5b,
round(afr5_3a + afr5_3b,3) as afr5_3ab,
round(afr7_3a + afr7_3b,3) as afr7_3ab,
round(afr9_3a + afr9_3b,3) as afr9_3ab,
round(afr5_4a + afr5_4b,3) as afr5_4ab,
round(afr7_4a + afr7_4b,3) as afr7_4ab,
round(afr9_4a + afr9_4b,3) as afr9_4ab,
round(afr5_5a + afr5_5b,3) as afr5_5ab,
round(afr7_5a + afr7_5b,3) as afr7_5ab,
round(afr9_5a + afr9_5b,3) as afr9_5ab,
round(afr5_3a + afr5_3b + afr7_3a*0.98 + afr7_3b*0.98 + afr9_3a*0.95 + afr9_3b*0.95,3) as afr3,
round(afr5_4a + afr5_4b + afr7_4a*0.98 + afr7_4b*0.98 + afr9_4a*0.95 + afr9_4b*0.95,3) as afr4,
round(afr5_5a + afr5_5b + afr7_5a*0.98 + afr7_5b*0.98 + afr9_5a*0.95 + afr9_5b*0.95,3) as afr5,
round(afr5_3a + afr5_3b + afr7_3a*0.98 + afr7_3b*0.98 + afr9_3a*0.95 + afr9_3b*0.95 +
      afr5_4a + afr5_4b + afr7_4a*0.98 + afr7_4b*0.98 + afr9_4a*0.95 + afr9_4b*0.95 +
      afr5_5a + afr5_5b + afr7_5a*0.98 + afr7_5b*0.98 + afr9_5a*0.95 + afr9_5b*0.95,3) as afr
from
(select a.code,a.work_date,ny,a.cls_a,a.cls_b
     ,d.afr5_3 as afr5_3a,e.afr5_3 as afr5_3b
     ,d.afr7_3 as afr7_3a,e.afr7_3 as afr7_3b
     ,d.afr9_3 as afr9_3a,e.afr9_3 as afr9_3b
     ,d.afr5_4 as afr5_4a,e.afr5_4 as afr5_4b
     ,d.afr7_4 as afr7_4a,e.afr7_4 as afr7_4b
     ,d.afr9_4 as afr9_4a,e.afr9_4 as afr9_4b
     ,d.afr5_5 as afr5_5a,e.afr5_5 as afr5_5b
     ,d.afr7_5 as afr7_5a,e.afr7_5 as afr7_5b
     ,d.afr9_5 as afr9_5a,e.afr9_5 as afr9_5b
from ClsChange_{type}_Daily a
,ClsChange_ana_ab_overs_kpi_{type} d
,ClsChange_ana_ab_overs_kpi_{type} e
where a.cls_a = d.cls and a.cls_b = e.cls)
    '''.format(type=type)
    df = query(sql, daily_conn)
    dfs = df.groupby('code')
    def _getIdx(afs,ny,afr,afr3,afr4,afr5,nyar,nyar3,nyar4,nyar5):
        af_10 = np.argwhere(afs ==0)[:,0]
        dif_idx = np.argwhere(np.diff(af_10) > 1)[:,0]
        idxes =list(af_10[dif_idx])
        idxes.append(af_10[-1])
        idxes = sorted(list(set(idxes)))
        odatas= []
        p_idx = 0
        for i in range(len(idxes)):
            idx = idxes[i]
            afrs =  afr[p_idx:idx + 1]
            afr3s = afr3[p_idx:idx + 1]
            afr4s = afr4[p_idx:idx + 1]
            afr5s = afr5[p_idx:idx + 1]
            nyars  = nyar[p_idx:idx + 1]
            nyar3s = nyar3[p_idx:idx + 1]
            nyar4s = nyar4[p_idx:idx + 1]
            nyar5s = nyar5[p_idx:idx + 1]



            nys = ny[p_idx:idx + 1]
            yar = nys*afrs
            yar3= nys*afr3s
            yar4= nys*afr4s
            yar5= nys*afr5s

            afses = afs[p_idx:idx + 1]
            a_idxes  = np.argwhere(afses == 0)[:, 0]
            a_cnt    = len(a_idxes)
            a_score  = np.sum(nys[a_idxes])
            a_cnts   = np.zeros(len(afrs))
            a_scores = np.zeros(len(afrs))
            a_cnts[-1] = a_cnt
            a_scores[-1] = a_score
            stepts    = np.asarray(range(idx - p_idx+1)) + 1
            afr_csum  = np.round(np.cumsum(afrs) ,3)
            afr3_csum = np.round(np.cumsum(afr3s),3)
            afr4_csum = np.round(np.cumsum(afr4s),3)
            afr5_csum = np.round(np.cumsum(afr5s),3)
            yar_csum  = np.round(np.cumsum(yar), 3)
            yar3_csum = np.round(np.cumsum(yar3), 3)
            yar4_csum = np.round(np.cumsum(yar4), 3)
            yar5_csum = np.round(np.cumsum(yar5), 3)
            nyar_csum  = np.round(np.cumsum(nyars), 3)
            nyar3_csum = np.round(np.cumsum(nyar3s), 3)
            nyar4_csum = np.round(np.cumsum(nyar4s), 3)
            nyar5_csum = np.round(np.cumsum(nyar5s), 3)

            ny_csum   = np.round(np.cumsum(nys)  ,3)
            odatas.append([a_scores,a_cnts,stepts,afr_csum,afr3_csum,afr4_csum,afr5_csum,ny_csum,yar_csum,yar3_csum,yar4_csum,yar5_csum,nyar_csum,nyar3_csum,nyar4_csum,nyar5_csum])
            p_idx = idx + 1
            if i == len(idxes) - 1:
                yar  = ny[idx+1:] * afr[idx+1:]
                yar3 = ny[idx+1:] * afr3[idx+1:]
                yar4 = ny[idx+1:] * afr4[idx+1:]
                yar5 = ny[idx+1:] * afr5[idx+1:]

                afr_csum  = np.round(np.cumsum(afr[idx+1:])             ,3)
                afr3_csum = np.round(np.cumsum(afr3[idx+1:])            ,3)
                afr4_csum = np.round(np.cumsum(afr4[idx+1:])            ,3)
                afr5_csum = np.round(np.cumsum(afr5[idx+1:])            ,3)
                stepts    = np.round(np.asarray(range(len(afr_csum))) + 1,3)
                ny_csum   = np.round(np.cumsum(ny[idx+1:])              ,3)
                a_cnts    = np.round(np.zeros(len(stepts))               ,3)
                a_scores  = np.round(np.zeros(len(stepts))               ,3)
                yar_csum   = np.round(np.cumsum(yar )             ,3)
                yar3_csum  = np.round(np.cumsum(yar3)             ,3)
                yar4_csum  = np.round(np.cumsum(yar4)             ,3)
                yar5_csum  = np.round(np.cumsum(yar5)             ,3)
                nyar_csum  = np.round(np.cumsum(nyar[idx + 1:]), 3)
                nyar3_csum = np.round(np.cumsum(nyar3[idx + 1:]), 3)
                nyar4_csum = np.round(np.cumsum(nyar4[idx + 1:]), 3)
                nyar5_csum = np.round(np.cumsum(nyar5[idx + 1:]), 3)
                if len(a_scores) > 0:
                    odatas.append([a_scores,a_cnts,stepts,afr_csum,afr3_csum,afr4_csum,afr5_csum,ny_csum,yar_csum,yar3_csum,yar4_csum,yar5_csum,nyar_csum,nyar3_csum,nyar4_csum,nyar5_csum])
        return odatas
    rdfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        afs = idf.ny.apply(lambda x:1 if x<=score else 0).values
        afr3 = idf.afr3.values
        afr4 = idf.afr4.values
        afr5 = idf.afr5.values
        afr  =  idf.afr.values
        nyar = afs*afr
        nyar3 = afs*afr3
        nyar4 = afs*afr4
        nyar5 = afs*afr5
        try:
            odatas = _getIdx(afs,idf.ny.values,afr,afr3,afr4,afr5,nyar,nyar3,nyar4,nyar5)
            odatas = np.asarray(odatas)
            idf['a_scores ']=np.concatenate(odatas[:,0])
            idf['a_cnts']   =np.concatenate(odatas[:,1])
            idf['stepts']   =np.concatenate(odatas[:,2])
            idf['afr_csum'] =np.concatenate(odatas[:,3])
            idf['afr3_csum']=np.concatenate(odatas[:,4])
            idf['afr4_csum']=np.concatenate(odatas[:,5])
            idf['afr5_csum']=np.concatenate(odatas[:,6])
            idf['yar_csum']  = np.concatenate(odatas[:, 8])
            idf['yar3_csum'] = np.concatenate(odatas[:, 9])
            idf['yar4_csum'] = np.concatenate(odatas[:, 10])
            idf['yar5_csum'] = np.concatenate(odatas[:, 11])
            idf['nyar_csum'] =  np.concatenate(odatas[:, 12])
            idf['nyar3_csum'] = np.concatenate(odatas[:, 13])
            idf['nyar4_csum'] = np.concatenate(odatas[:, 14])
            idf['nyar5_csum'] = np.concatenate(odatas[:, 15])
            idf['ny_csum']  =np.concatenate(odatas[:,7])
        except:
            idf['a_scores '] =[0] * len(idf)
            idf['a_cnts'] =[0] * len(idf)
            idf['stepts'] =[0] * len(idf)
            idf['afr_csum']  =[0] * len(idf)
            idf['afr3_csum'] =[0] * len(idf)
            idf['afr4_csum'] =[0] * len(idf)
            idf['afr5_csum'] =[0] * len(idf)
            idf['ny_csum'] =[0] * len(idf)
            idf['yar_csum'] = [0] * len(idf)
            idf['yar3_csum'] =[0] * len(idf)
            idf['yar4_csum'] =[0] * len(idf)
            idf['yar5_csum'] =[0] * len(idf)
            idf['nyar_csum'] = [0] * len(idf)
            idf['nyar3_csum'] =[0] * len(idf)
            idf['nyar4_csum'] =[0] * len(idf)
            idf['nyar5_csum'] =[0] * len(idf)
        rdfs.append(idf)
        print("%s %s" %(code,len(rdfs)))
    rdf = pd.concat(rdfs)
    insert(rdf,daily_conn,'ClsChange_ana_ab_overs_kpi_chart_%s_%s' %(type,score))
def anaKpiChart():
    _anaKpiChart(1,daily_conn,train_conn,'Close')
    _anaKpiChart(1,daily_conn,train_conn,'Degress')
    _anaKpiChart(3,daily_conn,train_conn,'Close')
    _anaKpiChart(3,daily_conn,train_conn,'Degress')
    _anaKpiChart(5,daily_conn,train_conn,'Close')
    _anaKpiChart(5,daily_conn,train_conn,'Degress')

def runPointDailyData():
    getImagePointsDataDaily()
    getImagePointV2HData()
    getDataReverse()
    getNysFinal()
    getRateClsChangePNClose()
    getRateClsChangePNDegress()
    anaKpiChart()
if __name__ == '__main__':
    getImagePointsDataDaily()
    getImagePointV2HData()
    getDataReverse()
    getNysFinal()
    getRateClsChangePNClose()
    getRateClsChangePNDegress()
    anaKpiChart()