import numpy as np
from sklearn import preprocessing
import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path

degress_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_Degress'))
close_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY_CLOSE'))
daily_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_DAILY'))
train_conn = getConn(dest_summary_path + "/%s" % ('RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN'))

def getDailyTestData(column='work_date',normalise=True):
    columns_a = [
        "afr3",
        "afr4",
        "afr5",
        "pny",
        "stepts",
        "afr_csum",
        "afr3_csum",
        "afr4_csum",
        "afr5_csum",
        "ny_csum",
        "yar_csum",
        "yar3_csum",
        "yar4_csum",
        "yar5_csum",
        "ny"
    ]
    columns_b = [
        "afr3",
        "afr4",
        "afr5",
        "afr",
        "stepts",
        "afr_csum",
        "afr3_csum",
        "afr4_csum",
        "afr5_csum",
        "ny_csum",
        "yar_csum",
        "yar3_csum",
        "yar4_csum",
        "yar5_csum",
        "ny"
    ]
    columns_c = [
        "afr3",
        "afr4",
        "afr5",
        "pny",
        "stepts",
        "afr_csum",
        "afr3_csum",
        "afr4_csum",
        "afr5_csum",
        "ny_csum",
        "nyar_csum",
        "nyar3_csum",
        "nyar4_csum",
        "nyar5_csum",
        "ny"
    ]
    columns_d = [
        "afr3",
        "afr4",
        "afr5",
        "afr",
        "stepts",
        "afr_csum",
        "afr3_csum",
        "afr4_csum",
        "afr5_csum",
        "ny_csum",
        "nyar_csum",
        "nyar3_csum",
        "nyar4_csum",
        "nyar5_csum",
        "ny"
    ]
    tables = ['ClsChange_ana_ab_overs_kpi_chart_Close_1'
            , 'ClsChange_ana_ab_overs_kpi_chart_Close_3'
            , 'ClsChange_ana_ab_overs_kpi_chart_Close_5'
            , 'ClsChange_ana_ab_overs_kpi_chart_Degress_1'
            , 'ClsChange_ana_ab_overs_kpi_chart_Degress_3'
            , 'ClsChange_ana_ab_overs_kpi_chart_Degress_5']
    for table in tables:
        print("%s Done" %(table))
        sql = '''
            select distinct a.code, a.work_date,ts,cls_a,cls_b, ny, afr, afr3, afr4, afr5, stepts, afr_csum,ny as pny,
                   afr3_csum, afr4_csum, afr5_csum, yar_csum, yar3_csum, yar4_csum, yar5_csum, nyar_csum, nyar3_csum, nyar4_csum, nyar5_csum, ny_csum
                      from  {table} a,(select code,work_date,ts from raw_data_ana_cnts_ny_H2V_nys_final) b
        where a.code = b.code and a.work_date = b.work_date
            '''.format(table=table)
        df = query(sql,daily_conn)
        dfs = df.groupby('code')

        num = 0

        out_data = {
          'pny': []
        , 'afr':[  ]
        , 'yar_pny':[  ]
        , 'yar_afr':[  ]
        }

        for code, idf in dfs:
            num = num + 1
            if num > 10:
                continue
            try:

                idf = idf.sort_values(by=[column])
                data_train = idf.copy()
                data_train_a = data_train[columns_a].values
                data_train_b = data_train[columns_b].values
                data_train_c = data_train[columns_c].values
                data_train_d = data_train[columns_d].values
                datas = {
                      'pny'    : data_train_a
                    , 'afr'    : data_train_b
                    , 'yar_pny': data_train_c
                    , 'yar_afr': data_train_d

                }
                len_train = len(data_train)
                seq_len = 14
                data_heads = idf[['code','work_date','ny','pny','ts','cls_a','cls_b']].values
                for key, val in datas.items():
                    lines = out_data[key]
                    for i in range(len_train-14, len_train+1):
                    #window = data_train[i - seq_len:i]
                        window = val[i - seq_len:i]
                        head = data_heads[i-1]
                        x = window
                        try:
                            x = normalise_windows(window, single_window=True)[0] if normalise else x
                            x = x[:, :-1]
                            y = x[-1, [-1]]
                            # data_x.append(x)
                            # data_y.append(y)
                            # data_h.append(head)
                            lines.append([x,y,head])
                        except:
                            pass
                    out_data[key] = lines
            except:
                pass
            print("%s %s %s %s" %(table,code,num,len(out_data['pny'])))

        np.savez(r"D:\codes\data\test_daily_data\%s.npz" % (table), pny=np.asarray(out_data['pny']), afr=np.asarray(out_data['afr'])
                     , yar_pny=np.asarray(out_data['yar_pny']), yar_afr=np.asarray(out_data['yar_afr']))
def normalise_windows(window_data, single_window=False):
    '''Normalise window with a base value of zero'''
    normalised_data = []
    window_data = [window_data] if single_window else window_data
    for window in window_data:
        normalised_window = []
        for col_i in range(window.shape[1]):
            arrs = window[:, col_i]
            arrs = arrs[:, np.newaxis]

            scaler = preprocessing.StandardScaler().fit(arrs)
            normalised_col = scaler.transform(arrs)
            normalised_col = normalised_col.reshape((normalised_col.shape[0]))
            # normalised_col = [((float(p) / float(window[0, col_i])) - 1) for p in window[:, col_i]]
            normalised_window.append(normalised_col)
        normalised_window = np.array(
            normalised_window).T  # reshape and transpose array back into original multidimensional format
        normalised_data.append(normalised_window)
    return np.array(normalised_data)
def runLoader2NPZ():
    getDailyTestData()
if __name__ == '__main__':
    getDailyTestData()