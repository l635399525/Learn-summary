import glob
import os.path

import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
import math,cmath,shutil
def getImageByCondition(cls_a='4321',cls_b='45312'):
    sql = '''
select a.code,a.work_date,cls_a,cls_b,case when b.a_score >=5 then 1 else 0 end as af from raw_data_ana_cnts_rate a,raw_data_ana_cnts_ny3 b
where a.code = b.code and a.work_date = b.date and a.cls_a ='{a}' and a.cls_b = '{b}' and ts = 1
    '''.format(a=cls_a,b=cls_b)
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql,an_conn)
    dfs = df.groupby('code')
    for code,idf in dfs:
        images = glob.glob(r'D:\data\images\final\%s\*' %(code))
        images = np.asarray(images)
        a1 = list(map(lambda x: str(x).split("\\")[-1].split("#")[-1].split(".")[0], images))
        a1 = np.asarray(a1)
        df_a = idf[idf['af'] == 1]
        df_b = idf[idf['af'] == 0]
        if len(df_a) > 0:
            a2= df_a['work_date'].values
            inter = np.in1d(a1,a2)
            out_image = images[inter]
            out = r'D:\data\images\final_ana\%s_%s_%s' %(cls_a,cls_b,1)
            if not os.path.exists(out):
                os.makedirs(out)
            for img in out_image:
                fn = str(img).split("\\")[-1]
                shutil.copy(img,r'%s\%s' %(out,fn))
        if len(df_b) > 0:
            a2 = df_b['work_date'].values
            inter = np.in1d(a1, a2)
            out_image = images[inter]
            out = r'D:\data\images\final_ana\%s_%s_%s' % (cls_a, cls_b, 0)
            if not os.path.exists(out):
                os.makedirs(out)
            for img in out_image:
                fn = str(img).split("\\")[-1]
                shutil.copy(img,r'%s\%s' %(out,fn))
        print(code)
if __name__ == '__main__':
    getImageByCondition()