SQL = '''
select a.code,a.work_date,a.cls_a,a.cls_b,b.ts,cls_b_d,cls_b_d_deg,cls_a_d,cls_a_d_deg
,d.ny,d.t
from raw_data_ana_cnts_rate a,raw_data_ana_cnts b
,raw_data_ana_cnts_degress_arate c,raw_data_ana_cnts_ny_H2V_nys d
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.work_date
'''
import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getRateClsChange():
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(SQL,an_conn)
    df.to_csv(r'D:\codes\data\2022\work_from_homes\ClsChange.csv')
def getRateClsChangePN():
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(SQL, an_conn)
    dfs = df.groupby('code')
    rdfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        rdf = idf[['code','work_date','ts','t','ny','cls_a','cls_b']]
        for i in range(1,10):
            rdf['cls_a_%s' %(i)]  = idf['cls_a'].shift(i).values
            rdf['cls_b_%s' %(i)] = idf['cls_b'].shift(i).values
        rdfs.append(rdf)
        print("%s %s" %(code,len(rdfs)))
    rdf = pd.concat(rdfs)
    insert(rdf,an_conn,'ClsChange')
def get5Change():
    sql = '''
    select a.code, a.work_date, cls_a, cls_b, ts, av5, ny,t,
       av5_d_deg, av5_d, sp5_d, sp5_d_deg, av5_d_dir, av5_d_zr,
       av4_d_deg, av4_d, sp4_d, av3_d_deg, av3_d, sp3_d, av2_d_deg, av2_d, sp2_d, av1_d_deg, av1_d, sp1_d from
(select code,work_date
,av5_d_deg,av5_d,sp5_d,sp5_d_deg,av5_d_dir,av5_d_zr
,av4_d_deg,av4_d,sp4_d
,av3_d_deg,av3_d,sp3_d
,av2_d_deg,av2_d,sp2_d
,av1_d_deg,av1_d,sp1_d
from raw_data_ana_cnts_degress_normal) a,
(select a.code,a.work_date,a.cls_a,a.cls_b,b.ts,b.av5,c.ny,c.t from raw_data_ana_cnts_rate a,
raw_data_ana_cnts_a b,raw_data_ana_cnts_ny_H2V_nys c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date) b
where a.code = b.code and a.work_date = b.work_date
    '''
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql, an_conn)
    df.to_csv(r'D:\codes\data\2022\work_from_homes\Image5Chart.csv')
def get4Change():
    sql = '''
    select a.code, a.work_date, cls_a, cls_b, ts, av5, ny,t,
       av4_d_deg, av4_d, sp4_d,sp4_d_deg,av4_d_dir,av4_d_zr, av3_d_deg, av3_d, sp3_d, av2_d_deg, av2_d, sp2_d, av1_d_deg, av1_d, sp1_d from
(select code,work_date
,av4_d_deg,av4_d,sp4_d,sp4_d_deg,av4_d_dir,av4_d_zr
,av3_d_deg,av3_d,sp3_d
,av2_d_deg,av2_d,sp2_d
,av1_d_deg,av1_d,sp1_d
from raw_data_ana_cnts_degress_conv) a,
(select a.code,a.work_date,a.cls_a,a.cls_b,b.ts,b.av5,c.ny,c.t from raw_data_ana_cnts_rate a,
raw_data_ana_cnts_a b,raw_data_ana_cnts_ny_H2V_nys c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date) b
where a.code = b.code and a.work_date = b.work_date
    '''
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql, an_conn)
    df.to_csv(r'D:\codes\data\2022\work_from_homes\Image4Chart.csv')
def get45DataChange():
    sql = '''
    select a.code, a.work_date, cls_a, cls_b, ts, av5, ny,t
,av5_d_deg5,av5_d5
,av4_d_deg5,av4_d5
,av3_d_deg5,av3_d5
,av2_d_deg5,av2_d5
,av1_d_deg5,av1_d5
,av1_d4,av1_av1_d_deg4
,av2_d4,av2_av2_d_deg4
,av3_d4,av3_av3_d_deg4
,av4_d4,av4_av4_d_deg4 from
(select a.code,a.work_date
,a.av5_d_deg as av5_d_deg5,a.av5_d as av5_d5
,a.av4_d_deg as av4_d_deg5,a.av4_d as av4_d5
,a.av3_d_deg as av3_d_deg5,a.av3_d as av3_d5
,a.av2_d_deg as av2_d_deg5,a.av2_d as av2_d5
,a.av1_d_deg as av1_d_deg5,a.av1_d as av1_d5
,b.av1_d  as av1_d4,b.av1_d_deg  as av1_av1_d_deg4
,b.av2_d  as av2_d4,b.av2_d_deg  as av2_av2_d_deg4
,b.av3_d  as av3_d4,b.av3_d_deg  as av3_av3_d_deg4
,b.av4_d  as av4_d4,b.av4_d_deg  as av4_av4_d_deg4
from raw_data_ana_cnts_degress_normal a,raw_data_ana_cnts_degress_conv b
where a.code = b.code and a.work_date = b.work_date
    ) a,
(select a.code,a.work_date,a.cls_a,a.cls_b,b.ts,b.av5,c.ny,c.t from raw_data_ana_cnts_rate a,
raw_data_ana_cnts_a b,raw_data_ana_cnts_ny_H2V_nys c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date) b
where a.code = b.code and a.work_date = b.work_date
    '''
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql,an_conn)
    df.to_csv(r'D:\codes\data\2022\work_from_homes\Image45Chart.csv')
def getRateChange():
    sql = '''
    select a.code, a.work_date, cls_a, cls_b, ts, av5, ny,t
,av5_r5
,av4_r5
,av3_r5
,av2_r5
,av1_r5
,av4_r4
,av3_r4
,av2_r4
,av1_r4
,av5_r5_d_deg,av5_r5_d
,av4_r5_d_deg,av4_r5_d
,av3_r5_d_deg,av3_r5_d
,av2_r5_d_deg,av2_r5_d
,av1_r5_d_deg,av1_r5_d
,av4_r4_d_deg,av4_r4_d
,av3_r4_d_deg,av3_r4_d
,av2_r4_d_deg,av2_r4_d
,av1_r4_d_deg,av1_r4_d
from
(select code,work_date
,av5_r5_d_deg,av5_r5_d
,av4_r5_d_deg,av4_r5_d
,av3_r5_d_deg,av3_r5_d
,av2_r5_d_deg,av2_r5_d
,av1_r5_d_deg,av1_r5_d
,av4_r4_d_deg,av4_r4_d
,av3_r4_d_deg,av3_r4_d
,av2_r4_d_deg,av2_r4_d
,av1_r4_d_deg,av1_r4_d

from raw_data_ana_cnts_degress_arate) a,
(select a.code,a.work_date,a.cls_a,a.cls_b,b.ts,b.av5,c.ny,c.t
,av5_r5
,av4_r5
,av3_r5
,av2_r5
,av1_r5
,av4_r4
,av3_r4
,av2_r4
,av1_r4
from raw_data_ana_cnts_rate a,
raw_data_ana_cnts_a b,raw_data_ana_cnts_ny_H2V_nys c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date) b
where a.code = b.code and a.work_date = b.work_date
    '''
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql, an_conn)
    df.to_csv(r'D:\codes\data\2022\work_from_homes\ImageRateChart.csv')
def analysis_b():
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    scores = {
         '12534': 102
        ,'35412': 102
        ,'31425': 115
        ,'51234': 115
        ,'35214': 118
        ,'45123': 120
        ,'24315': 122
        ,'52314': 126
        ,'52134': 137
        ,'41325': 148
        ,'23415': 153
        ,'42315': 160
        ,'21435': 164
        ,'13425': 175
        ,'14325': 185
        ,'45213': 204
        ,'45312': 212
        ,'34125': 221
        ,'54123': 228
        ,'14235': 243
        ,'34215': 246
        ,'23145': 251
        ,'32145': 258
        ,'42135': 273
        ,'12354': 277
        ,'53124': 287
        ,'43215': 320
        ,'53214': 334
        ,'54312': 334
        ,'41235': 350
        ,'43125': 382
        ,'21345': 411
        ,'13245': 436
        ,'54213': 460
        ,'31245': 476
        ,'12435': 524
        ,'12345': 3482
    }

    cols = [ '12534'
,'35412'
,'31425'
,'51234'
,'35214'
,'45123'
,'24315'
,'52314'
,'52134'
,'41325'
,'23415'
,'42315'
,'21435'
,'13425'
,'14325'
,'45213'
,'45312'
,'34125'
,'54123'
,'14235'
,'34215'
,'23145'
,'32145'
,'42135'
,'12354'
,'53124'
,'43215'
,'53214'
,'54312'
,'41235'
,'43125'
,'21345'
,'13245'
,'54213'
,'31245'
,'12435'
,'12345']
    rlines = []
    for col_a in cols:
        score = scores[col_a]
        for col_b in cols:
            sql = '''
            select cls_a,sum(af1+af2+af3+af4+af5) as afs from
(select cls_a,
       case when cls_b_1 == '{c_b}' then 1 else 0 end as af1,
       case when cls_b_2 == '{c_b}' then 1 else 0 end as af2,
       case when cls_b_3 == '{c_b}' then 1 else 0 end as af3,
       case when cls_b_4 == '{c_b}' then 1 else 0 end as af4,
       case when cls_b_5 == '{c_b}' then 1 else 0 end as af5 from ClsChange where cls_b = '{c_a}'  and ny > 5
group by cls_b,cls_b_1, cls_b_2,cls_b_3, cls_b_4,cls_b_5)
            '''.format(c_a = col_a,c_b = col_b)
            df = query(sql,an_conn)
            afs = df['afs'].values[0]
            rline = {'c_a':col_a,'a_score':score,'c_b':col_b,'afs':afs}
            rlines.append(rline)
    df = pd.DataFrame(rlines)
    insert(df,an_conn,'ClsChange_ana_b')
def analysis_a():
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")

    scores = {'1234': 5179
        , '3214': 1377
        , '4312': 1083
        , '3124': 1070
        , '4213': 1060
        , '4321': 913}

    cols = ['1234'
        , '3214'
        , '4312'
        , '3124'
        , '4213'
        , '4321']
    rlines = []
    for col_a in cols:
        score = scores[col_a]
        for col_b in cols:
            sql = '''
                select cls_a,sum(af1+af2+af3+af4+af5) as afs from
    (select cls_a,
           case when cls_a_1 == '{c_b}' then 1 else 0 end as af1,
           case when cls_a_2 == '{c_b}' then 1 else 0 end as af2,
           case when cls_a_3 == '{c_b}' then 1 else 0 end as af3,
           case when cls_a_4 == '{c_b}' then 1 else 0 end as af4,
           case when cls_a_5 == '{c_b}' then 1 else 0 end as af5 from ClsChange where cls_a = '{c_a}'  and ny > 5
    group by cls_a,cls_a_1, cls_a_2,cls_a_3, cls_a_4,cls_a_5)
                '''.format(c_a=col_a, c_b=col_b)
            df = query(sql, an_conn)
            afs = df['afs'].values[0]
            rline = {'c_a':col_a,'a_score':score,'c_b':col_b,'afs':afs}
            rlines.append(rline)
    df = pd.DataFrame(rlines)
    insert(df, an_conn, 'ClsChange_ana_a')
def analysisOver4():
    sql = '''
    select 'A' as t,cls_a as cls,count(*) as acnt from ClsChange where  ny > 4 group by cls_a
union
select 'B' as t,cls_b as cls,count(*) as acnt from ClsChange where  ny > 4 group by cls_b
    '''
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql,an_conn)
    dfs = df.groupby('t')
    rdfs = []
    for t,idf in dfs:
        for i in range(len(idf)):
            line = dict(idf.iloc[i])
            tt = line['t']
            if tt == 'A':
                sql = '''
                 select cls_a as n_cls,sum(af1+af2+af3+af4+af5) as afs from
                (select cls_a,
                       case when cls_a_1 == '{c}' then 1 else 0 end as af1,
                       case when cls_a_2 == '{c}' then 1 else 0 end as af2,
                       case when cls_a_3 == '{c}' then 1 else 0 end as af3,
                       case when cls_a_4 == '{c}' then 1 else 0 end as af4,
                       case when cls_a_5 == '{c}' then 1 else 0 end as af5 from ClsChange where  ny > 4)
                group by cls_a
                '''.format(c = line['cls'])
            elif tt == 'B' :
                sql = '''
                                 select cls_b as n_cls,sum(af1+af2+af3+af4+af5) as afs from
                                (select cls_b,
                                       case when cls_b_1 == '{c}' then 1 else 0 end as af1,
                                       case when cls_b_2 == '{c}' then 1 else 0 end as af2,
                                       case when cls_b_3 == '{c}' then 1 else 0 end as af3,
                                       case when cls_b_4 == '{c}' then 1 else 0 end as af4,
                                       case when cls_b_5 == '{c}' then 1 else 0 end as af5 from ClsChange where  ny > 4)
                             group by cls_b
                                '''.format(c=line['cls'])
            rdf = query(sql,an_conn)
            rdf['acnt'] = line['acnt']
            rdf['p_cls']  = line['cls']
            rdfs.append(rdf)
    df = pd.concat(rdfs)
    insert(df, an_conn, 'ClsChange_ana_ab_over4')
    sql = '''
    select p_cls, afs,acnt, cnt,round(afs*1.0/cnt,3) as ar
from
(select p_cls,sum(afs) as afs,acnt from ClsChange_ana_ab_over4 group by p_cls) a,

(select cls_a as cls,count(*) as cnt from ClsChange group by cls_a
union
select cls_b as cls,count(*) as cnt from ClsChange group by cls_b) b
where a.p_cls = b.cls
    '''
    df = query(sql,an_conn)
    insert(df, an_conn, 'ClsChange_ana_ab_over4')



if __name__ == '__main__':
    #getRateClsChange()
    #get5Change()
    #get4Change()
    #get45DataChange()
    #getRateChange()
    getRateClsChangePN()
    #analysisOver4()
    #analysis_b()