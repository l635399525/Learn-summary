import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
import math,cmath
def getDegress(table='raw_data_ana_cnts_b',cols =['av1_d','av2_d','av3_d','av4_d','av5_d', 'sp5_d'],end = 'normal'):
    if end =='conv':
        sql = '''
            select code,work_date,av1_d, sp1_d, av2_d, sp2_d, av3_d, sp3_d, av4_d, sp4_d from {table}

        '''.format(table=table)
    elif end == 'normal' :
        sql = '''
        select code,work_date,av1_d, sp1_d, av2_d, sp2_d, av3_d, sp3_d, av4_d, sp4_d, av5_d, sp5_d from {table}
        '''.format(table=table)
    elif end == 'arate':
        sql = '''
                select code,work_date,av1_r4_d, av2_r4_d, av3_r4_d, av4_r4_d, av1_r5_d, av2_r5_d, av3_r5_d, av4_r5_d, av5_r5_d, cls_a_s_d as cls_a_d,cls_b_s_d as  cls_b_d from {table}
                '''.format(table=table)
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
    df = query(sql,an_conn)
    dfs = df.groupby('code')
    rdfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        rdf = idf.copy()

        aeses = []
        beses = []
        ceses = []
        for i in range(len(idf)):
            s_idx = 0 if i < 5 else i - 4
            e_idx = i + 1
            tdf = idf.iloc[s_idx:e_idx]
            aes = []
            bes = []
            ces = []
            for col in cols:
                dvals = tdf[col].values
                z_cnt = np.count_nonzero(dvals == 0)
                cnt = len(dvals)
                try:
                    last_val = dvals[max(np.argwhere(dvals != 0)[:,0])]
                except:
                    last_val = 0
                degress = round(math.degrees(cmath.polar(complex(len(tdf)*4, sum(dvals)))[1]), 1)
                if last_val > 0:
                    acnt = np.count_nonzero(dvals > 0)
                    a = 1
                elif last_val <0:
                    acnt = np.count_nonzero(dvals < 0)
                    a= -1
                if cnt == z_cnt:
                    zr = 1
                    ar = 0
                else:
                    ar = a*round(acnt/(cnt-z_cnt),3)
                    zr = round(z_cnt/(cnt),3)
                aes.append(degress)
                bes.append(ar)
                ces.append(zr)
            aeses.append(aes)
            beses.append(bes)
            ceses.append(ces)
        aeses = np.asarray(aeses)
        beses = np.asarray(beses)
        ceses = np.asarray(ceses)
        for i in range(len(cols)):
            col = cols[i]
            degress = aeses[:,i]
            dir = beses[:, i]
            zr = ceses[:, i]
            rdf['%s_deg' % (col) ] = degress
            rdf['%s_dir' % (col)] = dir
            rdf['%s_zr'  % (col)] = zr
        print("%s %s Done" %(code,len(rdfs)))
        rdfs.append(rdf)
    df = pd.concat(rdfs)
    insert(df, an_conn, 'raw_data_ana_cnts_degress_%s' %(end))
if __name__ == '__main__':
    #getDegress()
    #getDegress('raw_data_ana_cnts_conv4_b',['av1_d','av2_d','av3_d','av4_d','sp4_d'],'conv')
    getDegress('raw_data_ana_cnts_rate_b',['av1_r4_d', 'av2_r4_d', 'av3_r4_d', 'av4_r4_d', 'av1_r5_d', 'av2_r5_d', 'av3_r5_d', 'av4_r5_d', 'av5_r5_d'
        , 'cls_a_d', 'cls_b_d'],'arate')