ARATE_SQL = '''
select a.code, a.work_date ,e.ts,e.av5,
       av1_r4, av2_r4, av3_r4, av4_r4,
       av1_r5, av2_r5, av3_r5, av4_r5, av5_r5,
       cls_a, cls_b,
       b.av1_r4_d,b.av2_r4_d, b.av3_r4_d, b.av4_r4_d,
       b.av1_r5_d,b.av2_r5_d, b.av3_r5_d, b.av4_r5_d, b.av5_r5_d,
       b.cls_a_d, b.cls_b_d,
       av1_r4_d_deg,av2_r4_d_deg,av3_r4_d_deg,av4_r4_d_deg,
       av1_r5_d_deg,av2_r5_d_deg,av3_r5_d_deg,av4_r5_d_deg
       ,av5_r5_d_deg, av5_r5_d_dir, av5_r5_d_zr,  av4_r5_d_dir, av4_r5_d_zr,
    a_score,b_score from
  raw_data_ana_cnts_rate a
,raw_data_ana_cnts_rate_b b
,raw_data_ana_cnts_degress_arate c
,raw_data_ana_cnts_ny3 d
,raw_data_ana_cnts_a e
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.date
and a.code = e.code and a.work_date = e.work_date
'''
NORMAL_SQL = '''
select a.code, a.work_date, a.ts, av5, sp5,
       b.av1_d, b.av2_d,b.av3_d,b.av4_d,b.av5_d,
       b.sp5_d, b.sp1_d,b.sp2_d,b.sp3_d,b.sp4_d,
        av1_d_deg,av2_d_deg,  av3_d_deg,  av4_d_deg, av5_d_deg, av5_d_dir, av5_d_zr, sp5_d_deg, sp5_d_dir, sp5_d_zr,a_score,b_score from
raw_data_ana_cnts_a a,
raw_data_ana_cnts_b b,
raw_data_ana_cnts_degress_normal c,
raw_data_ana_cnts_ny3 d
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.date
'''
sql_conv = '''
    select a.code, a.work_date,d.ts, av4, sp4,
       b.av1_d, b.av2_d,b.av3_d,b.av4_d,
       b.sp1_d,b.sp2_d,b.sp3_d,b.sp4_d,
       av1_d_deg,av2_d_deg,  av3_d_deg,  av4_d_deg, av4_d_dir, av4_d_zr, sp4_d_deg, sp4_d_dir, sp4_d_zr,a_score,b_score from
raw_data_ana_cnts_conv4_a a,
raw_data_ana_cnts_conv4_b b,
raw_data_ana_cnts_degress_conv c,
raw_data_ana_cnts_ny3 d
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.work_date
and a.code = d.code and a.work_date = d.date
    '''
import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getConvData():
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(ARATE_SQL,an_conn)
    print(ARATE_SQL)
    insert(df,an_conn,'arate_data')
    df = query(sql_conv,an_conn)
    print(sql_conv)

    insert(df,an_conn,'conv_data')
    print(NORMAL_SQL)

    df = query(NORMAL_SQL,an_conn)
    insert(df,an_conn,'normal_data')
if __name__ == '__main__':
    getConvData()
