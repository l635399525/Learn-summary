import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getImage25BlockData():
    files = ['RAW_HLWAVES_DATA_HISTORYSES','RAW_HLWAVES_DATA_HISTORYSES_SH','RAW_HLWAVES_DATA_HISTORYSES_SZ','RAW_HLWAVES_DATA_HISTORYSES_SZ1']
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
    lines = []
    for file in files:
        print(file)
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        codes = list(query('select distinct code from raw_merger_degress_data_pn_SH',sh_conn)['code'].values)
        for idx,code in enumerate(codes):
            sql = '''
                    select * from raw_merger_degress_data_pn_SH where code = '{code}'
            '''.format(code=code)
            df = query(sql,sh_conn)
            dfs = df.groupby(['code','work_date'])
            for line,idf in dfs:
                idf = idf.sort_values(by=['date'])
                #ts = idf['ts'].values[-1]
                code,work_date = line
                idfs = idf.groupby(['w_ct','h_ct'])
                rline = {
                         'code':code,'work_date':work_date,
                         'c1#1':0,'c1#2':0,'c1#3':0,'c1#4':0,'c1#5':0,
                         'c2#1':0,'c2#2':0,'c2#3':0,'c2#4':0,'c2#5':0,
                         'c3#1':0,'c3#2':0,'c3#3':0,'c3#4':0,'c3#5':0,
                         'c4#1':0,'c4#2':0,'c4#3':0,'c4#4':0,'c4#5':0,
                         'c5#1':0,'c5#2':0,'c5#3':0,'c5#4':0,'c5#5':0
                         }
                for iline,iidf in idfs:
                    w_ct,h_ct = iline
                    rline['c%s#%s'%(w_ct,h_ct)] = len(iidf)
                lines.append(rline)
                print("%s %s %s %s" %(idx,code,work_date,len(lines)))
    df = pd.DataFrame(lines)
    insert(df,an_conn,'raw_data_ana_cnts')
def getImage25BlockDataSum():
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_PN")
    sql = '''
    select code, work_date,  v1, v2, v3, v4, v5, c1, c2, c3, c4, c5, hl1, hl2, hl3, hl4, hl5
,case when round(v1*1.0/c1,3) is null then 0 else round(v1*1.0/c1,3) end as av1, case when round((v1*1.0/c1)/c1,3) is null then 0 else round((v1*1.0/c1)/c1,3) end as sp1
,case when round(v2*1.0/c2,3) is null then 0 else round(v2*1.0/c2,3) end as av2, case when round((v2*1.0/c2)/c2,3) is null then 0 else round((v2*1.0/c2)/c2,3) end as sp2
,case when round(v3*1.0/c3,3) is null then 0 else round(v3*1.0/c3,3) end as av3, case when round((v3*1.0/c3)/c3,3) is null then 0 else round((v3*1.0/c3)/c3,3) end as sp3
,case when round(v4*1.0/c4,3) is null then 0 else round(v4*1.0/c4,3) end as av4, case when round((v4*1.0/c4)/c4,3) is null then 0 else round((v4*1.0/c4)/c4,3) end as sp4
,case when round(v5*1.0/c5,3) is null then 0 else round(v5*1.0/c5,3) end as av5, case when round((v5*1.0/c5)/c5,3) is null then 0 else round((v5*1.0/c5)/c5,3) end as sp5
from
(select code, work_date,
       "c1#1"*1 + "c1#2"*2 + "c1#3"*3 + "c1#4" *4 + "c1#5" *5 as v1,
       "c2#1"*1 + "c2#2"*2 + "c2#3"*3 + "c2#4" *4 + "c2#5" *5 as v2,
       "c3#1"*1 + "c3#2"*2 + "c3#3"*3 + "c3#4" *4 + "c3#5" *5 as v3,
       "c4#1"*1 + "c4#2"*2 + "c4#3"*3 + "c4#4" *4 + "c4#5" *5 as v4,
       "c5#1"*1 + "c5#2"*2 + "c5#3"*3 + "c5#4" *4 + "c5#5" *5 as v5
, "c1#1" + "c1#2" + "c1#3" + "c1#4" + "c1#5" as c1
, "c2#1" + "c2#2" + "c2#3" + "c2#4" + "c2#5" as c2
, "c3#1" + "c3#2" + "c3#3" + "c3#4" + "c3#5" as c3
, "c4#1" + "c4#2" + "c4#3" + "c4#4" + "c4#5" as c4
, "c5#1" + "c5#2" + "c5#3" + "c5#4" + "c5#5" as c5
,max("c1#1","c1#2","c1#3","c1#4","c1#5") - min("c1#1","c1#2","c1#3","c1#4","c1#5") as hl1
,max("c2#1","c2#2","c2#3","c2#4","c2#5") - min("c2#1","c2#2","c2#3","c2#4","c2#5") as hl2
,max("c3#1","c3#2","c3#3","c3#4","c3#5") - min("c3#1","c3#2","c3#3","c3#4","c3#5") as hl3
,max("c4#1","c4#2","c4#3","c4#4","c4#5") - min("c4#1","c4#2","c4#3","c4#4","c4#5") as hl4
,max("c5#1","c5#2","c5#3","c5#4","c5#5") - min("c5#1","c5#2","c5#3","c5#4","c5#5") as hl5
from raw_data_ana_cnts)
    '''
    df = query(sql,an_conn)
    dfs = df.groupby('code')
    rdfs = []
    rdf_diffs = []
    for code,idf in dfs:
        if len(idf) <= 1:
            continue
        idf = idf.sort_values(by=['work_date'])
        rdfs.append(idf)
        cols   = list(idf.columns)[3:]
        heads  = list(idf.columns)[:3]
        f_data = idf[cols].copy().values
        rlines = []
        for i in range(1,len(f_data)):
            cline = f_data[i,:]
            pline = f_data[i-1,:]
            dif_line = (cline - pline)*100
            dif_val = np.round(dif_line/pline,3)
            z_idx = np.argwhere(pline == 0)[:,0]
            dif_val[z_idx] = 100
            rlines.append(dif_val)
        rlines = np.asarray(rlines)
        cols = list(map(lambda x:'%s_d' %(x),cols))
        dif_df = pd.DataFrame(data=rlines,columns=cols)
        for head in heads:
            dif_df[head] = idf[head].values[1:]
        rdf_diffs.append(dif_df)
        print("%s %s %s" %(code,len(rdfs),len(rdf_diffs)))
    adf = pd.concat(rdfs)
    bdf = pd.concat(rdf_diffs)
    insert(adf, an_conn, 'raw_data_ana_cnts_a')
    insert(bdf, an_conn, 'raw_data_ana_cnts_b')
if __name__ == '__main__':
    #getImage25BlockData()
    getImage25BlockDataSum()
