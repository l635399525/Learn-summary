import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getData():
    files = ['RAW_HLWAVES_DATA_HISTORYSES','RAW_HLWAVES_DATA_HISTORYSES_SH','RAW_HLWAVES_DATA_HISTORYSES_SZ','RAW_HLWAVES_DATA_HISTORYSES_SZ1']
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    sql = '''
select distinct code,date,ts,close from raw_merger_image_data_info_SH  
        '''
    for file in files:
        odfs = []
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        df = query(sql,sh_conn)
        dfs = df.groupby(['code','ts'])
        for line,idf in dfs:
            code,ts = line
            idf = idf.sort_values(by=['date'])
            scores = [5,3,2]
            for i in range(1,4):
                idf['close_%s' %(i)] = idf.close.shift(i*-1).values
                idf['date_%s' %(i)]  = idf.date.shift(i*-1).values


            data = idf[['close','close_1','close_2','close_3','date_1','date_2','date_3']].values
            data = np.diff(data,axis=1)
            data_a = np.zeros(data.shape)
            data_a[data > 0] = 1
            data_b = np.zeros(data.shape)
            data_b[data < 0] = 1
            scores_a = data_a*scores
            scores_b = data_b*scores*-1
            a_scores = np.sum(scores_a,axis=1)
            b_scores = np.sum(scores_b,axis=1)
            idf['a_score'] = a_scores
            idf['a0'] = data_a[:,0]
            idf['a1'] = data_a[:,1]
            idf['a2'] = data_a[:,2]
            idf['b_score'] = b_scores
            idf['b0'] = data_b[:,0]
            idf['b1'] = data_b[:,1]
            idf['b2'] = data_b[:,2]
            odfs.append(idf)
            print("%s %s %s" %(code,ts,len(odfs)))
        fdf = pd.concat(odfs)
        insert(fdf, an_conn, 'raw_data_ana_cnts_ny3', opType='append')
def getDataReverse():
    files = ['RAW_HLWAVES_DATA_HISTORYSES','RAW_HLWAVES_DATA_HISTORYSES_SH','RAW_HLWAVES_DATA_HISTORYSES_SZ','RAW_HLWAVES_DATA_HISTORYSES_SZ1']
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    sql = '''
select distinct code,date,ts,close from raw_merger_image_data_info_SH  
        '''
    for file in files:
        odfs = []
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        df = query(sql,sh_conn)
        dfs = df.groupby(['code','ts'])
        for line,idf in dfs:
            code,ts = line
            idf = idf.sort_values(by=['date'])
            scores = [5,3,2]
            for i in range(1,4):
                idf['close_%s' %(i)] = idf.close.shift(i).values
                idf['date_%s' %(i)]  = idf.date.shift(i).values


            data = idf[['close_3','close_2','close_1','close']].values
            data = np.diff(data,axis=1)
            data_a = np.zeros(data.shape)
            data_a[data > 0] = 1
            data_b = np.zeros(data.shape)
            data_b[data < 0] = 1
            scores_a = data_a*scores
            scores_b = data_b*scores*-1
            a_scores = np.sum(scores_a,axis=1)
            b_scores = np.sum(scores_b,axis=1)
            idf['a_score'] = a_scores
            idf['a0'] = data_a[:,0]
            idf['a1'] = data_a[:,1]
            idf['a2'] = data_a[:,2]
            idf['b_score'] = b_scores
            idf['b0'] = data_b[:,0]
            idf['b1'] = data_b[:,1]
            idf['b2'] = data_b[:,2]
            odfs.append(idf)
            print("%s %s %s" %(code,ts,len(odfs)))
        fdf = pd.concat(odfs)
        insert(fdf, an_conn, 'raw_data_ana_cnts_ny3_reverse', opType='append')

def getNYSummary():
    sql = '''
    select a.code,a.work_date,a.ny as any
     ,case when b.ny is null then a.ny else a.ny + b.ny end as ny
     ,case when b.t  is null then 'C' else b.t end as t
 from
(select code,work_date,(nhc_t - min(hc_t_5,hc_t_4,hc_t_3,hc_t_2)) - 2 as  ny from raw_data_ana_cnts_ny_H2V) a
left outer join
(select a.code,a.date,ny + ny1 as ny,'A' as t from raw_data_ana_cnts_ny3_reverse a,(select a.code, a.work_date,
       nhc_t -  hc_t_5 AS ny,nhc_t - hc_t_4 as ny1 from raw_data_ana_cnts_ny_H2V a where  ny >= 2) b
where a.code = b.code and a.date = b.work_date
union
select code,date,a0 + a1 + a2 as ny,'B' as t from raw_data_ana_cnts_ny3_reverse where a0 + a1 + a2 = 3 and ts = 1
and code || date not in
(select code||date as key from
(select a.code,a.date from raw_data_ana_cnts_ny3_reverse a,(select a.code, a.work_date,
       nhc_t -  hc_t_5 AS ny,nhc_t - hc_t_4 as ny1 from raw_data_ana_cnts_ny_H2V a where  ny >= 2) b
where a.code = b.code and a.date = b.work_date))) b
on a.code = b.code and a.work_date=b.date
    '''
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")

    df = query(sql,an_conn)
    insert(df,an_conn,'raw_data_ana_cnts_ny_H2V_nys')
if __name__ == '__main__':
    getNYSummary()
