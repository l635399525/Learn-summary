import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getImage16ConvData():
    a = [["c1#1", "c1#2", "c2#1", "c2#2"],
         ["c1#2", "c1#3", "c2#2", "c2#3"],
         ["c1#3", "c1#4", "c2#3", "c2#4"],
         ["c1#4", "c1#5", "c2#4", "c2#5"]]
    b = [["c2#1", "c2#2", "c3#1", "c3#2"],
         ["c2#2", "c2#3", "c3#2", "c3#3"],
         ["c2#3", "c2#4", "c3#3", "c3#4"],
         ["c2#4", "c2#5", "c3#4", "c3#5"]]
    c = [["c3#1", "c4#2", "c3#1", "c4#2"],
         ["c3#2", "c4#3", "c3#2", "c4#3"],
         ["c3#3", "c4#4", "c3#3", "c4#4"],
         ["c3#4", "c4#5", "c3#4", "c4#5"]]
    d = [["c4#1", "c5#2", "c4#1", "c5#2"],
         ["c4#2", "c5#3", "c4#2", "c5#3"],
         ["c4#3", "c5#4", "c4#3", "c5#4"],
         ["c4#4", "c5#5", "c4#4", "c5#5"]]
    ws = [a,b,c,d]
    an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    sql = '''
select * from raw_data_ana_cnts 
            '''
    df = query(sql,an_conn)
    olines = []
    for i in range(len(df)):
        line = df.iloc[i]
        max_idxes = []
        rline = {'code':line['code'],'date':line['work_date']}
        for w in range(len(ws)):
            hs = ws[w]
            counts = []
            for h in range(len(hs)):
                hv = hs[h]
                data = line[hv].values
                try:
                    cnts = np.sum(data)
                except:
                    cnts = 0
                counts.append(cnts)
                rline['%s#%s' %(w+1,h+1)] = cnts
            counts = np.asarray(counts)
            max_idx = max(np.argwhere(counts == max(counts))[:, 0])
            max_idxes.append(str(max_idx))
        cls = "#".join(max_idxes)
        rline['cls'] = cls
        olines.append(rline)
        print('%s %s %s %s' %(line['code'],line['work_date'],len(olines),len(df)))
    rdf = pd.DataFrame(olines)
    insert(rdf,an_conn,'raw_data_ana_cnts_conv4')
def getImage16ConvDataSum():
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    sql = '''
    select code, work_date,  v1, v2, v3, v4, c1, c2, c3, c4, hl1, hl2, hl3, hl4
,case when round(v1*1.0/c1,3) is null then 0 else round(v1*1.0/c1,3) end as av1, case when round((v1*1.0/c1)/c1,3) is null then 0 else round((v1*1.0/c1)/c1,3) end as sp1
,case when round(v2*1.0/c2,3) is null then 0 else round(v2*1.0/c2,3) end as av2, case when round((v2*1.0/c2)/c2,3) is null then 0 else round((v2*1.0/c2)/c2,3) end as sp2
,case when round(v3*1.0/c3,3) is null then 0 else round(v3*1.0/c3,3) end as av3, case when round((v3*1.0/c3)/c3,3) is null then 0 else round((v3*1.0/c3)/c3,3) end as sp3
,case when round(v4*1.0/c4,3) is null then 0 else round(v4*1.0/c4,3) end as av4, case when round((v4*1.0/c4)/c4,3) is null then 0 else round((v4*1.0/c4)/c4,3) end as sp4
from
(select code, date as work_date,
       "1#1"*1 + "1#2"*2 + "1#3"*3 + "1#4" *4 as v1,
       "2#1"*1 + "2#2"*2 + "2#3"*3 + "2#4" *4 as v2,
       "3#1"*1 + "3#2"*2 + "3#3"*3 + "3#4" *4 as v3,
       "4#1"*1 + "4#2"*2 + "4#3"*3 + "4#4" *4 as v4,
         "1#1" + "1#2" + "1#3" + "1#4"  as c1
        , "2#1" + "2#2" + "2#3" + "2#4"  as c2
        , "3#1" + "3#2" + "3#3" + "3#4"  as c3
        , "4#1" + "4#2" + "4#3" + "4#4"  as c4
,max("1#1","1#2","1#3","1#4") - min("1#1","1#2","1#3","1#4") as hl1
,max("2#1","2#2","2#3","2#4") - min("2#1","2#2","2#3","2#4") as hl2
,max("3#1","3#2","3#3","3#4") - min("3#1","3#2","3#3","3#4") as hl3
,max("4#1","4#2","4#3","4#4") - min("4#1","4#2","4#3","4#4") as hl4
from raw_data_ana_cnts_conv4)
    '''
    df = query(sql,an_conn)
    dfs = df.groupby('code')
    rdfs = []
    rdf_diffs = []
    for code,idf in dfs:
        if len(idf) <= 1:
            continue
        idf = idf.sort_values(by=['work_date'])
        rdfs.append(idf)
        cols   = list(idf.columns)[3:]
        heads  = list(idf.columns)[:3]
        f_data = idf[cols].copy().values
        rlines = []
        for i in range(1,len(f_data)):
            cline = f_data[i,:]
            pline = f_data[i-1,:]
            dif_line = (cline - pline)*100
            dif_val = np.round(dif_line/pline,3)
            z_idx = np.argwhere(pline == 0)[:,0]
            dif_val[z_idx] = 100
            rlines.append(dif_val)
        rlines = np.asarray(rlines)
        cols = list(map(lambda x:'%s_d' %(x),cols))
        dif_df = pd.DataFrame(data=rlines,columns=cols)
        for head in heads:
            dif_df[head] = idf[head].values[1:]
        rdf_diffs.append(dif_df)
        print("%s %s %s" %(code,len(rdfs),len(rdf_diffs)))
    adf = pd.concat(rdfs)
    bdf = pd.concat(rdf_diffs)
    insert(adf, an_conn, 'raw_data_ana_cnts_conv4_a')
    insert(bdf, an_conn, 'raw_data_ana_cnts_conv4_b')
if __name__ == '__main__':
    getImage16ConvDataSum()
