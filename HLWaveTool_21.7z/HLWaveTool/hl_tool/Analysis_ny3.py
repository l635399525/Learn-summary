import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def getData():
    files = ['RAW_HLWAVES_DATA_HISTORYSES','RAW_HLWAVES_DATA_HISTORYSES_SH','RAW_HLWAVES_DATA_HISTORYSES_SZ','RAW_HLWAVES_DATA_HISTORYSES_SZ1']
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    sql = '''
select distinct code,date,ts,close from raw_merger_image_data_info_SH  
        '''
    for file in files:
        odfs = []
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        df = query(sql,sh_conn)
        dfs = df.groupby(['code','ts'])
        for line,idf in dfs:
            code,ts = line
            idf = idf.sort_values(by=['date'])
            scores = [5,3,2]
            for i in range(1,4):
                idf['close_%s' %(i)] = idf.close.shift(i*-1).values
            data = idf[['close','close_1','close_2','close_3']].values
            data = np.diff(data,axis=1)
            data_a = np.zeros(data.shape)
            data_a[data > 0] = 1
            data_b = np.zeros(data.shape)
            data_b[data < 0] = 1
            scores_a = data_a*scores
            scores_b = data_b*scores*-1
            a_scores = np.sum(scores_a,axis=1)
            b_scores = np.sum(scores_b,axis=1)
            idf['a_score'] = a_scores
            idf['a0'] = data_a[:,0]
            idf['a1'] = data_a[:,1]
            idf['a2'] = data_a[:,2]
            idf['b_score'] = b_scores
            idf['b0'] = data_b[:,0]
            idf['b1'] = data_b[:,1]
            idf['b2'] = data_b[:,2]
            odfs.append(idf)
            print("%s %s %s" %(code,ts,len(odfs)))
        fdf = pd.concat(odfs)
        insert(fdf, an_conn, 'raw_data_ana_cnts_ny3', opType='append')


if __name__ == '__main__':
    getData()
