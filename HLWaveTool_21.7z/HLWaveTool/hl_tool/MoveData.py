import glob

import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD,RAW_HLS_WORK_FILE_HIST,RAW_HLS_WORK_FILE_HISTES
from hl_tool.FuncTool import getImageSplit, getClsV

conn = getConn(RAW_HLS_WORK_FILE_HIST)
h_cls = getImageSplit(440)
w_cls = getImageSplit(1820)
def move1(code):
    sql = '''
    select date, close, ma60, ma10, p_date, c_date, n_date, degress, w_idx, date_type, x, h, ts, w_ct, h_ct, code, work_date 
    from raw_merger_degress_data_cn_SH where code = '{code}'
    '''.format(code=code)
    df = query(sql,conn)
    rdf = df.copy()
    w_v = df.x.apply(lambda x:getClsV(x,w_cls)).values
    h_v = df.h.apply(lambda x:getClsV(440 - x,h_cls)).values
    rdf['w_ct'] = w_v
    rdf['h_ct'] = h_v
    return rdf
    #insert(rdf,dest_conn,'raw_merger_degress_data_cn_SH',opType='append')
def move2(code):
    sql = '''
select  date,  p_date,c_date,n_date, degress,  date_type, x, h,  w_ct, h_ct, code, work_date from 
raw_merger_degress_data_pn_SH   where code = '{code}'
 '''.format(code=code)
    df = query(sql,conn)
    rdf = df.copy()
    w_v = df.x.apply(lambda x:getClsV(x,w_cls)).values
    h_v = df.h.apply(lambda x:getClsV(440 - x,h_cls)).values
    rdf['w_ct'] = w_v
    rdf['h_ct'] = h_v
    return rdf
    #insert(rdf,dest_conn,'raw_merger_degress_data_pn_SH',opType='append')


def move3(code):
    sql = '''
select w, h, c10, c60, date, x, close, ma10, ma60, code, work_date, ts, w_ct, h_ct, h_1t, h_6t from raw_merger_image_data_info_SH
 where code = '{code}'
 '''.format(code=code)
    df = query(sql, conn)
    rdf = df.copy()
    w_v  = df.w.apply(lambda x: getClsV(x, w_cls)).values
    hc_v = df.h.apply(lambda x: getClsV(440 - x, h_cls)).values
    h1_v = df.c10.apply(lambda x: getClsV(440 - x, h_cls)).values
    h6_v = df.c60.apply(lambda x: getClsV(440 - x, h_cls)).values
    rdf['w_ct'] = w_v
    rdf['h_ct'] = hc_v
    rdf['h_1t'] = h1_v
    rdf['h_6t'] = h6_v
    return rdf

    #insert(rdf,conn,'raw_merger_degress_data_pn_SH')
if __name__ == '__main__':
    codes = glob.glob(r'D:\data\images\final\*')
    codes = list(map(lambda x:x.split("\\")[-1],codes))
    rdf_a = []
    rdf_b = []
    rdf_c = []
    dest_conn = getConn(RAW_HLS_WORK_FILE_HISTES)
    for idx,code in enumerate(codes):
        if False:
            rdfa = move1(code)
            if len(rdfa) > 0:
                rdf_a.append(rdfa)
            if len(rdf_a) %50 == 0 and len(rdf_a) > 0:
                df_a = pd.concat(rdf_a)
                insert(df_a, dest_conn, 'raw_merger_degress_data_cn_SH', opType='append')
                rdf_a = []
        if True:
            rdfb = move2(code)
            if len(rdfb) > 0:
                rdf_b.append(rdfb)

            if len(rdf_b) % 89 == 0 and len(rdf_b) > 0:
                df_b = pd.concat(rdf_b)
                insert(df_b, dest_conn, 'raw_merger_degress_data_pn_SH', opType='append')
                rdf_b = []
        if False:
            rdfc = move3(code)
            if len(rdfc) > 0:
                rdf_c.append(rdfc)
            if len(rdf_c) % 50 == 0 and len(rdf_c) > 0:
                df_c = pd.concat(rdf_c)
                insert(df_c, dest_conn, 'raw_merger_image_data_info_SH', opType='append')
                rdf_c = []

        print("-------------%s %s %s %s %s %s" %(idx,code,len(codes),len(rdf_a),len(rdf_b),len(rdf_c)))
    if len(rdf_a) > 0:
        df_a = pd.concat(rdf_a)
        insert(df_a, dest_conn, 'raw_merger_degress_data_cn_SH', opType='append')

    if len(rdf_b) > 0:
        df_b = pd.concat(rdf_b)
        insert(df_b, dest_conn, 'raw_merger_degress_data_pn_SH', opType='append')

    if len(rdf_c) > 0:
        df_c = pd.concat(rdf_c)
        insert(df_c, dest_conn, 'raw_merger_image_data_info_SH',opType='append')

    #move2()
    #
    #print("-------------2")

