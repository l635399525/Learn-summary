import cv2
import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD,RAW_HLS_WORK_FILE_HIST
from hl_tool.FuncTool import getDataSplitIdx, _draw_close
import os

def getHLWavePoints():
    conn = getConn(RAW_HLS_WORK_FILE_HIST)
    sql = '''
    select distinct code,date,close,percent from raw_data_d_hist 
    and date(date) > date('2003-01-01')
    '''
    df = query(sql,conn)
    dfs = df.groupby('code')
    for code,idf in dfs[:10]:
        idf = idf.sort_values(by=['date'])
        idf['ma60'] = np.round(idf.close.rolling(60).mean().values,3)
        idf['ma10'] = np.round(idf.close.rolling(10).mean().values,3)
        idf = idf.dropna()
        idf_1 = idf[['code','date','percent']].copy()
        idf_1 = idf_1.sort_values(by=['date'])
        close_date = idf[['date', 'close','ma10','ma60']].values

        cols = []
        for i in range(13):
            idf_1['c_%s' %(i)] = idf.close.shift(i).values
            cols.append('c_%s' %(i))
        idf_1 = idf_1.dropna()
        datas = idf_1[cols].values
        max_idxes = np.argmax(datas,axis=1)
        min_idxes = np.argmin(datas,axis=1)
        max_idxes = np.argwhere(max_idxes == 0)[:,0]
        min_idxes = np.argwhere(min_idxes == 0)[:, 0]
        dfa = idf_1[['code', 'date', 'percent', 'c_0']].iloc[max_idxes].copy()
        dfa['t'] = 'A'
        dfb = idf_1[['code', 'date', 'percent', 'c_0']].iloc[min_idxes].copy()
        dfb['t'] = 'B'
        rdf = pd.concat([dfa,dfb])
        rdf = rdf.sort_values(by=['date'])
        afs = rdf.t.apply(lambda x: 1 if x == 'A' else -1).values
        idxes = getDataSplitIdx(afs)
        max_idxes = list(map(lambda x:max(x),idxes))
        rdf = rdf.iloc[max_idxes].copy()
        rdf.rename(columns={'code':'code', 'percent':'percent','t':'t', 'date':'ndate', 'c_0':'nclose'}, inplace=True)
        rdf['cdate'] = rdf.ndate.shift(1).values
        rdf['cclose'] = rdf.nclose.shift(1).values
        rdf['pdate'] = rdf.ndate.shift(2).values
        rdf['pclose'] = rdf.nclose.shift(2).values
        rdf = rdf.dropna()
        rdf = rdf.sort_values(by=['ndate'])
        diffs = np.diff(rdf[['pclose', 'cclose', 'nclose']].values, axis=1)
        gap = diffs[:,0]*diffs[:,1]
        if np.count_nonzero(gap >= 0) > 0:
            print("%s ################Issue" %(code))
        wdates = list(rdf.ndate.values)
        pdate = rdf.iloc[0]['pdate']
        cdate = rdf.iloc[0]['cdate']
        wdates.append(pdate)
        wdates.append(cdate)
        wdates = sorted(wdates)
        wdate_idxes = list(map(lambda x: np.argwhere(close_date[:, 0] == x)[0][0], wdates))
        spec = 454
        work_idxes = list(filter(lambda x:x>spec,wdate_idxes))
        wdates = np.asarray(wdates)
        out = r'D:\data\images\final\%s' %(code)
        for i in range(len(work_idxes)):
            eidx = work_idxes[i]
            sids = eidx - spec
            show_data = close_date[sids:eidx+1]
            show_wave_idxes = np.argwhere(np.in1d(show_data[:,0],wdates))[:,0]
            mask = _draw_close(show_data,show_wave_idxes)
            if not os.path.exists(out):
                os.makedirs(out)
            cv2.imwrite(r'%s\%s#%s.jpg' %(out,i+1,show_data[-1][0]),mask)
            print("%s %s" %(i,len(wdate_idxes)))
if __name__ == '__main__':
    getHLWavePoints()