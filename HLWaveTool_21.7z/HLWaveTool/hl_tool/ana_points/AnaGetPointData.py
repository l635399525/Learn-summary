import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
def _calAngle(pp, cp, np):
    # a 左边 b 右边
    import math
    x1, y1 = pp[0], pp[1]
    x2, y2 = cp[0], cp[1]
    x3, y3 = np[0], np[1]
    try:
        a = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        b = math.sqrt((x2 - x3) ** 2 + (y2 - y3) ** 2)
        c = math.sqrt((x1 - x3) ** 2 + (y1 - y3) ** 2)
        A = math.degrees(math.acos((a * a - b * b - c * c) / (-2 * b * c)))
        B = math.degrees(math.acos((b * b - a * a - c * c) / (-2 * a * c)))
        C = math.degrees(math.acos((c * c - a * a - b * b) / (-2 * a * b)))
    except:
        import traceback
        traceback.print_exc()

    return a,b,c,A,B,C
import math,cmath
def getImagePointsData():
    files = ['RAW_HLWAVES_DATA_HISTORYSES','RAW_HLWAVES_DATA_HISTORYSES_SH','RAW_HLWAVES_DATA_HISTORYSES_SZ','RAW_HLWAVES_DATA_HISTORYSES_SZ1']
    an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS")
    lines = []

    for file in files:
        sh_conn = getConn(dest_summary_path + "/%s" %(file))
        sql = '''
        select distinct code from raw_merger_image_data_info_SH
        '''
        odfs = []
        codes = list(query(sql,sh_conn)['code'].values)
        for idx,code in enumerate(codes):
            sql = '''
                    select distinct w, h, c10, c60, date, x, close, ma10, ma60, code, work_date, ts, w_ct, h_ct, h_1t, h_6t from raw_merger_image_data_info_SH where code = '{code}'
                    '''.format(code=code)
            df = query(sql,sh_conn)
            dfs = df.groupby(['code','work_date'])
            for line,idf in dfs:
                try:
                    idf = idf.sort_values(by=['date'])
                    cdate = idf['date'].shift(1).values
                    pdate = idf['date'].shift(2).values
                    p1h = 440 - idf['h'].shift(1).values
                    p2h = 440 - idf['h'].shift(2).values
                    p1w = idf['w'].shift(1).values
                    p2w = idf['w'].shift(2).values

                    p1wc_t = idf['w_ct'].shift(1).values
                    p2wc_t = idf['w_ct'].shift(2).values
                    p1hc_t = idf['h_ct'].shift(1).values
                    p2hc_t = idf['h_ct'].shift(2).values

                    idf['cdate'] = cdate
                    idf['pdate'] = pdate
                    rdf = pd.DataFrame()

                    rdf['code'] = idf['code'].values
                    rdf['work_date'] = idf['work_date'].values
                    rdf['pdate'] = pdate
                    rdf['cdate'] = cdate
                    rdf['ndate'] = idf['date'].values
                    rdf['pw'] = p2w
                    rdf['cw'] = p1w
                    rdf['nw'] = idf['w'].values
                    rdf['ph'] = p2h
                    rdf['ch'] = p1h
                    rdf['nh'] = 440 - idf['h'].values
                    rdf['pwc_t'] = p2wc_t
                    rdf['cwc_t'] = p1wc_t
                    rdf['nwc_t'] = idf['w_ct'].values

                    rdf['phc_t'] = p2hc_t
                    rdf['chc_t'] = p1hc_t
                    rdf['nhc_t'] = idf['h_ct'].values

                    rdf = rdf.dropna()
                    #rdf.apply(lambda x:_calAngle([x['pw'],x['ph']],[x['cw'],x['ch']],[x['nw'],x['nh']]),axis=1)
                    try:
                        angle_infos = list(rdf.apply(lambda x: _calAngle([x['pw'], x['ph']], [x['cw'], x['ch']], [x['nw'], x['nh']]),axis=1).values)
                    except:
                        pass
                    polor_degress_c = rdf.apply(lambda x:  math.degrees(cmath.polar(complex(x['cw'] - x['pw'], x['ch'] - x['ph']))[1]), axis=1).values
                    polor_degress_n = rdf.apply(lambda x:  math.degrees(cmath.polar(complex(x['nw'] - x['cw'], x['nh'] - x['ch']))[1]), axis=1).values
                    rdf['d_a'] = np.round(list(map(lambda x:x[0],angle_infos)),1)
                    rdf['d_b'] = np.round(list(map(lambda x:x[1],angle_infos)),1)
                    rdf['d_c'] = np.round(list(map(lambda x:x[2],angle_infos)),1)
                    rdf['a_A'] = np.round(list(map(lambda x:x[3],angle_infos)),1)
                    rdf['a_B'] = np.round(list(map(lambda x:x[4],angle_infos)),1)
                    rdf['a_C'] = np.round(list(map(lambda x:x[5],angle_infos)),1)
                    rdf['polor_c'] = np.round(polor_degress_c,1)
                    rdf['polor_n'] = np.round(polor_degress_n,1)
                    fdf = rdf.iloc[-7:]
                    odfs.append(fdf)
                except:
                    import traceback
                    traceback.print_exc()
                    pass
            print("%s %s %s %s" %(code,idx,len(odfs),len(dfs)))
        fdf = pd.concat(odfs)
        insert(fdf, an_conn, 'raw_data_ana_cnts_point',opType='append')

def move():
    dest_an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    srcs_an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS")

    sql = '''
select distinct code,min(work_date) as work_date,pdate,cdate,ndate,d_a,d_b,phc_t,chc_t,nhc_t,
chc_t - phc_t as cy,nhc_t - chc_t as ny
from raw_data_ana_cnts_point group by code,pdate,cdate,ndate
    '''
    df = query(sql,srcs_an_conn)
    dfs = df.groupby('code')
    odfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['ndate'])
        idf['ny1'] =idf['ny'].shift(-1).values
        idf['ny2'] =idf['ny'].shift(-2).values
        idf['ny3'] =idf['ny'].shift(-3).values
        idf['ny4'] =idf['ny'].shift(-4).values
        odfs.append(idf)
    rdf = pd.concat(odfs)
    insert(rdf,dest_an_conn,'raw_data_ana_cnts_ny')
def move0():
    dest_an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    srcs_an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS")

    sql = '''
select distinct code,work_date,ndate,nhc_t from raw_data_ana_cnts_point 
    '''
    df = query(sql,srcs_an_conn)
    dfs = df.groupby('code')
    odfs = []
    for code,idf in dfs:
        idfs = idf.groupby('work_date')
        for work_date,iidf in idfs:

            iidf = iidf.sort_values(by=['ndate'])
            for i in range(1,6):
                iidf['date_%s' %(6-i)] = iidf['ndate'].shift(i).values
                iidf['hc_t_%s' %(6-i)] = iidf['nhc_t'].shift(i).values
            line = dict(iidf.iloc[-1])
            odfs.append(line)
            print("%s %s %s" %(code,work_date,len(odfs)))
    rdf = pd.DataFrame(odfs)
    insert(rdf,dest_an_conn,'raw_data_ana_cnts_ny_H2V')
def move1():
    sql = '''
    select a.code, pdate, cdate, ny,
       p_cls_a, p_cls_b, p_cls_a_d, p_cls_a_d_deg, p_cls_b_d, p_cls_b_d_deg
       ,c_cls_a, c_cls_b, c_cls_a_d, c_cls_a_d_deg, c_cls_b_d, c_cls_b_d_deg
from
 (select code, pdate, cdate, ny from raw_data_ana_cnts_ny  ) a
,(select a.code,a.work_date
      ,cls_a       as p_cls_a
      ,cls_b       as p_cls_b
      ,cls_a_d     as p_cls_a_d
      ,cls_a_d_deg as p_cls_a_d_deg
      ,cls_b_d     as p_cls_b_d
      ,cls_b_d_deg as p_cls_b_d_deg
from raw_data_ana_cnts_rate a,raw_data_ana_cnts_degress_arate b
where a.code = b.code and a.work_date = b.work_date) b
 ,(select a.code,a.work_date
      ,cls_a       as c_cls_a
      ,cls_b       as c_cls_b
      ,cls_a_d     as c_cls_a_d
      ,cls_a_d_deg as c_cls_a_d_deg
      ,cls_b_d     as c_cls_b_d
      ,cls_b_d_deg as c_cls_b_d_deg
from raw_data_ana_cnts_rate a,raw_data_ana_cnts_degress_arate b
where a.code = b.code and a.work_date = b.work_date) c
where a.code = b.code and a.pdate = b.work_date
and a.code =c.code and a.cdate = c.work_date
    '''
    dest_an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql,dest_an_conn)
    insert(df,dest_an_conn,'raw_data_ana_cnts_cls_ny_tmp')
    '''
    select a.c_cls_a,a.aclsa_cnt,b.clsa_cnt,round(a.aclsa_cnt*1.0/b.clsa_cnt,3) as ar_a from (select c_cls_a,count(*) as aclsa_cnt from raw_data_ana_cnts_cls_ny_tmp where ny > 1
group by c_cls_a) a,
(select cls_a,count(*) as clsa_cnt from raw_data_ana_cnts_rate group by cls_a) b
where a.c_cls_a = b.cls_a

select a.c_cls_b,a.bclsa_cnt,b.clsb_cnt,round(a.bclsa_cnt*1.0/b.clsb_cnt,3) as ar_b from
(select c_cls_b,count(*) as bclsa_cnt from raw_data_ana_cnts_cls_ny_tmp where ny >= 1
group by c_cls_b) a,
(select cls_b,count(*) as clsb_cnt from raw_data_ana_cnts_rate group by cls_b) b
where a.c_cls_b = b.cls_b
    '''
def move2():
    sql = '''
    select a.cls, a.ts,
       a.af1s, a.af2s, a.af3s, a.ar1, a.ar2, a.ar3, a.avg_ny, a.cnt,
       b.b_af1s, b.b_af2s, b.b_af3s, b.b_ar1, b.b_ar2, b.b_ar3, b.b_avg_ny from
(select cls_a as cls,ts,'A' as type
       ,sum(af1) as af1s
       ,sum(af2) as af2s
       ,sum(af3) as af3s
       ,round(sum(af1)*1.0/count(*),3) as ar1
       ,round(sum(af2)*1.0/count(*),3) as ar2
       ,round(sum(af3)*1.0/count(*),3) as ar3
       ,round(avg(ny)              ,3) as avg_ny
     ,count(*) as cnt from
(select case when (ny0 + ny1 + ny2 + ny3) > 0 then 1 else 0 end as af1,
        case when (ny0 + ny1 + ny2 + ny3) > 1 then 1 else 0 end as af2,
        case when (ny0 + ny1 + ny2 + ny3) > 2 then 1 else 0 end as af3,
        cls_a,cls_b,(ny0 + ny1 + ny2 + ny3) as ny,ts  from
(select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,cy,
 case when ny  > 0 then ny  else 0 end ny0,
 case when ny1 > 0 then ny1 else 0 end ny1,
 case when ny2 > 0 then ny2 else 0 end ny2,
 case when ny3 > 0 then ny3 else 0 end ny3
from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
raw_data_ana_cnts_ny c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.cdate)) group by cls_a,ts
union
select cls_b as cls,ts,'A' as type
       ,sum(af1) as af1s
       ,sum(af2) as af2s
       ,sum(af3) as af3s
       ,round(sum(af1)*1.0/count(*),3) as ar1
       ,round(sum(af2)*1.0/count(*),3) as ar2
       ,round(sum(af3)*1.0/count(*),3) as ar3
       ,round(avg(ny)              ,3) as avg_ny
     ,count(*) as cnt from
(select case when (ny0 + ny1 + ny2 + ny3) > 0 then 1 else 0 end as af1,
        case when (ny0 + ny1 + ny2 + ny3) > 1 then 1 else 0 end as af2,
        case when (ny0 + ny1 + ny2 + ny3) > 2 then 1 else 0 end as af3,
        cls_a,cls_b,(ny0 + ny1 + ny2 + ny3) as ny,ts  from
(select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,cy,
 case when ny  > 0 then ny  else 0 end ny0,
 case when ny1 > 0 then ny1 else 0 end ny1,
 case when ny2 > 0 then ny2 else 0 end ny2,
 case when ny3 > 0 then ny3 else 0 end ny3
from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
raw_data_ana_cnts_ny c
where  a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.cdate)) group by cls_b,ts) a,
(select cls_a as cls,ts,'B' as type
       ,sum(af1) as b_af1s
       ,sum(af2) as b_af2s
       ,sum(af3) as b_af3s
       ,round(sum(af1)*1.0/count(*),3) as b_ar1
       ,round(sum(af2)*1.0/count(*),3) as b_ar2
       ,round(sum(af3)*1.0/count(*),3) as b_ar3
       ,round(avg(ny)              ,3) as b_avg_ny
     ,count(*) as cnt from
(select case when (ny0 + ny1 + ny2 + ny3) <= -4 then 1 else 0 end as af1,
        case when (ny0 + ny1 + ny2 + ny3) <= -2 then 1 else 0 end as af2,
        case when (ny0 + ny1 + ny2 + ny3) <= 0  then 1 else 0 end as af3,
        cls_a,cls_b,(ny0 + ny1 + ny2 + ny3) as ny,ts  from
(select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,cy,
 case when ny  > 0 then 0 else ny  end ny0,
 case when ny1 > 0 then 0 else ny1 end ny1,
 case when ny2 > 0 then 0 else ny2 end ny2,
 case when ny3 > 0 then 0 else ny3 end ny3
from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
raw_data_ana_cnts_ny c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.cdate)) group by cls_a,ts
union
select cls_b as cls,ts,'B' as type
       ,sum(af1) as b_af1s
       ,sum(af2) as b_af2s
       ,sum(af3) as b_af3s
       ,round(sum(af1)*1.0/count(*),3) as b_ar1
       ,round(sum(af2)*1.0/count(*),3) as b_ar2
       ,round(sum(af3)*1.0/count(*),3) as b_ar3
       ,round(avg(ny)              ,3) as b_avg_ny
     ,count(*) as cnt from
(select case when (ny0 + ny1 + ny2 + ny3) <= -4 then 1 else 0 end as af1,
        case when (ny0 + ny1 + ny2 + ny3) <= -2 then 1 else 0 end as af2,
        case when (ny0 + ny1 + ny2 + ny3) <= 0  then 1 else 0 end as af3,
        cls_a,cls_b,(ny0 + ny1 + ny2 + ny3) as ny,ts  from
(select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,cy,
case when ny  > 0 then 0 else ny  end ny0,
case when ny1 > 0 then 0 else ny1 end ny1,
case when ny2 > 0 then 0 else ny2 end ny2,
case when ny3 > 0 then 0 else ny3 end ny3
from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
raw_data_ana_cnts_ny c
where  a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.cdate)) group by cls_b,ts) b
where a.cls = b.cls and a.ts = b.ts
    '''
    dest_an_conn = getConn(dest_summary_path  + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")

    df = query(sql,dest_an_conn)
    insert(df,dest_an_conn,'raw_data_ana_cnts_ny_kpi')
def move3():
    sql = '''
    select a.cls,a.ar as ar0,a.a_cnt,b.cnt,round(a_cnt*1.0/cnt,3) as ar1,45206 as cnts from
    (select cls_a as cls,round(count(*)*1.0/45206,3) as ar ,count(*) as a_cnt from
    (select * from
    (select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,
              max(ny,ny1,ny2,ny3) as ny
    from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
    raw_data_ana_cnts_ny c
    where a.code = b.code and a.work_date = b.work_date
    and a.code = c.code and a.work_date = c.cdate)
    where ny > 2) group by cls_a
    union
    select cls_b,round(count(*)*1.0/45206,3) as br, count(*) as b_cnt from
    (select * from
    (select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,
              max(ny,ny1,ny2,ny3) as ny
    from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
    raw_data_ana_cnts_ny c
    where a.code = b.code and a.work_date = b.work_date
    and a.code = c.code and a.work_date = c.cdate)
    where ny > 2) group by cls_b) a,
    (select cls_a as cls,count(*) as cnt from raw_data_ana_cnts_rate group by cls_a
    union
    select cls_b as cls,count(*) from raw_data_ana_cnts_rate group by cls_b) b
    where a.cls = b.cls
    '''
    dest_an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")

    df = query(sql, dest_an_conn)
    insert(df, dest_an_conn, 'raw_data_ana_cnts_ny_kpi_1')
def move4():
    sql = '''
    select cls_a as cls,ts,'A' as type
       ,sum(af1) as af1s
       ,sum(af2) as af2s
       ,sum(af3) as af3s
       ,sum(bf1) as bf1s
       ,sum(bf2) as bf2s
       ,sum(bf3) as bf3s
       ,round(sum(af1)*1.0/count(*),3) as ar1
       ,round(sum(af2)*1.0/count(*),3) as ar2
       ,round(sum(af3)*1.0/count(*),3) as ar3
       ,round(sum(bf1)*1.0/count(*),3) as br1
       ,round(sum(bf2)*1.0/count(*),3) as br2
       ,round(sum(bf3)*1.0/count(*),3) as br3
       ,round(avg(ny),3) as avg_ny
     ,count(*) as cnt from
(select case when (ny0 + ny1 + ny2 + ny3) > 0   then 1 else 0 end as af1,
        case when (ny0 + ny1 + ny2 + ny3) > 1   then 1 else 0 end as af2,
        case when (ny0 + ny1 + ny2 + ny3) > 2   then 1 else 0 end as af3,
        case when (ny0 + ny1 + ny2 + ny3) <= 0  then 1 else 0 end as bf1,
        case when (ny0 + ny1 + ny2 + ny3) <= -2 then 1 else 0 end as bf2,
        case when (ny0 + ny1 + ny2 + ny3) <= -4 then 1 else 0 end as bf3,ts,cls_a,cls_b
,ny0 + ny1 + ny2 + ny3 as ny
from
(select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,cy,
ny  as  ny0,
ny1 as  ny1,
ny2 as  ny2,
ny3 as  ny3
from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
raw_data_ana_cnts_ny c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.cdate)) group by cls_a,ts
union
select cls_b as cls,ts,'B' as type
       ,sum(af1) as af1s
       ,sum(af2) as af2s
       ,sum(af3) as af3s
       ,sum(bf1) as bf1s
       ,sum(bf2) as bf2s
       ,sum(bf3) as bf3s
       ,round(sum(af1)*1.0/count(*),3) as ar1
       ,round(sum(af2)*1.0/count(*),3) as ar2
       ,round(sum(af3)*1.0/count(*),3) as ar3
       ,round(sum(bf1)*1.0/count(*),3) as br1
       ,round(sum(bf2)*1.0/count(*),3) as br2
       ,round(sum(bf3)*1.0/count(*),3) as br3
       ,round(avg(ny),3) as avg_ny
     ,count(*) as cnt from
(select case when (ny0 + ny1 + ny2 + ny3) > 0   then 1 else 0 end as af1,
        case when (ny0 + ny1 + ny2 + ny3) > 1   then 1 else 0 end as af2,
        case when (ny0 + ny1 + ny2 + ny3) > 2   then 1 else 0 end as af3,
        case when (ny0 + ny1 + ny2 + ny3) <= 0  then 1 else 0 end as bf1,
        case when (ny0 + ny1 + ny2 + ny3) <= -2 then 1 else 0 end as bf2,
        case when (ny0 + ny1 + ny2 + ny3) <= -4 then 1 else 0 end as bf3,ts,cls_a,cls_b
,ny0 + ny1 + ny2 + ny3 as ny
from
(select distinct a.code,a.work_date,ts,b.cls_a,b.cls_b,cy,
ny  as  ny0,
ny1 as  ny1,
ny2 as  ny2,
ny3 as  ny3
from raw_data_ana_cnts a,raw_data_ana_cnts_rate b,
raw_data_ana_cnts_ny c
where a.code = b.code and a.work_date = b.work_date
and a.code = c.code and a.work_date = c.cdate)) group by cls_b,ts
    '''
    dest_an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")

    df = query(sql, dest_an_conn)
    insert(df, dest_an_conn, 'raw_data_ana_cnts_ny_kpi_2')
if __name__ == '__main__':
    move0()
