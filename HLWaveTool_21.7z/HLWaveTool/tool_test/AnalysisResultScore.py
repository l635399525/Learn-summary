import itertools

import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
import glob
import pandas as pd
from datetime import datetime
def getScore():
    sql = '''
    select distinct cds,b1_ar_b,b0_ar_b,a1_ar_a,a0_ar_a from test_summary_kpi5
    '''
    train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")
    data_info = query(sql,train_conn)
    data_info['cds'] = data_info['cds'].apply(lambda x:",".join(sorted(x.split(",")))).values
    data_info = data_info[['cds','b1_ar_b','b0_ar_b','a1_ar_a','a0_ar_a']].values
    import itertools
    sql = '''
    select distinct code, work_date, ny, pny, ts, cls_a, cls_b, a, r_close_1, r_close_1afr, r_close_1nycusm, r_close_1nycusmafr, r_close_1nycusmafrpny, r_close_1nycusmafrpny1, r_close_2, r_close_2afr, r_close_2nycusm, r_close_2nycusmafr, r_close_2nycusmafrpny, r_close_2nycusmafrpny1, r_close_3, r_close_3afr, r_close_3nycusm, r_close_3nycusmafr, r_close_3nycusmafrpny, r_close_3nycusmafrpny1, r_degress_1, r_degress_1afr, r_degress_1nycusm, r_degress_1nycusmafr, r_degress_1nycusmafrpny, r_degress_1nycusmafrpny1, r_degress_2, r_degress_2afr, r_degress_2nycusm, r_degress_2nycusmafr, r_degress_2nycusmafrpny, r_degress_2nycusmafrpny1, r_degress_3, r_degress_3afr, r_degress_3nycusm, r_degress_3nycusmafr, r_degress_3nycusmafrpny, r_degress_3nycusmafrpny1 from test_summary
    '''
    df = query(sql,train_conn)
    df = df.fillna(0)
    cols = list(df.keys())
    cols = list(filter(lambda x:str(x).startswith('r_'),cols))
    for col in cols:
        df[col] = df[col].apply(lambda x:1 if x > 0 else 0).values
    datas = df[cols].values
    datas = list(map(lambda x:",".join(list(x)),list(datas.astype(str))))
    df['key'] = datas
    dfs = df.groupby(['key','ts'])
    cols = np.asarray(cols)
    def _getScoreVal(data_info,datas,iv):
        score = 0
        cds = data_info[:,0]
        data_V = data_info[:,iv]
        data_CD = data_info[:,0]
        e_cds = []
        cnt = 0
        while len(datas) >= 5:
            cnt = cnt + 1
            line5 = list(itertools.combinations(datas,5))
            line5s = np.asarray(list(map(lambda x:",".join(sorted(list(x))),line5)))
            idxes = np.intersect1d(cds,line5s,return_indices=True)[1]
            max_idx = idxes[np.argmax(data_V[idxes])]
            max_v = data_V[max_idx]
            score = score + max_v
            data_V[max_idx] = 0
            o_cds = data_CD[max_idx].split(",")
            e_cds.extend(o_cds)
            datas = list(filter(lambda x:x not in e_cds,datas))
        return score,cnt
    rdfs = []
    for line,idf in dfs:
        try:
            print("%s %s %s" %(line,len(rdfs),len(dfs)))
            key,ts = line
            keys = np.asarray(key.split(",")).astype(int)
            cols_a = cols[np.argwhere(keys > 0)[:,0]]
            cols_b = cols[np.argwhere(keys <= 0)[:,0]]
            iv_a = 3 if ts > 0 else 4
            iv_b = 1 if ts > 0 else 2
            score_a,cnt_a = _getScoreVal(data_info,cols_a,iv_a)
            score_b,cnt_b = _getScoreVal(data_info, cols_b, iv_b)
            rdf = idf[['code', 'work_date', 'ny', 'pny', 'ts', 'cls_a', 'cls_b', 'a']].copy()
            rdf['score_a'] = score_a
            rdf['score_b'] = score_b
            rdf['cnt_a'] = cnt_a
            rdf['cnt_b'] = cnt_b
            if len(rdf) > 0:
                rdfs.append(rdf)
        except:
            print(line)
    fdf = pd.concat(rdfs)
    insert(fdf,train_conn,'test_summary_kpi5_score')
if __name__ == '__main__':
    getScore()
sql = '''


'''