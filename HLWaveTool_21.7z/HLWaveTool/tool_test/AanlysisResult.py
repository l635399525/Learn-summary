import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path
import glob
import pandas as pd
from datetime import datetime
def putTrainResult():
    csvs = glob.glob(r'D:\codes\data\2022\train_result\ana_data\*')
    hs = []
    for csv in csvs:
        df = pd.read_csv(csv)
        if "-" not in df.iloc[0]['work_date']:
            df['work_date'] = df.work_date.apply(lambda x: datetime.strftime(datetime.strptime(x, "%Y/%m/%d"), "%Y-%m-%d")).values
        heads = df[['code', 'work_date', 'ny', 'pny', 'ts', 'cls_a', 'cls_b']].copy()
        hs.append(heads)
    heads = pd.concat(hs)
    heads = heads.drop_duplicates()
    heads['a'] = heads.ny.apply(lambda x:1 if x > 0 else 0 ).values
    rline = heads.copy()
    cols = ['code', 'work_date', 'ny', 'pny', 'ts', 'cls_a', 'cls_b','a']
    train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")
    for csv in csvs:
        col = csv.split("\\")[-1].split("#")[0].replace("res_", "r_")
        cols.append(col)
        df = pd.read_csv(csv)
        tdf = df[['code', 'work_date', col]].copy()
        if "-" not in tdf.iloc[0]['work_date']:
            tdf['work_date'] = tdf.work_date.apply(lambda x: datetime.strftime(datetime.strptime(x, "%Y/%m/%d"), "%Y-%m-%d")).values
        rline = pd.merge(rline, tdf, how='outer', on=['code', 'work_date'])
        rline = rline[cols]
        rline = rline.drop_duplicates()
        print(len(list(rline.keys())))
    insert(rline, train_conn, 'test_summary')
def putAnalysis():
    train_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_TRAIN")
    sql = '''
    select * from test_summary
    '''
    df = query(sql,train_conn)
    columns = list(df.keys())
    cols = list(filter(lambda x:str(x).startswith('r_'),columns))
    import itertools
    ls = []
    l2 = list(itertools.combinations(cols,2))
    l3 = list(itertools.combinations(cols,3))
    l4 = list(itertools.combinations(cols,4))
    l5 = list(itertools.combinations(cols,5))

    ls.extend(l2)
    ls.extend(l3)
    ls.extend(l4)
    ls = l5
    rlines = []
    for idx,l in enumerate(ls):
        score = 0
        if len(l) == 2:
            rdf_a = df[(df[l[0]] > score) &  (df[l[1]] > score)]
            rdf_b = df[(df[l[0]] <= score) & (df[l[1]] <= score)]
        if len(l) == 3:
            rdf_a = df[(df[l[0]] > score)  & (df[l[1]] > score)  & (df[l[2]] > score)]
            rdf_b = df[(df[l[0]] <= score) & (df[l[1]] <= score) & (df[l[2]] <= score)]
        if len(l) == 4:
            rdf_a = df[(df[l[0]] > score) & (df[l[1]] > score)   & (df[l[2]] > score)  & (df[l[3]] > score)]
            rdf_b = df[(df[l[0]] <= score) & (df[l[1]] <= score) & (df[l[2]] <= score) & (df[l[3]] <= score)]
        if len(l) == 5:
            rdf_a = df[(df[l[0]] > score)  & (df[l[1]] > score)  & (df[l[2]] > score)  & (df[l[3]] > score)  & (df[l[4]] > score)]
            rdf_b = df[(df[l[0]] <= score) & (df[l[1]] <= score) & (df[l[2]] <= score) & (df[l[3]] <= score) & (df[l[4]] <= score)]

        rdf_a0   = rdf_a[rdf_a['ts'] == 0]
        rdf_a0_a = rdf_a0[rdf_a0['ny'] > 0]
        rdf_a0_b = rdf_a0[rdf_a0['ny'] <= 0]

        rdf_a1   = rdf_a[rdf_a['ts'] == 1]
        rdf_a1_a = rdf_a1[rdf_a1['ny'] >= 0]
        rdf_a1_b = rdf_a1[rdf_a1['ny'] < 0]

        rdf_b0 = rdf_b[rdf_b['ts'] == 0]
        rdf_b0_a = rdf_b0[rdf_b0['ny'] > 0]
        rdf_b0_b = rdf_b0[rdf_b0['ny'] <= 0]

        rdf_b1 = rdf_b[rdf_b['ts'] == 1]
        rdf_b1_a = rdf_b1[rdf_b1['ny'] >= 0]
        rdf_b1_b = rdf_b1[rdf_b1['ny'] < 0]

        acnts = len(rdf_a)
        acnts_0 = len(rdf_a0)
        acnts_0_a = len(rdf_a0_a)
        acnts_0_b = len(rdf_a0_b)

        acnts_1 = len(rdf_a1)
        acnts_1_a = len(rdf_a1_a)
        acnts_1_b = len(rdf_a1_b)

        bcnts = len(rdf_b)
        bcnts_0 = len(rdf_b0)
        bcnts_0_a = len(rdf_b0_a)
        bcnts_0_b = len(rdf_b0_b)

        bcnts_1 = len(rdf_b1)
        bcnts_1_a = len(rdf_b1_a)
        bcnts_1_b = len(rdf_b1_b)
        b1_ar_b = round(bcnts_1_b/bcnts_1,3)
        b1_ar_a = round(bcnts_1_a/bcnts_1,3)

        b0_ar_b = round(bcnts_0_b/bcnts_0,3)
        b0_ar_a = round(bcnts_0_a/bcnts_0,3)

        a1_ar_a = round(acnts_1_a / acnts_1, 3)
        a1_ar_b = round(acnts_1_b / acnts_1, 3)

        a0_ar_a = round(acnts_0_a / acnts_0, 3)
        a0_ar_b = round(acnts_0_b / acnts_0, 3)

        rline = {'cds' : ",".join(list(l)),
                 'b1_ar_a':b1_ar_a,'b0_ar_a':b0_ar_a,'a1_ar_a':a1_ar_a,'a0_ar_a':a0_ar_a,
                 'b1_ar_b':b1_ar_b,'b0_ar_b':b0_ar_b,'a1_ar_b':a1_ar_b,'a0_ar_b':a0_ar_b,
                 'acnts_0': acnts_0, 'acnts_0_a': acnts_0_a, 'acnts_0_b': acnts_0_b, 'acnts_1':acnts_1,'acnts_1_a': acnts_1_a,'acnts_1_b': acnts_1_b,
                 'bcnts_0': bcnts_0, 'bcnts_0_b': bcnts_0_b, 'bcnts_0_a': bcnts_0_a, 'bcnts_1':bcnts_1,'bcnts_1_b': bcnts_1_b,'bcnts_1_a': bcnts_1_a
                 }
        print("%s %s" %(idx + 1,len(ls)))
        rlines.append(rline)
    df = pd.DataFrame(rlines)
    insert(df,train_conn,'test_summary_kpi5')



if __name__ == '__main__':
    #putTrainResult()
    putAnalysis()
    # import itertools
    # itertools.combinations()
    # sql = '''
    #
    # '''