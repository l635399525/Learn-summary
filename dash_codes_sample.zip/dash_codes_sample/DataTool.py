# zsdf = getZSValues(rdate, days)
# pn_df = getValues(rdate, days)
from tools.DataPreParing import getValues
from tools.DbTool import getConn,insert,query
from tools.DataFactorTools import getZSValues
dest_path = "/Users/lili/data/prod/bs_summary"
db_file = "%s/%s" % (dest_path, 'sumarry_data.db')
def getDates():
    sql = "select distinct date as date from summary_data where date(date) > date('2020-10-30')"
    conn = getConn(db_file)
    df = query(sql,conn=conn)
    dates = list(df["date"].values)
    return dates
def getPNDatas(days=[4,7]):
    dates = getDates()
    conn = getConn(db_file)
    for day in days:
        for idx,date in enumerate(dates):
            # if date == '2021-01-19':
            #     print(day)
            # zsdf = getZSValues(date, day)
            # columns = list(zsdf.keys())
            # new_columns = list(map(lambda x:x if x in ["code","date"] else "zs_%s" %(x),columns))
            # column_map = dict(list(zip(columns,new_columns)))
            # zsdf.rename(columns=column_map, inplace=True)
            pn_df = getValues(date, day)
            pn_df["date"] = [date]*len(pn_df)
            insert(pn_df,conn,"raw_factor%s_data" %(day),opType="append")
            print("%s %s %s-Done" %(date,len(pn_df),day))
if __name__ == '__main__':
    sql = "select * from summary_data"
    conn = getConn(db_file)
    df = query(sql,conn)
    dest_file = dest_path+"/test_data.db"
    dest_conn = getConn(dest_file)
    insert(df,dest_conn,"summary_data",opType="append")
    #getPNDatas()