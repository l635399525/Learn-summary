yl_sqls = {
    "yl_col":"round((close - \"YL#3#price\")*100/close,3)"
}

gini_sqls = \
    {"DS_13":"\"DS_13#B_v_gini\"",
     "DS_21":"\"DS_21#B_v_gini\"",
     "CS_13":"\"CS_13#B_v_gini\"",
     "CS_21":"\"CS_21#B_v_gini\"",
     "dbavg2":"round((\"DS_13#B_v_gini\" + \"DS_21#B_v_gini\") /2,3)",
     "cbavg2":"round((\"CS_13#B_v_gini\" + \"CS_21#B_v_gini\") /2,3)",
     "abavg4":"round((\"DS_13#B_v_gini\" + \"DS_21#B_v_gini\" + \"CS_13#B_v_gini\" + \"CS_21#B_v_gini\") /4,3)",
     "gap_DS_13":"round( \"DS_13#B_v_gini\" - \"DS_13#S_v_gini\",3)",
     "gap_DS_21":"round( \"DS_21#B_v_gini\" - \"DS_21#S_v_gini\",3)",
     "gap_CS_13":"round( \"CS_13#B_v_gini\" - \"CS_13#S_v_gini\",3)",
     "gap_CS_21":"round( \"CS_21#B_v_gini\" - \"CS_21#S_v_gini\",3)",
     "gap_dbavg2":"round((\"DS_13#B_v_gini\" + \"DS_21#B_v_gini\") /2 - (\"DS_13#S_v_gini\" + \"DS_21#S_v_gini\") /2,3)",
     "gap_cbavg2":"round((\"CS_13#B_v_gini\" + \"CS_21#B_v_gini\") /2 - (\"CS_13#S_v_gini\" + \"CS_21#S_v_gini\") /2,3)"}

def getGiNiSqls():
    for key,column in gini_sqls.items():
        print(column)

def getGiNiBSql(column,lcl=-1000,ucl=1000):
    sql = '''
    
    '''

def getBaseASql(day=4,key_column='next_type',types=['A']):
    types = list(map(lambda x:"'%s'" %(x),types))
    type_str = ','.join(types)
    sql = '''
    select a1.code, a1.date, a1.pctchg, a1.next_chg, a1.pre_chg, a1.zs_next_chg, a1.zs_pre_chg,a2.cnts,a3.total_cnts from
        (select code,date,pctchg,next_chg,pre_chg,zs_next_chg,zs_pre_chg from raw_factor{day}_data
    where {column} in ({type}) order by date desc) a1,
    (select date,count(*) as cnts from raw_factor{day}_data
    where {column} in ({type}) group by date) a2,
     (select date,count(*) as total_cnts from raw_factor{day}_data
      group by date) a3 where a1.date = a2.date and a1.date = a3.date
    '''.format(column=key_column,type=type_str,day=day)
    return sql

def getYLSql(column='round((close - "YL#3#price")*100/close,3)',lcl=-1000,ucl=1000):
    sql = '''
    select a1.code, a1.date, a1.rate,a2.type,a2.type_cnt from (select code,date,{column} as rate from summary_data where
            date(date) > date('2020-11-30') and date(date) < date('2022-01-15') and
        "YL#3#price" >= "YL#5#price" and "YL#5#price" >= "YL#13#price" and "YL#13#price" >= "YL#34#price"
        and rate >= {lcl} and rate <= {ucl}) a1,
(select 'YL' as type,date,count(*) as type_cnt,{column} as rate from summary_data where
            date(date) > date('2020-11-30') and date(date) < date('2022-01-15') and
        "YL#3#price" >= "YL#5#price" and "YL#5#price" >= "YL#13#price" and "YL#13#price" >= "YL#34#price"
        and rate >= {lcl} and rate <= {ucl} group by date) a2 where a1.date = a2.date order by a1.date
    '''.format(column=column,lcl=lcl,ucl=ucl)
    return sql

sql_col_condition_mapping = {
    'yl':{"column":'round((close - \"YL#3#price\")*100/close,3)',"condition":'\"YL#3#price\" >= \"YL#5#price\" and \"YL#5#price\" >= \"YL#13#price\" and \"YL#13#price\" >= \"YL#34#price\"'}
}

def getFactorRawSql(key='yl',lcl=-1000,ucl=1000):
    line = sql_col_condition_mapping[key]
    column = line["column"]
    condition = line["condition"]
    sql = '''
        select a1.code, a1.date, a1.rate,a2.type,a2.type_cnt from (select code,date,{column} as rate from summary_data where
                date(date) > date('2020-11-30') and {condition}
            and rate >= {lcl} and rate <= {ucl}) a1,
    (select 'YL' as type,date,count(*) as type_cnt,{column} as rate from summary_data where
                date(date) > date('2020-11-30')  and {condition}
            and rate >= {lcl} and rate <= {ucl} group by date) a2 where a1.date = a2.date order by a1.date
        '''.format(column=column, lcl=lcl, ucl=ucl,condition=condition)
    return sql


def getFactorBaseSql(day=4,key_column='next_type',types=['A'],lcl=-1000,ucl=1000,b_name='yl'):
    a_cols =  "a.code, a.date, a.pctchg, a.next_chg, a.pre_chg, a.zs_next_chg, a.zs_pre_chg,a.cnts,a.total_cnts"
    b_cols =  "b.rate,b.type,b.type_cnt"
    sql_a = getBaseASql(day,key_column,types)
    if b_name == 'yl':
        sql_b = getYLSql(lcl = lcl,ucl=ucl)
    sql_full_a = "select %s,%s from (%s) a,(%s) b where a.code = b.code and a.date = b.date order by a.date desc" %(a_cols,b_cols,sql_a,sql_b)
    sql_a_cols = "a.code as code, a.date as date, a.pctchg as pctchg, a.next_chg as next_chg" \
                 ", a.pre_chg as pre_chg, a.zs_next_chg as zs_next_chg, a.zs_pre_chg as zs_pre_chg," \
                 "a.cnts as cnts,a.total_cnts as total_cnts,a.rate as rate,a.type as type,a.type_cnt as type_cnt"
    sql_cols_plus="round(type_f_cnts*100/type_cnt,3) as type_f_rate,round(cnts*100/total_cnts,3) as a_total_rate,round(type_f_cnts*100/cnts) as f_a_rate"
    sql_full_b = "select date,count(*) as type_f_cnts from (%s) group by date" %(sql_full_a)
    sql_full = "select %s,b.type_f_cnts,%s from (%s) a,(%s) b where a.date = b.date " %(sql_a_cols,sql_cols_plus,sql_full_a,sql_full_b)
    return sql_full

from tools.DbTool import getConn, insert, query
dest_path = "/Users/lili/data/prod/bs_summary"
db_file = "%s/%s" % (dest_path, 'sumarry_data.db')
def dump(sql):
    conn = getConn(db_file)
    df = query(sql,conn)
    insert(df,conn,"tmp")
def printAvg(idx):
    conn = getConn(db_file)
    sql = '''
    select avg( type_f_rate), avg(a_total_rate), avg(f_a_rate) from
              (select  type_f_rate, a_total_rate, f_a_rate from tmp
              where next_chg is not null
              group by date)
    '''
    df = query(sql,conn)
    jsonline = df.to_dict(orient="records")
    print("%s %s" %(idx,jsonline))

if __name__ == '__main__':
    #sql_basea = getBaseASql()
    #yl_sql = getYLSql()
    lst = [[10,1000]]

    for idx,line in enumerate(lst):
        lcl,ucl = line
        yl_base_sql = getFactorBaseSql(day=4,types=['A'],lcl=lcl,ucl=ucl)
        print(yl_base_sql)
        dump(yl_base_sql)
        printAvg(idx)