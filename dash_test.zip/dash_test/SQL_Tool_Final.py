yl_sqls = {
    "yl_col":"round((close - \"YL#3#price\")*100/close,3)"
}

gini_sqls = \
    {"DS_13":"\"DS_13#B_v_gini\"",
     "DS_21":"\"DS_21#B_v_gini\"",
     "CS_13":"\"CS_13#B_v_gini\"",
     "CS_21":"\"CS_21#B_v_gini\"",
     "dbavg2":"round((\"DS_13#B_v_gini\" + \"DS_21#B_v_gini\") /2,3)",
     "cbavg2":"round((\"CS_13#B_v_gini\" + \"CS_21#B_v_gini\") /2,3)",
     "abavg4":"round((\"DS_13#B_v_gini\" + \"DS_21#B_v_gini\" + \"CS_13#B_v_gini\" + \"CS_21#B_v_gini\") /4,3)",
     "gap_DS_13":"round( \"DS_13#B_v_gini\" - \"DS_13#S_v_gini\",3)",
     "gap_DS_21":"round( \"DS_21#B_v_gini\" - \"DS_21#S_v_gini\",3)",
     "gap_CS_13":"round( \"CS_13#B_v_gini\" - \"CS_13#S_v_gini\",3)",
     "gap_CS_21":"round( \"CS_21#B_v_gini\" - \"CS_21#S_v_gini\",3)",
     "gap_dbavg2":"round((\"DS_13#B_v_gini\" + \"DS_21#B_v_gini\") /2 - (\"DS_13#S_v_gini\" + \"DS_21#S_v_gini\") /2,3)",
     "gap_cbavg2":"round((\"CS_13#B_v_gini\" + \"CS_21#B_v_gini\") /2 - (\"CS_13#S_v_gini\" + \"CS_21#S_v_gini\") /2,3)"}

#"sb#CS_13","sb#CS_21","sb#DS_21","sb#DS_13"
sql_col_condition_mapping = {
    'yl':{"limits":[[10,1000]],"column":'round((close - \"YL#3#price\")*100/close,3)',"condition":'\"YL#3#price\" >= \"YL#5#price\" and \"YL#5#price\" >= \"YL#13#price\" and \"YL#13#price\" >= \"YL#34#price\"'}
    ,'sbgini_c13':{"limits":[[0.718,1]],"column":'\"CS_13#B_v_gini\"',"condition":'\"CS_13#B_v_gini\" > \"CS_13#S_v_gini\" '}
    ,'sbgini_c21':{"limits":[[0.768,1]],"column":'\"CS_21#B_v_gini\"',"condition":'\"CS_21#B_v_gini\" > \"CS_21#S_v_gini\" '}
    ,'sbgini_d13': {"limits": [[0.818, 1]], "column": '\"DS_13#B_v_gini\"',"condition": '\"DS_13#B_v_gini\" > \"DS_13#S_v_gini\" '}
    ,'sbgini_csum': {"limits": [[0.718, 1]], "column": "round((\"CS_13#B_v_gini\" + \"CS_21#B_v_gini\") /2,3)","condition": '\"CS_13#B_v_gini\" > \"CS_13#S_v_gini\" and \"CS_21#B_v_gini\" > \"CS_21#S_v_gini\" '}
    ,'sbgini_dsum': {"limits": [[0.868, 1]], "column": "round((\"DS_13#B_v_gini\" + \"DS_21#B_v_gini\") /2,3)","condition": '\"DS_13#B_v_gini\" > \"DS_13#S_v_gini\" and \"DS_21#B_v_gini\" > \"DS_21#S_v_gini\" '}
    ,'pgini_b': {"limits": [[0.718, 1]], "column": "pgi_b_5_volume","condition": 'pgi_b_5_volume+1 > pgi_b_13_volume'}
    ,'predict_sb_c13':{"limits":[[-100,1000]],"column":'\"sb#CS_21\"',"condition":'\"sb#CS_13\" <= -2.618 and \"sb#CS_21\" >= 2.618 and \"sb#DS_21\" > 2.618 ' }
    ,'predict_train_y': {"limits": [[-100, 1000]], "column": '\"sb#CS_21\"',"condition": '\"sb#CS_13\" <= -2.618 and \"sb#CS_21\" >= 2.618 and \"sb#DS_21\" > 2.618 and  \"ma#train_y\" > 1'}
}

def getBaseASql(day=4,key_column='next_type',types=['A']):
    types = list(map(lambda x:"'%s'" %(x),types))
    type_str = ','.join(types)
    sql = '''
    select a1.code, a1.date, a1.pctchg, a1.next_chg, a1.pre_chg, a1.zs_next_chg, a1.zs_pre_chg,a2.cnts,a3.total_cnts from
        (select code,date,pctchg,next_chg,pre_chg,zs_next_chg,zs_pre_chg from raw_factor{day}_data
    where {column} in ({type}) order by date desc) a1,
    (select date,count(*) as cnts from raw_factor{day}_data
    where {column} in ({type}) group by date) a2,
     (select date,count(*) as total_cnts from raw_factor{day}_data
      group by date) a3 where a1.date = a2.date and a1.date = a3.date
    '''.format(column=key_column,type=type_str,day=day)
    return sql

def getFactorRawSql(key='yl',lcl=-1000,ucl=1000):
    line = sql_col_condition_mapping[key]
    column = line["column"]
    condition = line["condition"]
    sql = '''
        select a1.code, a1.date, a1.rate,a2.type,a2.type_cnt from (select code,date,{column} as rate from summary_data where
                date(date) > date('2020-11-30') and {condition}
            and rate >= {lcl} and rate <= {ucl}) a1,
    (select '{key}' as type,date,count(*) as type_cnt,{column} as rate from summary_data where
                date(date) > date('2020-11-30')  and {condition}
            and rate >= {lcl} and rate <= {ucl} group by date) a2 where a1.date = a2.date order by a1.date
        '''.format(column=column, lcl=lcl, ucl=ucl,condition=condition,key=key)
    return sql


def getFactorBaseSql(day=4,key_column='next_type',types=['A'],lcl=-1000,ucl=1000,b_name='yl'):
    a_cols =  "a.code, a.date, a.pctchg, a.next_chg, a.pre_chg, a.zs_next_chg, a.zs_pre_chg,a.cnts,a.total_cnts"
    b_cols =  "b.rate,b.type,b.type_cnt"
    sql_a = getBaseASql(day,key_column,types)
    sql_b = getFactorRawSql(b_name,lcl,ucl)
    sql_full_a = "select %s,%s from (%s) a,(%s) b where a.code = b.code and a.date = b.date order by a.date desc" %(a_cols,b_cols,sql_a,sql_b)
    sql_a_cols = "a.code as code, a.date as date, a.pctchg as pctchg, a.next_chg as next_chg" \
                 ", a.pre_chg as pre_chg, a.zs_next_chg as zs_next_chg, a.zs_pre_chg as zs_pre_chg," \
                 "a.cnts as cnts,a.total_cnts as total_cnts,a.rate as rate,a.type as type,a.type_cnt as type_cnt"
    sql_cols_plus="round(type_f_cnts*100/type_cnt,3) as type_f_rate,round(cnts*100/total_cnts,3) as a_total_rate,round(type_f_cnts*100/cnts) as f_a_rate"
    sql_full_b = "select date,count(*) as type_f_cnts from (%s) group by date" %(sql_full_a)
    sql_full = "select %s,b.type_f_cnts,%s from (%s) a,(%s) b where a.date = b.date " %(sql_a_cols,sql_cols_plus,sql_full_a,sql_full_b)
    return sql_full

from tools.DbTool import getConn, insert, query
dest_path = "/Users/lili/data/prod/bs_summary"
db_file = "%s/%s" % (dest_path, 'sumarry_data.db')
def dump(sql):
    conn = getConn(db_file)
    df = query(sql,conn)
    insert(df,conn,"tmp")
def printAvg(idx,line,key):
    conn = getConn(db_file)
    sql = '''
    select avg( type_f_rate), avg(a_total_rate), avg(f_a_rate) from
              (select  type_f_rate, a_total_rate, f_a_rate from tmp
              where next_chg is not null
              group by date)
    '''
    df = query(sql,conn)
    jsonline = df.to_dict(orient="records")
    print("%s %s %s %s" %(key,idx,str(line),jsonline))

if __name__ == '__main__':
    #sql_basea = getBaseASql()
    #yl_sql = getYLSql()
    #yl_lst = [[10,1000]]
    #sbgini_lst = [[0.718,1]]
    keys = list(sql_col_condition_mapping.keys())
    for key in keys:
        limits = sql_col_condition_mapping[key]["limits"]
        for idx,line in enumerate(limits):
            lcl,ucl = line
            yl_base_sql = getFactorBaseSql(day=7,types=['A'],lcl=lcl,ucl=ucl,b_name=key)
            #print(yl_base_sql)
            dump(yl_base_sql)
            printAvg(idx,line,key)
