from tools.DataFactorTools import formatFactorData
from tools.DataPreParing import getValues
from tools.DbTool import getConn,insert,query
from tools.offline.SQL_Tool_Final import sql_col_condition_mapping

dest_path = "/Users/lili/data/prod/bs_summary"
db_file = "%s/%s" % (dest_path, 'sumarry_data.db')
# 10108885
def getDateCodeDF(conn):
    sql = "select code,date from summary_data where date(date) > date('2020-10-23') group by date,code order by date desc"
    df = query(sql,conn)
    return df
yl_sqls = {
    "yl_col":"round((close - \"YL#3#price\")*100/close,3)"
}

def getYlSqlsByKey():
    sqls = {}
    for key,column in yl_sqls.items():
        sql = '''
            select code,date,{column} as rate from summary_data where
            date(date) > date('2020-11-30') and date(date) < date('2022-01-15') and
        "YL#3#price" >= "YL#5#price" and "YL#5#price" >= "YL#13#price" and "YL#13#price" >= "YL#34#price"
        '''.format(column=column)
        sqls[key] = sql
    return sqls

def getPNRaw():
    conn = getConn(db_file)
    df = getDateCodeDF(conn)
    days=[3,5,7]
    for day in days:
        rdf = formatFactorData(df,days=day)
        insert(rdf,conn,"raw_factor%s_data" %(day),opType="append")
        print("%s Done" %(day))
def getWorkDateLst():
    sql = "select distinct date as date from  summary_data where date(date) > date('2020-12-30') "
    conn = getConn(db_file)
    df = query(sql,conn)
    dates = list(df["date"].unique())
    return dates
def getWorkCodeLst():
    dates = getWorkDateLst()
    conn = getConn(db_file)

    for date in dates:
        for key, line in sql_col_condition_mapping.items():
            column = line["column"]
            condition = line["condition"]
            limits = line["limits"]
            lcl, ucl = limits[0]
            sql = '''
            select '{key}' as type,date,code,{column} as rate from summary_data where
                date(date) = date('{indate}') and {condition}
            and rate >= {lcl} and rate <= {ucl}
            '''.format(column=column, lcl=lcl, ucl=ucl,condition=condition,key=key,indate=date)
            df = query(sql,conn)
            insert(df,conn,"analysis_tmp_data",opType="append")
            print("%s %s %s" %(date,key,len(df)))
        print("%s-------Done" %(date))
if __name__ == '__main__':
    getWorkCodeLst()
