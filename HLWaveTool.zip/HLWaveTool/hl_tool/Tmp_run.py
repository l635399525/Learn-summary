from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD,RAW_HLS_WORK_FILE_HIST
def moveRawData():
    sql = '''
    select code, date, open, high, low, close, percent from raw_data_d_xq
    union
    select code, date, open, high, low, close, percent from raw_data_d_xq_hy
    '''
    src_conn = getConn(RAW_HLS_WORK_FILE_HIST_OLD)
    des_conn = getConn(RAW_HLS_WORK_FILE_HIST)
    df = query(sql,src_conn)
    insert(df,des_conn,'raw_data_d_hist')
if __name__ == '__main__':
    moveRawData()