def getDataSplitIdx(afs):
    oidxes = []
    idxes = []
    for i in range(len(afs) - 1):
        c_idx = i
        n_idx = i + 1
        c_v = afs[c_idx]
        n_v = afs[n_idx]
        if c_v == n_v:
            idxes.extend([c_idx, n_idx])
        else:
            if len(idxes) == 0:
                idxes.append(c_idx)
                oidxes.append(list(set(idxes)))
                idxes = []
            else:
                oidxes.append(list(set(idxes)))
                idxes = []
    if len(idxes) > 0:
        oidxes.append(list(set(idxes)))
    if n_idx not in oidxes[-1]:
        oidxes.append([n_idx])
    return oidxes

def _draw_close(close_data,wdate,num=456, c=4):
    import numpy as np
    import cv2
    from sklearn import preprocessing
    fit = preprocessing.MinMaxScaler()
    dates = close_data[:,0]
    closes = close_data[:,1]
    ma10s =close_data[:,2]
    ma60s =close_data[:,3]
    fit.fit(closes.reshape(len(closes),1))
    std_close  = fit.transform(closes.reshape(len(closes),1))[:,0]
    ma10_close = fit.transform(ma10s.values.reshape(len(closes), 1))
    ma60_close = fit.transform(ma60s.values.reshape(len(closes), 1))
    closes_points = np.round((440 - std_close * 405) - 15).astype(int)
    ma10_points = np.round((440 - ma10_close * 405) - 15).astype(int)
    ma60_points = np.round((440 - ma60_close * 405) - 15).astype(int)
    mask = np.zeros((440, 1820, 3), np.uint8) + 200
    x = np.asarray(range(1, num)) * c
    try:
        data = np.vstack([x, closes_points])
    except:
        if len(closes_points) < 455:
            data = np.concatenate([(np.zeros(num-len(closes_points) - 1) + closes_points[0]).astype(int),closes_points])
        data = np.vstack([x, data])

