def getPNPctsSqls(date,start='0 days',end='3 days',pre_start='-4 days',pre_end='0 days',code = None):
    sql_a = "(select code,round(sum(pctchg),2) as chg from summary_data where date(date) > date('%s','%s') " \
            "and date(date) <= date('%s','%s') group by code) a" %(date,start,date,end)
    sql_b = "(select code,pctchg from summary_data where date = '%s') b " %(date)
    sql_c = "(select code,round(sum(pctchg),2) as chg from summary_data where date(date) > date('%s','%s') " \
            "and date(date) <= date('%s','%s') group by code) c " % (date, pre_start, date, pre_end)

    colums = "a.code,a.chg as next_chg,b.pctchg,c.chg as pre_chg " \
             ",case when a.chg > 3 then 'A' when a.chg <=0 then 'C' else 'B' end next_type " \
             ",case when c.chg > 3 then 'A' when c.chg <=0 then 'C' else 'B' end pre_type "
    # if code is None:
    #     sql = "select %s from %s,%s,%s where a.code = c.code and a.code = b.code" %(colums,sql_a,sql_c,sql_b)
    # else:
    #     sql = "select %s from %s,%s,%s where a.code = '%s' and a.code = c.code and a.code = b.code" %(colums,sql_a,sql_c,sql_b,code)
    if code is None:
        sql = "select %s from %s left join %s on b.code = c.code left join %s on b.code = a.code " %(colums,sql_b,sql_c,sql_a)
    else:
        sql = "select %s from %s left join %s on b.code = c.code left join %s on b.code = a.code where a.code = '%s' " %(colums,sql_b,sql_c,sql_a,code)

    return sql
def getSZZSData(date,start='0 days',end='3 days',pre_start='-4 days',pre_end='0 days',code= 'sh.000001'):
    sql_a = "(select code,round(sum(pctchg),2) as chg from ZS_HY_GN_DATA where date(date) > date('%s','%s') " \
            "and date(date) <= date('%s','%s') group by code) a" % (date, start, date, end)
    sql_b = "(select code,pctchg from ZS_HY_GN_DATA where date = '%s') b " % (date)
    sql_c = "(select code,round(sum(pctchg),2) as chg from ZS_HY_GN_DATA where date(date) > date('%s','%s') " \
            "and date(date) <= date('%s','%s') group by code) c " % (date, pre_start, date, pre_end)

    colums = "a.code,a.chg as next_chg,b.pctchg,c.chg as pre_chg " \
             ",case when a.chg > 3 then 'A' when a.chg <=0 then 'C' else 'B' end next_type " \
             ",case when c.chg > 3 then 'A' when c.chg <=0 then 'C' else 'B' end pre_type "

    sql = "select %s from %s,%s,%s where a.code = '%s' and a.code = c.code and a.code = b.code" % (colums, sql_a, sql_c, sql_b,code)
    return sql
def getFactorYLSql(code):
    sql_head = '''
    select code,date,pctchg,close,open,high,low,volume,
       "yl#3#price"  as yl3price,
       "yl#5#price"  as yl5price,
       "YL#13#price" as yl13price,
       "yl#34#price" as yl34price
    '''
    sql_foot = " from summary_data where code = '%s' and date(date) > date('2020-11-30') group by code,date order by code,date" %(code)
    sql = "%s %s" %(sql_head,sql_foot)
    return sql
def getFactorSBGiSql(code):
    sql_head = '''
    select code,date,pctchg,
       "cs_13#b_v_gini"   as cs13bgini,
       "cs_21#b_v_gini"   as cs21bgini,
       "cs_13#s_v_gini"   as cs13sgini,
       "cs_21#s_v_gini"   as cs21sgini,
       "cs_13#all_v_gini" as cs13agini,
       "cs_21#all_v_gini" as cs21agini,
       "ds_13#b_v_gini"   as ds13bgini,
       "ds_13#s_v_gini"   as ds13sgini,
       "ds_13#all_v_gini" as ds13agini,
       "ds_21#b_v_gini"   as ds21bgini,
       "ds_21#s_v_gini"   as ds21sgini,
       "ds_21#all_v_gini" as ds21agini,
       round(("cs_13#b_v_gini" + "cs_21#b_v_gini")/2    ,3) as csbgis,
       round(("cs_13#s_v_gini" + "cs_21#s_v_gini")/2    ,3) as cssgis,
       round(("cs_13#all_v_gini" + "cs_21#all_v_gini")/2,3) as csagis,
       round(("ds_13#b_v_gini" + "ds_21#b_v_gini")/2    ,3) as dsbgis,
       round(("ds_13#s_v_gini" + "ds_21#s_v_gini")/2    ,3) as dssgis,
       round(("ds_13#all_v_gini" + "ds_21#all_v_gini")/2,3) as dsagis
    '''
    sql_foot = " from summary_data where code = '%s' and date(date) > date('2020-11-30') group by code,date order by code,date" %(code)
    sql = "%s %s" %(sql_head,sql_foot)
    return sql
def getFactorPriceGiSql(code):
    sql_head = '''
    select  code,date,pctchg,volume
       pgi_b_5_volume,
       pgi_b_13_volume,
       pgi_b_34_volume,
       pgi_s_5_volume,
       pgi_s_13_volume,
       pgi_s_34_volume,
       pgi_a_5_volume,
       pgi_a_13_volume,
       pgi_a_34_volume,
       round((pgi_b_5_volume+pgi_b_13_volume+pgi_b_34_volume)/3,2) as pbgis,
       round((pgi_s_5_volume+pgi_s_13_volume+pgi_s_34_volume)/3,2) as psgis,
       round((pgi_a_5_volume+pgi_a_13_volume+pgi_a_34_volume)/3,2) as pagis
    '''
    sql_foot = " from summary_data where code = '%s' and date(date) > date('2020-11-30') group by code,date order by code,date" %(code)
    sql = "%s %s" %(sql_head,sql_foot)
    return sql
def getFactorMAInfoSql(code):
    sql_head = '''
    select   code, date,pctchg,volume,open, close,  high, low,raw_hl, 
       ma13, ma144, ma21, ma5, ma55, ma89,
       ma_sort_3, ma_sort_all, 
       candle_code, candle_id
    '''
    sql_foot = " from summary_data where code = '%s' and date(date) > date('2020-11-30') group by code,date order by code,date" %(code)
    sql = "%s %s" %(sql_head,sql_foot)
    return sql
def getFactorMAModelSql(code):
    sql_head = '''
    select   code, date,volume,
       "ma#train_y" as predict_pct,pctchg, round(("ma#train_y" - pctchg)*100/pctchg,2) as predict_pct_rate,
       "ma#train_c" as predict_c  ,close,  round(("ma#train_c" - close )*100/close ,2) as predict_c_rate,
       "ma#train_h" as predict_h  ,high,   round(("ma#train_h" - high  )*100/high  ,2) as predict_h_rate,
       "ma#train_l" as predict_l  ,low,    round(("ma#train_l" - low   )*100/low   ,2) as predict_l_rate,
       "ma#train_hl"as predict_hl ,raw_hl, round(("ma#train_hl"- raw_hl)*100/raw_hl,2) as predict_hl_rate
    '''
    sql_foot = " from summary_data where code = '%s' and date(date) > date('2020-11-30') group by code,date order by code,date" %(code)
    sql = "%s %s" %(sql_head,sql_foot)
    return sql
def getFactorSBModelSql(code):
    sql_head = '''
    select   code, date,volume,pctchg,
       "sb#CS_13" as sbcs13,
       "sb#CS_21" as sbcs21,
       "sb#DS_13" as sbds13,
       "sb#DS_21" as sbds21,
        round(("sb#DS_13"+"sb#DS_21")/2,2) as sbdss,
        round(("sb#CS_13"+"sb#CS_21")/2,2) as sbcss
    '''
    sql_foot = " from summary_data where code = '%s' and date(date) > date('2020-11-30') group by code,date order by code,date" %(code)
    sql = "%s %s" %(sql_head,sql_foot)
    return sql
def getFactorSQLByType(code,type):
    '''
    "YL"
    ,"SBGI"
    ,"PRICEGI"
    ,"MAINFO"
    ,"MAMODEL"
    ,"SBMODEL"
    :param code:
    :param type:
    :return:
    '''
    if type == 'YL':
        sql = getFactorYLSql(code)
    elif type == 'SBGI':
        sql = getFactorSBGiSql(code)
    elif type == 'PRICEGI':
        sql = getFactorPriceGiSql(code)
    elif type == 'MAINFO':
        sql = getFactorMAInfoSql(code)
    elif type == 'MAMODEL':
        sql = getFactorMAModelSql(code)
    elif type == 'SBMODEL':
        sql = getFactorSBModelSql(code)
    return sql
if __name__ == '__main__':
    sql = getSZZSData("2020-12-17")
    sql = getFactorSBGiSql("sz.000725")
    print(sql)