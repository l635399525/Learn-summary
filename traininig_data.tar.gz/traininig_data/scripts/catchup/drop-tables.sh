#!/bin/bash
mysql -u root -ptraining < drop-tables.sql
