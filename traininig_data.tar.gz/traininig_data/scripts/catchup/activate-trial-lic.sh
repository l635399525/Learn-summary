#!/bin/bash

curl -X POST -H "Content-Type:application/json" -u admin:admin http://cmhost:7180/api/v10/cm/trial/begin


