mysql -u root
