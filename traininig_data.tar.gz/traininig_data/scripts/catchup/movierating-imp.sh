#!/bin/bash
impala-shell