#!/bin/bash
beeline -u jdbc:hive2://elephant:10000/default -n training