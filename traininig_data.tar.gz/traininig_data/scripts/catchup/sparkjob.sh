#!/bin/bash
spark-shell --master yarn-client 