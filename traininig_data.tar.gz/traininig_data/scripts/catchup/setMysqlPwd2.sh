mysqladmin -u root -p password ''



