#!/bin/bash
mysql -u root -ptraining
