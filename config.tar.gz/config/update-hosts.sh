#!/bin/bash
echo
echo "Starting running update-hosts.sh at $(date '+%Y-%m-%d %T')"

scpNoCheck="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=error -i /home/training/.ssh/admincourse.pem"
nocheck="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=error -i /home/training/.ssh/admincourse.pem"

#if alreadyRun returns empty, then we assume this is the first time this script has been run (because worker-2 is not named worker-2 until this script has already run once)
alreadyRun=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE NAME='worker-1.example.com';" 2>&1 | grep -v "Warning: Using a password")
echo "alreadyRun="$alreadyRun
echo "if alreadyRun returns empty, then we assume this is the first time this script has been run"
region=$(curl instance-data/latest/dynamic/instance-identity/document/ | grep region | cut -d '"' -f4)

cleanup_and_log() {
	#remove log from old run
	rm -f update-hosts.log

	#capture stout and sterr to log files
	exec > >(tee -ia update-hosts.log)
	echo 
	echo "Started logging update-hosts.sh at $(date '+%Y-%m-%d %T')"
}

check_pending(){
	#check if last command completed before trying to start the cluster
	pending=$(curl -s -X GET -u "admin:admin" -i http://localhost:7180/api/v8/clusters/$clusterName/commands | grep active | grep true)
	echo "pending="$pending
	
	while [[ $pending != "" ]];
		do
			sleep 10
			pending=$(curl -s -X GET -u "admin:admin" -i http://localhost:7180/api/v8/clusters/$clusterName/commands | grep active | grep true)
	done
}

#Always runs
check_worker3_status(){
	#echo "$(date '+%T'): Invoking function ${FUNCNAME[0]}"
	
	if [ -e /home/training/.worker3 ]; then
		w3stat=$(nmap $(cat .worker3 | sed -n 2p) | grep '22/tcp')
		if [[ "$w3stat" != "" ]]; then
			w3Created="true"
		else
			#if it was created, it is not running or responding
			w3Created="false"
		fi
	else
		w3Created="false"
	fi
	echo "w3Created="$w3Created

	checkw3inCM=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE NAME='worker-3.example.com';"  2>&1 | grep -v "Warning: Using a password")
	if [[ "$checkw3inCM" != "" ]]; then 
		w3InCM="true"
	else
		w3InCM="false"
	fi
	echo "w3InCM="$w3InCM
}

#Always runs
verify_cmserver(){
	#echo "$(date '+%T'): Invoking function ${FUNCNAME[0]}"

	#start cm server if it is not already running
	echo
	echo "1. Verifying CM Server is running..."
	#verifyRunning=$(sudo service cloudera-scm-server status | grep 'is running')
	verifyRunning=$(sudo systemctl status cloudera-scm-server | grep 'active (exited)')
	if [[ "$verifyRunning" == "" ]]; then
		echo
		echo "CM server is not started yet. Starting it now..."
		#sudo service cloudera-scm-server start
		sudo systemctl start cloudera-scm-server
		echo "Waiting 60 seconds for it to finish starting..."
		count=0
		while [ $count -lt 60 ];
		do
			count=$(( $count + 1))
			printf "."
			sleep 1
		done
		#verifyRunning=$(sudo service cloudera-scm-server status | grep 'is running')
		verifyRunning=$(sudo systemctl status cloudera-scm-server | grep 'active (exited)')
		if [[ "$verifyRunning" == "" ]]; then
			echo "CM Server has still not start. Restarting it now..."
			#sudo service cloudera-scm-server restart
			sudo systemctl restart cloudera-scm-server
			echo "Waiting 60 seconds for it to finish starting..."
			#sleep 60 seconds
			count=0
			while [ $count -lt 60 ];
			do
				count=$(( $count + 1))
				printf "."
				sleep 1
			done
		fi
	else
		echo "Verified."
	fi
}

#only runs the first time, and only if a /home/training/.worker3 file is not found on cmhost
launch_worker3(){
	#echo "$(date '+%T'): Invoking function ${FUNCNAME[0]}"
	if [[ "$w3Created" == "false" ]]; then
		amiId=$(sudo cat /usr/lib64/cloudera-director/client/adminbootstrap.conf | grep 'worker3 ami-' | grep $region | awk '{print $4}' )
		echo "amiId="$amiId
		sg=$(sudo cat /usr/lib64/cloudera-director/client/adminbootstrap.conf | grep securityGroupsIds | grep -v '^\s*\#' | awk '{print $2}')
		echo "sg="$sg
		sId=$(sudo cat /usr/lib64/cloudera-director/client/adminbootstrap.conf | grep subnetId | grep -v '^\s*\#'  | awk '{print $2}')
		echo "sId="$sId
		echo
		echo "2. Creating worker-3 instance..."
		w3Instance=$(aws ec2 run-instances --image-id $amiId --subnet-id $sId --security-group-ids $sg --count 1 --instance-type t2.large --region $region --output json)
		echo "w3Instance="$w3Instance
		w3instanceId=$(echo $w3Instance | grep -o '"InstanceId": "[^"]*' | grep -o '[^"]*$' | head -1)
		rm -f .worker3
		echo $ginstanceId > .worker3
		w3privIP=$(echo $w3Instance | grep -o '"PrivateIpAddress": "[^"]*' | grep -o '[^"]*$' | head -1)	
		echo "worker-3 private IP: "$w3privIP
		echo $w3privIP >> .worker3
		w3privDns=$(echo $w3Instance | grep -o '"PrivateDnsName": "[^"]*' | grep -o '[^"]*$' | head -1)	
		echo "worker-3 private DNS: "$w3privDns
		echo $w3privDns >> .worker3
		sleep 4

		#get the cmhost name tag value and use it in the worker-3 instance name
		cmhostName=$(aws ec2 describe-instances --instance-ids $(curl instance-data/latest/dynamic/instance-identity/document/ | grep instanceId | cut -d '"' -f4)  --region $region --output text | grep 'TAGS' | awk '{print $3}')
		#cmhostInstId=$(curl instance-data/latest/dynamic/instance-identity/document/ | grep instanceId | cut -d '"' -f4)
		aws ec2 create-tags --resources $w3instanceId --tags Key=Name,Value=$cmhostName-worker3  --region $region --output json
		
		w3Created="true" #there is now a worker-3
		w3InCM="false" #but it is not yet part of the cluster
	fi
}

#only runs the first time
get_deployment_json(){
	#echo "$(date '+%T'): Invoking function ${FUNCNAME[0]}"

	#write cluster json to file
	clusterName=$(curl -s -X GET -u "admin:admin"  -H "Content-Type:application/json" -i 'http://localhost:7180/api/v12/clusters/' | grep '"name"' | awk '{print $3}' | cut -d '"' -f2)
	verifyOneCluster=$(echo $clusterName | wc -l )
	if [[ "$verifyOneCluster" != "1" ]]; then
		echo
		echo "ERROR: It appears that you either have a space in the name of your cluster, OR you have more than one cluster. Please fix this using the Cloudera Manager web UI, then re-run this script. Exiting."
		exit 1
	fi
	echo 
	echo "clusterName="$clusterName
	if [ -e cluster.json ]; then
		mv cluster.json /tmp/
	fi
	curl -s -X GET -u "admin:admin"  -H "Content-Type:application/json" -i "http://localhost:7180/api/v12/clusters/$clusterName/export" > cluster.json
}

#only runs the first time
config_hosts_files(){
	#echo "$(date '+%T'): Invoking function ${FUNCNAME[0]}"

	echo
	echo "3. Configuring hosts files..."

	#parse master IP addresses and private DNSs out of cluster.json 
	m1privIp=$(cat /home/training/cluster.json |grep -B3 '\-NAMENODE-BASE' | grep from-ip- | cut -d '-' -f5- | cut -d '.' -f1 | sed s/-/./g)
	m1dns=$(cat /home/training/cluster.json |grep -B3 '\-NAMENODE-BASE' | grep from-ip- | cut -d '-' -f4- | cut -d '"' -f1)
	echo "m1ip="$m1privIp
	echo "m1dns="$m1dns
	if [[ "$m1privIp" == "" ]] || [[ "$m1dns" == "" ]]; then
		echo "error, master-1 details not found, exiting."
		exit 1
	fi

	m2privIp=$(cat /home/training/cluster.json |grep -B3 '\-HIVESERVER2-BASE' | grep from-ip- | cut -d '-' -f5- | cut -d '.' -f1 | sed s/-/./g)
	m2dns=$(cat /home/training/cluster.json |grep -B3 '\-HIVESERVER2-BASE' | grep from-ip- | cut -d '-' -f4- | cut -d '"' -f1)
	echo "m2ip="$m2privIp
	echo "m2dns="$m2dns
	if [[ "$m2privIp" == "" ]] || [[ "$m2dns" == "" ]]; then
		echo "error, master-2 details not found, exiting."
		exit 1
	fi

	#gprivIp=$(cat /home/training/cluster.json |grep -B3 '\-GATEWAY-BASE' | grep from-ip- | cut -d '-' -f5- | cut -d '.' -f1 | sed s/-/./g)
	#gdns=$(cat /home/training/cluster.json |grep -B3 '\-GATEWAY-BASE' | grep from-ip- | cut -d '-' -f4- | cut -d '"' -f1)
	#echo "gip="$gprivIp
	#echo "gdns="$gdns
	#if [[ "$gprivIp" == "" ]] || [[ "$gdns" == "" ]]; then
#		echo "error, gateway details not found, exiting."
	#	exit 1
	#fi

	#parse worker IP addresses and private DNS addresses out of MySQL
	allWorkerHostIds=$(mysql -N -uroot -ptraining -e "SELECT HOST_ID FROM cmserver.ROLES WHERE ROLE_TYPE='DATANODE';" 2>&1 | grep -v "Warning: Using a password")
	w1Id=$(echo $allWorkerHostIds | awk '{print $1}')
	w2Id=$(echo $allWorkerHostIds | awk '{print $2}')
	#gId=$(echo $allWorkerHostIds | awk '{print $3}')
	w1privIp=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE HOST_ID=\"$w1Id\";" 2>&1 | grep -v "Warning: Using a password")
	w1dns=$(mysql -N -uroot -ptraining -e "SELECT NAME FROM cmserver.HOSTS WHERE HOST_ID=\"$w1Id\";" 2>&1 | grep -v "Warning: Using a password")
	w2privIp=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE HOST_ID=\"$w2Id\";" 2>&1 | grep -v "Warning: Using a password")
	w2dns=$(mysql -N -uroot -ptraining -e "SELECT NAME FROM cmserver.HOSTS WHERE HOST_ID=\"$w2Id\";" 2>&1 | grep -v "Warning: Using a password")
	#gprivIp=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE HOST_ID=\"$gId\";" 2>&1 | grep -v "Warning: Using a password")
	#gdns=$(mysql -N -uroot -ptraining -e "SELECT NAME FROM cmserver.HOSTS WHERE HOST_ID=\"$gId\";" 2>&1 | grep -v "Warning: Using a password")

	#if this script is being run after the hostnames were already set to friendly names, find the private IPs differently
	if [[ "$w1privIp" == "" ]]; then
		w1privIp=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE NAME='worker-1';" 2>&1 | grep -v "Warning: Using a password")
		echo "w1privIp="$w1privIp
	fi
	
	if [[ "$w2privIp" == "" ]]; then
		w2privIp=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE NAME='worker-2';" 2>&1 | grep -v "Warning: Using a password")
		echo "w2privIp="$w2privIp
	fi

	#if [[ "$gprivIp" == "" ]]; then
	#	gprivIp=$(mysql -N -uroot -ptraining -e "SELECT IP_ADDRESS FROM cmserver.HOSTS WHERE NAME='gateway';" 2>&1 | grep -v "Warning: Using a password")
	#	echo "gprivIp="$gprivIp
	#fi

	if [ -e /home/training/.admin-hosts ]; then
		mv /home/training/.admin-hosts /tmp/
	fi

	echo $m1privIp" master-1.example.com master-1" > .admin-hosts
	echo $m2privIp" master-2.example.com master-2" >> .admin-hosts
	echo $w1privIp" worker-1.example.com worker-1" >> .admin-hosts
	echo $w2privIp" worker-2.example.com worker-2" >> .admin-hosts
	#echo $gprivIp" gateway.example.com gateway" >> .admin-hosts

	if [[ "$w3Created" == "true" ]]; then
		w3privIP=$(cat /home/training/.worker3| sed -n 2p)
		w3dns=$(cat /home/training/.worker3 | sed -n 3p)
		echo $w3privIP" worker-3.example.com worker-3" >> .admin-hosts
	fi
	echo
	echo "This is the contents of .admin-hosts:"
	echo "-------------------------------------"
	cat .admin-hosts
	echo "-------------------------------------"

	check1=$(cat .admin-hosts |grep master-1|wc -w)
	check2=$(cat .admin-hosts |grep master-2|wc -w)
	check3=$(cat .admin-hosts |grep worker-1|wc -w)
	check4=$(cat .admin-hosts |grep worker-2|wc -w)
	#check5=$(cat .admin-hosts |grep gateway|wc -w)
	if [[ "$check1" != "3" ]] || [[ "$check2" != "3" ]] || [[ "$check3" != "3" ]] || [[ "$check4" != "3" ]]; then
		echo "The ~/.admin-hosts file is missing something. Exiting."
		exit 1
	fi

	#clean up /etc/hosts
	cat /etc/hosts | grep -v master | grep -v worker > newcmhosts
	#now put the latest IPs in /etc/hosts
	cat .admin-hosts >> newcmhosts
	sudo mv newcmhosts /etc/hosts
	#CMHOST NOW HAS A FULLY READY HOSTS FILE
	
	echo
	echo "4. Copying hosts to all cluster machines" 
	scp $scpNoCheck /etc/hosts root@$m1privIp:/etc/
	scp $scpNoCheck /etc/hosts root@$m2privIp:/etc/
	scp $scpNoCheck /etc/hosts root@$w1privIp:/etc/
	scp $scpNoCheck /etc/hosts root@$w2privIp:/etc/
	#scp $scpNoCheck /etc/hosts root@$gprivIp:/etc/

	if [[ "$w3Created" == "true" ]]; then
		check=$(cat .admin-hosts |grep worker-3|wc -w)
	
		#if [[ "$check" != "3" ]]; then 
		if [[ "$check" != "3" ]]; then 
			echo "The admin-hosts file does not have a correct worker-3 entry, please fix this. Exiting."
			exit 1
		fi

		#verify worker-3 is running before continuing on
		cvResp=0
		ccount=0
		echo
		echo "5. Verifying the worker-3 instance passed all status checks (this may take 3 to 5 minutes)..."
	  	while [ $cvResp -eq 0 ] 
	  	do 
			ccurrentStatus=$(aws ec2 describe-instance-status --instance-ids $w3instanceId  --region $region --output json | grep -o '"Status": "[^"]*' | grep -o '[^"]*$')
			#echo $ccurrentStatus
			c13=$(echo $ccurrentStatus | awk '{print $1}')
			c14=$(echo $ccurrentStatus | awk '{print $2}')
			
			if [[ "$c13" == "ok" ]] && [[ "$c14" == "passed" ]]; then 
					echo "The worker-3 instance is now responsive, moving on..."
					cvResp=1
			else
				# sleep 15 seconds
				ccount=0
				while [ $ccount -lt 15 ];
				do
					ccount=$(( $ccount + 1 ))
					printf "."
					sleep 1
				done
			fi
		done

		echo "Copying hosts to worker-3"
		scp $scpNoCheck /etc/hosts root@$w3privIP:/etc/
		echo "Setting hostname to worker-3"
		ssh $nocheck training@worker-3 sudo hostnamectl set-hostname worker-3
	fi
}

#only runs the first time
change_hostnames_in_db(){
	#echo "$(date '+%T'): Invoking function ${FUNCNAME[0]}"

	clusterName=$(curl -s -X GET -u "admin:admin" -i http://localhost:7180/api/v8/clusters/ | grep name| cut -d '"' -f4)
	verifyOneCluster=$(echo $clusterName | wc -l )
	if [[ "$verifyOneCluster" != "1" ]]; then
		echo
		echo "ERROR: It appears that you either have a space in the name of your cluster, OR you have more than one cluster. Please fix this using the Cloudera Manager web UI, then re-run this script. Exiting."
		exit 1
	fi

	echo
	echo "7. Stopping the cluster..."
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v8/clusters/$clusterName/commands/stop
	echo
	echo
	echo "8. Stopping the CM Management Services"
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/cm/service/commands/stop
	echo
	echo
	echo "9. Stopping CM server and all CM agents..."
	sudo systemctl stop cloudera-scm-server
	sudo systemctl stop cloudera-scm-agent

	######NOTHING ACTUALLY SETS w3Exists
	for i in master-1 master-2 worker-1 worker-2 ; do ssh $nocheck -t training@$i sudo systemctl stop cloudera-scm-agent  ; done 
	if [[ "$w3Exists" == "true" ]]; then
		ssh $nocheck training@worker-3 sudo systemctl stop cloudera-scm-agent
	fi

	echo
	echo "10. Updating OS hostnames."
	#for i in master-1.example.com master-2.example.com worker-1.example.com worker-2.example.com gateway.example.com ; do ssh $nocheck training@$i sudo hostnamectl set-hostname $i ; done 
	#if [[ "$w3Exists" == "true" ]]; then
	#	ssh $nocheck training@worker-3 sudo hostnamectl set-hostname worker-3.example.com
	#fi
	for i in master-1 master-2 worker-1 worker-2 ; do ssh $nocheck training@$i sudo hostnamectl set-hostname $i ; done 
	if [[ "$w3Exists" == "true" ]]; then
		ssh $nocheck training@worker-3 sudo hostnamectl set-hostname worker-3
	fi

	#change how the agent addresses cmhost
	for i in master-1 master-2 worker-1 worker-2 ; do ssh $nocheck -t training@$i sudo sed -i 's/.*server_host.*/server_host=cmhost/' /etc/cloudera-scm-agent/config.ini ; done
	if [[ "$w3Exists" == "true" ]]; then
		ssh $nocheck -t training@worker-3 sudo sed -i 's/.*server_host.*/server_host=cmhost/' /etc/cloudera-scm-agent/config.ini
	fi

	count=0
	while [ $count -lt 15 ];
	do
		count=$(( $count + 1))
		printf "."
		sleep 1
	done

	echo
	echo
	echo "11. Updating MySQL HOSTS table entries."
	mysql -uroot -ptraining -e "UPDATE cmserver.HOSTS SET NAME='master-1.example.com' WHERE IP_ADDRESS='$m1privIp';" 2>&1 | grep -v "Warning: Using a password"
	mysql -uroot -ptraining -e "UPDATE cmserver.HOSTS SET NAME='master-2.example.com' WHERE IP_ADDRESS='$m2privIp';" 2>&1 | grep -v "Warning: Using a password"
	mysql -uroot -ptraining -e "UPDATE cmserver.HOSTS SET NAME='worker-1.example.com' WHERE IP_ADDRESS='$w1privIp';" 2>&1 | grep -v "Warning: Using a password"
	mysql -uroot -ptraining -e "UPDATE cmserver.HOSTS SET NAME='worker-2.example.com' WHERE IP_ADDRESS='$w2privIp';" 2>&1 | grep -v "Warning: Using a password"
	#mysql -uroot -ptraining -e "UPDATE cmserver.HOSTS SET NAME='gateway.example.com' WHERE IP_ADDRESS='$gprivIp';" 2>&1 | grep -v "Warning: Using a password"
	if [[ "$w3Exists" == "true" ]] && [[ "$w3InCM" == "false" ]]; then
		mysql -uroot -ptraining -e "UPDATE cmserver.HOSTS SET NAME='worker-3.example.com' WHERE IP_ADDRESS='$w3privIP';" 2>&1 | grep -v "Warning: Using a password"
	fi

	echo
	echo "Confirming change in HOSTS table:"
	echo $(mysql -uroot -ptraining -e "SELECT NAME, IP_ADDRESS FROM cmserver.HOSTS;")
	echo
	echo "12. Capturing instance IDs..."

	#collect instance IDs
	m1instanceId=$(ssh $nocheck training@master-1 curl instance-data/latest/meta-data/instance-id/)
	m2instanceId=$(ssh $nocheck training@master-2 curl instance-data/latest/meta-data/instance-id/)
	w1instanceId=$(ssh $nocheck training@worker-1 curl instance-data/latest/meta-data/instance-id/)
	w2instanceId=$(ssh $nocheck training@worker-2 curl instance-data/latest/meta-data/instance-id/)
	#ginstanceId=$(ssh $nocheck training@gateway curl instance-data/latest/meta-data/instance-id/)
	echo "m1 "$m1instanceId > .instance-ids
	echo "m2 "$m2instanceId >> .instance-ids
	echo "w1 "$w1instanceId >> .instance-ids
	echo "w2 "$w2instanceId >> .instance-ids
	#echo "g "$ginstanceId >> .instance-ids
}



#Always runs
start_clean(){
	#echo "$(date '+%T'): Invoking function ${FUNCNAME[0]}"

	if [[ "$alreadyRun" == "" ]]; then
		echo 
		echo "Starting CM Server..."
		#sudo service cloudera-scm-server start
		sudo systemctl restart cloudera-scm-server

		echo
		echo "Waiting 60 seconds for machines to come back up and for cm server to fully start..."
		#sleep 60 seconds
		count=0
		while [ $count -lt 60 ];
		do
			count=$(( $count + 1))
			printf "."
			sleep 1
		done
	fi

	checkHosts=$(cat /etc/hosts | grep master-1 )
	if [[ "$checkHosts" == "" ]]; then
		sudo cat .admin-hosts >> /etc/hosts
	fi

	echo
	echo "Restarting CM agents on all nodes."
	#sudo service cloudera-scm-agent restart
	sudo systemctl restart cloudera-scm-agent
	for i in master-1 master-2 worker-1 worker-2 ; do ssh $nocheck -t training@$i sudo systemctl restart cloudera-scm-agent  ; done 
	if [[ "$w3Exists" == "true" ]]; then
		ssh $nocheck training@worker-3 sudo systemctl restart cloudera-scm-agent
	fi

	echo
	echo "Waiting 30 seconds for cm agents to finish starting."
	count=0
	while [ $count -lt 30 ];
	do
		count=$(( $count + 1))
		printf "."
		sleep 1
	done

	echo
	echo "Starting the CM Management Services."
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/cm/service/commands/restart

	
	echo
	echo "Waiting for CM Management Services to finish starting."
	check_pending

	#echo 
	#echo "Redeploying client configs."
	#curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/commands/deployClientConfig
	
	#echo
	#echo "Waiting for client config redeployment to complete..."
	#check_pending

	#echo "Starting the cluster up again."
	#clusterName=$(curl -s -X GET -u "admin:admin" -i http://localhost:7180/api/v8/clusters/ | grep name| cut -d '"' -f4)

	#THIS STILL FAILS
	#sleep 10
	#curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v8/clusters/$clusterName/commands/start

	#echo
	#echo "Waiting for cluster start to complete..."
	#check_pending
}

restart_services(){
	clusterName=$(curl -s -X GET -u "admin:admin" -i http://localhost:7180/api/v8/clusters/ | grep name| cut -d '"' -f4)
	curlURL="-s -X GET -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/"

	hdfsServiceName=$(curl $curlURL | grep CD-HDFS | grep name | cut -d '"' -f4 )
	hiveServiceName=$(curl  $curlURL | grep CD-HIVE | grep name | cut -d '"' -f4 )
	hueServiceName=$(curl  $curlURL | grep CD-HUE | grep name | cut -d '"' -f4 )
	impalaServiceName=$(curl $curlURL | grep CD-IMPALA | grep name | cut -d '"' -f4 )
	oozieServiceName=$(curl $curlURL | grep CD-OOZIE | grep name | cut -d '"' -f4 )
	yarnServiceName=$(curl $curlURL | grep CD-YARN | grep name | cut -d '"' -f4 )
	soyarnServiceName=$(curl $curlURL | grep CD-SPARK_ON_YARN | grep name | cut -d '"' -f4 )
	zkServiceName=$(curl $curlURL | grep CD-ZOOKEEPER | grep name | cut -d '"' -f4 )
	
	echo
	echo "Verifying no other CM commands are running..."
	check_pending

	echo
	echo "Restarting services..."
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$zkServiceName/commands/restart
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$hdfsServiceName/commands/restart
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$yarnServiceName/commands/restart
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$soyarnServiceName/commands/restart
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$hiveServiceName/commands/restart
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$impalaServiceName/commands/restart
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$oozieServiceName/commands/restart
	curl -s -X POST -u "admin:admin" -i http://localhost:7180/api/v10/clusters/$clusterName/services/$hueServiceName/commands/restart
	echo
	echo "Deploying client configs..."
	#calling this on Hive will redeploy the configs for all the other services as well
	curl -s -X POST -u "admin:admin" -H "Content-Type:application/json" -i http://cmhost:7180/api/v18/clusters/$clusterName/commands/deployClientConfig/ -d "{\"items\":[\"$hiveServiceName\"]}"
}

cleanup_and_log
check_worker3_status
verify_cmserver
if [[ "$alreadyRun" == "" ]]; then
	launch_worker3
	get_deployment_json
	config_hosts_files
	change_hostnames_in_db
fi
start_clean
if [[ "$alreadyRun" == "" ]]; then
	restart_services
fi

echo
echo "Finished running update-hosts.sh at $(date '+%Y-%m-%d %T')"
