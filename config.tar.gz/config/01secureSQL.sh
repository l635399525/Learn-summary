#!/bin/bash

sudo /usr/bin/mysql_secure_installation
