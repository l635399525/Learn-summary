#!/bin/bash

#fix private ip entry in hosts
cmPrivIP=$(ip addr | grep eth0 | grep inet | awk '{print $2}' | cut -d '/' -f1)
sudo sed -i '/cmhost/d' /etc/hosts
echo $cmPrivIP" cmhost.example.com cmhost" | sudo tee -a /etc/hosts

#restart services

#restart the CM mgmt services
apiAvail=0
count=0
while [ $apiAvail -eq 0 ] 
    do
        checkIfUp=$(curl -s -X GET -H "Content-Type:application/json" -u admin:admin http://cmhost:7180/api/v10/clusters | grep items)

        if [[ "$checkIfUp" != "" ]]; then
            apiAvail=1
        else
            echo "CM API not yet available, checking again in 5 seconds..."
            sleep 5
            count=$(( $count + 1 ))
            if [[ "$count" == "8" ]]; then
                echo "Cloudera Manager is not responding. Attempting to restart the CM server and CM agent on cmhost."
                sudo systemctl restart cloudera-scm-server
                sudo systemctl restart cloudera-scm-agent
                echo "Pausing 60 seconds. Please wait."
                sleep 60
                checkIfUp=$(curl -s -X GET -H "Content-Type:application/json" -u admin:admin http://cmhost:7180/api/v10/clusters | grep items)
                if [[ "$checkIfUp" != "" ]]; then
                    echo "CM Server is now responsive."
                fi
            fi
            if [[ "$count" == "12" ]]; then
                echo "Cloudera Manager is still not responding. Please consult next steps with your instructor."
                echo "Exiting."
                exit 1
            fi
        fi
    done
echo 
echo "Done."

