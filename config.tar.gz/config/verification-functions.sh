#!/bin/bash

# Bash functions for verifying expected aspects of a newly-created
# CentOS-based virtual machines used in training class; for example, 
# to ensure that we have a given amount of RAM or free disk space, 
# that certain packages are installed, that certain commands are in
# the path, and so on).  This is meant to be sourced into another 
# shell script that calls these functions with arguments that check 
# whatever is appropriate for that VM.


NUM_TESTS=0
NUM_ERRORS=0

verify_xml_config() {
	# NOTE: shell metacharacters must be escaped, so if you want to search for
	# a value of *, you need to pass '*' as $3
	
	XML_PATH=$1
	ELEM_NAME=$2
	EXPECTED_VALUE=$3
	
	if [ -z "$XML_PATH" ] || [ -z "$ELEM_NAME" ] || [ -z "$EXPECTED_VALUE" ]; then
		echo '### FATAL: verify_xml_config invoked incorrectly ###'
		exit 999
	fi
	
	FUNCTIONS_BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
	PYTHON_CMD="python $FUNCTIONS_BASE_DIR/hadoop-config-parser.py"

	$PYTHON_CMD "$XML_PATH" "$ELEM_NAME" "$EXPECTED_VALUE" >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "Validation of element '$ELEM_NAME' in '$XML_PATH' failed"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_listen_on_tcp_port() {
	TCP_PORT=$1

	if [ -z "$TCP_PORT" ]; then
		echo '### FATAL: verify_listen_on_tcp_port invoked incorrectly ###'
		exit 999
	fi

	netstat -tnl | perl -ne 'print /^\S+\s+\d+\s+\d+\s+(\S+)\s.*$/,"\n"' | grep ":${TCP_PORT}$" >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "VM is NOT listening on TCP port '$TCP_PORT'"
	fi
	
	NUM_TESTS=$((NUM_TESTS+1))
}

verify_process_running() {
	PROC_NAME=$1
	
	if [ -z "$PROC_NAME" ]; then
		echo '### FATAL: verify_process_running invoked incorrectly ###'
		exit 999
	fi

	pgrep "$PROC_NAME" >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "Process '$PROC_NAME' IS NOT running"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_process_not_running() {
	NPROC_NAME=$1
	
	if [ -z "$NPROC_NAME" ]; then
		echo '### FATAL: verify_process_not_running invoked incorrectly ###'
		exit 999
	fi	

	pgrep "$NPROC_NAME" >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		log_error "Process '$NPROC_NAME' IS running"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_service_running() {
	SVC_NAME=$1
	
	if [ -z "$SVC_NAME" ]; then
		echo '### FATAL: verify_service_running invoked incorrectly ###'
		exit 999
	fi

	/sbin/service "$SVC_NAME" status 2> /dev/null | egrep '^running$|is running' > /dev/null
	if [ $? -ne 0 ]; then
		log_error "Service '$SVC_NAME' IS NOT running"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_service_not_running() {
	NSVC_NAME=$1

	if [ -z "$NSVC_NAME" ]; then
		echo '### FATAL: verify_service_not_running invoked incorrectly ###'
		exit 999
	fi

	/sbin/service "$NSVC_NAME" status 2> /dev/null | egrep '^running$|is running' > /dev/null
	if [ $? -eq 0 ]; then
		log_error "Service '$NSVC_NAME' IS running"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_package_installed() {
	PKG_NAME=$1

	if [ -z "$PKG_NAME" ]; then
		echo '### FATAL: verify_package_installed invoked incorrectly ###'
		exit 999
	fi
	
	rpm -qi "$PKG_NAME" >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "Package '$PKG_NAME' IS NOT installed"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_package_not_installed() {
	NPKG_NAME=$1
	
	if [ -z "$NPKG_NAME" ]; then
		echo '### FATAL: verify_package_not_installed invoked incorrectly ###'
		exit 999
	fi

	rpm -qi "$NPKG_NAME" >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		log_error "Package '$NPKG_NAME' IS installed"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_command_in_path() {
	# NOTE: The test may fail if bash was not invoked as a login 
	# shell (bash -l), since it otherwise might not read the 
	# /etc/profile like the shell the actual user starts would
	CMD_NAME=$1
	
	if [ -z "$CMD_NAME" ]; then
		echo '### FATAL: verify_command_in_path invoked incorrectly ###'
		exit 999
	fi

	which "$CMD_NAME" >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "No command '$CMD_NAME' in PATH"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_file_exists() {
	FILE_NAME=$1
	
	if [ -z "$FILE_NAME" ]; then
		echo '### FATAL: verify_file_exists invoked incorrectly ###'
		exit 999
	fi

	if [ ! -f "$FILE_NAME" ]; then
		log_error "File '$FILE_NAME' was expected but does not exist"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_dir_exists() {
	DIR_NAME=$1
	
	if [ -z "$DIR_NAME" ]; then
		echo '### FATAL: verify_dir_exists invoked incorrectly ###'
		exit 999
	fi

	if [ ! -d "$DIR_NAME" ]; then
		log_error "Directory '$DIR_NAME' was expected but does not exist"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_hdfs_path_exists() {
	OBJ_PATH=$1
	
	if [ -z "$OBJ_PATH" ]; then
		echo '### FATAL: verify_hdfs_path_exists invoked incorrectly ###'
		exit 999
	fi

	hdfs dfs -ls "$OBJ_PATH" >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "No object exists in HDFS at '$OBJ_PATH'"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_hdfs_path_not_exists() {
	OBJ_PATH=$1
	
	if [ -z "$OBJ_PATH" ]; then
		echo '### FATAL: verify_hdfs_path_not_exists invoked incorrectly ###'
		exit 999
	fi

	hdfs dfs -ls "$OBJ_PATH" >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		log_error "Object exists in HDFS at '$OBJ_PATH'"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_hive_table_record_count() {
	# NOTE that Hive is very slow, so running this test takes several seconds
	TABLE_NAME=$1
	EXPECTED_COUNT=$2

	if [ -z "$TABLE_NAME" ] || [ -z "$EXPECTED_COUNT" ]; then
		echo '### FATAL: verify_hive_table_record_count invoked incorrectly ###'
		exit 999
	fi

	RCOUNT=$(hive -S -e "select count(*) from $TABLE_NAME" | egrep '^[0-9]+$') >/dev/null 2>&1
	if [ $? -ne 0 ] || [ "$RCOUNT" != "$EXPECTED_COUNT" ]; then
		log_error "Validation of Hive table $TABLE_NAME failed ($RCOUNT records != $EXPECTED_COUNT)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_impala_table_record_count() {
	TABLE_NAME=$1
	EXPECTED_COUNT=$2

	if [ -z "$TABLE_NAME" ] || [ -z "$EXPECTED_COUNT" ]; then
		echo '### FATAL: verify_impala_table_record_count invoked incorrectly ###'
		exit 999
	fi

	impala-shell --quiet -q "SELECT COUNT(*) AS mycount FROM $TABLE_NAME" | grep "\| $EXPECTED_COUNT " >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "Validation of Impala table $TABLE_NAME failed ($RCOUNT records != $EXPECTED_COUNT)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_mysql_table_record_count() {
	DB_NAME=$1
	TABLE_NAME=$2
	EXPECTED_COUNT=$3

	if [ -z "$DB_NAME" ] || [ -z "$TABLE_NAME" ] || [ -z "$EXPECTED_COUNT" ]; then
		echo '### FATAL: verify_mysql_table_record_count() invoked incorrectly ###'
		exit 999
	fi

	mysql -s --user=training --password=training -D"$DB_NAME" -e"SELECT COUNT(*) FROM $TABLE_NAME" | grep "\| $EXPECTED_COUNT " >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log_error "Validation of MYSQL table $TABLE_NAME failed (expected $EXPECTED_COUNT)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_numdocs_in_solr_collection() {
	COLL_NAME=$1
	EXPECTED_COUNT=$2

	if [ -z "$COLL_NAME" ] || [ -z "$EXPECTED_COUNT" ]; then
		echo '### FATAL: verify_numdocs_in_solr_collection invoked incorrectly ###'
		exit 999
	fi

	URL="http://localhost:8983/solr/${COLL_NAME}/admin/luke"
	ACTUAL_COUNT=$(curl -s "$URL" | perl -ne 'print /<int name="numDocs">(\d+)<\/int>/') >/dev/null 2>&1
	if [ $? -ne 0 ] || [ "$ACTUAL_COUNT" != "$EXPECTED_COUNT" ]; then
		log_error "Wrong # of docs in collection '$COLL_NAME' (actual $ACTUAL_COUNT, expected $EXPECTED_COUNT)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}


verify_min_free_disk_space_kb() {
	FILESYSTEM=$1
	EXPECTED_FREE_KB=$2
	
	if [ -z "$FILESYSTEM" ] || [ -z "$EXPECTED_FREE_KB" ]; then
		echo '### FATAL: verify_min_free_disk_space_kb invoked incorrectly ###'
		exit 999
	fi

	FREE_KB=$(df | grep /dev/sda1 | perl -ne 'print /^\S+\s+\S+\s+\S+\s+(\d+)\s/')
	if [ "$FREE_KB" -lt "$EXPECTED_FREE_KB" ]; then
		log_error "Free disk space on $FILESYSTEM less than expected (actual $FREE_KB, expected $EXPECTED_FREE_KB)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_swap() {
	# As of 07/13/2016, this function has been updated to consider a tolerance
	# value before determining that the test has failed. This is because the 
	# amount of swap space may vary slightly from one host machine to the next,
	# and since we're dealing with swap sizes in the gigabyte range, it's much
	# more important to have a reliable test than having precision down to a
	# single byte. The tolerance value is 32 bytes by default, but you can 
	# override it by passing an optional second argument to the function.
	EXPECTED_SWAP_SIZE=$1
	EXPECTED_SWAP_TOLERANCE=${2:-32}
	
	if [ -z "$EXPECTED_SWAP_SIZE" ]; then
		echo '### FATAL: verify_swap invoked incorrectly ###'
		exit 999
	fi

	EXPECTED_SWAP_LOWER=$((EXPECTED_SWAP_SIZE-EXPECTED_SWAP_TOLERANCE))
	EXPECTED_SWAP_UPPER=$((EXPECTED_SWAP_SIZE+EXPECTED_SWAP_TOLERANCE))

	TOTAL_SWAP=$(free | perl -ne 'print /^Swap:\s+(\d+)\s/')
	if [[ $TOTAL_SWAP -lt $EXPECTED_SWAP_LOWER || $TOTAL_SWAP -gt $EXPECTED_SWAP_UPPER ]]; then
		log_error "Incorrect amount of swap space on the VM (actual $TOTAL_SWAP, expected $EXPECTED_SWAP_SIZE +/- $EXPECTED_SWAP_TOLERANCE)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_ram() {
	# As of 07/13/2016, this function has been updated to consider a tolerance
	# value before determining that the test has failed. This is because the 
	# amount of memory reported by the "free" command in a VM may vary by a 
	# very small amount (such as 8 or 12 or 24 bytes) from one host machine
	# to the next. Since we're dealing with memory allocations of 2 GB or more,
	# having a test that works reliably is more important than having one that
	# is precise to a single byte. The tolerance value is 32 bytes by default, 
	# but you can override it through an optional second argument.
	EXPECTED_RAM_SIZE=$1
	EXPECTED_RAM_TOLERANCE=${2:-32}
	
	if [ -z "$EXPECTED_RAM_SIZE" ]; then
		echo '### FATAL: verify_ram invoked incorrectly ###'
		exit 999
	fi

	EXPECTED_RAM_LOWER=$((EXPECTED_RAM_SIZE-EXPECTED_RAM_TOLERANCE))
	EXPECTED_RAM_UPPER=$((EXPECTED_RAM_SIZE+EXPECTED_RAM_TOLERANCE))

	TOTAL_RAM=$(free | perl -ne 'print /^Mem:\s+(\d+)\s/')
	if [[ $TOTAL_RAM -lt $EXPECTED_RAM_LOWER || $TOTAL_RAM -gt $EXPECTED_RAM_UPPER ]]; then
		log_error "Incorrect amount of RAM allocated to the VM (actual $TOTAL_RAM, expected $EXPECTED_RAM_SIZE +/- $EXPECTED_RAM_TOLERANCE)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_centos_version() {
	EXPECTED_CENTOS_VERSION=$1

	if [ -z "$EXPECTED_CENTOS_VERSION" ]; then
		echo '### FATAL: verify_centos_version invoked incorrectly ###'
		exit 999
	fi

	CENTOS_VERSION=$(lsb_release -r | cut -f2)
	if [ "$CENTOS_VERSION" != "$EXPECTED_CENTOS_VERSION" ]; then
		log_error "Wrong CentOS version installed (actual $CENTOS_VERSION, expected $EXPECTED_CENTOS_VERSION)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_cdh_version() {
	EXPECTED_CDH_VERSION=$1
	
	if [ -z "$EXPECTED_CDH_VERSION" ]; then
		echo '### FATAL: verify_cdh_version invoked incorrectly ###'
		exit 999
	fi

	CDH_VERSION=$(hadoop version | grep '^Hadoop ' | perl -ne 'print /-cdh(\d+\.\d+\.\d+)/')
	if [ "$CDH_VERSION" != "$EXPECTED_CDH_VERSION" ]; then
		log_error "Wrong CDH version installed (actual $CDH_VERSION, expected $EXPECTED_CDH_VERSION)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_java_version() {
	EXPECTED_JAVA_VERSION=$1
	
	if [ -z "$EXPECTED_JAVA_VERSION" ]; then
		echo '### FATAL: verify_java_version invoked incorrectly ###'
		exit 999
	fi

	JAVA_VERSION=$(java -version 2>&1 | grep "^java version" | cut -d'"' -f2)
	if [ "$JAVA_VERSION" != "$EXPECTED_JAVA_VERSION" ]; then
		log_error "Wrong Java version in PATH (actual $JAVA_VERSION, expected $EXPECTED_JAVA_VERSION)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_python_version() {
	EXPECTED_PYTHON_VERSION=$1
	
	if [ -z "$EXPECTED_PYTHON_VERSION" ]; then
		echo '### FATAL: verify_python_version invoked incorrectly ###'
		exit 999
	fi
	
	PYTHON_VERSION=$(python -V 2>&1 | perl -ne 'print /^Python\s+([0-9\.]+)/')
	if [ "$PYTHON_VERSION" != "$EXPECTED_PYTHON_VERSION" ]; then
		log_error "Wrong Python version in PATH (actual $PYTHON_VERSION, expected $EXPECTED_PYTHON_VERSION)"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_ipv6_disabled() {
	/sbin/ifconfig | grep inet6 >/dev/null 2>&1
	if [ $? -eq 0 ] ; then
		log_error "IPv6 DOES NOT appear to be disabled"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_selinux_disabled() {
	grep 'SELINUX=disabled' /etc/selinux/config >/dev/null 2>&1
	if [ $? -ne 0 ] ; then
		log_error "SELinux DOES NOT appear to be disabled"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_sudo() {
	sudo -n id | grep 'uid=0(root)' > /dev/null 2>&1
	if [ $? -ne 0 ] ; then
		log_error "Passwordless sudo DOES NOT appear to be set up for $USER"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_env_variable() {
	TEST_VAR_NAME=$1
	EXPECTED_VALUE=$2

	TEST_VAR_VALUE=$(eval "echo \$${TEST_VAR_NAME}")

	if [ ! "$TEST_VAR_VALUE" == "$EXPECTED_VALUE" ]; then
        log_error "Env variable '$TEST_VAR_NAME' has value '$TEST_VAR_VALUE' instead of expected value '$EXPECTED_VALUE'"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_permissions_for_local_path() {
	EXPECTED_PERMS=$1
	LOCAL_PATH=$2

	PATH_PERMS=$(/usr/bin/stat -c '%a' "$LOCAL_PATH") >/dev/null 2>&1
	if [ $? -ne 0 ] || [ "$PATH_PERMS" != "$EXPECTED_PERMS" ]; then
		log_error "Invalid permissions on '$LOCAL_PATH' (expected '$EXPECTED_PERMS' but found '$PATH_PERMS')"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_ownership_for_local_path() {
	EXPECTED_USER_COLON_GROUP=$1
	PATH=$2

	USER_COLON_GROUP=$(/usr/bin/stat -c '%U:%G' "$PATH") >/dev/null 2>&1
	if [ $? -ne 0 ] || [ "$USER_COLON_GROUP" != "$EXPECTED_USER_COLON_GROUP" ]; then
		log_error "Invalid permissions on '$PATH' (expected '$EXPECTED_USER_COLON_GROUP' but found '$USER_COLON_GROUP')"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}


verify_file_contains_string() {
	# NOTE: This was a quick-and-dirty implementation meant to work
	# with alphanumeric data. Further testing (and possibly a different
	# implementation) is needed with asterisks, parentheses, and other
	# characters that have special meaning within the shell.
	FILE=$1
	STRING=$2

	grep -F "$STRING" "$FILE" > /dev/null
	if [ $? -ne 0 ]; then
		log_error "File '$FILE' does not contain string '$STRING' as expected."
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_file_lacks_string() {
	# NOTE: This was a quick-and-dirty implementation meant to work
	# with alphanumeric data. Further testing (and possibly a different
	# implementation) is needed with asterisks, parentheses, and other
	# characters that have special meaning within the shell.
	FILE=$1
	STRING=$2

	grep -Fv "$STRING" "$FILE" > /dev/null
	if [ $? -ne 0 ]; then
		log_error "File '$FILE' contains unexpected string '$STRING'."
	fi
}

verify_md5sum() {
	# compares supplied MD5 checksum against one calculated for local file
	FILE_PATH=$1
	EXPECTED_MD5=$2

	if [ -z "$FILE_PATH" ] || [ -z "$EXPECTED_MD5" ]; then
		echo '### FATAL: verify_md5sum invoked incorrectly ###'
		exit 999
	fi

	if [ ! -f "$FILE_PATH" ] || [ ! -r "$FILE_PATH" ]; then
		log_error "File '$FILE_PATH' does not exist, so cannot compare MD5."
		return
	fi

	ACTUAL_MD5=$(md5sum "$FILE_PATH" | cut -f1 -d' ') >/dev/null 2>&1
	if [ "$EXPECTED_MD5" != "$ACTUAL_MD5" ]; then
		log_error "MD5 comparison for file '$FILE_PATH' fails ( actual $ACTUAL_MD5, expected $EXPECTED_MD5)."
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_files_are_identical() {
	FILE_ONE=$1
	FILE_TWO=$2

	RC=$(cmp "$FILE_ONE" "$FILE_TWO")
	if [ "$RC" -ne 0 ]; then
		log_error "Files '$FILE_ONE' and '$FILE_TWO' are not identical"
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

verify_command_result() {
    RUN_COMMAND=$1
    EXPECTED_RESULT=$2
   
   	if [ -z "$RUN_COMMAND" ] || [ -z "$EXPECTED_RESULT" ]; then
		echo '### FATAL: verify_command_result invoked incorrectly ###'
		exit 999
	fi 
	
	ACTUAL_RESULT=$($RUN_COMMAND)
	
	if [ "$EXPECTED_RESULT" != "$ACTUAL_RESULT" ]; then
		log_error "verify_command_result fails (actual $ACTUAL_RESULT, expected $EXPECTED_RESULT)."
	fi

	NUM_TESTS=$((NUM_TESTS+1))
}

log_error() {
	# indent slightly to be subordinate to message about the
	# component we are currently examining
	echo "  ERROR: $1"

	# Increment this counter, which the parent script can check.
	# If non-zero, then the parent script should exit with a 
	# non-zero status code
	NUM_ERRORS=$((NUM_ERRORS+1))
}
