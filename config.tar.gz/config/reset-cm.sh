#!/bin/bash

update_s3_creds() {
  cd /home/training/config
  ./update-s3-creds.sh
}

check_cm_mgmt_status(){
	status=$(curl -s -X GET -H "Content-Type:application/json" -u admin:admin http://cmhost:7180/api/v12/cm/service/ | grep entityStatus | cut -d '"' -f4)
	if [[ "$status" == "GOOD_HEALTH" ]]; then
		echo "Cloudera Manager Management Service reports good health"
	else
		restart_cm_services
	fi
}

restart_cm_services() {
	echo
	echo "Restarting Cloudera Manager Server"
	sudo service cloudera-scm-server restart
  		
	echo "Waiting 90 seconds to allow it time to finish starting..."
  	count=0
  
	while [ $count -lt 90 ];
  	do
    	count=$(( $count + 1))
    	printf "."
    	sleep 1
  	done
  	
	printf "\n"
	echo
	echo "Restarting Cloudera Manager Agent on cmhost"
	sudo service cloudera-scm-agent restart
  	
	echo
	echo "Restarting Cloudera Manager Management service"
  	curl -s -X POST -H "Content-Type:application/json" -u admin:admin http://cmhost:7180/api/v12/cm/service/commands/restart 2>/dev/null
  	
	echo "Waiting 90 seconds to allow it time to finish starting..."
    while [ $count -lt 90 ];
    do
      count=$(( $count + 1))
      printf "."
      sleep 1
    done
	
	printf "\n"
	#check_cm_mgmt_status
}

# update_s3_creds
check_cm_mgmt_status
