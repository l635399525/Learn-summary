#!/bin/bash

# Script to pull latest IAM role credentials
export PATH=~/.local/bin:$PATH
################################
#local gateway credentials update
################################
# make a copy of template json file and place in working directory
rm -rf ~/.aws
mkdir ~/.aws
cp aws_credentials ~/.aws/credentials

# NOTE: this config file can be used to control training materials to be downloaded
cp aws_config ~/.aws/config

iamRoleAssigned=$(curl -s http://169.254.169.254/latest/meta-data/iam/info | grep InstanceProfileArn | cut -d '"' -f4 |cut -d '/' -f2)
echo "iamRoleAssigned="$iamRoleAssigned
# get latest IAM security file from AWS
curl -s http://169.254.169.254/latest/meta-data/iam/security-credentials/$iamRoleAssigned > newS3sec.txt
region=$(sudo curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep '\"region\"' | cut -d\" -f4)

# remove unwanted characters surrounding security credentials 
sed -i 's/\"//g' newS3sec.txt 
sed -i 's/,*$//g' newS3sec.txt

# configure aws credentials with working region
sed -i s/changeme/$region/ ~/.aws/config

# configure aws credentials with temporary aws security keys
changeme1=$(awk '/AccessKeyId/{print $NF}' newS3sec.txt) 
sed -i s/changeme1/$changeme1/ ~/.aws/credentials

changeme2=$(awk '/SecretAccessKey/{print $NF}' newS3sec.txt)
sed -i 's|changeme2|'"$changeme2"'|g' ~/.aws/credentials

changeme3=$(awk '/Token/{print $NF}' newS3sec.txt)
sed -i 's|changeme3|'"$changeme3"'|g' ~/.aws/credentials

#################################
#Update the cluster's iam role credentials
#################################

#get the current json
rm -f currentdeployment.json
curl -X GET -u "admin:admin"  -H "Content-Type:application/json" -i 'http://cmhost:7180/api/v18/cm/deployment' > currentdeployment.json 

#get current namenode host in the HA cluster
nnMaster=$(cat currentdeployment.json |grep 'CD-HDFS-' | grep 'NAMENODE-master' | grep name | cut -d '-' -f6)
if [[ "$nnMaster" == "" ]]; then
	#handles when there is no NNHA configured
	nnMaster="1"
fi
nnMaster="master-"$nnMaster
echo "nnMaster="$nnMaster

#update credentials on the NameNode host and copy to the gateway
ssh -i ~/.ssh/admincourse.pem training@$nnMaster 'cd /home/training/config && ./update-s3-creds.sh'
rm -f credentials
scp -i ~/.ssh/admincourse.pem training@$nnMaster:/home/training/.aws/credentials .
mv credentials nn-aws-credentials

#use the credentials template to create the json we will want to post
value1=$(cat nn-aws-credentials | sed -n 2p | cut -d '=' -f2)
echo "value1="$value1
value2=$(cat nn-aws-credentials | sed -n 3p | cut -d '=' -f2)
echo "value2="$value2
value3=$(cat nn-aws-credentials | sed -n 4p | cut -d '=' -f2-)
echo "value3="$value3

mkdir -p working
rm -f /home/training/config/working/s3-cluster-creds.json
cp /home/training/training_materials/admin/scripts/catchup/json/s3-cluster-creds.json /home/training/config/working/
echo "sed line 1"
sed -i "s~replace-value-1~$value1~" /home/training/config/working/s3-cluster-creds.json
echo "sed line 2"
sed -i "s~replace-value-2~$value2~" /home/training/config/working/s3-cluster-creds.json
echo "sed line 3"
sed -i "s~replace-value-3~$value3~" /home/training/config/working/s3-cluster-creds.json

clusterName=$(curl -s -X GET -u "admin:admin"  -H "Content-Type:application/json" -i 'http://cmhost:7180/api/v12/clusters/' | grep '"name"' | awk '{print $3}' | cut -d '"' -f2)
echo "clusterName="$clusterName
curlURL="-s -X GET -u "admin:admin" -i http://cmhost:7180/api/v10/clusters/$clusterName/services/"
hdfsServiceName=$(curl $curlURL | grep CD-HDFS | grep name | cut -d '"' -f4 )
if [[ "$hdfsServiceName" == "" ]]; then
	hdfsServiceName="hdfs"
fi
echo "hdfsServiceName="$hdfsServiceName
oozieServiceName=$(curl $curlURL | grep CD-OOZIE | grep name | cut -d '"' -f4 )
echo "oozieServiceName="$oozieServiceName
echo "posting s3 credentials to the cluster"
curl -X PUT -u "admin:admin"  -H "Content-Type:application/json" -i "http://cmhost:7180/api/v18/clusters/$clusterName/services/$hdfsServiceName/config/" -d @working/s3-cluster-creds.json
echo "restarting services"
#curl -X POST -u "admin:admin"  -H "Content-Type:application/json" -i "http://cmhost:7180/api/v18/clusters/$clusterName/services/$hdfsServiceName/commands/restart"
#curl -s -X POST -H "Content-Type:application/json" -u admin:admin http://cmhost:7180/api/v12/clusters/$clusterName/services/$oozieServiceName/commands/restart 2>/dev/null
curl -X POST -u admin:admin http://cmhost:7180/api/v16/clusters/$clusterName/commands/restart -d '{[{"restartOnlyStaleServices":"true", "redeployClientConfiguration":"true"}]}'

#calling this on HDFS will redeploy the configs for all the other services as well
curl -s -X POST -u "admin:admin" -H "Content-Type:application/json" -i http://cmhost:7180/api/v18/clusters/$clusterName/commands/deployClientConfig/ -d "{\"items\":[\"$hdfsServiceName\"]}"


