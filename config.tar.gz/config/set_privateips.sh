#!/bin/bash
# THIS SCRIPT called by config_hosts_file.sh on the Get2Cluster VM.

nocheck="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"

if [[ "$(cat /etc/hosts |grep master-1)" == "" || \
"$(cat /etc/hosts |grep master-2)" == "" || \
"$(cat /etc/hosts |grep worker-1)" == "" || \
"$(cat /etc/hosts |grep worker-2)" == "" ]]; then

	echo "5 (path A). No cluster exists yet, setting cmhost IP in cmhost /etc/hosts."
	sudo mv /home/training/config/builthosts /etc/hosts

	echo "6. Updating cmhost's networking settings."
	region=$(curl http://169.254.169.254/latest/meta-data/hostname | cut -d . -f 2) 
	cmPrivIP=$(/sbin/ip addr | grep eth0 | grep inet | awk '{print $2}' | cut -d '/' -f1)

	echo ""
	echo "NOTE: if you see a message below that states that IP information for eth0"
	echo "failed, Unable to obtain IPv4 address, you can safely ignore it."
	echo ""
	echo "Restarting Network service on cmhost"
	#sudo service dnsmasq restart 2>/dev/null
	sudo service network restart 2>/dev/null
	echo "Waiting 30 seconds after the network restart."
	sleep 30
	echo ""
	echo "Restarting cm agent on cmhost."
	sudo service cloudera-scm-agent restart 2>/dev/null

else
	#Since cdh node entries exist, check if the one of the non-cmhost nodes is running
	m1Access=$(nmap master-1 -PN -p 443|grep open)
	if [[ "$m1Access" != "" ]]; then
		echo ""
		echo "5 (path B). Cluster already exists and is running."

		echo "Restarting cm agent on all nodes (since instances were likely stopped before)."
		sudo service cloudera-scm-agent restart 2>/dev/null
		ssh $nocheck training@master-1 sudo service cloudera-scm-agent restart 2>/dev/null
		ssh $nocheck training@master-2 sudo service cloudera-scm-agent restart 2>/dev/null
		ssh $nocheck training@worker-1 sudo service cloudera-scm-agent restart 2>/dev/null
		ssh $nocheck training@worker-2 sudo service cloudera-scm-agent restart 2>/dev/null
		ssh $nocheck training@worker-3 sudo service cloudera-scm-agent restart 2>/dev/null
		#ssh $nocheck training@gateway sudo service cloudera-scm-agent restart 2>/dev/null

		echo ""
		echo "6. Gathering cluster node public IPs in case they have changed."
	    m1pubip=$(ssh $nocheck training@master-1 curl http://169.254.169.254/latest/meta-data/public-ipv4)
	    m2pubip=$(ssh $nocheck training@master-2 curl http://169.254.169.254/latest/meta-data/public-ipv4)
	    w1pubip=$(ssh $nocheck training@worker-1 curl http://169.254.169.254/latest/meta-data/public-ipv4)
	    w2pubip=$(ssh $nocheck training@worker-2 curl http://169.254.169.254/latest/meta-data/public-ipv4)
	    w3pubip=$(ssh $nocheck training@worker-3 curl http://169.254.169.254/latest/meta-data/public-ipv4)
	    #gpubip=$(ssh $nocheck training@gateway curl http://169.254.169.254/latest/meta-data/public-ipv4)
		
		#write the newhosts.txt file contents (which will be used by the VM)
	    echo $m1pubip" master-1" > /home/training/config/newpubips.txt
	    echo $m2pubip" master-2" >> /home/training/config/newpubips.txt
	    echo $w1pubip" worker-1" >> /home/training/config/newpubips.txt
	    echo $w2pubip" worker-2" >> /home/training/config/newpubips.txt
	    echo $w3pubip" worker-3" >> /home/training/config/newpubips.txt
	    #echo $gpubip" gateway"  >> /home/training/config/newpubips.txt

	    #NOTE: no dnsmasq or network service restart required, because no private IP address changes were made on cmhost.

	else
		#master-1 non-responsive so cluster must have been deleted. Let the old referenced internal IPs be deleted from cmhost's /etc/hosts
		echo ""
		echo "5 (path C). master-1 entry found in cmhost /etc/hosts, but it is non-responsive."

		#ask if the other nodes are still valid but just stopped 
		#or if they want to reuse cmhost for a new cluster
		echo ""
		echo "-----------------------------------------------"
		echo "cmhost cannot connect to the cluster it controls."
		echo ""
		echo "This usually means the cluster instances are stopped"
		echo "or the cluster was terminated. "
		echo "-----------------------------------------------"
		echo ""
		echo "Please enter 1 or 2 to indicate your choice."
		echo ""
		echo "1. Keep existing cluster."
		echo ""
		echo "2. Prepare cmhost for a new cluster."
		echo ""
		echo ">>"
		validResp=0
		while [ $validResp -eq 0 ]  
		do
			read answer
			if [[ "$answer" -eq 1 ]]; then
				#KEEP CLUSTER
				echo ""
				echo "OK. If you want to re-use this cmhost to create a new cluster, see the instructions in the exercise guide for what to do after this script completes."
				echo "Exiting. "
				exit
				validResp=1
			elif [[ "$answer" -eq 2 ]]; then
				#forget the old cluster
				sudo cp /etc/hosts /tmp/hosts"$(date '+%Y-%m-%d %T')"
				sudo mv /home/training/config/builthosts /etc/hosts #using this file built and copied over in steps 3 and 4 of config_hosts_files.sh
				echo ""
				echo "OK, references to the old cluster have been removed from cmhost's /etc/hosts"
				echo "NOTE: cmhost's old /etc/hosts, can be found in /tmp/hosts-<timestamp> file."
				echo "The old cluster instances have not been deleted."
				echo ""
				validResp=1
			else
				echo "Please reply with 1 or 2."
			fi
		done

		echo "6. Restarting network service on cmhost (to clear mappings to cluster that no longer exists)."
		#sudo service dnsmasq restart 2>/dev/null
		sudo service network restart 2>/dev/null
		echo "Waiting 30 seconds after the network restart."
		sleep 30
		echo ""
		echo "Restarting cm agent on cmhost (since instance was likely stopped before)."
		sudo service cloudera-scm-agent restart 2>/dev/null

		#should also DELETE public ips on VM
		#cat /etc/hosts | grep localhost > /home/training/config/newpubips.txt
	    #echo $cmhostpubip" cmhost" >> /home/training/config/newpubips.txt
	fi	
fi
