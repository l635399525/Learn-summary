#!/bin/bash

# Script to pull latest IAM role credentials
export PATH=~/.local/bin:$PATH

# make a copy of template json file and place in working directory
rm -rf /home/training/.aws
mkdir /home/training/.aws
cp /home/training/config/aws_credentials ~/.aws/credentials

# NOTE: this config file can be used to control training materials to be downloaded
cp /home/training/config/aws_config /home/training/.aws/config

# get latest IAM security file from AWS
iamRoleAssigned=$(curl -s http://169.254.169.254/latest/meta-data/iam/info | grep InstanceProfileArn | cut -d '"' -f4 |cut -d '/' -f2)
curl -s http://169.254.169.254/latest/meta-data/iam/security-credentials/$iamRoleAssigned > /home/training/config/newS3sec.txt
region=$(sudo curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep '\"region\"' | cut -d\" -f4)

# remove unwanted characters surrounding security credentials 
sed -i 's/\"//g' /home/training/config/newS3sec.txt 
sed -i 's/,*$//g' /home/training/config/newS3sec.txt

# configure aws credentials with working region
sed -i s/changeme/$region/ /home/training/.aws/config

# configure aws credentials with temporary aws security keys
changeme1=$(awk '/AccessKeyId/{print $NF}' newS3sec.txt) 
sed -i s/changeme1/$changeme1/ /home/training/.aws/credentials

changeme2=$(awk '/SecretAccessKey/{print $NF}' newS3sec.txt)
sed -i 's|changeme2|'"$changeme2"'|g' /home/training/.aws/credentials

changeme3=$(awk '/Token/{print $NF}' newS3sec.txt)
sed -i 's|changeme3|'"$changeme3"'|g' /home/training/.aws/credentials
