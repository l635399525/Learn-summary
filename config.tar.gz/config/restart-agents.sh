#!/bin/bash
nocheck="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=error"
#Re-start CM Agents to the rest of the nodes other than cmhost 
#sudo service cloudera-scm-server restart 2>/dev/null
#sleep 45
echo "Restarting CM agent on cmhost"
sudo service cloudera-scm-agent restart 
echo "Restarting CM agent on master-1"
ssh $nocheck training@master-1 sudo service cloudera-scm-agent restart
echo "Restarting CM agent on master-2"
ssh $nocheck training@master-2 sudo service cloudera-scm-agent restart
echo "Restarting CM agent on worker-1"
ssh $nocheck training@worker-1 sudo service cloudera-scm-agent restart
echo "Restarting CM agent on worker-2"
ssh $nocheck training@worker-2 sudo service cloudera-scm-agent restart
echo "Restarting CM agent on worker-3"
ssh $nocheck training@worker-3 sudo service cloudera-scm-agent restart
echo "Restarting CM agent on gateway"
ssh $nocheck training@gateway sudo service cloudera-scm-agent restart 