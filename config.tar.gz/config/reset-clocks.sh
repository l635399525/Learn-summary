#!/bin/bash
nocheck="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=error"
#Re-start clocks for all cluster nodes 
echo "Restarting ntpd on cmhost"
sudo service ntpd restart 
echo "Restarting ntpd on master-1"
ssh $nocheck training@master-1 sudo service ntpd restart
echo "Restarting ntpd on master-2"
ssh $nocheck training@master-2 sudo service ntpd restart 
echo "Restarting ntpd on worker-1"
ssh $nocheck training@worker-1 sudo service ntpd restart
echo "Restarting ntpd on worker-2"
ssh $nocheck training@worker-2 sudo service ntpd restart 
echo "Restarting ntpd on worker-3"
ssh $nocheck training@worker-3 sudo service ntpd restart 
echo "Restarting ntpd on gateway"
ssh $nocheck training@gateway sudo service ntpd restart 

#restart Kudu also
#echo "Restarting Kudu as well."
clusters=$(curl -X GET -u "admin:admin" -i http://localhost:7180/api/v12/clusters/)
clusterN=$(echo $clusters | cut -d '"' -f6)
curl -s -X POST -H "Content-Type:application/json" -u admin:admin http://cmhost:7180/api/v12/clusters/$clusterN/services/kudu/commands/restart 2>/dev/null

echo 
echo "Done resetting system clock on all nodes. Note: It may still take Cloudera "
echo "Manager two minutes or so to reflect this update."
