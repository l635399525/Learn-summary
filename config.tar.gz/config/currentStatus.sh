#!/bin/bash
iamRole=$(curl -s http://169.254.169.254/latest/meta-data/iam/security-credentials/)
#sed -i 's/replace-cmhost-iam-role/'"$iamRole"'/g' /home/training/config/update-s3-creds.sh
cd /home/training/config
./update-s3-creds.sh
cmhostInstanceId=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
cmhostRegion=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep '\"region\"' | cut -d\" -f4)

#set the correct internal IP in cmhost's /etc/hosts
cmPrivIP=$(/sbin/ip addr | grep eth0 | grep inet | awk '{print $2}' | cut -d '/' -f1)
sudo sed -i '/cmhost/d' /etc/hosts
echo $cmPrivIP"   cmhost.example.com  cmhost" | sudo tee -a /etc/hosts


#verify status checks before continuing on
vResp=0
count=0
echo
echo "Verifying cmhost instance has passed all status checks..."
while [ $vResp -eq 0 ] 
do 
	currentStatus=$(aws ec2 describe-instance-status --instance-ids $cmhostInstanceId --region $cmhostRegion --output json | grep -o '"Status": "[^"]*' | grep -o '[^"]*$')
	c1=$(echo $currentStatus | awk '{print $1}')
	c2=$(echo $currentStatus | awk '{print $2}')
	c3=$(echo $currentStatus | awk '{print $3}')
	c4=$(echo $currentStatus | awk '{print $4}')

	if [[ "$c1" == "ok" ]] && [[ "$c2" == "passed" ]] && [[ "$c3" == "ok" ]] && [[ "$c4" == "passed" ]]; then 
		printf "\n"
		echo "Verified, moving on..."
		echo
		vResp=1
	else
		#sleep 15 seconds
		count=0
		while [ $count -lt 15 ];
		do
			count=$(( $count + 1))
			printf "."
			sleep 1
		done

#		count=$(( $count + 1 )) 
#		if [[ "$count" == "1" ]]; then
#			echo 
#			echo "If cmhost was only recently started, this may take a couple of minutes, "
#			echo "please be patient. "
#		fi
#		if [[ "$count" == "8" ]]; then
#			echo "2 minutes elapsed. "
#		fi
#		if [[ "$count" == "12" ]]; then
#			echo "3 minutes elapsed. "
#		fi
#		if [[ "$count" == "16" ]]; then
#			echo "4 minutes elapsed. This script will keep trying until 7 minutes have "
#			echo "passed before exiting."
#		fi
#		if [[ "$count" == "28" ]]; then
#			echo "It has been 7 minutes and the cmhost instance is still not ready. "
#			echo "FAILED. Exiting."
#			exit 1
#		fi
#		sleep 15
	fi
done
