#!/usr/bin/env bash

JDK8_RPM="openjdk8-8.0+232_9-cloudera.x86_64.rpm"
JDK8_VERSION="jdk1.8.0_232-cloudera"
JAVA_HOME="/usr/java/default"

MYSQL_RPM="mysql-community-release-el7-5.noarch.rpm"

#originally from https://archive.cloudera.com/p/cdh7/7.1.5.0/parcels/
CDH715_PARCEL_EL7="CDH-7.1.5-1.cdh7.1.5.p0.7431829-el7.parcel" #used
CDH715_SHA256_EL7="CDH-7.1.5-1.cdh7.1.5.p0.7431829-el7.parcel.sha256" #used
CDH715_SHA1_EL7="CDH-7.1.5-1.cdh7.1.5.p0.7431829-el7.parcel.sha1" #used 
CDH715_SHA_EL7="CDH-7.1.5-1.cdh7.1.5.p0.7431829-el7.parcel.sha" #used 
CDH715_MANIFEST="CDH-7.1.5.manifest.json"

#originally from https://archive.cloudera.com/p/cdh7/7.1.6.0/parcels/
CDH716_PARCEL="CDH-7.1.6-1.cdh7.1.6.p0.10506313-el7.parcel" #used
CDH716_SHA256="CDH-7.1.6-1.cdh7.1.6.p0.10506313-el7.parcel.sha256" #used
CDH716_SHA1="CDH-7.1.6-1.cdh7.1.6.p0.10506313-el7.parcel.sha1" #used 
CDH716_SHA="CDH-7.1.6-1.cdh7.1.6.p0.10506313-el7.parcel.sha" #used 
CDH716_MANIFEST="CDH-7.1.6.manifest.json"

#originally from https://archive.cloudera.com/p/cm7/7.3.1/redhat7/yum/RPMS/x86_64/
CM731_SERVER_RPM_EL7="cloudera-manager-server-7.3.1-10891891.el7.x86_64.rpm" #on S3
CM731_DAEMONS_RPM_EL7="cloudera-manager-daemons-7.3.1-10891891.el7.x86_64.rpm" #on S3
CM731_AGENT_RPM_EL7="cloudera-manager-agent-7.3.1-10891891.el7.x86_64.rpm" #on S3
CM731_REPO="cm7.3.1-redhat7.tar.gz"

FLINK_PARCEL_EL7="FLINK-1.10.0-csa1.2.0.0-cdh7.1.1.0-565-3525501-el7.parcel"
FLINK_SHA_EL7="FLINK-1.10.0-csa1.2.0.0-cdh7.1.1.0-565-3525501-el7.parcel.sha"

SQL_STREAM_CSD="SQL_STREAM_BUILDER-1.12-csa1.3.0.0-cdh7.1.6.0-297-11607198.jar"

#CFM/NiFi
CFM_PARCEL="CFM-2.0.4.0-80-el7.parcel"
CFM_SHA="CFM-2.0.4.0-80-el7.parcel.sha"
CFM_MANIFEST="CFM-2.0.4.manifest.json"

NIFI_CSD="NIFI-1.11.4.1.1.0.0-119.jar"
NIFICA_CSD="NIFICA-1.11.4.1.1.0.0-119.jar"
NIFIREGISTRY_CSD="NIFIREGISTRY-0.6.0.1.1.0.0-119.jar"


#Streams Messenger Manager (SMM)
SMM_VERSION=2.1.0
SMM_PARCEL=STREAMS_MESSAGING_MANAGER-${SMM_VERSION}.2.0.1.0-29-el7.parcel
SMM_SHA=STREAMS_MESSAGING_MANAGER-${SMM_VERSION}.2.0.1.0-29-el7.parcel.sha
SMM_CSD=STREAMS_MESSAGING_MANAGER-${SMM_VERSION}.jar

#Streams Replication Manager (SRM)
SRM_VERSION=1.0.0
SRM_PARCEL=STREAMS_REPLICATION_MANAGER-${SRM_VERSION}.2.0.1.0-29-el7.parcel
SRM_SHA=STREAMS_REPLICATION_MANAGER-${SRM_VERSION}.2.0.1.0-29-el7.parcel.sha
SRM_CSD=STREAMS_REPLICATION_MANAGER-${SRM_VERSION}.jar

#Spark3
SPARK3_VERSION=3.0.0
SPARK3_PARCEL=SPARK3-${SPARK3_VERSION}.2.99.7110.0-18-1.p0.3525631-el7.parcel
SPARK3_SHA=SPARK3-${SPARK3_VERSION}.2.99.7110.0-18-1.p0.3525631-el7.parcel.sha1
SPARK3_CSD=SPARK3_ON_YARN-${SPARK3_VERSION}.2.99.7110.0-18.jar