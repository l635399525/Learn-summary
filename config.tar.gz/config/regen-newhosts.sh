#!/bin/bash
nocheck="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"

#collect the public ip address from all cluster nodes, plus cmhost and director
call="curl http://169.254.169.254/latest/meta-data/public-ipv4"

#start writing the file we are building
cat /etc/hosts |grep localhost >  ~/config/newhosts.txt

master1() {
    ssh $nocheck training@$(cat /etc/hosts|grep master-1|awk '{print $1}') $call > ~/config/master-1-pubip.txt
    if [[ "$(cat ~/config/master-1-pubip.txt)" == "" ]]; then
        echo "master-1 instance not running."
    else
        echo -n $(cat ~/config/master-1-pubip.txt) " master-1" >> ~/config/newhosts.txt
        sed -i -e '$a\' ~/config/newhosts.txt
    fi
}

master2() {
    ssh $nocheck training@$(cat /etc/hosts|grep master-2|awk '{print $1}') $call > ~/config/master-2-pubip.txt
    if [[ "$(cat ~/config/master-2-pubip.txt)" == "" ]]; then
     echo "master-2 instance not running."
    else
        echo -n $(cat ~/config/master-2-pubip.txt) " master-2" >> ~/config/newhosts.txt    
        sed -i -e '$a\' ~/config/newhosts.txt
    fi
}

worker1() {
    ssh $nocheck training@$(cat /etc/hosts|grep worker-1|awk '{print $1}') $call > ~/config/worker-1-pubip.txt
    if [[ "$(cat ~/config/worker-1-pubip.txt)" == "" ]]; then
        echo "worker-1 instance not running."
    else
        echo -n $(cat ~/config/worker-1-pubip.txt) " worker-1" >> ~/config/newhosts.txt
        sed -i -e '$a\' ~/config/newhosts.txt
    fi
}

worker2() {
    ssh $nocheck training@$(cat /etc/hosts|grep worker-2|awk '{print $1}') $call > ~/config/worker-2-pubip.txt
    if [[ "$(cat ~/config/worker-2-pubip.txt)" == "" ]]; then
        echo "worker-2 instance not running."
    else
        echo -n $(cat ~/config/worker-2-pubip.txt) " worker-2" >> ~/config/newhosts.txt    
        sed -i -e '$a\' ~/config/newhosts.txt
    fi
}

worker3() {
    ssh $nocheck training@$(cat /etc/hosts|grep worker-3|awk '{print $1}') $call > ~/config/worker-3-pubip.txt
    if [[ "$(cat ~/config/worker-3-pubip.txt)" == "" ]]; then
        echo "worker-3 instance not running."
    else
        echo -n $(cat ~/config/worker-3-pubip.txt) " worker-3" >> ~/config/newhosts.txt
        sed -i -e '$a\' ~/config/newhosts.txt
    fi
}

gateway() {
    ssh $nocheck training@$(cat /etc/hosts|grep gateway|awk '{print $1}') $call > ~/config/gateway-pubip.txt
    if [[ "$(cat ~/config/gateway-pubip.txt)" == "" ]]; then
        echo "gateway instance not running."
    else
        echo -n $(cat ~/config/gateway-pubip.txt) " gateway" >> ~/config/newhosts.txt    
        sed -i -e '$a\' ~/config/newhosts.txt
    fi
}

cmhost() {
    ssh $nocheck training@$(cat /etc/hosts|grep cmhost|awk '{print $1}') $call > ~/config/cmhost-pubip.txt
    echo -n $(cat ~/config/cmhost-pubip.txt) " cmhost" >> ~/config/newhosts.txt
    sed -i -e '$a\' ~/config/newhosts.txt
}

results() {

    cat ~/config/newhosts.txt
}

master1
master2
worker1
worker2
worker3
gateway
cmhost






