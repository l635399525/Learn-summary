from flask import Flask, render_template, request, url_for
from sin import *
import matplotlib.pyplot as plt
import io
import base64

from DbTool import getConn,query
from GetDatas import dest_file_hists_img,dest_file_hists

app = Flask(__name__)

@app.route('/', methods=['GET','POST'])
def home():
    return render_template('index4.html')


@app.route('/code', methods=['GET','POST'])
def code():
    return render_template('index4_code.html')
@app.route('/code_act', methods=['GET','POST'])
def code_act():
    hist_img_conn = getConn(dest_file_hists_img)
    hist_conn = getConn(dest_file_hists)
    wave_type = request.form['wave_type']
    code = request.form['code']
    nday = request.form['nday']
    start = request.form['start']
    end = request.form['end']
    sql = ''' select * from raw_show_img_mapping where code = '{code}'  '''.format(code=code)
    print("code_act ############################# %s" % ('start'))

    df = query(sql, hist_img_conn)
    df['fn'] = df.file.apply(lambda x: x.split("\\")[-1]).values
    rdf = df.copy()
    print("############################# %s %s" % (len(df), len(rdf)))
    try:
        imgs = list(rdf[['data', 'fn']].values)
        imgs.sort(key=lambda x: x[1].split("#")[-1])
    except:
        imgs = []
    return render_template('index1.html', var1="code", var2=wave_type, var3=start, var4=end, var5=code, plot_url=imgs)


@app.route('/work_date', methods=['GET','POST'])
def work_date():
    return render_template('index4_date.html')
@app.route('/work_date_act', methods=['GET','POST'])
def work_date_act():
    hist_img_conn = getConn(dest_file_hists_img)
    hist_conn = getConn(dest_file_hists)
    wave_type = request.form['wave_type']
    code = request.form['code']
    nday = request.form['nday']
    start = request.form['start']
    end = request.form['end']
    sql = ''' select * from raw_show_img_mapping where code = '{code}'  '''.format(code=code)
    print("############################# %s" % ('start'))

    df = query(sql, hist_img_conn)
    df['fn'] = df.file.apply(lambda x: x.split("\\")[-1]).values
    rdf = df.copy()
    print("############################# %s %s" % (len(df), len(rdf)))
    try:
        imgs = list(rdf[['data', 'fn']].values)
        imgs.sort(key=lambda x: x[1].split("#")[-1])
    except:
        imgs = []
    return render_template('index1.html', var1="work_date", var2=wave_type, var3=start, var4=end, var5=code, plot_url=imgs)


@app.route('/', methods=['POST'])
def add():
        hist_img_conn = getConn(dest_file_hists_img)
        hist_conn = getConn(dest_file_hists)

        wave_type = request.form['wave_type']
        code = request.form['code']
        nday = request.form['nday']
        start = request.form['start']
        end = request.form['end']
        try:
            lcl = int(request.form['lcl'])
        except:
            lcl = -100
        if lcl > -10:
            sql = '''
                select distinct code||end as key from test_back_hist_analysis_data where  (work_close - c_zs_hcl)*100/c_zs_hcl > {lcl}
            '''.format(lcl=lcl)
            ekeys = list(query(sql,hist_conn)['key'].values)
        else:
            ekeys = []
        if code != '':
            sql = '''
                    select * from raw_show_img_mapping where code = '{code}' 
                    '''.format(code=code)
        else:
            sql = '''
            select * from raw_show_img_mapping where ndays || '' = {nday} || '' and wave_t = '{wave_t}'
    and date(date) >= date('{start}') and date(date) <= date('{end}') 
            '''.format(wave_t=wave_type,start=start,end=end,nday= nday)
        print("#############################")
        df = query(sql,hist_img_conn)
        df['fn'] = df.file.apply(lambda x:x.split("\\")[-1]).values
        if len(ekeys) > 0:
            rdf = df[df.apply(lambda x:'%s%s' %(x['code'],x['date']),axis=1).isin(ekeys)].copy()
        else:
            rdf = df.copy()
        print("############################# %s %s" %(len(df),len(rdf)))
        try:
            imgs = list(rdf[['data','fn']].values)
            imgs.sort(key=lambda x:x[1].split("#")[-1])
            # A = float(1)
            # f = float(1)
            # xmin = float(8)
            # xmax = float(16)
            # x, y = sin_function(A, f, xmin, xmax)
            #
            # img = io.BytesIO()
            # plt.plot(x, y)
            # plt.rcParams['font.sans-serif'] = ['SimHei']
            # plt.rcParams['axes.unicode_minus'] = False
            # plt.title('正弦函数')
            # plt.xlabel('x')
            # plt.ylabel('y')
            # plt.savefig(img, format='png')
            # img.seek(0)
            #
            # plot_url = base64.b64encode(img.getvalue()).decode()
            return render_template('index1.html', var1=nday, var2=wave_type, var3=start, var4=end, var5=code, plot_url=imgs)
        except:
            return render_template('index4.html', message='inputs false!!!', var1=nday, var2=wave_type, var3=start, var4=end, var5=code)
        
if __name__ == '__main__':
    app.run(port=8002)