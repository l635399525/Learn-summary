import base64

import pandas as pd
from DbTool import getConn,insert,query,delete
dest_file_hists = r"D:\data\0_g\ana_sum_datas_newses2023_draw"
dest_file_hists_img = r"D:\data\0_g\ana_db_test_backs_hists_img"


hist_conn = getConn(dest_file_hists)
hist_img_conn = getConn(dest_file_hists_img)
import io
from PIL import Image
def getEFiles():
    sql = '''
    select distinct outf from raw_draw_sum where rflag = 'G'
    '''
    ofs = list(query(sql,hist_conn)['outf'].values)
    print("#############%s" %(len(ofs)))
    cds = ','.join(list(map(lambda x:"'%s'" %(x),ofs)))
    sql = '''
    delete from raw_show_img_mapping where outf in ({cds})
        '''.format(cds=cds)
    delete(hist_img_conn,sql)
    sql = '''
    select distinct outf from raw_show_img_mapping
    '''
    outfs = list(query(sql,hist_img_conn)['outf'].values)
    return outfs
def readimage(path):
    with open(path, "rb") as f:
        a = f.read()
        img = io.BytesIO(a)
        #img = Image.open(bytes_stream)
        plot_url = base64.b64encode(img.getvalue()).decode()
        return plot_url

def genInitDatas():

    olines = []
    efiles = getEFiles()
    sql = '''
        select cls,outf,code, sdt, edt, d1,rflag,x1,x6,
           ag_4341, ag_4241, ag_4313, ag_4212, ag_4131, ag_4221, ag_1232, ag_41x, ag_42x, ag_43x, ag_12x, ag_13x
           , ag_32x from raw_draw_sum
        '''
    df = query(sql, hist_conn)
    for i in range(len(df)):
        line = df.iloc[i]
        outf = line['outf']
        if outf in efiles:
            continue
        bytes = readimage(outf)
        line['data'] = bytes
        olines.append(line)
        if len(olines) > 0 and len(olines) %2000 == 0:

            rdf = pd.DataFrame(olines)
            insert(rdf,hist_img_conn,'raw_show_img_mapping',opType='append')
            olines = []
        print("%s %s %s" %(i,len(olines),len(df)))
    if len(olines) > 0:
        rdf = pd.DataFrame(olines)
        insert(rdf, hist_img_conn, 'raw_show_img_mapping', opType='append')
        #ofiles = []
def genNDaysKPIs():
    sql = '''
    
    '''

if __name__ == '__main__':
    genInitDatas()