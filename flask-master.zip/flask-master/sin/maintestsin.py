from sin import *
c = sin_function(1,1,0,1)
print (c)
