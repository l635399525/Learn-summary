from flask import Flask, render_template, request, url_for
from sin import *
import matplotlib.pyplot as plt
import io
import base64

from DbTool import getConn,query
from GetDatas import dest_file_hists_img

app = Flask(__name__)

@app.route('/', methods=['GET'])
def home():
    return render_template('index4.html')

@app.route('/', methods=['POST'])
def add_code():
        hist_img_conn = getConn(dest_file_hists_img)
        code = request.form['code']
        nday = code
        start = ''
        end = ''
        wave_type = ''
        sql = '''
        select * from raw_show_img_mapping where code = '{code}' 
        '''.format(code=code)
        print("#############################")
        df = query(sql,hist_img_conn)
        df['fn'] = df.file.apply(lambda x:x.split("\\")[-1]).values
        print(len(df))
        print("#############################")
        try:
            imgs = list(df[['data','fn']].values)
            return render_template('index1.html', var1=nday, var2=wave_type, var3=start, var4=end, plot_url=imgs)
        except:
            return render_template('index4.html', message='inputs false!!!', var1=nday, var2=wave_type, var3=start, var4=end)
        
if __name__ == '__main__':
    app.run(port=8001)