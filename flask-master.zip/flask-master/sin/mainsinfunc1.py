from flask import Flask, render_template, request, url_for
from sin import *
import matplotlib.pyplot as plt
import io
import base64

from DbTool import getConn, query
from GetDatas import dest_file_hists_img

app = Flask(__name__)


@app.route('/', methods=['GET'])
def home():
    return render_template('index4.html')
from datetime import datetime
def putProperties(key,conn,value=None,sql=None,ndays=None):

    if key == 'put_name':
        SQL = '''
            select name,case when code like '6%' then 'sh.'||code else 'sz.'||code end as code from raw_code_hy_mapping
        where (code like '6%' or code like '0%') and name not like '%ST%'
        union
        select distinct name_hy,code_hy from raw_code_hy_mapping
            '''
        name_map = dict(query(SQL, conn)[['code', 'name']].values)
        return name_map
    elif key == 'hycode':
        if value != '':
            sql = '''
              select case when code like '60%' then 'sh.'|| code else 'sz.'|| code end as code from raw_code_hy_mapping where code_hy = '{code}' and (code like '60%' or code like '00%')
              '''.format(code=value)
            ecodes = list(query(sql, conn)['code'].values)
        else:
            ecodes = []
        return ecodes
    elif key == 'code':
        if value != '':
            sql = '''
select distinct code_hy as code from raw_code_hy_mapping where code = '{code}'
              '''.format(code=value)
            ecodes = list(query(sql, conn)['code'].values)
        else:
            ecodes = []
        return ecodes
    elif key == 'base_date':
        if value == '':
            base_date = datetime.now().strftime('%Y-%m-%d')
        else:
            base_date = value
        sql = sql.replace("{dt}",base_date)
        sql1 = '''
select distinct code,pctChg from raw_draw_detail where  date = '{dt}'
        '''.format(dt=base_date)
        pct_map = dict(query(sql1,conn)[['code','pctChg']].values)
        return sql,pct_map
    elif key == 'top_Ndays':
        try:
            value = int(value)
        except:
            value = ''
        if sql == '':
            base_date = datetime.now().strftime('%Y-%m-%d')
        else:
            base_date = sql
        dates = [base_date]
        if ndays != '':
            sql = '''
select distinct date from raw_draw_detail where date(date) < date('{dt}') order by date desc limit {top}
            '''.format(dt=base_date,top=ndays)
            dates = list(query(sql,conn)['date'].values)
        top_codes = []
        for date in dates:
            if value != '':
                sql = '''
            select * from
            (select distinct code,pctChg,date from raw_draw_detail where  code like 'BK%' and date = '{dt}' order by pctChg desc limit  {top})
            union
            select * from
            (select distinct code,pctChg,date from raw_draw_detail where  code not like 'BK%' and date = '{dt}' order by pctChg desc limit  {top})     
            '''.format(top=value, dt=date)
                top_code = list(query(sql, conn)['code'].values)
            else:
                top_code = []
            top_codes.extend(top_code)
        return top_codes

    elif key == 'top':
        try:
            value = int(value)
        except:
            value = ''

        if sql == '':
            base_date = datetime.now().strftime('%Y-%m-%d')
        else:
            base_date = sql

        if value != '':
            sql = '''
select * from
(select distinct code,pctChg,date from raw_draw_detail where  code like 'BK%' and date = '{dt}' order by pctChg desc limit  {top})
union
select * from
(select distinct code,pctChg,date from raw_draw_detail where  code not like 'BK%' and date = '{dt}' order by pctChg desc limit  {top})     
'''.format(top=value,dt=base_date)
            top_codes = list(query(sql, conn)['code'].values)
        else:
            top_codes = []
        return top_codes

def filterProperty(df,key,value):
    if value != 'all':
        df =  df[df[key] == value].copy()
    return df
def appendSQL(request,conn):
    golden_code = request.form['golden_code']

    base_date = request.form['base_date']
    if base_date == '':
        base_date = datetime.now().strftime('%Y-%m-%d')

    sql = '''
       select max(d1) as d,cls,x1,x6, ag_4341, ag_4241, ag_4313, ag_4212, ag_4131, ag_4221, ag_1232, ag_41x, ag_42x, ag_43x, ag_12x, ag_13x, ag_32x
        from raw_draw_sum
       where code = '{code}' and date(d1) <= date('{dt}')
       '''.format(code=golden_code,dt=base_date)
    df = query(sql,conn)
    line = dict(df.iloc[0])
    print(sql)
    cd = '''
    and cls = '{cls}' and x1 = '{x1}' and x6 = '{x6}'
    '''.format(cls=line['cls'],x1=line['x1'],x6=line['x6'])
    cols = ['ag_41x' ,'ag_42x'  ,'ag_43x'  ,'ag_12x'  ,'ag_13x' ,'ag_32x'
    ,'ag_4341' ,'ag_4241' ,'ag_4313' ,'ag_4212' ,'ag_4131' ,'ag_4221']
    cds = [cd]
    for col in cols:
        spec = request.form[col]

        if spec != '':
            val = line[col]
            spec = float(spec)
            u,l = val + spec,val - spec
            cd1= '''
            {col} >= {l} and {col} <= {u}
            '''.format(col=col,l=l,u=u)
            cds.append(cd1)
    return " and ".join(cds)

@app.route('/', methods=['POST'])
def add_code():
    #hist_img_conn = getConn(dest_file_hists_img)
    dest_file_hists = r"D:\data\0_g\ana_sum_datas_newses2023_draw"
    dest_file_hists_img = r"D:\data\0_g\ana_db_test_backs_hists_img"
    hist_conn = getConn(dest_file_hists)
    hist_img_conn = getConn(dest_file_hists_img)
    append_conditon = request.form['append_conditon']
    if append_conditon == 'Y':
        append_sql = appendSQL(request,hist_conn)
    else:
        append_sql = None
    sql = request.form['sql']
    if append_sql is not None:
        sql = sql + append_sql
    top = request.form['top']
    nday = request.form['nday']

    cls = request.form['cls']
    code = request.form['code']
    hycode = request.form['hycode']
    base_date = request.form['base_date']
    strong_cls = request.form['strong_cls']
    if strong_cls != 'all':
        cdses = strong_cls.split(",")[0].split("#")
        acdses = '''
        and cls = '{cls}' and x1 = '{x1}' and x6 = '{x6}' 
        '''.format(cls=cdses[0],x1=cdses[1],x6=cdses[2])
        sql = sql + acdses
    print(sql)

    e_codes   = putProperties('hycode',hist_conn,hycode)
    e_hycodes = putProperties('code',hist_conn,code)
    name_map = putProperties('put_name',hist_conn)
    sql,pct_map = putProperties('base_date',hist_conn,base_date,sql)
    if nday != '':
        top_codes = putProperties('top_Ndays',hist_conn,top,base_date,nday)
    else:
        top_codes = putProperties('top', hist_conn, top, base_date)
    print(sql)
    df = query(sql,hist_conn)
    if len(e_codes) >0:
        df = df[df.code.isin(e_codes)]
    if len(e_hycodes) > 0:
        df = df[df.code.isin(e_hycodes)]
    if len(top_codes) > 0:
        df = df[df.code.isin(top_codes)]

    x1 = request.form['x1']
    x2 = request.form['x2']
    x3 = request.form['x3']
    x4 = request.form['x4']
    x5 = request.form['x5']
    x6 = request.form['x6']
    df = filterProperty(df,'x1',x1)
    df = filterProperty(df,'x2',x2)
    df = filterProperty(df,'x3',x3)
    df = filterProperty(df,'x4',x4)
    df = filterProperty(df,'x5',x5)
    df = filterProperty(df,'x6',x6)
    df = filterProperty(df,'cls',cls)
    print("#############################")

    cds = list(df['outf'].values)
    cd = ",".join(list(map(lambda x: "'%s'" % (x), cds)))
    sql = '''
            select data,outf,code from raw_show_img_mapping where outf in ({cd})
            '''.format(cd=cd)
    rdf = query(sql, hist_img_conn)
    print("############################# %s %s" % (len(df), len(rdf)))
    try:
        imgs = list(rdf[['data', 'outf','code']].values)
        nlines = []
        for i in range(len(imgs)):
            line = imgs[i]
            data = line[0]
            outf = line[1]
            code = line[-1]

            try:
                score = pct_map[code]
            except:
                score = 0
            try:
                name = name_map[code]
                n_name = '%s#%s#' %(name,score) + outf
            except:
                n_name = code
                pass
            nlines.append([data,n_name,score])
        nlines.sort(key=lambda x: x[-1],reverse=True)
        log = 'code:(%s) hycode:(%s) cls:(%s) base_date(%s) x1:(%s) x6:(%s)' %(code,hycode,cls,base_date,x1,x6)
        return render_template('index1.html', var1=x1, var2=log, var3='', var4='', plot_url=nlines)
    except:
        import traceback
        traceback.print_exc()
        return render_template('index4.html', message='inputs false!!!', var1='nday', var2='wave_type', var3='start', var4='end')


if __name__ == '__main__':
    app.run(port=8001)