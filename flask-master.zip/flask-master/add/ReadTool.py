import pandas as pd
df = pd.read_csv(r'D:\data\bishow\txts\show_kpis\2023_test_data\analysis_info_ai1.csv')
df.columns
df = df[df['ndays'] == '0'].copy()
df = df[df['wave_type'] == 'aInfos'].copy()
cols = [
'score_0'
,'ccnt'
,'ccnt_sp'
,'ccnt_spa'
,'over_cnts_t'
,'over_cnts_l'
,'h_rate']
cols = ['ccnt']
def scoreAinfoFormat(df):
    df['ccnt'].apply(lambda x:0 if x<=0 else x if x > 20 else 20)
for col in cols:
    score_lcl = 0
    score_ucl = 20
    dfs = df.groupby(col)
    rline = []
    for val,idf in dfs:
        rline.append([val,len(idf)])
        print("%s %s" %(val,len(idf)))
