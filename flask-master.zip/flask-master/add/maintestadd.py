from add import *
c = sum_function(6, 9)
print (c)
