def sum_function(a, b):
    c = a + b
    return c