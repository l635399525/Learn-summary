import numpy as np
from flask import Flask, render_template, request, url_for
from sin import *
import matplotlib.pyplot as plt
import io
import base64
import numpy as np
from sin.DbTool import getConn,query
import math
app = Flask(__name__)
#from DbTool import getConn,query
dest_file_hists = r'D:\data\0_g\ana_db_2024_img'
hist_conn = getConn(dest_file_hists)

df_raw = query('select distinct merge_files,outf_merge,code,data_merge as data_realtime,data_code as data_bycode from raw_img_b64_data_lst',hist_conn)
print('################%s' %('df_raw'))
#df_raw_wids = query('select distinct merge_files,data from raw_img_merge_b64_data',hist_conn)
df_raw_codes = query('select type, code, date, fn, file, data from raw_img_b64_data_code',hist_conn)

print('################%s' %('df_raw_codes'))

df_raw_code_full = query('select * from raw_img_b64_data_code_full',hist_conn)
print('################%s' %('df_raw_code_full'))

@app.route('/', methods=['GET'])
def home():
    return render_template('index4.html')

@app.route('/codes', methods=['GET'])
def codes():
    dest_file_hists = r'D:\data\0_g\ana_db_2024_img'
    hist_conn = getConn(dest_file_hists)
    codes = list(query('select code,c_w_edir|| code || w_ids || log_pcw_br as log from raw_img_b64_data_lst', hist_conn)[['code','log']].values)
    #codes = list(map(lambda x:[x],codes))
    codes.sort(key=lambda x: x[0])
    return render_template('index4_code.html',plot_url=codes)
@app.route('/wids', methods=['GET'])
def wids():
    dest_file_hists = r'D:\data\0_g\ana_db_2024_img'
    hist_conn = getConn(dest_file_hists)
    df = query('select distinct merge_files,code from raw_img_b64_data_lst', hist_conn)[['merge_files','code']]
    dfs = df.groupby('merge_files')
    lsts = []
    num = 0
    for code,idf in dfs:
        num = num + 1
        cds = idf.code.values
        cds_es = np.array_split(cds, math.ceil(len(idf) / 10))
        for cd in cds_es:
            cds = ",".join(list(cd))
            lsts.append([code.split("\\")[-1].replace("#","%23"),"%s：" %(num) + code.split("\\")[-1].split(".")[0] + "\n" + cds])
    lsts.sort(key=lambda x: x[0])
    return render_template('index4_code.html',plot_url=lsts)

@app.route('/wids_hist', methods=['GET'])
def wids_hist():
    dest_file_hists = r'D:\data\0_g\ana_db_2024_img'
    hist_conn = getConn(dest_file_hists)
    df = query('select distinct type as merge_files,code from raw_img_b64_data_code', hist_conn)[['merge_files','code']]
    dfs = df.groupby('merge_files')
    lsts = []
    num = 0
    for code,idf in dfs:
        num = num + 1
        cds = idf.code.values
        cds_es = np.array_split(cds, math.ceil(len(idf) / 10))
        for cd in cds_es:
            cds = ",".join(list(cd))
            lsts.append([code.split("\\")[-1].replace("#","%23"),"%s：" %(num) + code.split("\\")[-1].split(".")[0] + "\n" + cds])
    lsts.sort(key=lambda x: x[0])
    return render_template('index4_code_hist.html',plot_url=lsts)


@app.route('/code_lst', methods=['GET','POST'])
def code_lst():
    sql = request.args['code']
    lsts = []
    if sql.endswith(".jpg"):
        #df_raw_wids_sub = df_raw_wids[df_raw_wids['merge_files'].apply(lambda x:sql in x)]
        #wids_line = dict(df_raw_wids_sub.iloc[-1])
        #lsts.append([wids_line['data'],sql])
        df_raw_sub = df_raw[df_raw['outf_merge'].apply(lambda x:sql.split(".")[0] in x)]
        df_raw_subs = df_raw_sub.groupby('outf_merge')
        for key, idf in df_raw_subs:
            lsts.append([dict(idf.iloc[-1])['data_realtime'], key])
        for i in range(len(df_raw_sub)):
            rline = dict(df_raw_sub.iloc[i])
            lsts.append([rline['data_bycode'], "%s_code" % (rline['code'])])
    else:
        df_raw_sub = df_raw[df_raw['code'].apply(lambda x:str(x).endswith(sql))]
        for i in range(len(df_raw_sub)):
            rline = dict(df_raw_sub.iloc[i])
            lsts.append([rline['data_bycode'], "%s_code" % (rline['code'])])
        key = df_raw_sub['outf_merge'].values[-1]
        key = "#".join(list(str(key).split("\\")[-1].split("#")[:2]))
        df_raw_key = df_raw[df_raw['outf_merge'].apply(lambda x:key in x)]
        df_raw_keys = df_raw_key.groupby('outf_merge')

        for ikey, idf in df_raw_keys:
            lsts.append([dict(idf.iloc[-1])['data_realtime'], ikey])

    # df_raw_subs = df_raw_sub.groupby('outf_merge')
    # for key, idf in df_raw_subs:
    #     lsts.append([dict(idf.iloc[-1])['data_realtime'], key])
    # for i in range(len(df_raw_sub)):
    #     rline = dict(df_raw_sub.iloc[i])
    #     lsts.append([rline['data_bycode'], "%s_code" % (rline['code'])])
    # try:
    #     lsts.sort(key=lambda x: x[1].split("#")[-1])
    # except:
    #     lsts = []
    return render_template('index1.html', var1='nday', var2='wave_type', var3='start', var4='end', var5='code', plot_url=lsts)

    #hist_img_conn = getConn(dest_file_hists_img)
        # dest_file_hists = r'D:\data\0_g\ana_db_2024_img'
        # hist_conn = getConn(dest_file_hists)
        # sql = 'select merge_files,data from raw_img_merge_b64_data'
        # df = query(sql,hist_conn)
        # try:
        #     imgs = list(df[['data', 'merge_files']].values)
        #     imgs.sort(key=lambda x: x[1].split("#")[-1])
        # except:
        #     imgs = []
        # return render_template('index1.html', var1='nday', var2='wave_type', var3='start', var4='end', var5='code', plot_url=imgs)
        # print(sql)

@app.route('/code_lst_hist', methods=['GET','POST'])
def code_lst_hist():
    sql = request.args['code']
    df_raw_sub = df_raw_codes[df_raw_codes['type'] == sql]
    lsts = []
    for i in range(len(df_raw_sub)):
        rline = dict(df_raw_sub.iloc[i])
        dt = dict(df_raw_code_full[df_raw_code_full['code'] == rline['code']].iloc[-1])['data']
        lsts.append([rline['data'], "%s" % (rline['file'])])
        lsts.append([dt, "%s" % (rline['file'])])
    lsts.sort(key=lambda x:x[-1].split("#")[-1],reverse=True)
    return render_template('index1_hist.html', var1='nday', var2='wave_type', var3='start', var4='end', var5='code', plot_url=lsts)

    #hist_img_conn = getConn(dest_file_hists_img)
        # dest_file_hists = r'D:\data\0_g\ana_db_2024_img'
        # hist_conn = getConn(dest_file_hists)
        # sql = 'select merge_files,data from raw_img_merge_b64_data'
        # df = query(sql,hist_conn)
        # try:
        #     imgs = list(df[['data', 'merge_files']].values)
        #     imgs.sort(key=lambda x: x[1].split("#")[-1])
        # except:
        #     imgs = []
        # return render_template('index1.html', var1='nday', var2='wave_type', var3='start', var4='end', var5='code', plot_url=imgs)
        # print(sql)


@app.route('/', methods=['POST'])
def add():
        #hist_img_conn = getConn(dest_file_hists_img)
        dest_file_hists = r''
        hist_conn = getConn(dest_file_hists)
        sql = request.form['sql']
        print(sql)



@app.route('/lst', methods=['GET','POST'])
def lst():
        #hist_img_conn = getConn(dest_file_hists_img)
        dest_file_hists = r'D:\data\0_g\ana_db_2024_img'
        hist_conn = getConn(dest_file_hists)
        sql = 'select merge_files,data from raw_img_merge_b64_data'
        df = query(sql,hist_conn)
        try:
            imgs = list(df[['data', 'merge_files']].values)
            imgs.sort(key=lambda x: x[1].split("#")[-1])
        except:
            imgs = []
        return render_template('index1.html', var1='nday', var2='wave_type', var3='start', var4='end', var5='code', plot_url=imgs)
        print(sql)
if __name__ == '__main__':
    app.run(port=8002)