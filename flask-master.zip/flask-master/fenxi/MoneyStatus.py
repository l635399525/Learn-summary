import pandas as pd
import numpy as np

from sin.DbTool import getConn, query
dest_file_hists = r"D:\data\0_g\ana_sum_datas_newses2023"
hist_conn = getConn(dest_file_hists)
class CodesInfo():
    def __init__(self):
        self.conn = getConn(dest_file_hists)
    def getRawData(self):
        sql = '''
        select * from raw_data where code = 'sh.600031'
        '''
        df = query(sql,self.conn)
        df['pclose'] = df.close.shift(1).values
        df['hr'] = df.apply(lambda x:round ((x['high'] - max(x['open'],x['close']))*100/x['pclose'],3),axis=1).values
        df['lr'] = df.apply(lambda x: round ((x['low'] - min(x['open'], x['close'])) * 100 / x['pclose'],3),axis=1).values
        df['br'] = df.apply(lambda x: round ((x['close'] - x['open']) * 100 / x['pclose'],3),axis=1).values
        df['zq_r0'] = df.apply(lambda x: round((x['hr']+x['br']+x['lr']),3),axis=1).values
        df['zq_r1'] = df.zq_r0.shift(1).values
        df['zq_r2'] = df.zq_r0.shift(2).values
        df['zq_r3'] = df.zq_r0.shift(3).values
        df['zq_r4'] = df.zq_r0.shift(4).values
        df = df.dropna()
        datas = df[['zq_r0', 'zq_r1', 'zq_r2', 'zq_r3', 'zq_r4']].values
        zq_3days = np.sum(datas[:,:3],axis=1)
        zq_5days = np.sum(datas, axis=1)
        df['zq_3days'] = zq_3days
        df['zq_5days'] = zq_5days

        zq0 = df.zq_r0.values.copy()
        zq0[zq0 > 0] = 1
        zq0[zq0 <= 0] = 0
        zq1 = df.zq_r1.values.copy()
        zq1[zq1 > 0] = 1
        zq1[zq1 <= 0] = 0

        zq2 = df.zq_r2.values.copy()
        zq2[zq2 > 0] = 1
        zq2[zq2 <= 0] = 0
        zq3 = df.zq_r3.values.copy()
        zq3[zq3 > 0] = 1
        zq3[zq3 <= 0] = 0
        zq4 = df.zq_r4.values.copy()
        zq4[zq4 > 0] = 1
        zq4[zq4 <= 0] = 0

        tdf = pd.DataFrame(columns=['zq0'],data=zq0)
        tdf['zq1'] = zq1
        tdf['zq2'] = zq2
        tdf['zq3'] = zq3
        tdf['zq4'] = zq4
        sum_a = np.sum(tdf[['zq0', 'zq1', 'zq2', 'zq3', 'zq4']].values, axis=1)/5

        print(df)
if __name__ == '__main__':
    ci = CodesInfo()
    ci.getRawData()