import numpy as np
import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_OLD, RAW_HLS_WORK_FILE_HIST, dest_summary_path

an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA_POINTS")
def getPointCls():
    sql = '''
    select code, work_date,ndate, nh - ph as pny,nh - ch as cny,  d_a, d_b,  a_c, polor_c, polor_n
,case when nh - ch > 0 then 1 else 0 end as t
from raw_data_ana_cnts_point where work_date = ndate 
    '''
    df = query(sql,an_conn)
    def _getClsDt(v):
        a = [0,21,55,144,377,999]
        ar = None
        br = None
        for i in range(1,len(a)):
            lcl = a[i-1]
            ucl = a[i]
            if ar is not None:
                continue
            if lcl <= v and ucl > v:
                ar = i
        b = [0,34,89,233,999]
        for i in range(1,len(b)):
            lcl = b[i-1]
            ucl = b[i]
            if br is not None:
                continue
            if lcl <= v and ucl > v:
                br = i
        return ar,br
    def _getClsAg(v):
        a = [0 ,45 ,90 ,135 ,180]
        ar = None
        br = None
        for i in range(1, len(a)):
            lcl = a[i - 1]
            ucl = a[i]
            if ar is not None:
                continue
            if lcl <= v and ucl > v:
                ar = i
        b = [0 ,60 ,120 ,180]
        for i in range(1, len(b)):
            lcl = b[i - 1]
            ucl = b[i]
            if br is not None:
                continue
            if lcl <= v and ucl > v:
                br = i
        return ar, br
    df['dt_a_cla'] = df.apply(lambda x:_getClsDt(x['d_a'])[0],axis=1)
    df['dt_a_clb'] = df.apply(lambda x: _getClsDt(x['d_a'])[1], axis=1)
    df['dt_b_cla'] = df.apply(lambda x: _getClsDt(x['d_b'])[0], axis=1)
    df['dt_b_clb'] = df.apply(lambda x: _getClsDt(x['d_b'])[1], axis=1)
    df['a_c_cla'] = df.apply(lambda x: _getClsAg(x['a_C'])[0], axis=1)
    df['a_c_clb'] = df.apply(lambda x: _getClsAg(x['a_C'])[1], axis=1)
    dfs = df.groupby('code')
    odfs = []
    for code,idf in dfs:
        idf = idf.sort_values(by=['ndate'])
        idf['cny1'] = idf.cny.shift(-1).values
        idf['cny2'] = idf.cny.shift(-2).values
        for i in range(0,3,2):
            idf['d_a_%s' % (i)] = idf.d_a.shift(i).values
            idf['d_b_%s' % (i)] = idf.d_b.shift(i).values
            idf['a_c_%s' % (i)] = idf.a_C.shift(i).values
        odfs.append(idf)
    rdf = pd.concat(odfs)
    insert(rdf,an_conn,'raw_data_ana_cnts_point_cls')
def _getPN10Datas():
    SQL = '''
    select  code, work_date, ndate, pny, cny, cny1, cny2,t,
       dt_a_cla|| dt_a_clb as dt_a_cls,
       dt_b_cla|| dt_b_clb as dt_b_cls,
       a_c_cla || a_c_clb  as ac_cls,
       dt_a_cla|| dt_a_clb||dt_b_cla|| dt_b_clb||a_c_cla || a_c_clb||t as cls 
        from raw_data_ana_cnts_point_cls
    '''
    #an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(SQL, an_conn)
    dfs = df.groupby('code')
    rdfs = []
    for code, idf in dfs:
        idf = idf.sort_values(by=['work_date'])
        rdf = idf[['code', 'work_date', 'ndate', 't', 'pny', 'cny', 'cny1', 'cny2']]
        for i in range(0, 10):
            rdf['dt_a_cls_%s' % (i)] = idf['dt_a_cls'].shift(i).values
            rdf['dt_b_cls_%s' % (i)] = idf['dt_a_cls'].shift(i).values
            rdf['ac_cls_%s' % (i)] = idf['ac_cls'].shift(i).values
            rdf['cls_%s' % (i)] = idf['cls'].shift(i).values

        rdfs.append(rdf)
        print("%s %s" % (code, len(rdfs)))
    rdf = pd.concat(rdfs)
    insert(rdf, an_conn, 'raw_data_ana_cnts_point_cls_pn')
    #print(1)
def analysisOvers(score=89):
    sql = '''
     select t,a.cls_0 as cls,acnt,cnts,acnt*1.0/cnts as ar from
(select 'A' as t, cls_0,count(*) as acnt from raw_data_ana_cnts_point_cls_pn
where  dt_a_cls_9 is not null  and t = 0 and cny1 >= {score} group by cls_0
union
select 'B' as t,cls_0,count(*) as acnt from raw_data_ana_cnts_point_cls_pn
where  dt_a_cls_9 is not null  and t = 1 and cny1 <= -1*{score} group by cls_0) a,
(select cls_0,count(*) as cnts from raw_data_ana_cnts_point_cls_pn group by cls_0) b
where a.cls_0 = b.cls_0
    '''.format(score=score)
    #an_conn = getConn(dest_summary_path + "/RAW_HLWAVES_DATA_HISTORYSES_ANA")
    df = query(sql,an_conn)
    rdfs = []
    for i in range(len(df)):

        line = dict(df.iloc[i])
        print("%s %s" %(i,line))
        tt = line['t']
        if tt == 'A':
            sql = '''
            select cls as n_cls,t
                ,sum(af1+af2+af3+af4+af5) as afs5
                ,sum(af1+af2+af3+af4+af5+af6+af7) as afs7
                ,sum(af1+af2+af3+af4+af5+af6+af7+af8+af9) as afs9
                from
                (select      cls_0 as cls,'A' as t,
                   case when cls_1 == '{c}' then 1 else 0 end as af1,
                   case when cls_2 == '{c}' then 1 else 0 end as af2,
                   case when cls_3 == '{c}' then 1 else 0 end as af3,
                   case when cls_4 == '{c}' then 1 else 0 end as af4,
                   case when cls_5 == '{c}' then 1 else 0 end as af5,
                   case when cls_6 == '{c}' then 1 else 0 end as af6,
                   case when cls_7 == '{c}' then 1 else 0 end as af7,
                   case when cls_8 == '{c}' then 1 else 0 end as af8,
                   case when cls_9 == '{c}' then 1 else 0 end as af9
                   from raw_data_ana_cnts_point_cls_pn where   cny1 >= {score})
                group by cls
                '''.format(c = line['cls'],score=score)
        else:
            sql = '''
            select cls as n_cls,'B' as t
                ,sum(af1+af2+af3+af4+af5) as afs5
                ,sum(af1+af2+af3+af4+af5+af6+af7) as afs7
                ,sum(af1+af2+af3+af4+af5+af6+af7+af8+af9) as afs9
                from
                (select cls_0 as cls,t,
                   case when cls_1 == '{c}' then 1 else 0 end as af1,
                   case when cls_2 == '{c}' then 1 else 0 end as af2,
                   case when cls_3 == '{c}' then 1 else 0 end as af3,
                   case when cls_4 == '{c}' then 1 else 0 end as af4,
                   case when cls_5 == '{c}' then 1 else 0 end as af5,
                   case when cls_6 == '{c}' then 1 else 0 end as af6,
                   case when cls_7 == '{c}' then 1 else 0 end as af7,
                   case when cls_8 == '{c}' then 1 else 0 end as af8,
                   case when cls_9 == '{c}' then 1 else 0 end as af9
                   from raw_data_ana_cnts_point_cls_pn where   cny1 <= -1*{score})
                group by cls
                '''.format(c=line['cls'], score=score)
        rdf = query(sql, an_conn)
        rdf['p_acnt'] = line['acnt']
        rdf['p_cnts'] = line['cnts']
        rdf['p_ar']   = line['ar']
        rdf['p_cls']  = line['cls']
        rdfs.append(rdf)
    df = pd.concat(rdfs)
    insert(df, an_conn, 'ClsChange_ana_ab_over%s_points' % (score))
def _analysisOversSums(type='points'):
    table3 = 'ClsChange_ana_ab_over89_%s' %(type)
    table4 = 'ClsChange_ana_ab_over144_%s' %(type)
    table5 = 'ClsChange_ana_ab_over203_%s' %(type)
    table_raw = 'ClsChange_%s' %(type)
    sql = '''
    select cls,
afs5_3, afs7_3, afs9_3,
afs5_4, afs7_4, afs9_4,
afs5_5, afs7_5, afs9_5, cnt,
ar5_3, ar7_3, ar9_3,
ar5_4, ar7_4, ar9_4,
ar5_5, ar7_5, ar9_5,
round(ar5_3*afs5_3,2) as kpi5_3, round(ar7_3*afs7_3,2) as kpi7_3, round(ar9_3*afs9_3,2) as kpi9_3,
round(ar5_4*afs5_4,2) as kpi5_4, round(ar7_4*afs7_4,2) as kpi7_4, round(ar9_4*afs9_4,2) as kpi9_4,
round(ar5_5*afs5_5,2) as kpi5_5, round(ar7_5*afs7_5,2) as kpi7_5, round(ar9_5*afs9_5,2) as kpi9_5
from
(select a.cls, afs5_3, afs7_3, afs9_3, afs5_4, afs7_4, afs9_4, afs5_5, afs7_5, afs9_5, cnt
, round(afs5_3*ar3*1.0/cnt,5) as ar5_3
, round(afs7_3*ar3*1.0/cnt,5) as ar7_3
, round(afs9_3*ar3*1.0/cnt,5) as ar9_3
, round(afs5_4*ar4*1.0/cnt,5) as ar5_4
, round(afs7_4*ar4*1.0/cnt,5) as ar7_4
, round(afs9_4*ar4*1.0/cnt,5) as ar9_4
, round(afs5_5*ar5*1.0/cnt,5) as ar5_5
, round(afs7_5*ar5*1.0/cnt,5) as ar7_5
, round(afs9_5*ar5*1.0/cnt,5) as ar9_5
from
(select p_cls as cls
      ,sum(afs5) as afs5_3
      ,sum(afs7) as afs7_3
      ,sum(afs9) as afs9_3
 from {table3} group by p_cls) a,
(select p_cls as cls
      ,sum(afs5) as afs5_4
      ,sum(afs7) as afs7_4
      ,sum(afs9) as afs9_4
 from {table4} group by p_cls) b,
(select p_cls as cls
      ,sum(afs5) as afs5_5
      ,sum(afs7) as afs7_5
      ,sum(afs9) as afs9_5
 from {table5} group by p_cls) c,
(select a.cls, ar3, ar4,
       case when ar5 is null then ar4 else ar5 end as ar5
       , a.cnt from
(select a.cls,ar3,
        case when ar4 is null then ar3 else ar4 end as ar4
        ,a.cnts as cnt from
(select distinct p_cls as cls ,p_ar as ar3,p_cnts as cnts from {table3})  a
left outer join
(select distinct p_cls as cls ,p_ar as ar4,p_cnts as cnts from {table4}) b
on a.cls = b.cls) a left outer join
(select distinct p_cls as cls ,p_ar as ar5,p_cnts as cnts from {table5}) c
on a.cls = c.cls) d
where a.cls = b.cls and a.cls = c.cls and a.cls = d.cls)
    '''.format(table3=table3,table4=table4,table5=table5,table_raw=table_raw)
    print(sql)
    df = query(sql, an_conn)
    insert(df, an_conn, 'ClsChange_ana_ab_overs_%s' %(type))

if __name__ == '__main__':
    #_getPN10Datas()
    #analysisOvers(89)
    #analysisOvers(144)
    #analysisOvers(203)
    _analysisOversSums()
