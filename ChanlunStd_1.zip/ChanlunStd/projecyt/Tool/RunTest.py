import os.path

import pandas as pd

from czsc import CZSC
from czsc.utils import kline_pro

from projecyt.Tool.CZSCTool import getNewBars,getBIs,get_zs_seq,drawImage
from projecyt.Tool.QueryTool import CzscDB
from dataclasses import asdict
if __name__ == '__main__':

    czz = CzscDB()
    bars_map = czz.getRawData()
    rlines = []
    num = 0
    for symbol,bars in bars_map.items():
        num = num + 1
        try:
            if False:
                file_html = r"D:\codes\chanlun_bis_charts\%s_Daily.html" %(symbol)
                if os.path.exists(file_html):
                    continue
                c = CZSC(bars)
                print('%s %s' %(num,file_html))
                drawImage(c,file_html)
            #continue
            nbars,fxses = getNewBars(bars)
            bis = getBIs(nbars)
            for bi in bis:
                rline = {'code':bi.symbol}
                rline['diretion'] = bi.direction.name
                rline['edt'] = bi.edt
                rline['sdt'] = bi.sdt
                rline['change'] = bi.change
                rline['high'] = bi.high
                rline['low']  = bi.low
                rline['length'] = bi.length
                rline['power']         = bi.power
                rline['power_price']   = bi.power_price
                rline['power_volume']  = bi.power_volume
                rline['rsq']           = bi.rsq
                rline['power_price']   = bi.power_price
                rlines.append(rline)
            print("%s %s %s" %(symbol,num,len(bars_map)))
        except:
            import traceback
            traceback.print_exc()
            pass
        #zses = get_zs_seq(bis)
    df = pd.DataFrame(rlines)
    czz.putRawData(df,'raw_bi_infos')