from projecyt.Tool.QueryTool import CzscDB
if __name__ == '__main__':
    czz = CzscDB()
    #czz.putBiClsData()
    #czz.getXianDuansLst()
    czz.putXDData()