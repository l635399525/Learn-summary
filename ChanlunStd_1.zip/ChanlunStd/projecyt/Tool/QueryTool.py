from com.DbTool import getConn,query,insert
from com.RunConf import RAW_HLS_WORK_FILE_HIST_TRAIN,RAW_HLS_WORK_FILE_HIST_TRAIN_CZSC
from czsc import Freq
from czsc.objects import RawBar
import pandas as pd
class CzscDB():
    #r'D:\data\summary_db\2022\RAW_HLWAVES_DATA_HISTORYS'
    #r'D:\data\summary_db\RAW_HLWAVES_DATA'
    def __init__(self,srcs_file=r'D:\data\summary_db\2022\RAW_HLWAVES_DATA_HISTORYS',dest_file=RAW_HLS_WORK_FILE_HIST_TRAIN_CZSC):
        self.src_conn = getConn(srcs_file)
        self.des_conn = getConn(dest_file)
    def getSymbols(self,table='raw_bi_infos',col='code'):
        sql = '''
        select distinct {col} from {table} limit 10000
        '''.format(table=table,col=col)
        codes = list(query(sql,self.des_conn)[col].values)
        return codes
    def getRawData(self):
        sql = '''
        select code as symbol, date as dt, open, close, high, low, percent as pctchg, 100 as vol from raw_data_d_hist where
        --code = 'sh.600031' and
        date(date) > date('2010-01-01')
        '''
        # sql = '''
        #         select code as symbol, date as dt, open, close, high, low, pctchg, volume as vol from raw_data_d where
        #         --code = 'sh.600031' and
        #         date(date) > date('2010-01-01')
        #         '''
        df = query(sql,self.src_conn)
        #insert(df, self.des_conn, 'raw_data_d')
        dfs = df.groupby('symbol')
        bars_map = {}
        for symbol,idf in dfs:
            kline = idf.sort_values(by='dt')
            kline.loc[:, "dt"] = pd.to_datetime(kline.dt)
            bars = [RawBar(symbol=row['symbol'], id=i, freq=Freq.D, open=row['open'], dt=row['dt'],
                           close=row['close'], high=row['high'], low=row['low'], vol=row['vol'])
                    for i, row in kline.iterrows()]
            bars_map[symbol] = bars
        return bars_map
    def _getBiRawDataPN(self,symbol,n=9):
        sql = '''
        select code, diretion, edt, sdt, change, high, low, length,
       power, power_price, power_volume, rsq from raw_bi_infos where code = '{code}'
        '''.format(code=symbol)
        df = query(sql,self.des_conn)
        dfs = df.groupby('code')
        odfs = []
        for symbol,idf in dfs:
            kline = idf.sort_values(by='edt')
            cols = ['high', 'low', 'length']
            for col in cols:
                for i in range(1,n):
                    kline['%s_%s' %(col,i)] = kline[col].shift(i).values
            kline = kline.dropna()
            odfs.append(kline)
        rdf = pd.concat(odfs)
        rdf.sort_values(by=['edt'])
        #insert(rdf,self.des_conn,'raw_tmp_data')
        return rdf
    def _getBiClass(self,x):
        def _getUpCls(chl, phl):
            pcv = phl / chl if chl >= phl else chl / phl
            pct = 'A' if chl >= phl else 'B'
            pct_cls = 3 if pcv > 0.618 else 1 if pcv < 0.382 else 2
            c_cls = 'U%s%s' % (pct, pct_cls)
            return c_cls

        def _getDownCls(chl, phl):
            pcv = chl / phl if chl <= phl else phl / chl
            pct = 'A' if chl <= phl else 'B'
            pct_cls = 1 if pcv > 0.618 else 3 if pcv < 0.382 else 2
            c_cls = 'D%s%s' % (pct, pct_cls)
            return c_cls

        hl_1  = (x['high'] - x['low'])
        hl_2  = (x['high_1'] - x['low_1'])
        hl_3  = (x['high_2'] - x['low_2'])
        hl_4  = (x['high_3'] - x['low_3'])
        hl_5  = (x['high_4'] - x['low_4'])

        if x['diretion'] == 'Up':
            c_cls = _getUpCls(hl_1, hl_2)
            p1_cls = _getDownCls(hl_2, hl_3)
            p2_cls = _getUpCls(hl_3, hl_4)
            p3_cls = _getDownCls(hl_4, hl_5)

        else:
            c_cls = _getDownCls(hl_1, hl_2)
            p1_cls = _getUpCls(hl_2, hl_3)
            p2_cls = _getDownCls(hl_3, hl_4)
            p3_cls = _getUpCls(hl_4, hl_5)

        #print("%s %s %s %s %s" %(hl_1,hl_2,hl_3,c_cls,p_cls))
        cls = '%s#%s#%s#%s' % (c_cls,p1_cls,p2_cls,p3_cls)
        return cls
    def getBiRawDataPNCls(self,symbol):
        df = self._getBiRawDataPN(symbol)
        cls = list(df.apply(lambda x: self._getBiClass(x), axis=1).values)
        df['c_cls'] = list(map(lambda x:str(x).split("#")[0],cls))
        df['p1_cls'] = list(map(lambda x:str(x).split("#")[1],cls))
        df['p2_cls'] = list(map(lambda x:str(x).split("#")[2],cls))
        df['p3_cls'] = list(map(lambda x:str(x).split("#")[3],cls))
        #insert(df,self.des_conn,'raw_tmp_data')
        df = df.sort_values(by=['edt'])
        return df
    def putRawData(self,df,table,ot='replace'):
        insert(df,self.des_conn,table,opType=ot)
    def putBiClsData(self):
        codes = self.getSymbols()
        odfs = []
        for idx,code in enumerate(codes):
            try:
                df = self.getBiRawDataPNCls(code)
                if len(df) > 0:
                    odfs.append(df)
            except:
                pass
            print("%s %s %s" %(idx + 1,code,len(codes)))
        rdf = pd.concat(odfs)
        insert(rdf,self.des_conn,'raw_bi_cls')
    def _getBiData(self,code):
        sql = '''
        select code, diretion, edt, sdt, change, high, low, length, power, power_price, power_volume, rsq from raw_bi_infos 
        where code = '{symbol}'
        '''.format(symbol=code)
        df = query(sql,self.des_conn)
        return df
    def getXianDuansLst(self,symbol):
        bis_ = []
        rlines = []
        df = self._getBiData(symbol)
        df = df.sort_values(by=['edt'])
        fdf = df.copy()

        #df.apply(lambda x:1 if x['diretion'] == 'Up' else x[])
        df['high1'] = df['high'].shift(1)
        df['high2'] = df['high'].shift(2)
        df['high3'] = df['high'].shift(3)
        df['high4'] = df['high'].shift(4)

        df['low1']  = df['low'].shift(1)
        df['low2']  = df['low'].shift(2)
        df['low3']  = df['low'].shift(3)
        df['low4']  = df['low'].shift(4)

        fdf['high_p']  = df.apply(lambda x: x['high1'] if x['diretion'] == 'Up'   else x['high2'],axis=1).values
        fdf['lows_p']  = df.apply(lambda x: x['low1'] if  x['diretion'] == 'Down' else x['low2'], axis=1).values
        fdf['high_pp'] = df.apply(lambda x: x['high3'] if x['diretion'] == 'Up'   else x['high4'], axis=1).values
        fdf['lows_pp'] = df.apply(lambda x: x['low3'] if  x['diretion'] == 'Down' else x['low4'], axis=1).values

        fdf = fdf.dropna()
        lines = fdf.to_dict("records")
        xds = []
        type = 'Normal'
        for i in range(len(lines)):
            bi = lines[i]
            bis_.append(bi)
            if type == 'Normal':
                spec = 6
            else:
                spec = 3
            if len(bis_) < spec:
                continue
            hbis = bis_[:3]
            last_bi_h = hbis[-1]
            h_direction = last_bi_h['diretion']
            last_bi_f  = bis_[-1]
            f_direction = last_bi_f['diretion']
            j_ups = len(list(filter(lambda x: x['low']  > x['high_p'], bis_[3:])))
            j_dws = len(list(filter(lambda x: x['high'] < x['lows_p'], bis_[3:])))
            #向下 跳空 取 向下
            #向上 跳空 取 向上
            if type == 'up_jump_down':

                lst_down = list(filter(lambda x:x['diretion'] == 'Down',bis_))
                lst_down_last_n = lst_down[-1]['low'] < lst_down[-1]['lows_p'] and lst_down[-1]['high'] < lst_down[-1]['high_p']
                lst_down_last_c = lst_down[-2]['low'] > lst_down[-2]['lows_p'] and lst_down[-2]['high'] > lst_down[-2]['high_p']
                if lst_down_last_n and lst_down_last_c:
                    xds.append(XD('Up', bis_, type))
                    type = 'Normal'
                    bis_ = []
                continue
            if   h_direction == 'Up'   and j_dws > 0 and type == 'Normal':
                # 查找顶分型 看下跌
                idx = None
                for i in range(len(bis_)-1,3,-1):
                    if bis_[i]['high'] < bis_[i]['lows_p']:
                        tbis_ = bis_[:i-1]
                        if len(tbis_) > 2:
                            xds.append(XD('Up',tbis_,'N'))
                        idx = i
                bis_ = bis_[idx-1:]
                type = 'up_jump_down'
                continue
            elif h_direction == 'Up'   and j_ups > 0 and type == 'Normal':
                # 查找底分型 看上涨
                lst_up = list(filter(lambda x: x['diretion'] == 'Up', bis_))
                lst_up_last_n = lst_up[-1]['low'] > lst_up[-1]['lows_p'] and lst_up[-1]['high'] > lst_up[-1]['high_p']
                lst_up_last_c = lst_up[-2]['low'] < lst_up[-2]['lows_p'] and lst_up[-2]['high'] < lst_up[-2]['high_p']
                if lst_up_last_c and lst_up_last_n:
                    type = 'up_jump_up'
                    xds.append(XD('Up', bis_, type))
                    type = 'Normal'
                    bis_ = []
                continue
            elif h_direction == 'Down' and j_dws > 0 and type == 'Normal':
                # 查找顶分型 看下跌
                lst_down = list(filter(lambda x: x['diretion'] == 'Down', bis_))
                lst_down_last_n = lst_down[-1]['low'] < lst_down[-1]['lows_p'] and lst_down[-1]['high'] < lst_down[-1]['high_p']
                lst_down_last_c = lst_down[-2]['low'] > lst_down[-2]['lows_p'] and lst_down[-2]['high'] > lst_down[-2]['high_p']
                if lst_down_last_c and lst_down_last_n:
                    type = 'down_jump_down'
                    xds.append(XD('Down', bis_, type))
                    type = 'Normal'
                    bis_ = []
                continue
            elif h_direction == 'Down' and j_ups > 0 and type == 'Normal':
                ###################on going##################
                idx = None
                for i in range(len(bis_) - 1, 3, -1):
                    if bis_[i]['high'] < bis_[i]['lows_p']:
                        tbis_ = bis_[:i - 1]
                        if len(tbis_) > 2:
                            xds.append(XD('Up', tbis_, 'N'))
                        idx = i
                bis_ = bis_[idx - 1:]
                type = 'down_jump_up'
                continue
            else:
                if h_direction == 'Up' and f_direction == 'Down':
                    if j_ups == 0 and last_bi_f['high'] < last_bi_f['high_p'] and last_bi_f['low'] < last_bi_f['lows_p'] and last_bi_f['lows_p'] < last_bi_f['lows_pp']:
                        xds.append(XD('Up', bis_[:-3], 'N'))
                        bis_ = bis_[-3:]
                elif h_direction == 'Down' and f_direction == 'Up':
                    if j_dws == 0 and last_bi_f['high'] > last_bi_f['high_p'] and last_bi_f['low'] > last_bi_f['lows_p'] and last_bi_f['high_p'] > last_bi_f['high_pp']:
                        xds.append(XD('Down', bis_[:-3], 'N'))
                        bis_ = bis_[-3:]
                continue
            # if f_direction == 'Up' and j_ups > 0 :
            #     jump_t = 'A'
            # elif f_direction == 'Down' and j_dws > 0:
            #     jump_t = 'A'
            # else:
            #     jump_t = 'B'

        for xd in xds:
            sdt =  xd.bis[0]['sdt']
            edt = xd.bis[-1]['edt']
            length =  round(sum(list(map(lambda x:x['length'],xd.bis)))      ,3)
            rsqs =    round(sum(list(map(lambda x:x['rsq'],xd.bis)))         ,3)
            volumes = round(sum(list(map(lambda x:x['power_volume'],xd.bis))),3)
            high =    round(sum(list(map(lambda x: x['high'], xd.bis)))      ,3)
            low =     round(sum(list(map(lambda x: x['low'], xd.bis)))       ,3)
            bi_cnt = len(xd.bis)
            rline = {'code':symbol,'sdt':sdt,'edt':edt,'direction':xd.direction,'bi_cnt':bi_cnt
                     ,'rsq':rsqs,'volumes':volumes,'high':high,'low':low,'length':length,'jump_t':xd.jump_t}
            rlines.append(rline)
        rdf = pd.DataFrame(rlines)
        return rdf
    def putXDData(self):
        codes = self.getSymbols()
        odfs = []
        for idx,code in enumerate(codes):
            try:
                if code != 'sh.600016':
                    continue
                df = self.getXianDuansLst(code)
                if len(df) > 0:
                    odfs.append(df)
            except:
                import traceback
                traceback.print_exc()
                pass
            print("%s %s %s" %(idx + 1,code,len(codes)))
        rdf = pd.concat(odfs)
        insert(rdf,self.des_conn,'raw_data_xd')

class XD():
    def __init__(self,direct,bis,jump_t):
        self.bis = bis
        self.direction = direct
        self.jump_t = jump_t
# 线段 后面是 两笔
# 上升线段 - 第一笔未新高，后面也没新高并跌破前敌
#  下跌限度 - 第一笔