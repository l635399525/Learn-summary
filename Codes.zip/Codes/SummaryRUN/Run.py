from hl_tool.HLRawData import getHLWaveKData
from hl_tool.HLZSRawData import getZSHLWaveKData,getZSHLMergeData
from hl_tool.HlTool import getHLDataPN, getHLMergeData, getHLDailyDatas, getDrawLineDatas
from hl_tool.kmeans_tool.KmeansDailySummary import getKmeansDailyRawData, getKmeansDailyRawDataDetail,getHLSummaryPNDays
from hl_tool.kmeans_tool.KmeansTool import getOOCData, getKPIKmeans, getKmeansSummary, genGLevelMapping
from net_tool.RunNet import runDaily, runHLDaily
from net_tool.XueQiuTool_ZS import genZSXueQiuByCodeDataData

if __name__ == '__main__':
    # get data from net work

    if True:
        print('###############Raw Daily Data###########')
        runDaily('ak')
        print('###############Hl Daily Data###########')
        runHLDaily('eq')
        print('###############Zs Daily Data###########')
        genZSXueQiuByCodeDataData()

    #######################################wave data##################
    if True:
        # get hl data
        print('###############Hl Wave Data###########')
        getHLWaveKData()
        print('###############ZS Hl Wave Data########')
        getZSHLWaveKData()
        # get hl data pn
        print('#############Hl Wave pn Data##########')
        getHLDataPN()
    if True:
        # get hl merge data
        print('##########Hl Wave merge Data###########')
        getHLMergeData()
        print('##########Hl Wave Daily Data###########')
        getHLDailyDatas()
        print('##########Hl ZS Wave merge Data###########')
        getZSHLMergeData()
    #######################################analysis##################
    if True:
        print("################ooc close data----------")
        getOOCData()
        print("################close kmeas data----------")
        getKPIKmeans()
        print("################close summary data----------")
        getKmeansSummary()
        print("################Daily data----------")
        getKmeansDailyRawData()
        print("################Daily Detail data----------")
        getKmeansDailyRawDataDetail()
        print("################Daily N days data----------")
        getHLSummaryPNDays()
        print("################Get Gkey Mapping----------")
        genGLevelMapping()
        print("################Get DrawLineDatas---------")
        getDrawLineDatas()
    #######################################CSV Tool##################
    # if True:
    #     getDrawLineDatas()