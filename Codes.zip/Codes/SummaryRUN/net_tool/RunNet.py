from net_tool.AkshareTool_A import genDailyAKData
from net_tool.BaostockTool_A import genBaoStockDailyData
from net_tool.EasyquotationTool_T import genDailyEasyquotationData
from com.DbTool import getConn, query, insert
from com.RunConf import RAW_FINAL_FORMAT_HL_FILE,RAW_NET_WORK_FILE,RAW_HLS_WORK_FILE
from net_tool.XueQiuTool_A import genXueQiuDailyDataData


def runDaily(type):
    conn = getConn(RAW_NET_WORK_FILE)
    if type == 'ak':
        genDailyAKData()
        sql = '''
        select substr(code,0,3)||'.'||substr(code,3) as code,date,open,close,high,low,pctchg,volume from raw_data_d_akshare_tmp
where substr(code,0,3)||'.'||substr(code,3)||date not in (select distinct code||date from raw_data_d)
and substr(code,0,3)||'.'||substr(code,3) in (select distinct code from raw_data_d)
        '''
    elif type == 'eq':
        genDailyEasyquotationData()
        sql = '''
select code,date,open,close,high,low,pctchg,volume from raw_data_d_easyquotation_tmp
where code||date not in (select distinct code||date from raw_data_d)
and code  in (select distinct code from raw_data_d)       
        '''
    elif type == 'bt':
        genBaoStockDailyData()
        sql = '''
select code,date,open,close,high,low,pctchg,volume from raw_data_d_baostock_tmp
where code||date not in (select distinct code||date from raw_data_d)
and code  in (select distinct code from raw_data_d)
        '''
    else:
        genXueQiuDailyDataData()
        return

    df = query(sql, conn)
    if len(df) > 0:
        insert(df,conn,'raw_data_d',opType='append')
        print('%s-------------Done' %(len(df)))
def runHLDaily(type):
    conn = getConn(RAW_HLS_WORK_FILE)
    if type == 'ak':
        df = genDailyAKData()
        insert(df, conn, 'raw_data_d_akshare_tmp')
        sql = '''
        select substr(code,0,3)||'.'||substr(code,3) as code,date,open,close,high,low,pctchg,volume from raw_data_d_akshare_tmp
where substr(code,0,3)||'.'||substr(code,3)||date not in (select distinct code||date from raw_data_d)
and substr(code,0,3)||'.'||substr(code,3) in (select distinct code from raw_data_d)
        '''
    elif type == 'eq':
        df = genDailyEasyquotationData()
        insert(df, conn, 'raw_data_d_easyquotation_tmp')
        sql = '''
select code,date,open,close,high,low,pctchg,volume from raw_data_d_easyquotation_tmp
where code||date not in (select distinct code||date from raw_data_d)
and code  in (select distinct code from raw_data_d)       
        '''
    elif type == 'bt':
        df = genBaoStockDailyData()
        insert(df, conn, 'raw_data_d_baostock_tmp')
        sql = '''
select code,date,open,close,high,low,pctchg,volume from raw_data_d_baostock_tmp
where code||date not in (select distinct code||date from raw_data_d)
and code  in (select distinct code from raw_data_d)
        '''
    else:
        genXueQiuDailyDataData()
        return

    df = query(sql, conn)
    if len(df) > 0:
        insert(df,conn,'raw_data_d',opType='append')
        print('%s-------------Done' %(len(df)))

def runHist(type):
    conn = getConn(RAW_NET_WORK_FILE)

    if type == 'ak':
        sql = '''
        select code,date,open,close,high,low,pctchg,volume from raw_data_d_akshare 
        '''
    elif type == 'xq':
        sql = '''
        select code,date,open,close,high,low,percent as pctchg,volume from raw_data_d_xq
        '''
#         sql = '''
#         select code,date,open,close,high,low,percent as pctchg,volume from raw_data_d_xq
# where code not in (select distinct code as key from raw_data_d)
#         '''
    elif type == 'bt':
        sql = '''
        select code,date,open,close,high,low,pctchg,volume from raw_data_d_baostock
        '''
    df = query(sql, conn)
    if len(df) > 0:
        insert(df, conn, 'raw_data_d', opType='append')
        print('%s-------------Done' % (len(df)))

if __name__ == '__main__':
    #type = 'eq'
    flag = True
    if flag:
        runDaily('ak')
        runHLDaily('eq')
    if False:
        runHist(type)
