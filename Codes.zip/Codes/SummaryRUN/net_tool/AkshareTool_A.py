import akshare as ak
import numpy as np

from com.DbTool import getConn, query, insert
from com.RunConf import RAW_FINAL_FORMAT_HL_FILE,RAW_NET_WORK_FILE
import pandas as pd
def genByCodeAKData():
    RAW_NET_WORK_CONN = getConn(RAW_NET_WORK_FILE)
    RAW_FINAL_FORMAT_HL_CONN = getConn(RAW_FINAL_FORMAT_HL_FILE)
    codes = list(query('select distinct code from raw_data_d',RAW_FINAL_FORMAT_HL_CONN)['code'].values)
    ecodes = list(query('select distinct code from raw_data_d_akshare',RAW_NET_WORK_CONN)['code'].values)
    for idx,code in enumerate(codes):
        if code in ecodes:
            continue
        try:
            symbol = code.replace(".","")
            stock_zh_a_daily_hfq_df = ak.stock_zh_a_daily(symbol=symbol, adjust="qfq")
            stock_zh_a_daily_hfq_df['pclose'] = stock_zh_a_daily_hfq_df.close.shift(1).values
            stock_zh_a_daily_hfq_df = stock_zh_a_daily_hfq_df.dropna()
            stock_zh_a_daily_hfq_df = stock_zh_a_daily_hfq_df.sort_values(by=['date'])
            df = stock_zh_a_daily_hfq_df[-1399:]
            rdf = pd.DataFrame()
            rdf['code'] = len(df)*[code]
            rdf['date'] = df.date.apply(lambda x:str(x.date())).values
            rdf['open']  = df['open'].values
            rdf['high']  = df['high'].values
            rdf['low']   = df['low'].values
            rdf['close'] = df['close'].values
            pctchg = df.apply(lambda x:round((x['close']-x['pclose'])*100/x['pclose'],3),axis=1).values
            rdf['pctchg'] = pctchg
            rdf['volume'] = df['volume'].values
            rdf['outstanding_share'] = np.round(df['outstanding_share'].values,3)
            rdf['turnover'] = np.round(df['turnover'].values,5)
            if len(df) > 0:
                insert(rdf,RAW_NET_WORK_CONN,'raw_data_d_akshare',opType='append')
                print("%s %s %s %s" % (code, idx,len(rdf),len(codes)))
        except:
            print("%s issue" %(code))

def genDailyAKData():
    from datetime import datetime
    RAW_NET_WORK_CONN = getConn(RAW_NET_WORK_FILE)
    stock_zh_a_spot_df = ak.stock_zh_a_spot()
    today = datetime.now().today().strftime('%Y-%m-%d')

    new_columns = {
    '代码'   :'code'
  ,'名称'    :'code_name'
  ,'最新价'  :'close'
  ,'涨跌额'  :'pctval'
  ,'涨跌幅'  :'pctchg'
  ,'买入'   :'buy'
  ,'卖出'   :'sell'
  ,'昨收'   :'pclose'
  ,'今开'   :'open'
  ,'最高'   :'high'
  ,'最低'   :'low'
  ,'成交量'  :'volume'
  ,'成交额'  :'amount'
    }
    stock_zh_a_spot_df.rename(columns=new_columns, inplace=True)
    stock_zh_a_spot_df['date'] = today
    #stock_zh_a_spot_df['code'] = stock_zh_a_spot_df.code.apply(lambda x:x[:2] + "." +x['2:'])
    insert(stock_zh_a_spot_df,RAW_NET_WORK_CONN,'raw_data_d_akshare_tmp')
    return stock_zh_a_spot_df
def runAkShaer():
    sql = '''
    
    '''
if __name__ == '__main__':
    genByCodeAKData()
    #genDailyAKData()