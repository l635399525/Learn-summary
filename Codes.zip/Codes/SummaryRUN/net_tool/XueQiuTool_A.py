import time
import requests
import json
from com.DbTool import query, insert, drop, delete, getConn
import datetime
import numpy as np
import pandas as pd
from com.RunConf import RAW_FINAL_FORMAT_HL_FILE, RAW_NET_WORK_FILE_TMP,RAW_NET_WORK_FILE

RAW_FINAL_FORMAT_HL_FILE_CONN = getConn(RAW_FINAL_FORMAT_HL_FILE)
RAW_NET_WORK_CONN_TMP = getConn(RAW_NET_WORK_FILE_TMP)
RAW_NET_WORK_CONN = getConn(RAW_NET_WORK_FILE)

def genXueQiuByCodeDataData():
    #query('select distinct code from raw_data_d_xq',RAW_NET_WORK_CONN_TMP)['code'].values
    headers = {
        "accept": "application/json, text/plain, */* "
        , "accept-encoding": "gzip, deflate, br"
        , "accept-language": "zh-CN,zh;q=0.9"
        ,'cookie':'device_id=d8624f8f2c0b229a44e106361b858dbb; s=ch1152o26k; xq_a_token=f1e4545cb0f3cfb17acc98ad7a298b8106f55e86; xqat=f1e4545cb0f3cfb17acc98ad7a298b8106f55e86; xq_r_token=f5d9f889384a1b3b886c6a67f79bd30c74aaeb1c; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOi0xLCJpc3MiOiJ1YyIsImV4cCI6MTY1MTQ0NzY3MywiY3RtIjoxNjQ5NDAxMTU2ODgxLCJjaWQiOiJkOWQwbjRBWnVwIn0.dtJYSnh3h1pCclQQTKFTpTcuZuF-JKWLSHImcNJFglzN4-XSGaYmnTYulC52bQWbDwCgXG0UgLEyosf4sQ_xq7MwvfNtFhX04xgxMU1UgTw177wscUsQeyUkOebothlVbun4J-S8_kv8heXCT3NZ4b7mZSXke3ArdsEBWSVR9GkfbomXG2lan3ccOZOyPcsuVVj7uLbBXU9PG8xue5HrBX3CO0kpwwlVoVvY9RxRJnWw6p7OY8wWGx6BGTSTt8k2q0doUQAsgC2NECBpLMI_VpCQRPHbv3ODbd6Nn1RYEObt9mRi2c3XOL_KOOkYPhvlnAsaJwdN5WJqD-HsjJxAgg; u=431649401208663; Hm_lvt_1db88642e346389874251b5a1eded6e3=1648087933,1648203275,1649286155,1649401212; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1649401212'
        , "origin": "https://xueqiu.com"
        ,"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36"
    }
    cols = [
        "timestamp"
        , "volume"
        , "open"
        , "high"
        , "low"
        , "close"
        , "chg"
        , "percent"
        , "turnoverrate"
        , "amount"
    ]
    df = query("select distinct code from raw_data_d_hl_waves where code like 'sh.603%'",RAW_FINAL_FORMAT_HL_FILE_CONN)
    codes = list(df['code'].values)
    timestamp = int(time.time() * 1000)
    dfs = []
    for idx, code in enumerate(codes[20:]):
        try:
            time.sleep(0.1)
            symbol = code.upper().replace('.','')
            url = "https://stock.xueqiu.com/v5/stock/chart/kline.json?symbol=" + symbol + "&begin=" + str(timestamp) + "&period=day&type=before&count=-1420&indicator=kline,pe,pb,ps,pcf,market_capital,agt,ggt,balance"
            print(url)
            response = requests.get(url, headers=headers)
            # 转换为dict类型
            res_dict = json.loads(response.text)
            datas = res_dict['data']
            colums = datas["column"]
            ars = np.asarray(datas['item'])
            df = pd.DataFrame(columns=colums, data=ars)
            rdf = df[cols].copy()
            rdf["date"] = rdf.timestamp.apply(
                lambda x: datetime.datetime.fromtimestamp(x / 1000).strftime("%Y-%m-%d"))
            rdf["dt"] = rdf.timestamp.apply(
                lambda x: datetime.datetime.fromtimestamp(x / 1000).strftime("%Y-%m-%d %H:%M"))
            rdf["times"] = rdf.timestamp.apply(
                lambda x: datetime.datetime.fromtimestamp(x / 1000).strftime("%H:%M"))
            rdf["symbol"] = datas["symbol"]
            rdf["code"] = rdf.symbol.apply(lambda x: str(x[:2]).lower() + "." + str(x[2:]))
            if len(rdf) > 0:
                dfs.append(rdf)
                print("%s %s %s %s Done" % (idx, symbol, len(codes), len(rdf)))
        except:
            import traceback
            traceback.print_exc()
    rdf = pd.concat(dfs)
    insert(rdf, RAW_NET_WORK_CONN_TMP, "raw_data_d_xq", "append")

def genXueQiuDailyDataData():
    headers = {
        "accept": "application/json, text/plain, */* "
        , "accept-encoding": "gzip, deflate, br"
        , "accept-language": "zh-CN,zh;q=0.9"
        ,'cookie':'device_id=d8624f8f2c0b229a44e106361b858dbb; s=ch1152o26k; xq_a_token=f1e4545cb0f3cfb17acc98ad7a298b8106f55e86; xqat=f1e4545cb0f3cfb17acc98ad7a298b8106f55e86; xq_r_token=f5d9f889384a1b3b886c6a67f79bd30c74aaeb1c; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOi0xLCJpc3MiOiJ1YyIsImV4cCI6MTY1MTQ0NzY3MywiY3RtIjoxNjQ5NDAxMTU2ODgxLCJjaWQiOiJkOWQwbjRBWnVwIn0.dtJYSnh3h1pCclQQTKFTpTcuZuF-JKWLSHImcNJFglzN4-XSGaYmnTYulC52bQWbDwCgXG0UgLEyosf4sQ_xq7MwvfNtFhX04xgxMU1UgTw177wscUsQeyUkOebothlVbun4J-S8_kv8heXCT3NZ4b7mZSXke3ArdsEBWSVR9GkfbomXG2lan3ccOZOyPcsuVVj7uLbBXU9PG8xue5HrBX3CO0kpwwlVoVvY9RxRJnWw6p7OY8wWGx6BGTSTt8k2q0doUQAsgC2NECBpLMI_VpCQRPHbv3ODbd6Nn1RYEObt9mRi2c3XOL_KOOkYPhvlnAsaJwdN5WJqD-HsjJxAgg; u=431649401208663; Hm_lvt_1db88642e346389874251b5a1eded6e3=1648087933,1648203275,1649286155,1649401212; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1649401212'
        , "origin": "https://xueqiu.com"
        ,"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36"
    }
    date = datetime.datetime.now().today().strftime('%Y-%m-%d')

    import time
    ts = int(time.time()*1000)
    url = 'https://xueqiu.com/service/v5/stock/screener/quote/list?page=1&size=9000&order=desc&orderby=percent&order_by=percent&market=CN&type=sh_sz&_=%s' %(ts)
    response = requests.get(url, headers=headers)
    # 转换为dict类型
    res_dict = json.loads(response.text)
    data = res_dict['data']['list']
    df = pd.DataFrame(data)
    df['date'] = date
    if len(df) > 0:
        insert(df, RAW_NET_WORK_CONN, "raw_data_d_xq_tmp")
        print("---Done")
        #print("%s %s %s %s Done" % (idx, symbol, len(codes), len(rdf)))
def tmp_move_tool():
    sql = '''
    select timestamp, volume, open, high, low, close, chg, percent, turnoverrate, amount, date, dt, times, symbol, code from raw_data_d_xq
    '''
    df = query(sql,RAW_NET_WORK_CONN_TMP)
    insert(df,RAW_NET_WORK_CONN,'raw_data_d_xq')

if __name__ == '__main__':
    tmp_move_tool()
    #genXueQiuByCodeDataData()
    #genXueQiuDailyDataData()
