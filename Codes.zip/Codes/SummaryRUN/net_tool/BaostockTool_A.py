
from com.DbTool import query, insert, drop, delete, getConn
import baostock as bs
from com.RunConf import RAW_NET_WORK_FILE

RAW_NET_WORK_CONN = getConn(RAW_NET_WORK_FILE)
from datetime import datetime

def genBaoStockByCodeDataData(date='2022-04-07'):
    bs.login()
    #RAW_FINAL_FORMAT_CONN = getConn(RAW_NET_WORK_CONN)
    # 获取指定日期的指数、股票数据
    date = datetime.now().today().strftime('%Y-%m-%d')
    stock_rs = bs.query_all_stock(date)
    #stock_df = stock_rs.get_data()
    # data_df = pd.DataFrame()
    df = query('select distinct code from raw_data_d_akshare', RAW_NET_WORK_CONN)
    codes = list(df['code'].values)
    for code in codes:
        if code.startswith('sh.60') or code.startswith('sz.00'):
            print("Downloading :" + code)
            k_rs = bs.query_history_k_data_plus(code, "date,code,open,high,low,close,volume,amount,pctchg", '2016-01-01', date,adjustflag='2')
            data_df = k_rs.get_data()
            insert(data_df, RAW_NET_WORK_CONN, 'raw_data_d_baostock', opType='append')
    bs.logout()
def genBaoStockDailyData(date='2022-04-07'):
    bs.login()
    #RAW_FINAL_FORMAT_CONN = getConn(RAW_NET_WORK_CONN)
    # 获取指定日期的指数、股票数据
    stock_rs = bs.query_all_stock(date)
    #stock_df = stock_rs.get_data()
    # data_df = pd.DataFrame()
    df = query('select distinct code from raw_data_d_akshare', RAW_NET_WORK_CONN)
    codes = list(df['code'].values)
    dfs = []
    for code in codes:
        if code.startswith('sh.60') or code.startswith('sz.00'):
            print("Downloading :" + code)
            k_rs = bs.query_history_k_data_plus(code, "date,code,open,high,low,close,volume,amount,pctchg", date, date,adjustflag='2')
            data_df = k_rs.get_data()
            dfs.append(data_df)
            insert(data_df, RAW_NET_WORK_CONN, 'raw_data_d_baostock_tmp', opType='append')
    bs.logout()
    import pandas as pd
    rdf = pd.DataFrame(dfs)
    return rdf
if __name__ == '__main__':
    genBaoStockByCodeDataData()