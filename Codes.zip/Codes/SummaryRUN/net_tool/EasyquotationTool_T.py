from com.DbTool import getConn, query, insert
from com.RunConf import RAW_FINAL_FORMAT_HL_FILE,RAW_NET_WORK_FILE
import easyquotation
from datetime import datetime
from com.RunConf import RAW_FINAL_FORMAT_HL_FILE,RAW_NET_WORK_FILE
import pandas as pd
def genDailyEasyquotationData():
    type = 'tencent'
    quotation = easyquotation.use(type)  # 新浪 ['sina'] 腾讯 ['tencent', 'qq']
    today = datetime.now().today().strftime('%Y-%m-%d')
    df = quotation.market_snapshot(prefix=True)
    RAW_NET_WORK_FILE_CONN = getConn(RAW_NET_WORK_FILE)
    dest_conn = RAW_NET_WORK_FILE_CONN
    lines = []
    for key,line in df.items():
        code = key
        head = {"code":code}
        out_line = {**head,**line}
        if type == 'tencent':
            out_line['date'] = today
        lines.append(out_line)
    ndf = pd.DataFrame(lines)
    rdf = ndf[["code","name","date","open","high","low","now","close","volume"]].copy()
    new_columns = {"code":"code","name":"code_name","date":"date","open":"open","high":"high","low":"low","now":"close","close":"pclose","volume":"volume"}
    rdf["code"] = rdf["code"].apply(lambda x:"".join(x[:2]) + "." + "".join(x[2:]))
    rdf["pctchg"] = round((rdf["now"] - rdf["close"])*100/rdf["close"],3)
    rdf["amount"] = round((rdf["now"]*rdf["volume"]))
    rdf.rename(columns=new_columns, inplace=True)
    insert(rdf,dest_conn,"raw_data_d_easyquotation_tmp")
    print("--Done")
    return rdf

if __name__ == '__main__':
    genDailyEasyquotationData()