from com.DbTool import getConn
import numpy as np
from com.DbTool import query, insert, delete, drop,getConn
from com.RunConf import RAW_HLS_WORK_FILE
import pandas as pd
conn = getConn(RAW_HLS_WORK_FILE)
def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['work_date'] = list(df_close['work_date'])
    st_data['c_date'] = list(df_close['c_date'])
    st_data['code']  = [st] * len(st_data)
    st_data['type']  = list(df_close['type'])
    st_data['act_y_dt'] = list(df_close['a_dt'])
    st_data['act_y_ag'] = list(df_close['a_ag'])

    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data = st_data.dropna()
    return np.array(st_data)

def genRfData(n=1):
    for type in [0,1]:
        sql ='''
        select code, work_date, c_date, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt,  a_ag,  lb, avg_dt, ar
    ,case when ar == 1 then 'A'
        when ar > 0.5 and ar < 1 then 'B'
        else 'C'
        end as type
    from
    (select  a.code, work_date, c_date,
           x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag,
           a_dt,  a_ag, a.lb, avg_dt,
           case when avg_dt < 100 then 1
                when avg_dt >= 100 and avg_dt <= 200 then 0.618
                else 0.382
               end as ar
           from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_{type}_daily a,
    (select lb,round(avg(a_dt)) as avg_dt from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_{type}_daily group by lb) b
    where a.lb = b.lb)
        '''.format(type=type)
        trains = []
        tests = []
        df = query(sql,conn)
        dfs = df.groupby('code')
        for code,idf in dfs:
            try:
                if len(idf) < n:
                    continue
                idf = idf.sort_values(by=['c_date'])
                data = create_stock_data(idf,
                                         {'x_a_l': list(range(0, n)), 'x_b_l': list(range(0, n)), 'x_c_l': list(range(0, n)),
                                          'x_d_l': list(range(0, n)), 'x_e_l': list(range(0, n)), 'x_ab_ag': list(range(0, n)),
                                          'x_bc_ag': list(range(0, n)), 'x_cd_ag': list(range(0, n)), 'x_de_ag': list(range(0, n))
                                             , 'x_ea_ag': list(range(0, n))},code)
                #if code in train_codes:
                trains.append(data)
                #else:
                tests.append(data)
                print("%s %s--- Done" %(len(trains),code))
            except:
                pass
        train_data = np.concatenate([x for x in trains])
        test_data = np.concatenate([x for x in tests])
        np.savez('raw_hl_draw_merge_%s_fr_%s.npz' %(n,type),train = train_data,test=test_data)

import pickle
def testerFR():
    dfs = []
    for n in [1]:
        for type in [0, 1]:
            data = np.load('raw_hl_draw_merge_%s_fr_%s.npz' % (n, type), allow_pickle=True)
            train = data['train']
            for cls in ['A', 'B', 'C']:
                x_train = train[np.argwhere(train[:, 3] == cls)[:, 0]]
                st_data = pd.DataFrame([])
                st_data['code'] = x_train[:, 2]
                st_data['type'] = x_train[:, 3]
                st_data['work_date'] = x_train[:, 0]
                st_data['c_date'] = x_train[:, 1]
                st_data['act_y_dt'] = x_train[:, 4]
                st_data['act_y_ag'] = x_train[:, 5]

                data = x_train
                model = 'hl_draw_fr_%s_%s_%s' % (n, cls, type)
                model_file = r'D:\code_center\LSTM_TEST_RUN\draw_tool\%s' %(model)
                with open(model_file, 'rb') as f:
                    clf2 = pickle.load(f)
                    # 测试读取后的Model
                    test_x = data[:, 6:]
                    pv = clf2.predict(test_x)
                    nres = clf2.predict_proba(test_x)
                    pv1 = np.argmax(nres, axis=1)
                    gap = np.round(np.abs(nres[:, 0] - nres[:, 1]), 3)
                    #return res, test_y, res_1, gap


                #pv, av, pv1, gap = tester(model, data)
                st_data['pv'] = pv
                st_data['pv_t'] = pv1
                st_data['gap'] = gap
                st_data['mtype'] = 'fr'
                st_data['model'] = model
                st_data['cls'] = type
                dfs.append(st_data)

                print("--------start %s %s" % (len(x_train), type))
                #insert(st_data, conn, 'test_merge_result_dt', opType='append')
    return dfs
def testerXGB():
    import xgboost as xgb
    dfs = []
    for n in [1]:
        for type in [0, 1]:
            data = np.load('raw_hl_draw_merge_%s_fr_%s.npz' % (n, type), allow_pickle=True)
            train = data['train']
            for cls in ['A', 'B', 'C']:
                x_train = train[np.argwhere(train[:, 3] == cls)[:, 0]]
                st_data = pd.DataFrame([])
                st_data['code'] = x_train[:, 2]
                st_data['type'] = x_train[:, 3]
                st_data['work_date'] = x_train[:, 0]
                st_data['c_date'] = x_train[:, 1]
                st_data['act_y_dt'] = x_train[:, 4]
                st_data['act_y_ag'] = x_train[:, 5]
                data = x_train
                model = 'hl_draw_xgb_%s_%s_%s' % (n, cls, type)
                model_file = r'D:\code_center\LSTM_TEST_RUN\draw_tool\%s' %(model)

                with open(model_file, 'rb') as f:
                    clf2 = pickle.load(f)
                    # 测试读取后的Model
                    test_x= data[:, 6:]
                    test_x = xgb.DMatrix(test_x)
                    y_pred = clf2.predict(test_x)
                    predictions = [round(value) for value in y_pred]
                pv  =  np.asarray(predictions)
                pv1 = np.asarray(predictions)
                gap = y_pred
                #pv, av, pv1, gap = tester(model, data)
                st_data['pv'] = pv
                st_data['pv_t'] = pv1
                st_data['gap'] = gap
                st_data['mtype'] = 'xgb'
                st_data['model'] = model
                st_data['cls'] = type
                print("--------start %s %s" % (len(x_train), type))
                dfs.append(st_data)
                #insert(st_data, conn, 'test_merge_result_v2', opType='append')
    return dfs
def testerFRAg():
    dfs = []
    for n in [1]:
        for type in [0, 1]:
            data = np.load('raw_hl_draw_merge_%s_fr_%s.npz' % (n, type), allow_pickle=True)
            train = data['train']
            for cls in ['A', 'B', 'C']:
                x_train = train[np.argwhere(train[:, 3] == cls)[:, 0]]
                st_data = pd.DataFrame([])
                st_data['code'] = x_train[:, 2]
                st_data['type'] = x_train[:, 3]
                st_data['work_date'] = x_train[:, 0]
                st_data['c_date'] = x_train[:, 1]
                st_data['act_y_dt'] = x_train[:, 4]
                st_data['act_y_ag'] = x_train[:, 5]

                data = x_train
                model = 'hl_draw_fr_%s_%s_%s_ag' % (n, cls, type)
                model_file = r'D:\code_center\LSTM_TEST_RUN\draw_tool\%s' %(model)
                with open(model_file, 'rb') as f:
                    clf2 = pickle.load(f)
                    # 测试读取后的Model
                    test_x = data[:, 6:]
                    pv = clf2.predict(test_x)
                    nres = clf2.predict_proba(test_x)
                    pv1 = np.argmax(nres, axis=1)
                    #gap = np.round(np.abs(nres[:, 0] - nres[:, 1]), 3)
                    gap = np.zeros(len(nres))
                    for i in range(len(nres)):
                        line = nres[i][np.argsort(nres[i])][1:]
                        gap[i] = line[-1] - line[-2]

                st_data['pv'] = pv
                st_data['pv_t'] = pv1
                st_data['gap'] = gap
                st_data['mtype'] = 'fr'
                st_data['model'] = model
                st_data['cls'] = type
                dfs.append(st_data)

                print("--------start %s %s" % (len(x_train), type))
                #insert(st_data, conn, 'test_merge_result_v2', opType='append')
    return dfs
def testerXGBAg():
    import xgboost as xgb
    dfs = []
    for n in [1]:
        for type in [0, 1]:
            data = np.load('raw_hl_draw_merge_%s_fr_%s.npz' % (n, type), allow_pickle=True)
            train = data['train']
            for cls in ['A', 'B', 'C']:
                x_train = train[np.argwhere(train[:, 3] == cls)[:, 0]]
                st_data = pd.DataFrame([])
                st_data['code'] = x_train[:, 2]
                st_data['type'] = x_train[:, 3]
                st_data['work_date'] = x_train[:, 0]
                st_data['c_date'] = x_train[:, 1]
                st_data['act_y_dt'] = x_train[:, 4]
                st_data['act_y_ag'] = x_train[:, 5]
                data = x_train
                model = 'hl_draw_xgb_%s_%s_%s_ag' % (n, cls, type)
                model_file = r'D:\code_center\LSTM_TEST_RUN\draw_tool\%s' %(model)

                with open(model_file, 'rb') as f:
                    clf2 = pickle.load(f)
                    # 测试读取后的Model
                    test_x= data[:, 6:]
                    test_x = xgb.DMatrix(test_x)
                    y_pred = clf2.predict(test_x)
                    predictions = [round(value) for value in y_pred*180]
                pv  =  np.asarray(predictions)
                pv1 = np.asarray(predictions)
                gap = y_pred*0
                #pv, av, pv1, gap = tester(model, data)
                st_data['pv'] = pv
                st_data['pv_t'] = pv1
                st_data['gap'] = gap
                st_data['mtype'] = 'xgb'
                st_data['model'] = model
                st_data['cls'] = type
                print("--------start %s %s" % (len(x_train), type))
                dfs.append(st_data)
                #insert(st_data, conn, 'test_merge_result_v2', opType='append')
    return dfs

if __name__ == '__main__':
    if True:
        genRfData()
    if True:
        df_Fr  = testerFR()
        df_xgb = testerXGB()
        odfs = []
        if len(df_Fr) > 0:
            odfs.extend(df_Fr)
        if len(df_xgb) > 0:
            odfs.extend(df_xgb)
        rdf = pd.concat(odfs)
        insert(rdf, conn, 'test_merge_result_dt')

    if True:
        df_Fr  = testerFRAg()
        df_xgb = testerXGBAg()
        odfs = []
        if len(df_Fr) > 0:
            odfs.extend(df_Fr)
        if len(df_xgb) > 0:
            odfs.extend(df_xgb)
        rdf = pd.concat(odfs)
        insert(rdf, conn, 'test_merge_result_ag')