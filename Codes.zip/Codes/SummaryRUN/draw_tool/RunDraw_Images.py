# HlTool.py run getDrawLineData  raw_kmeans_hl_merge_close_summary_drawline_daily 重新 跑 完成的 data
# draw_line_D_ByDate 写 同步大盘的数据 包括 daily and done
# 画分析图
from draw_tool.DrawTool_Daily import draw_line_D, draw_line_D_ByDate,draw_line_D_ByDateDone,draw_line_D_ByDaily
from draw_tool.MoveToolByData import moveByCodeAnalysis,moveByDateAnalysis

def genImageWithZS():
    # 都是写入daily data merger 理论上应该 purge
    if False:
        # write zs data
        print("#######################start zs merge ############################")
        #draw_line_D()
        # append daily data near 5
        print("#######################start by date fully merge##################")
        #draw_line_D_ByDate()
        draw_line_D_ByDaily()
        # append done datas
        print("#######################start by date Dones merge##################")
        #draw_line_D_ByDateDone()
    if True:
        print("#######################merge by code#############################")
        moveByCodeAnalysis()
        print("#######################merge by date#############################")
        moveByDateAnalysis()

if __name__ == '__main__':
    genImageWithZS()
