import glob
import numpy as np
files = glob.glob(r'D:\data\images_B\4-0\*.jpg')
files = np.asarray(files)
folder = '4-0'
of = r'D:\data\images_B\merge\%s' %(folder)
import os
if not os.path.exists(of):
    os.makedirs(of)
import cv2
imgs = []
#img0 = cv2.imread(files[0])
#img1 = cv2.imread(files[1])
import numpy as np
idxes = np.asarray(range(len(files)))
batch_num = 12
batch_size = int(len(files)/batch_num)
lefts = len(files) - batch_size*batch_num
for i in range(1,batch_size+1):
    start = (i-1)*batch_num
    end = i * batch_num
    idx = idxes[start:end]
    tfiles = files[idx]
    tfiles = tfiles.reshape((int(batch_num/2),2))
    vimg = []
    for j in range(tfiles.shape[0]):
        line = tfiles[j]
        img1 = cv2.imread(line[0])
        img2 = cv2.imread(line[1])
        nimg = np.hstack([img1, img2])
        vimg.append(nimg)
    nimg = np.vstack(vimg)
    cv2.imwrite(r'%s\bath_%s.jpg' %(of,i),nimg)
    print(idx)
# nimg = np.hstack([img0,img1])
# nimg = np.hstack([img0,img1])
# nimg = np.hstack([img0,img1])
# nimg = np.hstack([img0,img1])
#
# cv2.imwrite('a.jpg',nimg)
#cv2.imshow('a',nimg)
#cv2.waitKey(0)
#print(nimg)