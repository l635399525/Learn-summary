import glob
import numpy as np
import pandas as pd

from com.DbTool import query
from draw_tool.DrawTool import RAW_HLS_WORK_CONN

files = glob.glob(r'D:\data\images_B\4-0\*.jpg')
files = np.asarray(files)
folder = '4-0'
of = r'D:\data\images_B\merge\%s' %(folder)
import os
if not os.path.exists(of):
    os.makedirs(of)
import cv2
def trun():
    imgs = []
    #img0 = cv2.imread(files[0])
    #img1 = cv2.imread(files[1])
    import numpy as np
    idxes = np.asarray(range(len(files)))
    batch_num = 12
    batch_size = int(len(files)/batch_num)
    lefts = len(files) - batch_size*batch_num
    for i in range(1,batch_size+1):
        start = (i-1)*batch_num
        end = i * batch_num
        idx = idxes[start:end]
        tfiles = files[idx]
        tfiles = tfiles.reshape((int(batch_num/2),2))
        vimg = []
        for j in range(tfiles.shape[0]):
            line = tfiles[j]
            img1 = cv2.imread(line[0])
            img2 = cv2.imread(line[1])
            nimg = np.hstack([img1, img2])
            vimg.append(nimg)
        nimg = np.vstack(vimg)
        cv2.imwrite(r'%s\bath_%s.jpg' %(of,i),nimg)
        print(idx)

def moveByCode(type='sh'):
    import glob
    if type == 'sh':
        sh_files = glob.glob(r'D:\data\images\daily\*\*\sh*.jpg')
    else:
        sh_files = glob.glob(r'D:\data\images\daily\*\*\sz*.jpg')
    codes = []
    for sh_file in sh_files:
        code = sh_file.split("\\")[-1].split("_")[0]
        codes.append(code)
    codes = list(set(codes))
    efiles = glob.glob(r'D:\data\images\merge\codes\*.jpg')
    ecodes = list(map(lambda x:x.split("\\")[-1].replace(".jpg",""),efiles))
    for code in codes:
        if code in ecodes:
            print("---------------%s" %(code))
            continue
        vimgs = []
        images = list(filter(lambda x:code in x,sh_files))
        for image in images:
            date_folder = "\\".join(image.split("\\")[:-2])
            if type == 'sh':
                #sh_files = glob.glob(r'D:\data\images\daily\*\*\sh*.jpg')
                sz_img = glob.glob("%s\\%s\sh.000001*.jpg" % (date_folder, 'Dones'))[0]

            else:
                #sh_files = glob.glob(r'D:\data\images\daily\*\*\sz*.jpg')
                sz_img = glob.glob("%s\\%s\sz.399001*.jpg" % (date_folder, 'Dones'))[0]
            img1 = cv2.imread(sz_img)
            img2 = cv2.imread(image)
            himg = np.hstack([img1, img2])
            vimgs.append(himg)
        nimage = np.vstack(vimgs)
        cv2.imwrite(r'D:\data\images\merge\codes\%s.jpg' %(code),nimage)
        print(code + " Done")
def moveByDate(type='sh'):
    import glob
    import numpy as np
    import cv2
    if type == 'sh':
        sh_files = glob.glob(r'D:\data\images\daily\*\Dones\sh*.jpg')
        sh_files =list(filter(lambda x:'sh.000001' not in x,sh_files))

    else:
        sh_files = glob.glob(r'D:\data\images\daily\*\Dones\sz*.jpg')
        sh_files =list(filter(lambda x:'sz.399001' not in x,sh_files))
    #glob.glob()
    dates = []
    for sh_file in sh_files:
        date = sh_file.split("\\")[-3]
        dates.append(date)
    dates = list(set(dates))
    for date in dates:
        if type == 'sh':
            # sh_files = glob.glob(r'D:\data\images\daily\*\*\sh*.jpg')
            sz_img = glob.glob("%s\\sh.000001*.jpg" % (r'D:\data\images\daily\%s\Dones' %(date)))[0]
        else:
            # sh_files = glob.glob(r'D:\data\images\daily\*\*\sz*.jpg')
            sz_img = glob.glob("%s\\%s\sz.399001*.jpg" % (r'D:\data\images\daily\%s\Dones' %(date), 'Dones'))[0]
        src_files = np.asarray(list(filter(lambda x:date in x,sh_files)))
        cnt = round(len(src_files)/30)
        file_arrs = np.array_split(src_files,cnt)
        for idx,files in enumerate(file_arrs):
            if len(files) %2 == 0:
                files = np.insert(sz_img, 0, files)
                files = np.insert(sz_img, -1, files)
            else:
                files = np.insert(sz_img, 0, files)
            if type == 'sh':
                files = sorted(files,reverse=True)
            else:
                files = sorted(files,reverse=False)
            files = np.reshape(files,(int(len(files)/2),2))
            imgs = []
            for line in files:
                a = line[0]
                b = line[1]
                img1 = cv2.imread(a)
                img2 = cv2.imread(b)
                himg = np.hstack([img1, img2])
                imgs.append(himg)
            nimg = np.vstack(imgs)
            cv2.imwrite(r'D:\data\images\merge\dates\%s_%s.jpg' % (date,idx+1), nimg)
            print("%s %s %s %s" %(date,idx,len(imgs)*2,len(src_files)))
def moveByFullDaily():
    images = glob.glob(r'D:\data\images\merge\full\*')
    work_date = query("select max(n_date) as work_date from raw_data_d_hl_wave13_pn_merge",RAW_HLS_WORK_CONN)['work_date'][0]
    for image in images:
        img = cv2.imread(image)
        code = image.split("\\")[-1].replace(".jpg","")
        jpgs = glob.glob(r'D:\data\images\daily\%s\*\*.jpg' %(work_date))
        jpg = list(filter(lambda x:code in x,jpgs))[0]
        jpg = cv2.imread(jpg)
        jpg = cv2.resize(jpg, (img.shape[1],440), cv2.INTER_LINEAR)
        out_img = np.vstack([img,jpg])
        cv2.imwrite(r'D:\data\images\merge\full_daily\%s.jpg' %(code),out_img)
        print(image)
def moveByCodeAnalysis():
    import glob
    codes = glob.glob(r'D:\data\images\full\*')
    dates = glob.glob(r'D:\data\images\daily\*')
    dates = sorted(list(map(lambda x:x.split("\\")[-1],dates)))
    edate = dates[-1]
    jpgs = glob.glob(r'D:\data\images\daily\%s\*\*.jpg' % (edate))
    work_codes = glob.glob(r'D:\data\images\daily\%s\Dones\*' %(edate))
    work_codes = list(map(lambda x:x.split("\\")[-1].split("_")[0],work_codes))

    for idx,code in enumerate(codes):
        files = glob.glob(r'%s\*.jpg' %(code))
        code = code.split("\\")[-1]
        out_file = r'D:\data\images\analysis\codes\%s.jpg' % (code)
        # if os.path.exists(out_file):
        #     continue
        if code not in work_codes:
            continue
        files = np.array_split(files,int((len(files) - len(files)%2)/2) + 1)
        imgs = []
        for line in files:
            if len(line) > 1:
                a = line[0]
                b = line[1]
                img1 = cv2.imread(a)
                img2 = cv2.imread(b)
                himg = np.hstack([img1, img2])
            else:
                a = line[0]
                img1 = cv2.imread(a)
                himg = np.hstack([img1, img1])
            imgs.append(himg)
        nimg = np.vstack(imgs)
        try:
            daily_image = list(filter(lambda x:code in x,jpgs))[0]
        except:
            pass
        daily_image = cv2.imread(daily_image)
        daily_image = cv2.resize(daily_image, (nimg.shape[1], 440), cv2.INTER_LINEAR)
        out_img = np.vstack([nimg, daily_image])
        cv2.imwrite(r'D:\data\images\analysis\codes\%s.jpg' % (code), out_img)
        #cv2.imwrite(r'D:\data\images\merge\full\%s.jpg' % (code), nimg)
        print("%s %s %s" %(idx,code,len(codes)))
def moveByDateAnalysis():
    from com.DbTool import getConn, query, insert
    from com.RunConf import RAW_FINAL_FORMAT_HL_FILE, RAW_NET_WORK_FILE, RAW_HLS_WORK_FILE
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    import glob
    edates = glob.glob(r'D:\data\images\analysis\dates\*')
    edates = list(map(lambda x:str(x).split("\\")[-1].split("#")[0],edates))
    full_files = glob.glob(r'D:\data\images\full\*\*.jpg')
    print("%s" %(len(full_files)))
    df = pd.DataFrame()
    df['files'] = full_files
    df['date'] = df.files.apply(lambda x:x.split("\\")[-1].split("_")[1])
    dfs = df.groupby('date')
    odfs = []
    for date,idf in dfs:
        if date in edates:
            print("%s ------------------ Done" %(date))
            continue
        if not str(date).startswith('2022'):
            continue
        files = list(idf['files'].values)
        print("%s %s" %(date,len(idf)))
        #src_files = np.asarray(list(filter(lambda x: date in x, files)))
        cnt = round(len(files) / 34)
        file_arrs = np.array_split(files, cnt)
        for idx, ifiles in enumerate(file_arrs):
            rdf = pd.DataFrame()
            rdf['code'] = list(map(lambda x:x.split("\\")[-1].split("_")[0],ifiles))
            rdf['date'] = list(map(lambda x:x.split("\\")[-1].split("_")[1],ifiles))
            rdf['type'] = list(map(lambda x:x.split("\\")[-1].split("_")[2],ifiles))

            tfiles = np.array_split(ifiles, int((len(ifiles) - len(ifiles) % 2) / 2) + 1)
            imgs = []
            for line in tfiles:
                if len(line) > 1:
                    a = line[0]
                    b = line[1]
                    img1 = cv2.imread(a)
                    img2 = cv2.imread(b)
                    himg = np.hstack([img1, img2])
                else:
                    a = line[0]
                    img1 = cv2.imread(a)
                    himg = np.hstack([img1, img1])
                imgs.append(himg)
            nimg = np.vstack(imgs)
            cv2.imwrite(r'D:\data\images\analysis\dates\%s#%s.jpg' % (date,idx), nimg)
            rdf['fn'] = r'D:\data\images\analysis\dates\%s#%s.jpg' % (date,idx)
            odfs.append(rdf)
    if len(odfs) > 0:
        rdf = pd.concat(odfs)
        insert(rdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_drawline_save_bydate',opType='append')


if __name__ == '__main__':
    #moveByCode('sh')
    #moveByDate('sh')
    #moveByCode()
    #moveByFullDaily()
    #full_files = glob.glob(r'D:\data\images\full\*\*.jpg')
    #for file in full_files:
    #    print(file)
    moveByDateAnalysis()