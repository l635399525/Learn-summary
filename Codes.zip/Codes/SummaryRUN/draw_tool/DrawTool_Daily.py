import glob
import os.path

import pandas as pd

from com.DbTool import getConn,query,insert
from com.RunConf import RAW_FINAL_FORMAT_HL_FILE, RAW_NET_WORK_FILE, RAW_HLS_WORK_FILE
from sklearn import preprocessing
RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
import numpy as np
import cv2


def _calAngle(pp, cp, np):
    # a 左边 b 右边
    import math
    x1, y1 = pp[0], pp[1]
    x2, y2 = cp[0], cp[1]
    x3, y3 = np[0], np[1]
    a = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    b = math.sqrt((x2 - x3) ** 2 + (y2 - y3) ** 2)
    c = math.sqrt((x1 - x3) ** 2 + (y1 - y3) ** 2)
    A = math.degrees(math.acos((a * a - b * b - c * c) / (-2 * b * c)))
    B = math.degrees(math.acos((b * b - a * a - c * c) / (-2 * a * c)))
    C = math.degrees(math.acos((c * c - a * a - b * b) / (-2 * a * b)))
    return a,b,c,A,B,C
    print("%s %s %s" %(A,B,C))
def _draw_close(work_date,n_dates,df,num=365,c=5,cdate=None,append_info=False):
    fit = preprocessing.MinMaxScaler()
    df = df.sort_values(by=['date'])
    dates = df['date'].values
    closes = df['close'].values
    fit.fit(closes.reshape(len(closes),1))
    std_close  = fit.transform(closes.reshape(len(closes),1))[:,0]
    ma10_close = fit.transform(df['ma10'].values.reshape(len(closes), 1))
    ma60_close = fit.transform(df['ma60'].values.reshape(len(closes), 1))
    #fit.transform(df['ma10'].reshape(len(closes),1).values)
    closes_points = np.round((440 - std_close * 405) - 15).astype(int)
    #ma10 = df['ma10'].values
    #ma60 = df['ma60'].values
    ma10_points = np.round((440 - ma10_close * 405) - 15).astype(int)
    ma60_points = np.round((440 - ma60_close * 405) - 15).astype(int)
    mask = np.zeros((440, 1820, 3), np.uint8) + 200
    #x = np.asarray(range(1, 365)) * 5
    x = np.asarray(range(1, num)) * c

    #mask = np.zeros((440,(num-1)*c, 3), np.uint8) + 200
    #x = np.asarray(range(1,num))*c
    try:
        data = np.vstack([x, closes_points])
    except:
        if len(closes_points) < 455:
            data = np.concatenate([(np.zeros(num-len(closes_points) - 1) + closes_points[0]).astype(int),closes_points])
        data = np.vstack([x, data])

        #import traceback
        #traceback.print_exc()
        #pass
    #map_data = data.reshape((data.shape[1], data.shape[0]))
    #data_map = dict(list(zip(list(dates), list(map_data))))
    ps = []
    font = cv2.FONT_HERSHEY_SIMPLEX
    t_pv = None
    for i in range(1,len(df)):
        c_date = dates[i]
        c_close = closes[i]
        c_point = data[:,i]
        p_point = data[:,i-1]
        c_ma10 = int(ma10_points[i] )
        c_ma60 = int(ma60_points[i] )
        #p_ma10 = int(ma10_points[i-1])
        #p_ma60 = int(ma60_points[i-1])
        #print("%s %s %s %s %s" %(c_date,c_close,c_point[1],ma10_points[i],ma10[i]))
        cv2.line(mask, (p_point[0], p_point[1]), (c_point[0], c_point[1]), (0, 0, 0), thickness=1)
        #cv2.line(mask, (p_point[0], p_ma10), (c_point[0], c_ma10), (0, 255, 0), thickness=1, lineType = cv2.LINE_4)
        cv2.circle(mask,(c_point[0],c_ma10), 1, (0, 255, 255), thickness=1)
        cv2.circle(mask,(c_point[0],c_ma60), 1, (0, 255, 0), thickness=1)
        if cdate is not None and c_date == cdate and cdate != work_date:
            cv2.circle(mask,(c_point[0],c_point[1]), 1, (255, 0, 0), thickness=4)
        if c_date in n_dates:
            ps.append((c_point[0], c_point[1],c_date,c_close))
            cv2.circle(mask,(c_point[0], c_point[1]),1,(0,0,255),thickness=4)
            if c_point[0] > 1800:
                w = c_point[0] - 77
            else:
                w = c_point[0]
            if t_pv is not None:
                h = c_point[1] + 10 if c_point[1] > t_pv else c_point[1] - 10
            else:
                h = c_point[1]
            color = (0,0,0)
            if c_date == work_date:
                color = (0,0,255)
            mask = cv2.putText(mask, c_date, (w, h), font, 0.3, color, 1)
            t_pv = c_point[1]
    for i in range(1,len(ps)):
        c_point = ps[i]
        p_point = ps[i - 1]
        cv2.line(mask, (p_point[0], p_point[1]), (c_point[0], c_point[1]), (255, 0, 0), thickness=1)
    ps = np.asarray(ps)
    rlines = []
    for i in range(1,len(ps) -1):
        rline = {}
        p_p = ps[i-1]
        c_p = ps[i]
        n_p = ps[i+1]
        a,b,c,A,B,C = _calAngle(p_p[:2].astype(int),c_p[:2].astype(int),n_p[:2].astype(int))
        rline['p_date']  = p_p[2]
        rline['p_close'] = p_p[3]
        rline['c_date']  = c_p[2]
        rline['c_close'] = c_p[3]
        rline['n_date']  = n_p[2]
        rline['n_close'] = n_p[3]
        p_p = p_p[:2].astype(int)
        c_p = c_p[:2].astype(int)
        n_p = n_p[:2].astype(int)
        rline['p_x'] = p_p[0]
        rline['p_y'] = 440 - p_p[1]
        rline['c_x'] = c_p[0]
        rline['c_y'] = 440 - c_p[1]
        rline['n_x'] = n_p[0]
        rline['n_y'] = 440 - n_p[1]
        rline['dt_a'] = round(a,2)
        rline['dt_b'] = round(b,2)
        rline['dt_c'] = round(c,2)
        rline['ag_a'] = round(A,2)
        rline['ag_b'] = round(B,2)
        rline['ag_c'] = round(C,2)
        w = int(c_p[0])
        h = int(c_p[1]) + 20 if int(c_p[1]) > int(p_p[1]) else int(c_p[1]) - 20
        if h < 10 or h > 430:
            h = 10 if h < 10 else 430
            w = w - 41
        mask = cv2.putText(mask, str(round(C)) + '.' +str(round(B))+ '.' +str(round(A)), (w, h), font, 0.3, (0, 0, 0), 1)
        rlines.append(rline)
    #cv2.imshow('a',mask)
    #cv2.waitKey(0)
    rdf = pd.DataFrame(rlines)
    mask[0, :] = [0, 0, 0]
    mask[-1, :] = [0, 0, 0]
    mask[:, 0] = [0, 0, 0]
    mask[:, -1] = [0, 0, 0]
    if append_info:
        #np.argsort(np.argmax(ps[:,0].astype(int)))
        c_p = ps[-1]
        p_p = ps[-2]
        n_p = data[:,-1]
        try:
            a, b, c, A, B, C = _calAngle(p_p[:2].astype(int), c_p[:2].astype(int), n_p[:2].astype(int))
        except:
            b = 0
            C = 0
        return mask,rdf,(round(b),round(C))
        #c_p =
        #w = ep[0]-
    return mask,rdf
def _draw_hl_info(work_date,rdf,info_append):
    rdf = rdf.sort_values(by=['n_date'])
    mask = np.zeros((440,315, 3), np.uint8) + 200
    font = cv2.FONT_HERSHEY_SIMPLEX
    #420/len(rdf)
    for i in range(len(rdf)):
        data =dict(rdf[['n_date','g_key','h','w','ag']].iloc[i])
        try:
            idx_a = np.argwhere(info_append[:,0] == data['n_date'])[0][0]
            info_a = info_append[idx_a]
            log = '%s,%s,%s,%s,%s,%s,%s,%s' % (
            data['n_date'].replace("-", ""), data['g_key'], round(data['h']), data['w'],round(data['ag']),round(info_a[1]),round(info_a[2]),round(info_a[3]))
        except:
            #info_a = None
            log = '%s,%s,%s,%s,%s' %(data['n_date'].replace("-",""), data['g_key'],round(data['h']),data['w'],round(data['ag']))
        color = (0, 0, 0)
        if data['n_date'] == work_date:
            color = (0, 0, 255)
        mask = cv2.putText(mask, log, (10, 20+i*(round(400/len(rdf)) - 1)), font, 0.5, color, 1)
    mask[0,:] = [0,0,0]
    mask[-1,:] = [0,0,0]
    mask[:,0] = [0, 0, 0]
    mask[:,-1] = [0, 0, 0]
    return mask
def _draw_hw(work_date,df):
    idxes = np.cumsum(df.w.values)
    font = cv2.FONT_HERSHEY_SIMPLEX
    w = max(idxes) + 1
    h = 440
    mask = np.zeros((h, w, 3), np.uint8) + 200
    from sklearn import preprocessing
    fit = preprocessing.MinMaxScaler()
    dates = df.n_date.values
    ys = df.h.values
    hses = df.h.values
    ys = ys.reshape((len(ys),1))
    fit.fit(ys)
    ys = fit.transform(ys)[:,0]
    zero = fit.transform([[0]])[0][0]
    zero = round((440 - zero * 405)) - 15
    try:
        ul_13 = fit.transform([[13]])[0][0]
        ul_13 = round((440 - ul_13 * 405)) - 15
        mask = cv2.putText(mask, '13', (10, ul_13 - 15), font, 0.3, (0, 0, 0), 1)
        mask[ul_13, :] = [0, 0, 255]
    except:
        pass
    try:
        ul_34 = fit.transform([[34]])[0][0]
        ul_34 = round((440 - ul_34 * 405)) - 15
        mask = cv2.putText(mask, '34', (10, ul_34 - 15), font, 0.3, (0, 0, 0), 1)
        mask[ul_34, :] = [0, 0, 255]
    except:
        pass
    try:
        ll_13 = fit.transform([[-13]])[0][0]
        ll_13 = round((440 - ll_13 * 405)) - 15
        mask = cv2.putText(mask, '-13', (10, ll_13 - 15), font, 0.3, (0, 0, 0), 1)
        mask[ll_13, :] = [0, 255, 0]
    except:
        pass
    try:
        ll_34 = fit.transform([[-34]])[0][0]
        ll_34 = round((440 - ll_34 * 405)) - 15
        mask = cv2.putText(mask, '-34', (10, ll_34 + -15), font, 0.3, (0, 0, 0), 1)
        mask[ll_34, :] = [0, 255, 0]
    except:
        pass
    #cv2.line(mask, (p_point[0], p_point[1]), (c_point[0], c_point[1]), (0, 0, 255), thickness=1)
    ys = (np.round((440 - ys * 405)) - 15).astype(int)
    mask[zero,:] = [0,0,0]
    mask[0, :] = [0, 0, 0]
    mask[-1, :] = [0, 0, 0]
    mask[:, 0] = [0, 0, 0]
    mask[:, -1] = [0, 0, 0]
    #ys = (np.round(ys * 420) + 10).astype(int)
    f_point = (idxes[0], ys[0])
    mask = cv2.putText(mask, str(round(hses[0], 1)), (f_point[0], f_point[1]), font, 0.3, (0, 0, 0), 1)
    for i in range(1,len(ys)):
        c_date = dates[i]
        p_point = (idxes[i-1],ys[i-1])
        c_point = (idxes[i],ys[i])
        c_h = hses[i]
        h = int(c_point[1]) - 20 if c_h > 0 else int(c_point[1]) + 20
        h = h if h < 430 else h - 20
        h = h + 20 if h < 10  else h
        cv2.line(mask, (p_point[0], p_point[1]), (c_point[0], c_point[1]), (255, 0, 0), thickness=1)
        w = c_point[0]
        if i == len(ys) -1:
            w = w - 34
        color = (0, 0, 0)
        if c_date == work_date:
            color = (0, 0, 255)
        mask = cv2.putText(mask, str(round(c_h,1)), (w, h), font, 0.3, color, 1)
    return mask
def draw_line_D():
    df = query("select distinct code,n_date as work_date from raw_data_d_zs_hl_wave13_pn_merge where date(sdate) > date('2021-01-01')  group by code,n_date",RAW_HLS_WORK_CONN)
    dfs = df.groupby('code')
    efiles = glob.glob(r'D:\data\images\daily\*\*\*.jpg')
    ekeys = list(map(lambda x: x.split("\\")[-1].split("_")[0] + "#" + x.split("\\")[-1].split("_")[-1].replace(".jpg", ""),efiles))
    for code,idf in dfs:
        work_dates = list(idf['work_date'].values)
        head = str(code[:2])
        for work_date in work_dates:
            sql = '''
                select code,lb_1 || '-' || lb_2 as key,lb_1 || '-' || lb_2 ||'#' ||substr(p_lb1,0,2) || '-' || substr(p_lb2,0,2) as j_key ,max(n_date) as n_date
            from raw_kmeans_hl_merge_close_cls where date(n_date) <= date('{work_date}') and code like '{head}%'group by code
                '''.format(work_date=work_date,head=head)
            data = query(sql,RAW_HLS_WORK_CONN)[['j_key','code','n_date']].values
            odfs = []
            for i in range(len(data)):
                try:
                    line = data[i]
                    key,code,n_date = line
                    key = "%s#%s" %(code,n_date.replace("-",""))
                    if key in ekeys:
                        print("---------%s exists" %(key))
                        continue
                    ef = 'Dones' if work_date == n_date else 'Going'
                    out_file = r'D:\data\images\daily\%s\%s' % (work_date, ef)
                    dest_file = "%s\\%s" %(out_file,'%s_%s_%s.jpg' %(code,key,n_date.replace("-","")))
                    sql = '''
                         select * from (
                         select code,date,close from raw_data_d
                        UNION ALL
                        select DISTINCT code,date,close from raw_data_d_xq_zs
                         ) where code = '{code}'
                    '''.format(code=code)
                    cdf = query(sql, RAW_HLS_WORK_CONN)
                    cdf = cdf.sort_values(by=['date'])
                    cdf['ma60'] = cdf.close.rolling(60).mean().values
                    cdf['ma10'] = cdf.close.rolling(10).mean().values
                    cdf = cdf.dropna()
                    cdf = cdf.sort_values(by=['date'])
                    sql = ''' select * from  (select code,p_date,n_date,lb_1||'-'||lb_2 as key,b.g_key,h,w,ag from raw_kmeans_hl_merge_close_cls a,raw_kmeans_gkey_kv b
                    where lb_1||'-'||lb_2 = b.key) where code = '{code}' order by n_date '''.format(code=code)
                    wdf = query(sql,RAW_HLS_WORK_CONN)
                    wdf = wdf.sort_values(by=['n_date'])
                    cidx = np.argwhere(cdf.date.values == n_date)[0,0]
                    widx = np.argwhere(wdf.n_date.values == n_date)[0, 0]
                    ceidx = 454 if cidx < 454 else cidx
                    csidx = ceidx - 454
                    hdf = cdf.iloc[csidx:ceidx+1]
                    sdate =wdf.n_date.values[widx-2]
                    fcidx = np.argwhere(cdf.date.values == sdate)[0,0]
                    gap = 0 if len(cdf) - fcidx -455 >=0  else abs(len(cdf) - fcidx -455)
                    fcidx = fcidx - gap
                    fdf = cdf[fcidx:fcidx + 1 + 454]
                    mask_c_h, rdf_h = _draw_close(n_date, wdf.n_date.values, hdf, num=456, c=4)
                    rdf_h['type'] = 'H'
                    mask_c_f, rdf_f = _draw_close(n_date, wdf.n_date.values, fdf, num=456, c=4,cdate=work_date)
                    rdf_f['type'] = 'F'
                    rdf_h['code'] = code
                    rdf_f['code'] = code

                    odf = pd.concat([rdf_h,rdf_f])
                    odf['e_type'] = ef
                    odfs.append(odf)
                    mask_c = np.hstack([mask_c_h,mask_c_f])
                    mask_c = cv2.resize(mask_c, (2250, 440), cv2.INTER_LINEAR)
                    start = sorted(list(rdf_h.p_date.values))[0]
                    end  =  sorted(list(rdf_h.n_date.values))[-1]
                    w_sidx = np.argwhere(wdf.n_date.values == start)[0, 0]
                    w_eidx = np.argwhere(wdf.n_date.values == end)[0, 0]
                    wdf = wdf.iloc[w_sidx:w_eidx+1]
                    mask_w = _draw_hw(n_date, wdf)
                    mask_w = cv2.resize(mask_w, (440, 440), cv2.INTER_LINEAR)
                    info_append = odf[['c_date', 'dt_a', 'dt_b', 'ag_c']].values
                    mask_i = _draw_hl_info(n_date, wdf, info_append)
                    mask_n = np.hstack([mask_w, mask_i, mask_c])
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    mask_n = cv2.putText(mask_n, code, (20, 20), font, 0.7, (0,0,0), 1)
                    if True:
                        if not os.path.exists(out_file):
                            os.makedirs(out_file)
                        cv2.imwrite(r'%s\%s' %(out_file,'%s_%s_%s.jpg' %(code,key,n_date.replace("-",""))),mask_n)
                    print("%s %s %s-------Done" %(i,code,len(data)))
                    print(len(cdf))
                except:
                    print("%s------------------------------Issue" %(key))
                    import traceback
                    traceback.print_exc()
                    pass
            #frdf = pd.concat(odfs)
            #insert(frdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_daily',opType='append')
            #print(len(df))
def draw_line_D_ByDate():
    df = query("select distinct n_date from raw_data_d_hl_wave13_pn_merge order by n_date desc limit 5",RAW_HLS_WORK_CONN)
    #dfs = df.groupby('code')
    efiles = glob.glob(r'D:\data\images\daily\*')
    edates = list(map(lambda x:x.split("\\")[-1],efiles))
    work_dates = list(df['n_date'].values)

    for work_date in work_dates:
        if work_date in edates:
            continue
        sql = '''
            select code,lb_1 || '-' || lb_2 as key,lb_1 || '-' || lb_2 ||'#' ||substr(p_lb1,0,2) || '-' || substr(p_lb2,0,2) as j_key ,max(n_date) as n_date
        from raw_kmeans_hl_merge_close_cls where date(n_date) <= date('{work_date}') and code like '{head}%'group by code
            '''.format(work_date=work_date,head='s')
        data = query(sql,RAW_HLS_WORK_CONN)[['j_key','code','n_date']].values
        # efiles = glob.glob(r'D:\data\images\daily\%s\*\*' %(work_date))
        # try:
        #     ekeys = list(map(lambda x: x.split("\\")[-1].split("_")[0] + "#" + x.split("\\")[-1].split("_")[-1].replace(".jpg", ""),efiles))
        # except:
        #     ekeys = []
        ekeys = []
        odfs = []
        for i in range(len(data)):
            try:
                line = data[i]
                key,code,n_date = line
                ekey = "%s#%s" % (code, n_date.replace("-", ""))
                if ekey in ekeys:
                    print("---------%s exists" % (key))
                    continue
                ef = 'Dones' if work_date == n_date else 'Going'
                out_file = r'D:\data\images\daily\%s\%s' % (work_date, ef)
                #dest_file = "%s\\%s" %(out_file,'%s_%s_%s.jpg' %(code,key,n_date.replace("-","")))
                sql = '''
                     select * from (
                     select code,date,close from raw_data_d
                    UNION ALL
                    select DISTINCT code,date,close from raw_data_d_xq_zs
                     ) where code = '{code}'
                '''.format(code=code)
                cdf = query(sql, RAW_HLS_WORK_CONN)
                cdf = cdf.sort_values(by=['date'])
                cdf['ma60'] = cdf.close.rolling(60).mean().values
                cdf['ma10'] = cdf.close.rolling(10).mean().values
                cdf = cdf.dropna()
                cdf = cdf.sort_values(by=['date'])
                sql = ''' select * from  (select code,p_date,n_date,lb_1||'-'||lb_2 as key,b.g_key,h,w,ag from raw_kmeans_hl_merge_close_cls a,raw_kmeans_gkey_kv b
                where lb_1||'-'||lb_2 = b.key) where code = '{code}' order by n_date '''.format(code=code)
                wdf = query(sql,RAW_HLS_WORK_CONN)
                wdf = wdf.sort_values(by=['n_date'])
                cidx = np.argwhere(cdf.date.values == n_date)[0,0]
                widx = np.argwhere(wdf.n_date.values == n_date)[0, 0]
                ceidx = 454 if cidx < 454 else cidx
                csidx = ceidx - 454
                hdf = cdf.iloc[csidx:ceidx+1]
                sdate =wdf.n_date.values[widx-2]
                fcidx = np.argwhere(cdf.date.values == sdate)[0,0]
                gap = 0 if len(cdf) - fcidx -455 >=0  else abs(len(cdf) - fcidx -455)
                fcidx = fcidx - gap
                fdf = cdf[fcidx:fcidx + 1 + 454]
                mask_c_h, rdf_h = _draw_close(n_date, wdf.n_date.values, hdf, num=456, c=4)
                rdf_h['type'] = 'H'
                mask_c_f, rdf_f = _draw_close(n_date, wdf.n_date.values, fdf, num=456, c=4,cdate=work_date)
                rdf_f['type'] = 'F'
                rdf_h['code'] = code
                rdf_f['code'] = code


                odf = pd.concat([rdf_h,rdf_f])
                odf['e_type'] = ef
                odfs.append(odf)
                mask_c = np.hstack([mask_c_h,mask_c_f])
                mask_c = cv2.resize(mask_c, (2250, 440), cv2.INTER_LINEAR)
                start = sorted(list(rdf_h.p_date.values))[0]
                end  =  sorted(list(rdf_h.n_date.values))[-1]
                w_sidx = np.argwhere(wdf.n_date.values == start)[0, 0]
                w_eidx = np.argwhere(wdf.n_date.values == end)[0, 0]
                wdf = wdf.iloc[w_sidx:w_eidx+1]
                mask_w = _draw_hw(n_date, wdf)
                mask_w = cv2.resize(mask_w, (440, 440), cv2.INTER_LINEAR)
                info_append = odf[['c_date', 'dt_a', 'dt_b', 'ag_c']].values
                mask_i = _draw_hl_info(n_date, wdf, info_append)
                mask_n = np.hstack([mask_w, mask_i, mask_c])
                font = cv2.FONT_HERSHEY_SIMPLEX
                mask_n = cv2.putText(mask_n, code, (20, 20), font, 0.7, (0,0,0), 1)
                if True:
                    if not os.path.exists(out_file):
                        os.makedirs(out_file)
                    cv2.imwrite(r'%s\%s' %(out_file,'%s_%s_%s.jpg' %(code,key,n_date.replace("-",""))),mask_n)
                print("%s %s %s-------Done" %(i,code,len(data)))
                print(len(cdf))
            except:
                import traceback
                traceback.print_exc()
                pass
        #frdf = pd.concat(odfs)
        #insert(frdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_daily',opType='append')
        #print(len(df))
def draw_line_D_ByDateDone():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    sql = '''
           select code,lb_1 || '-' || lb_2 as key,lb_1 || '-' || lb_2 ||'#' ||substr(p_lb1,0,2) || '-' || substr(p_lb2,0,2) as j_key ,n_date
        from raw_kmeans_hl_merge_close_cls where date(n_date) > date('2022-02-01')
            '''
    df = query(sql, RAW_HLS_WORK_CONN)
    efiles = glob.glob(r'D:\data\images\daily\*\Dones\*.jpg' )
    try:
        ekeys = list(map(lambda x: x.split("\\")[-1].split("_")[0] + "#" + x.split("\\")[-1].split("_")[-1].replace(".jpg", ""),efiles))
    except:
        ekeys = []
    dfs = df.groupby('code')
    for code,idf in dfs:
        data = idf[['j_key', 'code', 'n_date']].values
        sql = '''
                                 select * from (
                                 select code,date,close from raw_data_d
                                UNION ALL
                                select DISTINCT code,date,close from raw_data_d_xq_zs
                                 ) where code = '{code}'
                            '''.format(code=code)
        cdf = query(sql, RAW_HLS_WORK_CONN)
        cdf = cdf.sort_values(by=['date'])
        cdf['ma60'] = cdf.close.rolling(60).mean().values
        cdf['ma10'] = cdf.close.rolling(10).mean().values
        cdf = cdf.dropna()
        cdf = cdf.sort_values(by=['date'])
        sql = ''' select * from  (select code,p_date,n_date,lb_1||'-'||lb_2 as key,b.g_key,h,w,ag from raw_kmeans_hl_merge_close_cls a,raw_kmeans_gkey_kv b
                            where lb_1||'-'||lb_2 = b.key) where code = '{code}' order by n_date '''.format(code=code)
        wdf_hist = query(sql, RAW_HLS_WORK_CONN)
        wdf_hist = wdf_hist.sort_values(by=['n_date'])
        odfs = []
        for i in range(len(data)):
            try:
                line = data[i]
                key, code, n_date = line
                ekey = "%s#%s" % (code, n_date.replace("-", ""))
                if ekey in ekeys:
                    print("---------%s exists" % (key))
                    continue
                #out_file = r'D:\data\images\done_images\%s' %(n_date)
                out_file = r'D:\data\images\daily\%s\Dones' %(n_date)
                cidx = np.argwhere(cdf.date.values == n_date)[0, 0]
                widx = np.argwhere(wdf_hist.n_date.values == n_date)[0, 0]
                ceidx = 454 if cidx < 454 else cidx
                csidx = ceidx - 454
                hdf = cdf.iloc[csidx:ceidx + 1]
                sdate = wdf_hist.n_date.values[widx - 2]
                fcidx = np.argwhere(cdf.date.values == sdate)[0, 0]
                gap = 0 if len(cdf) - fcidx - 455 >= 0 else abs(len(cdf) - fcidx - 455)
                fcidx = fcidx - gap
                fdf = cdf[fcidx:fcidx + 1 + 454]
                mask_c_h, rdf_h = _draw_close(n_date, wdf_hist.n_date.values, hdf, num=456, c=4)
                mask_c_f, _ = _draw_close(n_date, wdf_hist.n_date.values, fdf, num=456, c=4, cdate=n_date)
                rdf_h['code'] = code
                rdf_h['work_date'] = n_date
                odf = rdf_h
                odfs.append(odf)
                mask_c = np.hstack([mask_c_h, mask_c_f])
                mask_c = cv2.resize(mask_c, (2250, 440), cv2.INTER_LINEAR)
                start = sorted(list(rdf_h.p_date.values))[0]
                end = sorted(list(rdf_h.n_date.values))[-1]
                w_sidx = np.argwhere(wdf_hist.n_date.values == start)[0, 0]
                w_eidx = np.argwhere(wdf_hist.n_date.values == end)[0, 0]
                wdf = wdf_hist.iloc[w_sidx:w_eidx + 1]
                mask_w = _draw_hw(n_date, wdf)
                mask_w = cv2.resize(mask_w, (440, 440), cv2.INTER_LINEAR)
                info_append = odf[['c_date', 'dt_a', 'dt_b', 'ag_c']].values
                mask_i = _draw_hl_info(n_date, wdf, info_append)
                mask_n = np.hstack([mask_w, mask_i, mask_c])
                font = cv2.FONT_HERSHEY_SIMPLEX
                mask_n = cv2.putText(mask_n, code, (20, 20), font, 0.7, (0, 0, 0), 1)
                if True:
                    if not os.path.exists(out_file):
                        os.makedirs(out_file)
                    cv2.imwrite(r'%s\%s' % (out_file, '%s_%s_%s.jpg' % (code, key, n_date.replace("-", ""))),mask_n)
                print("%s %s %s %s-------Done" % (i, code, len(data),n_date))
                print(len(cdf))
            except:
                print('####################%s' %(code))
                import traceback
                traceback.print_exc()
                pass
        # if len(odfs) > 0:
        #     frdf = pd.concat(odfs)
        #     insert(frdf, RAW_HLS_WORK_CONN, 'raw_kmeans_hl_merge_close_summary_drawline_daily_done', opType='append')
        #     print(len(df))

def draw_line_D_ByDaily():
    df = query("select distinct n_date from raw_data_d_hl_wave13_pn_merge order by n_date desc limit 1",RAW_HLS_WORK_CONN)
    #dfs = df.groupby('code')
    efiles = glob.glob(r'D:\data\images\daily\*')
    edates = list(map(lambda x:x.split("\\")[-1],efiles))
    work_dates = list(df['n_date'].values)

    for work_date in work_dates:
        sql = '''
            select code,lb_1 || '-' || lb_2 as key,lb_1 || '-' || lb_2 ||'#' ||substr(p_lb1,0,2) || '-' || substr(p_lb2,0,2) as j_key ,max(n_date) as n_date
        from raw_kmeans_hl_merge_close_cls where date(n_date) <= date('{work_date}') and code like '{head}%'group by code
            '''.format(work_date=work_date,head='s')
        data = query(sql,RAW_HLS_WORK_CONN)[['j_key','code','n_date']].values
        ekeys = []
        odfs = []
        for i in range(len(data)):
            try:
                line = data[i]
                key,code,n_date = line
                ekey = "%s#%s" % (code, n_date.replace("-", ""))
                if ekey in ekeys:
                    print("---------%s exists" % (key))
                    continue
                ef = 'Dones' if work_date == n_date else 'Going'
                out_file = r'D:\data\images\daily\%s\%s' % (work_date, ef)
                sql = '''
                     select * from (
                     select code,date,close from raw_data_d
                    UNION ALL
                    select DISTINCT code,date,close from raw_data_d_xq_zs
                     ) where code = '{code}'
                '''.format(code=code)
                cdf = query(sql, RAW_HLS_WORK_CONN)
                cdf = cdf.sort_values(by=['date'])
                cdf['ma60'] = cdf.close.rolling(60).mean().values
                cdf['ma10'] = cdf.close.rolling(10).mean().values
                cdf = cdf.dropna()
                cdf = cdf.sort_values(by=['date'])
                sql = ''' select * from  (select code,p_date,n_date,lb_1||'-'||lb_2 as key,b.g_key,h,w,ag from raw_kmeans_hl_merge_close_cls a,raw_kmeans_gkey_kv b
                where lb_1||'-'||lb_2 = b.key) where code = '{code}' order by n_date '''.format(code=code)
                wdf = query(sql,RAW_HLS_WORK_CONN)
                wdf = wdf.sort_values(by=['n_date'])
                cidx = np.argwhere(cdf.date.values == n_date)[0,0]
                widx = np.argwhere(wdf.n_date.values == n_date)[0, 0]
                ceidx = 454 if cidx < 454 else cidx
                csidx = ceidx - 454
                hdf = cdf.iloc[csidx:ceidx+1]
                sdate =wdf.n_date.values[widx-2]
                fcidx = np.argwhere(cdf.date.values == sdate)[0,0]
                gap = 0 if len(cdf) - fcidx -455 >=0  else abs(len(cdf) - fcidx -455)
                fcidx = fcidx - gap
                fdf = cdf[fcidx:fcidx + 1 + 454]
                mask_c_h, rdf_h = _draw_close(n_date, wdf.n_date.values, hdf, num=456, c=4)
                rdf_h['type'] = 'H'
                mask_c_f, rdf_f,daily_line = _draw_close(n_date, wdf.n_date.values, fdf, num=456, c=4,cdate=work_date,append_info=True)
                rdf_f['type'] = 'F'
                rdf_h['code'] = code
                rdf_f['code'] = code
                odfs.append(rdf_f)
                odf = pd.concat([rdf_h,rdf_f])
                odf['e_type'] = ef
                rdf_f['day_dtb'] = daily_line[0]
                rdf_f['day_agc'] = daily_line[1]
                #odfs.append(odf)
                mask_c = np.hstack([mask_c_h,mask_c_f])
                mask_c = cv2.resize(mask_c, (2250, 440), cv2.INTER_LINEAR)
                start = sorted(list(rdf_h.p_date.values))[0]
                end  =  sorted(list(rdf_h.n_date.values))[-1]
                w_sidx = np.argwhere(wdf.n_date.values == start)[0, 0]
                w_eidx = np.argwhere(wdf.n_date.values == end)[0, 0]
                wdf = wdf.iloc[w_sidx:w_eidx+1]
                mask_w = _draw_hw(n_date, wdf)
                mask_w = cv2.resize(mask_w, (440, 440), cv2.INTER_LINEAR)
                info_append = odf[['c_date', 'dt_a', 'dt_b', 'ag_c']].values
                mask_i = _draw_hl_info(n_date, wdf, info_append)
                mask_n = np.hstack([mask_w, mask_i, mask_c])
                font = cv2.FONT_HERSHEY_SIMPLEX
                mask_n = cv2.putText(mask_n, code, (20, 20), font, 0.7, (0,0,0), 1)
                if True:
                    if not os.path.exists(out_file):
                        os.makedirs(out_file)
                    cv2.imwrite(r'%s\%s' %(out_file,'%s_%s_%s.jpg' %(code,key,n_date.replace("-",""))),mask_n)
                print("%s %s %s-------Done" %(i,code,len(data)))
                print(len(cdf))
            except:
                import traceback
                traceback.print_exc()
                pass
        frdf = pd.concat(odfs)
        insert(frdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_daily_ongoing')

def genDrawLineKmeans():
    from sklearn.cluster import KMeans
    import pickle
    def _getModel(X, model_name, cls=9, rs=170):
        if not os.path.exists(model_name):
            kmeans = KMeans(cls, random_state=rs)
            kmeans.fit(X)
            with open(model_name, 'wb') as f:
                pickle.dump(kmeans, f)
        with open(model_name, 'rb') as f:
            kmeans = pickle.load(f)
            # kmeans = pickle.loads(s2)
        return kmeans

    sql = '''
        select code,work_date,n_date,c_date,p_date,dt_a,dt_b,ag_c,p_y,c_y,n_y from raw_kmeans_hl_merge_close_summary_drawline       
         '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql, RAW_HLS_WORK_CONN)
    X = df[['ag_c']].values
    kmeans = _getModel(X, r'D:\code_center\TmpProject\agtest\models\kmean_DrawLine_LV1')
    labels = kmeans.predict(X)  # 预测分类
    df['lb_1'] = labels
    dfs = df.groupby('lb_1')
    odfs = []
    for lb, idf in dfs:
        X = idf[['dt_a','dt_b']].values
        kmeans = _getModel(X, r'D:\code_center\TmpProject\agtest\models\kmean_DrawLine_LV2_%s' % (lb), 5, 170)
        kmeans.fit(X)  # 训练模型
        labels = kmeans.predict(X)
        idf['lb_2'] = labels
        odfs.append(idf)
    rdf = pd.concat((odfs))
    #'dt_a','dt_b',
    insert(rdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_kmeans_B')
if __name__ == '__main__':
    #draw_line_D()
    draw_line_D_ByDaily()
    #draw_line_D_ByDate()
    #draw_line_D_ByDateDone()