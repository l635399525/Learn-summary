import numpy as np

from com.DbTool import getConn, query, insert
from com.RunConf import RAW_FINAL_FORMAT_HL_FILE, RAW_NET_WORK_FILE, RAW_HLS_WORK_FILE

def draw_line():
    dest_conn = getConn(RAW_HLS_WORK_FILE)

    sql = '''
    select * from raw_data_d where code = 'sz.002214' and date(date) >= date('2019-07-19') order by date limit 364
    '''
    df = query(sql,draw_line)

def move_data_day():
    conn = getConn(RAW_FINAL_FORMAT_HL_FILE)
    net_conn = getConn(RAW_NET_WORK_FILE)
    sql = '''
   select a.code,code_name, date, open, close, high, low, volume, amount, percent as pctchg from raw_data_d_xq_tmp a,
(select code,max(code_name) as code_name from raw_data_d group by code) b where a.code = b.code
union all
select code, code_name, date, open, close, high, low, volume, amount, pctchg from raw_data_d
where date(date) > date('2022-01-01') and  code || date not in (select distinct code||date from raw_data_d_xq_tmp)
and code in (select distinct code from raw_data_d_xq_tmp)
    '''
    df = query(sql,conn)
    insert(df,net_conn,'raw_data_d')
    print("------------Move Done--------------")
def move_data_HL():
    dest_conn = getConn(RAW_HLS_WORK_FILE)
    srcs_conn = getConn(RAW_NET_WORK_FILE)
    df = query('select code, date, open, close, high, low, pctchg, volume from raw_data_d',srcs_conn)
    insert(df,dest_conn,'raw_data_d')
from sklearn import preprocessing
fit = preprocessing.MinMaxScaler()
#std_img = fit.fit_transform(stds_img)


if __name__ == '__main__':
    import cv2
    dest_conn = getConn(RAW_HLS_WORK_FILE)
    sql = '''
        select * from raw_data_d where code = 'sz.002214' and date(date) >= date('2019-07-19') order by date limit 364
        '''
    #cv2.line(mask, (pd_idx - sd_idx, pd_val), (nd_idx - sd_idx, nd_val), (0, 255, 0), thickness=1)
    df = query(sql, dest_conn)
    closes = df['close'].values
    std_close = fit.fit_transform(fit.fit_transform(closes.reshape(len(closes),1)))[:,0]
    closes_points = np.round((440 - std_close * 405) - 15).astype(int)
    mask = np.zeros((440,1820))
    mask = np.zeros((440,1820, 3), np.uint8) + 200
    #cv2.line(mask, (0, 0), (200, 200), (0, 255, 0), thickness=1)
    #cv2.imshow('a', mask)
    #cv2.waitKey(0)
    #x = np
    x = np.asarray(range(1,365))*5
    data = np.vstack([x, closes_points])

    for i in range(1,data.shape[1]):
        c_point = data[:,i]
        p_point = data[:,i-1]
        cv2.line(mask, (p_point[0], p_point[1]), (c_point[0], c_point[1]), (0, 0, 0), thickness=1)
        print(i)
    cv2.imshow('a',mask)
    cv2.waitKey(0)
    #mask[x,closes_points] = 255
    #print(mask)
