from com.RunConf import RAW_HLS_WORK_FILE

sql_key_kpi = '''
select a.*,b.ar_k1,c.ar_k2,b.acnt_sum_k1,c.acnt_sum_k2,b.cnt_sum_k1,c.cnt_sum_k2,a.key_p1||'#'||a.key_p2 as key from
(select * from
(select a.key_p1, a.key_p2, a.cnts, acnt, acnt * 1.0 / cnts as arate
from (select key_p1, key_p2, count(*) as cnts
from raw_kmeans_hl_merge_close_summary_pns
group by key_p1, key_p2) a
   left outer join
(select key_p1, key_p2, count(*) as acnt
from raw_kmeans_hl_merge_close_summary_pns
where h > 10
group by key_p1, key_p2) b
on a.key_p1 = b.key_p1 and a.key_p2 = b.key_p2)
order by key_p1,key_p2) a,
(select a.key_p1,acnt*1.0/cnts ar_k1,a.cnts as cnt_sum_k1,b.acnt as acnt_sum_k1 from
(select key_p1,count(*) as cnts from raw_kmeans_hl_merge_close_summary_pns group by key_p1) a
left outer join
(select key_p1,count(*) as acnt from raw_kmeans_hl_merge_close_summary_pns where h > 10 group by key_p1) b
on a.key_p1 = b.key_p1) b,
(
select a.key_p2,acnt*1.0/cnts ar_k2,a.cnts as cnt_sum_k2,b.acnt as acnt_sum_k2 from
(select key_p2,count(*) as cnts from raw_kmeans_hl_merge_close_summary_pns group by key_p2) a
left outer join
(select key_p2,count(*) as acnt from raw_kmeans_hl_merge_close_summary_pns where h > 10 group by key_p2) b
on a.key_p2 = b.key_p2)c
where a.key_p1 = b.key_p1 and a.key_p2 = c.key_p2
'''
from com.DbTool import query, insert, delete, drop,getConn

conn = getConn(RAW_HLS_WORK_FILE)


def getKmeansKeyKPISCSV_A():
    df = query(sql_key_kpi,conn)
    df.to_csv(r'D:\data\bishow\kmeans_key_kpis.csv')

def getKmeanDetailData_B():
    sql = '''
    select distinct code,code||p_date||n_date as j_key, p_date, n_date, ag, h, w, std_h, d_h, std_c, d_c, tws, d_ag from raw_kmeans_hl_merge_close
    '''
    df = query(sql,conn)
    df.to_csv(r'D:\data\bishow\kmeans_data_detail.csv')
    import shutil
    shutil.copy(r'D:\data\bishow\kmeans_data_detail.csv',r'D:\data\bishow\kmeans_data_detail_Next.csv')
def getKmeanClsMapping_C():
    sql = '''
    select key,g_key from raw_kmeans_gkey_kv
    '''
    df = query(sql,conn)
    df.to_csv(r'D:\data\bishow\kmeans_cls_mapping.csv')

def getKmeansClsSummary_D():
    sql = '''
        select code,j_key, key,p_key, p_date, n_date, h, w, ag, degress,
           dist_stds, dist_avgs, dist_sum_a, dist_sum_b, dist_a_idx, dist_b_idx,
           dist_a_cnt, dist_b_cnt, dist_max, dist_min, n_h, n_ag, n_w from raw_kmeans_hl_merge_close_summary
        '''
    df = query(sql,conn)
    df.to_csv(r'D:\data\bishow\kmeans_sum_dataA.csv')
    df.to_csv(r'D:\data\bishow\kmeans_sum_dataB.csv')

def getHLRawWaveData_E():
    sql = '''
select distinct code, sdate, work_date, type, cls, close as ec, pctchg from raw_data_d_hl_wave13
    '''
    #conn = getConn(r'D:\data\RAW_FINAL_FORMAT_HL')
    df = query(sql,conn)
    df.to_csv(r'D:\data\bishow\HL_Wave_Raw.csv')
def getHLDailyCloseData_F():
    sql = '''
select code, p_date, n_date, ag, h, w, std_h, d_h,sub_h, sub_std_h,  std_c, d_c, tws, d_ag, type, s_ag, s_h, s_w, sdate, today, p_h, c_h, p_w, c_w, p_ag, c_ag, g_key, g_t_key, wave_cnt, lcl, ucl, pct, lr, ur, c, min, max
from raw_kmeans_hl_merge_close_daily_summary
    '''
    df = query(sql,conn)
    df.to_csv(r'D:\data\bishow\HL_Daily_Close_Raw.csv')
def getHLWaveDailyData_G():
    #conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
    sql = '''
select  distinct code, sdate, work_date, cclose ,cls_chg, max_c8, min_c8, max_c13, min_c13, max_c21, min_c21, ugc, lgc, l_dist, u_dist, gu_dist, gl_dist from raw_data_d_hl_wave13_pn_daily
    '''
    df = query(sql,conn)
    print("########%s" %(len(df)))
    df.to_csv(r'D:\data\bishow\HL_Wave_Daily_Status.csv')
import shutil
def getDrawLine5shapeData():
    sql = '''
    select type,cls,sum(af) as afs,count(*) as cnts,sum(af)*1.0/count(*) as ar from (select a.code
                    , a.work_date
                    , a.c_date
                    , a.type
                    , a.cls
                    , a.pv_fr
                    , b.pv_xgb
                    , a.y
                    , case when a.y == a.pv_fr then 1 else 0 end as af
               from (select code, work_date, c_date, type, cls,  y, pv  as pv_fr, gap as gap_fr,  dt
                     from test_merge_result_v1
                     where mtype = 'fr') a,
                    (select code, work_date, c_date, type, cls, y, pv  as pv_xgb, gap as gap_xgb, model
                     from test_merge_result_v1
                     where mtype = 'xgb') b
               where a.code = b.code
                 and a.work_date = b.work_date
                 and a.c_date = b.c_date
                 and a.type = b.type
                 and a.cls = b.cls
                 and a.pv_fr = b.pv_xgb
                 and a.dt = 'tests'
              ) group by type,cls
    '''
    df_summary = query(sql,conn)
    df_summary.to_csv(r'D:\data\bishow\HL_DrawLine_Train_Result_Summary.csv')

    sql = '''
    select a.code
                    , a.work_date
                    , a.c_date
                    , a.type
                    , a.dt
                    , a.cls
                    , a.pv_fr
                    , b.pv_xgb
                    , a.y
                    , case when a.y == a.pv_fr then 1 else 0 end as af
                    ,gap_fr
                    ,gap_xgb
               from (select code,
                            work_date,
                            c_date,
                            type,
                            cls,
                            y,
                            pv  as pv_fr,
                            gap as gap_fr,
                            dt
                     from test_merge_result_v1
                     where mtype = 'fr') a,
                    (select code,
                            work_date,
                            c_date,
                            type,
                            cls,
                            y,
                            pv  as pv_xgb,
                            gap as gap_xgb,
                            model
                     from test_merge_result_v1
                     where mtype = 'xgb') b
               where a.code = b.code
                 and a.work_date = b.work_date
                 and a.c_date = b.c_date
                 and a.type = b.type
                 and a.cls = b.cls
                 and a.pv_fr = b.pv_xgb
    '''
    df_detail = query(sql,conn)
    df_detail.to_csv(r'D:\data\bishow\HL_DrawLine_Train_Result_Detail.csv')
    print("####################getDrawLine5shapeData#####################")
def getKlineChart():
    sql = '''
    select p_date, p_close, c_date, c_close, n_date, n_close, p_x, p_y, c_x, c_y, n_x, n_y, dt_a, dt_b, dt_c, ag_a, ag_b, ag_c, code, key, work_date, file from raw_kmeans_hl_merge_close_summary_drawline_daily
    '''
    df_detail = query(sql, conn)
    df_detail.to_csv(r'D:\data\bishow\HL_DrawLine_Detail.csv')
    print("####################getKlineChart#####################")
def getKlineTrainRawData():
    sql = '''
    select  code, work_date, c_date, type, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt, y_dt, a_ag, y_ag from raw_kmeans_hl_merge_close_summary_drawline_train_data_0
union
select  code, work_date, c_date, type, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt, y_dt, a_ag, y_ag from raw_kmeans_hl_merge_close_summary_drawline_train_data_1
    '''
    df_detail = query(sql, conn)
    df_detail.to_csv(r'D:\data\bishow\HL_DrawLine_train_raw_data.csv')
    print("####################getKlineTrainRawData#####################")
def genTrainingDailyAnalysis():
    sql = '''
    select a.code,a.work_date,a.c_date,a.type,a.cls,a.act_y_dt,a.pv_xgb,b.pv_fr,a.gap_xgb,b.gap_fr from
(select code,work_date,c_date,act_y_dt,pv as pv_xgb,cls,type,gap as gap_xgb
from test_merge_result_dt where mtype = 'xgb' ) a,
(select code,work_date,c_date,act_y_dt,pv as pv_fr,cls,type,gap as gap_fr
from test_merge_result_dt where mtype = 'fr') b,
(select code,max(work_date) as work_date from test_merge_result_dt group by code) c
where a.code = b.code and a.work_date = b.work_date and a.c_date = b.c_date
    and a.code = c.code and a.work_date = c.work_date
    '''
if __name__ == '__main__':
    if False:
        print("##################A###################")
        getKmeansKeyKPISCSV_A()
        print("##################B###################")
        getKmeanDetailData_B()
        print("##################C###################")
        getKmeanClsMapping_C()
        print("##################D###################")
        getKmeansClsSummary_D()
        print("##################E###################")
        getHLRawWaveData_E()
        print("##################F###################")
        getHLDailyCloseData_F()
        print("##################G###################")
        getHLWaveDailyData_G()
    if True:
        getDrawLine5shapeData()
        getKlineChart()
        getKlineTrainRawData()
    #getKmeanClsMapping_C()
    #shutil.copy(r'D:\data\bishow\kmeans_data_detail.csv',r'D:\data\bishow\kmeans_data_detail_Next.csv')

    ### cron job 跟HQ 要一下   还有 个hadoop log purge
    ### 培俊家的 project 的flume 什么时间上
    ### xjiang 要写code 研究
    ### nzhangb cdh upgrade