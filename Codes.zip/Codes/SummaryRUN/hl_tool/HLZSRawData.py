from com.DbTool import getConn, query, insert
from com.RunConf import RAW_NET_WORK_FILE,RAW_HLS_WORK_FILE
from hl_tool.HlTool import _getAngle


def _getEdateMap(RAW_FINAL_FORMAT_CONN,column='date',table='raw_d_data'):
    sql = '''
        select code,{column} from {table} group by code,{column}
        '''.format(column=column, table=table)
    try:
        df = query(sql, RAW_FINAL_FORMAT_CONN)
        dfs = df.groupby('code')
        date_map = {}
        for code, idf in dfs:
            dates = sorted(list(idf[column].values))
            date_map[code] = dates
    except:
        date_map = {}
    return date_map
from datetime import datetime
import numpy as np
import pandas as pd
def __datetime(df):
    a = df['date']
    b = df['sdate']
    gap = (datetime.strptime(a,'%Y-%m-%d') - datetime.strptime(b,'%Y-%m-%d')).days
    return gap
def getClsA(df):
    h = len(df)
    mv = h%9
    try:
        pdf = df[:mv]
    except:
        pdf = None
    ndf = df[mv:]
    idxes = np.asarray(range(len(ndf)))
    idxes_lst = np.split(idxes,9)
    mcask_fcls = np.zeros(mv+len(ndf))
    tmp_idx_lst = np.zeros(len(idxes_lst))
    if pdf is not None:
        df0 = ndf.iloc[idxes_lst[0]]
        df0 = pd.concat([pdf,df0])
        df0_vi = np.argmax(df0.close.values)
        df0_v  = df0.close.values[df0_vi]
        tmp_idx_lst[0] = df0_vi
    df9 = ndf.iloc[-1]
    df9_v = df9.close
    tmp_idx_lst[-1] = len(df) - 1
    mask = np.zeros(9)
    mask[0]  = df0_v
    mask[-1] = df9_v
    for i in range(1,len(idxes_lst) - 1):
        lst = idxes_lst[i]
        tdf = ndf.iloc[lst]
        idx = np.argmax(tdf.close.values)
        tmp_idx_lst[i] = lst[idx] + mv
        max_v = tdf.close.values[idx]
        mask[i] = max_v
    mask_sort = np.argsort(mask)
    mask_cls = np.zeros(9)
    for i in range(mask_sort.shape[0]):
        mask_cls[mask_sort[i]] = i + 1
    tmp_idx_lst = tmp_idx_lst.astype(int)
    mcask_fcls[tmp_idx_lst] = mask_cls
    return mcask_fcls
def getClsB(df):
    h = len(df)
    mv = h%9
    try:
        pdf = df[:mv]
    except:
        pdf = None
    ndf = df[mv:]
    idxes = np.asarray(range(len(ndf)))
    idxes_lst = np.split(idxes,9)
    mcask_fcls = np.zeros(mv+len(ndf))
    tmp_idx_lst = np.zeros(len(idxes_lst))
    if pdf is not None:
        df0 = ndf.iloc[idxes_lst[0]]
        df0 = pd.concat([pdf,df0])
        df0_vi = np.argmin(df0.close.values)
        df0_v  = df0.close.values[df0_vi]
        tmp_idx_lst[0] = df0_vi
    df9 = ndf.iloc[-1]
    df9_v = df9.close
    tmp_idx_lst[-1] = len(df) - 1
    mask = np.zeros(9)
    mask[0]  = df0_v
    mask[-1] = df9_v
    for i in range(1,len(idxes_lst) - 1):
        lst = idxes_lst[i]
        tdf = ndf.iloc[lst]
        idx = np.argmin(tdf.close.values)
        tmp_idx_lst[i] = lst[idx] + mv
        max_v = tdf.close.values[idx]
        mask[i] = max_v
    mask_sort = np.argsort(mask)
    mask_cls = np.zeros(9)
    for i in range(mask_sort.shape[0]):
        mask_cls[mask_sort[i]] = -9 + i
    tmp_idx_lst = tmp_idx_lst.astype(int)
    mcask_fcls[tmp_idx_lst] = mask_cls
    return mcask_fcls
def getDataSplit(df,n):
    #RAW_FINAL_FORMAT_HL_FILE_CONN = getConn(RAW_FINAL_FORMAT_HL_FILE)
    closes = df.close.values
    dates = df.date.values
    h = np.asarray(len(df))
    idxes = np.asarray(range(h))
    mask = np.zeros(h)
    mask_rsp = mask.reshape((int(h/n),n))
    idx_lst = np.split(idxes,h/n)
    for i in range(len(idx_lst)):
        lst = idx_lst[i]
        tdf = df.iloc[lst]
        tdf = tdf.sort_values(by=['date'])
        max_idx = np.argmax(tdf.close.values)
        min_idx = np.argmin(tdf.close.values)
        mask_rsp[i,max_idx] = 1
        mask_rsp[i,min_idx] = -1
    mask_f = mask_rsp.reshape(h)
    mask_r = mask_f.copy()
    n0idx = np.argwhere(mask_f!=0)[:,0]
    tlsta = mask_f[mask_f!=0]
    nlst = tlsta[1:]
    plst = tlsta[:-1]
    same_idx = np.argwhere(plst-nlst==0)[:,0]
    for i in range(same_idx.shape[0]):
        idx = same_idx[i]
        ci = idx
        ni = ci + 1
        tp  = tlsta[ci]
        cvi = n0idx[ci]
        nvi = n0idx[ni]
        if tp > 0:
            idx_s0 = nvi if closes[cvi] > closes[nvi] else cvi
        else:
            idx_s0 = cvi if closes[cvi] > closes[nvi] else nvi
        mask_r[idx_s0] = 0
    cls_idx = np.argwhere(mask_r!=0)[:,0]
    ccls_idx = cls_idx[1:]
    cls = mask_r[ccls_idx]
    pdates  =  dates[cls_idx[:-1] + 1]
    pcloses = closes[cls_idx[:-1] + 1]
    rtdf = df.iloc[ccls_idx].copy()
    rtdf['type'] = cls
    rtdf['sdate'] = pdates
    rtdf['sclose'] = pcloses
    rtdf['days'] = rtdf.apply(lambda x:__datetime(x),axis=1).values
    rtdf['pctchg'] = np.round((rtdf['close'].values - rtdf['sclose'].values)*100/rtdf['sclose'].values,3)
    work_date = dates[-1]
    rtdf['work_date'] = work_date
    adf = rtdf[rtdf['type'] == 1].copy()
    bdf = rtdf[rtdf['type'] == -1].copy()
    if len(adf) < 9:
        adf = adf.sort_values(by=['date'])
        adf['cls'] = None
    else:
        clses = getClsA(adf)
        adf['cls'] = clses
    if len(bdf) < 9:
        bdf = bdf.sort_values(by=['date'])
        bdf['cls'] = None
    else:
        clses = getClsB(bdf)
        bdf['cls'] = clses
    rdf = pd.concat([adf,bdf])
    return rdf
    #insert(adf,RAW_FINAL_FORMAT_HL_FILE_CONN,'raw_data_d_hl_wave%s' %(n),opType='append')
    #insert(bdf,RAW_FINAL_FORMAT_HL_FILE_CONN,'raw_data_d_hl_wave%s' %(n),opType='append')
def getZSHLWaveKData():
    #RAW_FINAL_FORMAT_CLOSE_FILE_CONN = getConn(RAW_FINAL_FORMAT_CLOSE_FILE)
    RAW_HLS_WORK_FILE_CONN = getConn(RAW_HLS_WORK_FILE)
    import numpy as np
    lst_conf = {13:325}
    sql = "select distinct code,close,date from raw_data_d_xq_zs order by code,date"
    df = query(sql,RAW_HLS_WORK_FILE_CONN)
    dfs = df.groupby('code')
    for key,value in lst_conf.items():
        num = 0
        dest_table = 'raw_data_d_zs_hl_wave%s' %(key)
        date_map = _getEdateMap(RAW_HLS_WORK_FILE_CONN,column='work_date',table=dest_table)
        odfs = []
        for code, idf in dfs:
            num = num + 1
            try:
                edates = date_map[code]
            except:
                edates = []
            idf = idf.sort_values(by=['date'])
            fdfs = []
            for i in range(len(idf),325,-1):
                try:
                    tdf = idf[i-key:i].sort_values(by=['date'])
                    closes = tdf.close.values
                    dates = tdf.date.values
                    work_date = dates[-1]
                    eclose = closes[-1]
                    max_val = np.max(closes)
                    min_val = np.min(closes)
                    if eclose == max_val:
                        cls = 1
                    elif eclose == min_val:
                        cls = -1
                    else:
                        cls = 0
                    if cls == 0:
                        continue
                    if work_date in edates:
                        continue
                    input_df = idf[i-value:i].sort_values(by=['date'])
                    if len(input_df) == value:
                        rdf = getDataSplit(input_df,key)
                        rdf = rdf.sort_values(by = ['date','sdate'])
                        ldf = rdf.iloc[-1]
                        fdfs.append(ldf)
                    #print("%s-------------%s %s %s" %(code,i,key,work_date))
                except:
                    pass
            rfdf = pd.DataFrame(fdfs)
            odfs.append(rfdf)
            if False:
                insert(rfdf,RAW_HLS_WORK_FILE_CONN,dest_table,opType='append')
            print("%s %s %s %s" %(code,len(fdfs),num,len(dfs)))
        frdf = pd.concat(odfs)
        insert(frdf, RAW_HLS_WORK_FILE_CONN, dest_table, opType='append')
    try:
        RAW_HLS_WORK_FILE_CONN.commit()
    except:
        pass
import math
def getZSHLMergeData():
    def _cal(a,b):
        if b != b:
            r  = 1 if a > 0 else -1
        else:
            pr = 1 if b > 0 else -1
            if a == 0:
                r = pr
            else:
                r = 1 if a > 0 else -1
        return r
    sql = '''
    select distinct code,sdate,work_date as n_date,pctchg as ny_13,cls as cls_13,close as ec_13,julianday(sdate) - julianday(work_date) as pw from raw_data_d_zs_hl_wave13
    where date = work_date and sdate != work_date 
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql,RAW_HLS_WORK_CONN)
    dfs = df.groupby('code')
    odfs = []
    for code,idf in dfs:
        try:
            idf = idf.sort_values(by=['n_date'])
            idf['p_ec13'] = idf.ec_13.shift(1).values
            idf = idf.dropna()
            #afs = idf.apply(lambda x:1 if x['ec_13'] > x['p_ec13'] else -1,axis=1).values
            h_size = len(idf)
            d_size = len(idf)
            afs = idf.ny_13.apply(lambda x: 1 if x > 0 else -1).values
            oidxes = []
            idxes = []
            for i in range(len(afs)-1):
                c_idx = i
                n_idx = i+1
                c_v = afs[c_idx]
                n_v = afs[n_idx]
                if c_v == n_v:
                    idxes.extend([c_idx,n_idx])
                else:
                    if len(idxes) == 0:
                        idxes.append(c_idx)
                        oidxes.append(list(set(idxes)))
                        idxes = []

                    else:
                        oidxes.append(list(set(idxes)))
                        idxes = []
            if len(idxes) > 0 :
                oidxes.append(list(set(idxes)))
            #oidxes[-1]
            if n_idx not in oidxes[-1]:
                oidxes.append([n_idx])
            rlines = []
            for i in range(len(oidxes)):
                idx = oidxes[i]
                idx = sorted(idx)
                tdf = idf.iloc[idx]
                rline = dict(idf.iloc[idx[-1]])
                pline = dict(idf.iloc[idx[0]])
                sdate = pline['sdate']
                edate = rline['n_date']
                if edate == '2019-07-05':
                    print(edate)
                sdate = str(sdate).replace("/", "-")
                edate = str(edate).replace("/", "-")
                sd = datetime.strptime(sdate, '%Y-%m-%d')
                ed = datetime.strptime(edate, '%Y-%m-%d')
                gap = (ed - sd).days
                rline['sdate'] = sdate
                rline['ny13s'] = round(sum(tdf['ny_13'].values),3)
                rline['se_gap'] = gap
                rlines.append(rline)
            rdf = pd.DataFrame(rlines)
            rdf['p_date'] = rdf['n_date'].shift(1).values
            pds = rdf.apply(lambda x:x['sdate'] if (isinstance(x['p_date'],float) and math.isnan(x['p_date'])) else x['p_date'],axis=1).values
            rdf['p_date'] = pds
            rdf['n_gap'] = rdf.apply(lambda x:(datetime.strptime(x['n_date'], '%Y-%m-%d') - datetime.strptime(x['p_date'], '%Y-%m-%d')).days,axis=1)
            rdf['ag'] = rdf.apply(lambda x: _getAngle(x['ny13s'], x['n_gap']), axis=1)
            if len(rdf) > 0:
                odfs.append(rdf)
            print("%s %s %s %s %s" % (code, len(odfs),h_size,d_size,h_size-d_size))
        except:
            import traceback
            traceback.print_exc()
            pass
    fdf = pd.concat(odfs)
    insert(fdf,RAW_HLS_WORK_CONN,'raw_data_d_zs_hl_wave13_pn_merge')

if __name__ == '__main__':
    #getZSHLWaveKData()
    getZSHLMergeData()