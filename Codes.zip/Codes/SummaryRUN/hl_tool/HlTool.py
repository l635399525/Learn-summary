import glob

import pandas as pd

from PyAngle import Angle
from com.DbTool import getConn, query, insert
from com.RunConf import RAW_NET_WORK_FILE, RAW_HLS_WORK_FILE, RAW_FINAL_FORMAT_ANALYSIS
from datetime import datetime
import math

from draw_tool.DrawTool_Daily import _draw_close, draw_line_D_ByDaily

import os
import cv2
import numpy as np

from draw_tool.MoveToolByData import moveByCodeAnalysis, moveByDateAnalysis


def getDrawLineDataDaily():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    codes = list(query('select distinct code from raw_data_d_hl_wave13_pn_merge group by code',RAW_HLS_WORK_CONN)['code'].values)
    odfs = []
    ekeys = glob.glob(r'D:\data\images\full\*\*.jpg')
    try:
        ekeys = list(map(lambda x:"#".join(str(x).split("\\")[-1].split("_")[:2]),ekeys))
    except:
        ekeys = []
    for idx,code in enumerate(codes):
        sql = ''' select code,lb_1 || '-' || lb_2 as key,lb_1 || '-' || lb_2 ||'#' ||substr(p_lb1,0,2) || '-' || substr(p_lb2,0,2) as j_key ,n_date as n_date
                from raw_kmeans_hl_merge_close_cls where code = '{code}'
                '''.format(code=code)
        df = query(sql, RAW_HLS_WORK_CONN)
        if len(df) == 0:
            continue
        df = df.sort_values(by=['n_date'])
        data = df[['j_key', 'code', 'n_date']].values
        sql = '''
                             select * from (
                             select code,date,close from raw_data_d
                            UNION ALL
                            select DISTINCT code,date,close from raw_data_d_xq_zs
                             ) where code = '{code}'
                        '''.format(code=code)
        cdf = query(sql, RAW_HLS_WORK_CONN)
        cdf = cdf.sort_values(by=['date'])
        cdf['ma60'] = cdf.close.rolling(60).mean().values
        cdf['ma10'] = cdf.close.rolling(10).mean().values
        cdf = cdf.dropna()
        cdf = cdf.sort_values(by=['date'])
        sql = ''' select * from  (select code,p_date,n_date,lb_1||'-'||lb_2 as key,b.g_key,h,w,ag from raw_kmeans_hl_merge_close_cls a,raw_kmeans_gkey_kv b
                        where lb_1||'-'||lb_2 = b.key) where code = '{code}' order by n_date '''.format(code=code)
        wdf_hist = query(sql, RAW_HLS_WORK_CONN)
        wdf_hist = wdf_hist.sort_values(by=['n_date'])
        for i in range(4,len(data)):
            try:
                line = data[i]
                key, code, n_date = line
                iekey = '%s#%s' %(code,n_date)
                cidx = np.argwhere(cdf.date.values == n_date)[0, 0]
                ceidx = 454 if cidx < 454 else cidx
                csidx = ceidx - 454
                hdf = cdf.iloc[csidx:ceidx + 1]
                mask_c_h, rdf_h = _draw_close(n_date, wdf_hist.n_date.values, hdf, num=456, c=4)
                rdf_h['code'] = code
                rdf_h['key']  = key
                rdf_h['work_date'] = n_date
                odfs.append(rdf_h)
                start = sorted(list(rdf_h.p_date.values))[0]
                end = sorted(list(rdf_h.n_date.values))[-1]
                if True:
                    out_file = r'D:\data\images\full\%s' % (code)
                    out_imgs = r'%s\%s' % (out_file, '%s_%s_%s.jpg' % (code,n_date.replace("-", ""),key))
                    rdf_h['file'] = out_imgs
                    if not iekey.replace("-","") in ekeys:
                        #continue
                        if not os.path.exists(out_file):
                            os.makedirs(out_file)
                        cv2.imwrite(out_imgs,mask_c_h)
                        print(out_imgs + "######################################Write")
                print("%s %s %s %s %s-------Done" % (idx,i, code, len(data),len(odfs)))
                print(len(cdf))
            except:
                import traceback
                traceback.print_exc()
                pass
    if len(odfs) > 0:
        frdf = pd.concat(odfs)
        insert(frdf, RAW_HLS_WORK_CONN, 'raw_kmeans_hl_merge_close_summary_drawline_daily')
def getDrawLineDataDailyAppend():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    try:
        ekeys = list(query('select distinct code||work_date as ekeys from raw_kmeans_hl_merge_close_summary_drawline_daily',RAW_HLS_WORK_CONN)['ekeys'].values)
    except:
        ekeys = []
    codes = list(query('select distinct code from raw_data_d_hl_wave13_pn_merge group by code',RAW_HLS_WORK_CONN)['code'].values)
    zs_codes = list(query('select distinct code from raw_data_d_zs_hl_wave13_pn_merge group by code', RAW_HLS_WORK_CONN)['code'].values)
    codes.extend(zs_codes)
    codes = sorted(codes)
    odfs = []
    for idx,code in enumerate(codes):
        sql = ''' select code,lb_1 || '-' || lb_2 as key,lb_1 || '-' || lb_2 ||'#' ||substr(p_lb1,0,2) || '-' || substr(p_lb2,0,2) as j_key ,n_date as n_date
                from raw_kmeans_hl_merge_close_cls where code = '{code}'
                '''.format(code=code)
        df = query(sql, RAW_HLS_WORK_CONN)
        if len(df) == 0:
            continue
        df = df.sort_values(by=['n_date'])
        data = df[['j_key', 'code', 'n_date']].values
        sql = '''
                             select * from (
                             select code,date,close from raw_data_d
                            UNION ALL
                            select DISTINCT code,date,close from raw_data_d_xq_zs
                             ) where code = '{code}'
                        '''.format(code=code)
        cdf = query(sql, RAW_HLS_WORK_CONN)
        cdf = cdf.sort_values(by=['date'])
        cdf['ma60'] = cdf.close.rolling(60).mean().values
        cdf['ma10'] = cdf.close.rolling(10).mean().values
        cdf = cdf.dropna()
        cdf = cdf.sort_values(by=['date'])
        sql = ''' select * from  (select code,p_date,n_date,lb_1||'-'||lb_2 as key,b.g_key,h,w,ag from raw_kmeans_hl_merge_close_cls a,raw_kmeans_gkey_kv b
                        where lb_1||'-'||lb_2 = b.key) where code = '{code}' order by n_date '''.format(code=code)
        wdf_hist = query(sql, RAW_HLS_WORK_CONN)
        wdf_hist = wdf_hist.sort_values(by=['n_date'])
        for i in range(4,len(data)):
            try:
                line = data[i]
                key, code, n_date = line
                iekey = '%s%s' %(code,n_date)
                if iekey in ekeys:
                    print(iekey + "################Exists")
                    continue
                cidx = np.argwhere(cdf.date.values == n_date)[0, 0]
                ceidx = 454 if cidx < 454 else cidx
                csidx = ceidx - 454
                hdf = cdf.iloc[csidx:ceidx + 1]
                mask_c_h, rdf_h = _draw_close(n_date, wdf_hist.n_date.values, hdf, num=456, c=4)
                rdf_h['code'] = code
                rdf_h['key']  = key
                rdf_h['work_date'] = n_date
                odfs.append(rdf_h)
                start = sorted(list(rdf_h.p_date.values))[0]
                end = sorted(list(rdf_h.n_date.values))[-1]
                if True:
                    out_file = r'D:\data\images\full\%s' % (code)
                    out_imgs = r'%s\%s' % (out_file, '%s_%s_%s.jpg' % (code,n_date.replace("-", ""),key))
                    rdf_h['file'] = out_imgs
                    if not iekey.replace("-","") in ekeys:
                        #continue
                        if not os.path.exists(out_file):
                            os.makedirs(out_file)
                        cv2.imwrite(out_imgs,mask_c_h)
                        print(out_imgs + "######################################Write")
                print("%s %s %s %s %s-------Done" % (idx,i, code, len(data),len(odfs)))
                print(len(cdf))
            except:
                import traceback
                traceback.print_exc()
                pass
    if len(odfs) > 0:
        frdf = pd.concat(odfs)
        insert(frdf, RAW_HLS_WORK_CONN, 'raw_kmeans_hl_merge_close_summary_drawline_daily',opType='append')
def moveTrain():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    sql = '''
    select p_date, p_close, c_date, c_close, n_date, n_close, p_x, p_y, c_x, c_y, n_x, n_y, dt_a, dt_b, dt_c, ag_a, ag_b, ag_c, code, key, work_date, file from raw_kmeans_hl_merge_close_summary_drawline_daily
    '''
    df = query(sql,RAW_HLS_WORK_CONN)
    insert(df,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_daily_init_train')
def getDrawLineDataSummary():
    from sklearn.cluster import KMeans
    import pickle
    def _getModel(X, model_name, cls=9, rs=170,retrain = False):
        if not os.path.exists(model_name) or retrain:
            kmeans = KMeans(cls, random_state=rs)
            kmeans.fit(X)
            with open(model_name, 'wb') as f:
                pickle.dump(kmeans, f)
        with open(model_name, 'rb') as f:
            kmeans = pickle.load(f)
            # kmeans = pickle.loads(s2)
        return kmeans
    sql = '''
    select distinct code,n_date,c_date,p_date,work_date,
    round(dt_a/dt_c,3) as ac_r,
    round(dt_b/dt_c,3) as bc_r,dt_a + dt_b + dt_c as perimeter,ag_c,ag_a,ag_b
,case when c_y > n_y and c_y > p_y then 1 else 0 end as type,p_x, p_y, c_x, c_y, n_x, n_y, dt_a, dt_b, dt_c
from raw_kmeans_hl_merge_close_summary_drawline_daily
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql,RAW_HLS_WORK_CONN)
    dfs = df.groupby(['code','work_date'])
    odfs = []
    for line,idf in dfs:
        code,work_date = line
        idf = idf.sort_values(by=['c_date'])
        idf['p_ag'] = idf.apply(lambda x: _getAngle(abs(x['c_y'] - x['p_y']), x['c_x'] - x['p_x']), axis=1).values
        idf['n_ag'] = idf.apply(lambda x: _getAngle(abs(x['c_y'] - x['p_y']), x['n_x'] - x['c_x']), axis=1).values
        idf['y_dta'] = idf.dt_a.shift(-1).values
        idf['y_cy']  = idf.c_y.shift(-1).values
        idf = idf.dropna()
        odfs.append(idf)
        print("%s %s" %(code,len(odfs)))
    rdf = pd.concat(odfs)
    insert(rdf, RAW_HLS_WORK_CONN, 'raw_kmeans_hl_merge_close_summary_drawline_daily_summary')
def getDrawLineTransShapes5Train():
    sql = '''
        select distinct code,n_date,c_date,p_date,work_date,
        round(dt_a/dt_c,3) as ac_r,
        round(dt_b/dt_c,3) as bc_r,dt_a + dt_b + dt_c as perimeter,ag_c,ag_a,ag_b
    ,case when c_y > n_y and c_y > p_y then 1 else 0 end as type,p_x, p_y, c_x, c_y, n_x, n_y, dt_a, dt_b, dt_c
    from raw_kmeans_hl_merge_close_summary_drawline_daily
        '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql, RAW_HLS_WORK_CONN)
    dfs = df.groupby(['code', 'work_date'])
    for type in [0,1]:
        odfs = []
        for line, idf in dfs:
            idf = idf.sort_values(by=['c_date'])
            code, work_date = line
            if len(idf) - 1 < 4:
                continue
            for i in range(3,len(idf) - 1):
                d = idf.iloc[i]
                a = idf.iloc[i-3]
                b = idf.iloc[i-2]
                c = idf.iloc[i-1]
                if c['type'] != type:
                    continue
                a_l   = a['dt_a']
                b_l   = b['dt_c']
                c_l   = c['dt_b']
                d_l   = c['dt_c']
                e_l   = a['dt_c']
                a_dt  = c['dt_a']
                b_dt =  c['dt_b']
                y_dt  = d['dt_b']
                a_ag  = c['ag_c']
                y_ag  = d['ag_c']
                ab_ag = round(a['ag_c'] + b['ag_b']             )
                bc_ag = round(b['ag_a'] + c['ag_c']             )
                cd_ag = round(c['ag_a']                         )
                de_ag = round(c['ag_b'] + b['ag_c'] + a['ag_a'] )
                ea_ag = round(a['ag_b']                         )
                c = dict(c)
                rline = {'code':c['code'],'work_date':work_date,'c_date':c['c_date'],'type':c['type']}
                rline['x_a_l']   =  a_l
                rline['x_b_l']   =  b_l
                rline['x_c_l']   =  c_l
                rline['x_d_l']   =  d_l
                rline['x_e_l']   =  e_l
                rline['x_ab_ag'] =  ab_ag
                rline['x_bc_ag'] =  bc_ag
                rline['x_cd_ag'] =  cd_ag
                rline['x_de_ag'] =  de_ag
                rline['x_ea_ag'] =  ea_ag
                rline['a_dt']    =  a_dt
                rline['b_dt']    =  b_dt
                rline['y_dt']    =  y_dt
                rline['a_ag']    =  a_ag
                rline['y_ag']    =  y_ag
                #rline['type']    = type
                odfs.append(rline)
            print("%s %s %s %s Done" %(code,work_date,len(odfs),len(dfs)))
        rdf = pd.DataFrame(odfs)
        insert(rdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_train_data_%s' %(type))
def getDrawLineTransShape5TrainKmeansDTA():
    from sklearn.cluster import KMeans
    import pickle
    def _getModel(X, model_name, cls=9, rs=170,retrain = False):
        if not os.path.exists(model_name) or retrain:
            kmeans = KMeans(cls, random_state=rs)
            kmeans.fit(X)
            with open(model_name, 'wb') as f:
                pickle.dump(kmeans, f)
        with open(model_name, 'rb') as f:
            kmeans = pickle.load(f)
            # kmeans = pickle.loads(s2)
        return kmeans
    for type in [0,1]:
        sql = '''
        select distinct code,min(work_date) as work_date, c_date,type, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt,b_dt, y_dt, a_ag, y_ag
    ,case when y_dt > a_dt then 1
        else 0 end as y
    from raw_kmeans_hl_merge_close_summary_drawline_train_data_{type} group by code,c_date
    order by code,c_date
        '''.format(type=type)
        RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
        df = query(sql,RAW_HLS_WORK_CONN)
        X = df[['a_dt']].values
        kmeans = _getModel(X, r'D:\code_center\TmpProject\agtest\models\kmean_draws_model_%s_A' %(type),cls=5)
        # 训练模型
        labels = kmeans.predict(X)  # 预测分类
        df['lb'] = labels
        insert(df,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_%s_A' %(type))
def getDrawLineTransShape5TrainKmeansDTB():
    from sklearn.cluster import KMeans
    import pickle
    def _getModel(X, model_name, cls=9, rs=170,retrain = False):
        if not os.path.exists(model_name) or retrain:
            kmeans = KMeans(cls, random_state=rs)
            kmeans.fit(X)
            with open(model_name, 'wb') as f:
                pickle.dump(kmeans, f)
        with open(model_name, 'rb') as f:
            kmeans = pickle.load(f)
            # kmeans = pickle.loads(s2)
        return kmeans
    for type in [0,1]:
        sql = '''
        select distinct code,min(work_date) as work_date, c_date,type, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt,b_dt, y_dt, a_ag, y_ag
    ,case when y_dt > a_dt then 1
        else 0 end as y
    from raw_kmeans_hl_merge_close_summary_drawline_train_data_{type} group by code,c_date
    order by code,c_date
        '''.format(type=type)
        RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
        df = query(sql,RAW_HLS_WORK_CONN)
        X = df[['b_dt']].values
        kmeans = _getModel(X, r'D:\code_center\TmpProject\agtest\models\kmean_draws_model_%s_B' %(type),cls=5)
        # 训练模型
        labels = kmeans.predict(X)  # 预测分类
        df['lb'] = labels
        insert(df,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_%s_B' %(type))

def getDrawLineTransShapes5TrainDaily():
    sql = '''
        select distinct code,n_date,c_date,p_date,work_date,
        round(dt_a/dt_c,3) as ac_r,
        round(dt_b/dt_c,3) as bc_r,dt_a + dt_b + dt_c as perimeter,ag_c,ag_a,ag_b
    ,case when c_y > n_y and c_y > p_y then 1 else 0 end as type,p_x, p_y, c_x, c_y, n_x, n_y, dt_a, dt_b, dt_c
    from raw_kmeans_hl_merge_close_summary_drawline_daily
        '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql, RAW_HLS_WORK_CONN)
    print(len(df))
    odfs = []
    issues = []
    for type in [0,1]:
        dfs = df.groupby('code')
        for code,tdf in dfs:
            tdf = tdf.sort_values(by=['work_date','c_date'])
            work_dates = sorted(list(set(tdf['work_date'].values)))[-3:]
            tdfs = tdf.groupby('work_date')
            for work_date,idf in tdfs:
                if work_date not in work_dates:
                    continue
                if len(idf) - 1 < 4:
                    issues.append(code)
                    print("%s %s Issue" %(code,len(issues)))
                    continue
                for i in range(len(idf)-1,3,-1):
                    c = idf.iloc[i]
                    #a = idf.iloc[i-3]
                    a = idf.iloc[i-2]
                    b = idf.iloc[i - 1]
                    if c['type'] != type:
                        continue
                    a_l   = a['dt_a']
                    b_l   = b['dt_c']
                    c_l   = c['dt_b']
                    d_l   = c['dt_c']
                    e_l   = a['dt_c']
                    a_dt  = c['dt_a']
                    #y_dt  = d['dt_b']
                    a_ag  = c['ag_c']
                    #y_ag  = d['ag_c']
                    ab_ag = round(a['ag_c'] + b['ag_b']             )
                    bc_ag = round(b['ag_a'] + c['ag_c']             )
                    cd_ag = round(c['ag_a']                         )
                    de_ag = round(c['ag_b'] + b['ag_c'] + a['ag_a'] )
                    ea_ag = round(a['ag_b']                         )
                    c = dict(c)
                    rline = {'code':c['code'],'work_date':work_date,'c_date':c['c_date'],'n_date':c['n_date'],'type':c['type']}
                    rline['x_a_l']   =  a_l
                    rline['x_b_l']   =  b_l
                    rline['x_c_l']   =  c_l
                    rline['x_d_l']   =  d_l
                    rline['x_e_l']   =  e_l
                    rline['x_ab_ag'] =  ab_ag
                    rline['x_bc_ag'] =  bc_ag
                    rline['x_cd_ag'] =  cd_ag
                    rline['x_de_ag'] =  de_ag
                    rline['x_ea_ag'] =  ea_ag
                    rline['a_dt']    =  a_dt
                    #rline['y_dt']    =  y_dt
                    rline['a_ag']    =  a_ag
                    #rline['y_ag']    =  y_ag
                    #rline['type']    = type
                    odfs.append(rline)
                print("%s %s %s %s Done" %(code,work_date,len(odfs),len(dfs)))
        rdf = pd.DataFrame(odfs)
        insert(rdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_train_data_daily')
def getDrawLineTransShape5TrainKmeansDaily():
    from sklearn.cluster import KMeans
    import pickle
    def _getModel(X, model_name, cls=9, rs=170,retrain = False):
        if not os.path.exists(model_name) or retrain:
            kmeans = KMeans(cls, random_state=rs)
            kmeans.fit(X)
            with open(model_name, 'wb') as f:
                pickle.dump(kmeans, f)
        with open(model_name, 'rb') as f:
            kmeans = pickle.load(f)
            # kmeans = pickle.loads(s2)
        return kmeans
    for type in [0,1]:
        sql = '''
        select distinct code, work_date, c_date,type, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt, a_ag
    from raw_kmeans_hl_merge_close_summary_drawline_train_data_daily where type = {type} 
    order by code,c_date
        '''.format(type=type)
        RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
        df = query(sql,RAW_HLS_WORK_CONN)
        X = df[['a_dt']].values
        kmeans = _getModel(X, r'D:\code_center\TmpProject\agtest\models\kmean_draws_model_%s' %(type),cls=5)
        # 训练模型
        labels = kmeans.predict(X)  # 预测分类
        df['lb'] = labels
        insert(df,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_%s_daily' %(type))

def getHLDataPN():
    lst_conf = {13: 325}
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    for key, value in lst_conf.items():
        dest_table = 'raw_data_d_hl_wave%s' % (key)
        num = 0
        sql = "select code, sdate, work_date as edate, close,  sclose, pctchg, cls from %s where date = work_date and sdate != work_date" %(dest_table)
        df = query(sql,RAW_HLS_WORK_CONN)
        dfs = df.groupby('code')
        odfs = []
        for code,idf in dfs:
            idf = idf.sort_values(by=['sdate','edate'])
            rdf = pd.DataFrame()
            rdf['code'] = len(idf)*[code]
            rdf['n_sdate'] = idf['sdate'].values
            rdf['c_sdate'] = idf.sdate.shift(1).values
            rdf['p_sdate'] = idf.sdate.shift(2).values
            rdf['n_edate'] = idf['edate'].values
            rdf['c_edate'] = idf.edate.shift(1).values
            rdf['p_edate'] = idf.edate.shift(2).values
            rdf['n_sclose'] = idf['sclose'].values
            rdf['c_sclose'] = idf.sclose.shift(1).values
            rdf['p_sclose'] = idf.sclose.shift(2).values
            rdf['n_close'] = idf['close'].values
            rdf['c_close'] = idf.close.shift(1).values
            rdf['p_close'] = idf.close.shift(2).values
            rdf['n_pctchg'] = idf['pctchg'].values
            rdf['c_pctchg'] = idf.pctchg.shift(1).values
            rdf['p_pctchg'] = idf.pctchg.shift(2).values
            rdf['n_cls'] = idf['cls'].values
            rdf['c_cls'] = idf.cls.shift(1).values
            rdf['p_cls'] = idf.cls.shift(2).values
            rdf = rdf.dropna()
            odfs.append(rdf)
            print("%s----%s %s" %(dest_table + "_pn",code,len(odfs)))
        fdf = pd.concat(odfs)
        insert(fdf, RAW_HLS_WORK_CONN, dest_table+"_pn")
def getHLMergeData():
    def _cal(a,b):
        if b != b:
            r  = 1 if a > 0 else -1
        else:
            pr = 1 if b > 0 else -1
            if a == 0:
                r = pr
            else:
                r = 1 if a > 0 else -1
        return r
    sql = '''
    select distinct code,sdate,work_date as n_date,pctchg as ny_13,cls as cls_13,close as ec_13,julianday(sdate) - julianday(work_date) as pw from raw_data_d_hl_wave13
    where date = work_date and sdate != work_date 
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql,RAW_HLS_WORK_CONN)
    dfs = df.groupby('code')
    odfs = []
    for code,idf in dfs:
        try:
            idf = idf.sort_values(by=['n_date'])
            idf['p_ec13'] = idf.ec_13.shift(1).values
            idf = idf.dropna()
            #afs = idf.apply(lambda x:1 if x['ec_13'] > x['p_ec13'] else -1,axis=1).values
            h_size = len(idf)
            d_size = len(idf)
            afs = idf.ny_13.apply(lambda x: 1 if x > 0 else -1).values
            oidxes = []
            idxes = []
            for i in range(len(afs)-1):
                c_idx = i
                n_idx = i+1
                c_v = afs[c_idx]
                n_v = afs[n_idx]
                if c_v == n_v:
                    idxes.extend([c_idx,n_idx])
                else:
                    if len(idxes) == 0:
                        idxes.append(c_idx)
                        oidxes.append(list(set(idxes)))
                        idxes = []

                    else:
                        oidxes.append(list(set(idxes)))
                        idxes = []
            if len(idxes) > 0 :
                oidxes.append(list(set(idxes)))
            #oidxes[-1]
            if n_idx not in oidxes[-1]:
                oidxes.append([n_idx])
            rlines = []
            for i in range(len(oidxes)):
                idx = oidxes[i]
                idx = sorted(idx)
                tdf = idf.iloc[idx]
                rline = dict(idf.iloc[idx[-1]])
                pline = dict(idf.iloc[idx[0]])
                sdate = pline['sdate']
                edate = rline['n_date']
                if edate == '2019-07-05':
                    print(edate)
                sdate = str(sdate).replace("/", "-")
                edate = str(edate).replace("/", "-")
                sd = datetime.strptime(sdate, '%Y-%m-%d')
                ed = datetime.strptime(edate, '%Y-%m-%d')
                gap = (ed - sd).days
                rline['sdate'] = sdate
                rline['ny13s'] = round(sum(tdf['ny_13'].values),3)
                rline['se_gap'] = gap
                rlines.append(rline)
            rdf = pd.DataFrame(rlines)
            rdf['p_date'] = rdf['n_date'].shift(1).values
            pds = rdf.apply(lambda x:x['sdate'] if (isinstance(x['p_date'],float) and math.isnan(x['p_date'])) else x['p_date'],axis=1).values
            rdf['p_date'] = pds
            rdf['n_gap'] = rdf.apply(lambda x:(datetime.strptime(x['n_date'], '%Y-%m-%d') - datetime.strptime(x['p_date'], '%Y-%m-%d')).days,axis=1)
            rdf['ag'] = rdf.apply(lambda x: _getAngle(x['ny13s'], x['n_gap']), axis=1)
            if len(rdf) > 0:
                odfs.append(rdf)
            print("%s %s %s %s %s" % (code, len(odfs),h_size,d_size,h_size-d_size))
        except:
            pass
    fdf = pd.concat(odfs)
    insert(fdf,RAW_HLS_WORK_CONN,'raw_data_d_hl_wave13_pn_m'
                                 'erge')
def _getAngle(h,w):
    a = Angle.from_atan2(x=w, y=abs(h))
    p = 1 if h > 0 else -1
    degress = p*a.to_degrees()
    return degress
def getHLDailyDatas():
    sql = '''
    select distinct work_date from raw_data_d_hl_wave13 order by work_date desc limit 133
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    dates = query(sql, RAW_HLS_WORK_CONN)['work_date'].values
    try:
        edates = list(query('select distinct work_date from raw_data_d_hl_wave13_pn_daily',RAW_HLS_WORK_CONN)['work_date'].values)
    except:
        edates = []
    work_dates = list(dates)
    for idx,work_date in enumerate(work_dates):
        if idx > 20 or work_date in edates:
            continue
        #np.argwhere(dates == work_date)[:,0]
        start = np.argwhere(dates == work_date)[0][0]
        e8 = start + 8 -1
        e13 = start + 13 -1
        e21 = start + 21 - 1
        #sd = work_date
        ed8 = dates[e8]
        ed13 = dates[e13]
        ed21 = dates[e21]
        sql = '''
        select a.*,max_c8,min_c8, max_c13, min_c13, max_c21, min_c21
        ,round(min_c13 + (max_c13 - min_c13)*0.618,3) as ugc
        ,round(min_c13 + (max_c13 - min_c13)*0.382,3) as lgc
        ,round((cclose - min_c13)*100.0/cclose,3) as l_dist
        ,round((max_c13 - cclose)*100.0/cclose,3) as u_dist
        ,round((cclose - (min_c13 + (max_c13 - min_c13)*0.618))*100.0/cclose,3) as gu_dist
        ,round((cclose - (min_c13 + (max_c13 - min_c13)*0.382))*100.0/cclose,3) as gl_dist
        from
(select a.code,b.sdate,a.work_date,a.close_17 as cclose,pclose, pctchg_17 as cpct,pchg,a.cls_17 as ccls, pcls,julianday(work_date)-julianday(sdate) as w,
           round((close_17 - pclose)*100/pclose,3) as h,
           case
               when cls_17 > 0 and pcls > 0 then 2
               when cls_17 < 0 and pcls < 0 then -2
               when cls_17 > 0 and pcls < 0 then 1
               when cls_17 < 0 and pcls > 0 then -1
            else 0
               end as cls_chg
           from
    (select code,work_date,close as close_17,pctchg as pctchg_17, cls as cls_17 from raw_data_d_hl_wave13 where work_date = '{work_date}'  and date = work_date and sdate != work_date) a,
    (select code,max(work_date) as sdate,close as pclose,pctchg as pchg,cls as pcls from raw_data_d_hl_wave13 where date(work_date) < date('{work_date}')
    group by code) b
    where a.code = b.code
    union all
    select a.code,b.sdate,work_date,a.cclose,b.pclose,a.cpct,b.pchg,
           case when cclose - pclose > 0 then 1 else -1 end as ccls,
           b.pcls,julianday(work_date)-julianday(sdate) as w,
           round((cclose - pclose)*100/pclose,3) as h,0 as cls_chg from
    (select code,date as work_date,close as cclose,pctchg as cpct from raw_data_d where date = '{work_date}' and code not in (
        select distinct code from raw_data_d_hl_wave13 where work_date = '{work_date}'
        ) and code in (select distinct code from raw_data_d_hl_wave13)) a,
    (select code,max(work_date) as sdate,close as pclose,pctchg as pchg,cls as pcls from raw_data_d_hl_wave13
    where date(work_date) < date('{work_date}') group by code) b
    where a.code = b.code) a,(select code,max(close) as max_c8,min(close) as min_c8 from raw_data_d
    where date(date) >= date('{ed8}') and date(date)  <= date('{work_date}') group by code) b,(select code,max(close) as max_c13,min(close) as min_c13 from raw_data_d
    where date(date) >= date('{ed13}') and date(date) <= date('{work_date}') group by code) c,(select code,max(close) as max_c21,min(close) as min_c21 from raw_data_d
    where date(date) >= date('{ed21}') and date(date) <= date('{work_date}') group by code) d
where a.code = b.code and a.code = c.code and a.code = d.code
        '''.format(work_date=work_date,ed8=ed8,ed13=ed13,ed21=ed21)
        #print(sql)
        rdf = query(sql,RAW_HLS_WORK_CONN)
        insert(rdf,RAW_HLS_WORK_CONN,'raw_data_d_hl_wave13_pn_daily',opType='append')
        print("%s %s " %(work_date,len(rdf)))
def move():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    RAW_FINAL_FORMAT_CONN = getConn(RAW_FINAL_FORMAT_ANALYSIS)
    sql = '''
    select code, sdate, work_date, cclose, pclose, cpct, pchg, ccls, pcls, w, h, cls_chg, max_c8, min_c8, max_c13, min_c13, max_c21, min_c21, ugc, lgc, l_dist, u_dist, gu_dist, gl_dist from raw_hl_daily_datas
    '''
    df = query(sql,RAW_FINAL_FORMAT_CONN)

    insert(df,RAW_HLS_WORK_CONN,'raw_data_d_hl_wave13_pn_daily')

def getDrawLineDatas():
    if False:
        print("################raw_kmeans_hl_merge_close_summary_drawline_daily#####################")
        getDrawLineDataDailyAppend()
        print("################draw ongoing datas#####################")
        draw_line_D_ByDaily()
        print("################raw_kmeans_hl_merge_close_summary_drawline_daily_train data#####################")
        getDrawLineTransShapes5TrainDaily()
        print("################raw_kmeans_hl_merge_close_summary_drawline_daily_train kmeans#####################")
        getDrawLineTransShape5TrainKmeansDaily()
    if True:
        print("#######################merge by code#############################")
        moveByCodeAnalysis()
        print("#######################merge by date#############################")
        moveByDateAnalysis()
def getDrawLineDatasInit():
    print("################raw_kmeans_hl_merge_close_summary_drawline_daily#####################")
    #getDrawLineDataDaily()
    #getDrawLineDataDailyAppend()
    print("################raw_kmeans_hl_merge_close_summary_drawline_daily_train data#####################")
    #getDrawLineTransShapes5Train()
    print("################raw_kmeans_hl_merge_close_summary_drawline_daily_train kmeans#####################")
    getDrawLineTransShape5TrainKmeansDTA()
    getDrawLineTransShape5TrainKmeansDTB()

if __name__ == '__main__':
    getDrawLineDatasInit()
    #getDrawLineTransShape5TrainKmeansDaily()
    #getDrawLineData()
    #getDrawLineDataSummary()
    #getDrawLineTransShapes5Train()
    #getDrawLineTransShape5TrainKmeans()
    #getHLDataPN()
    #getHLMergeData()
