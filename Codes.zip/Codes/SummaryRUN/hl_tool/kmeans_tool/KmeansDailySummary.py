from PyAngle import Angle
from com.DbTool import getConn, query, insert
from com.RunConf import RAW_NET_WORK_FILE,RAW_HLS_WORK_FILE
import pandas as pd
import numpy as np

def _getOOCInfos(x, close_map):
    pd = x['p_date']
    nd = x['n_date']
    import pandas as pds
    pd_idx = np.argwhere(close_map[:, 0] == pd)[:, 0][0]
    try:
        nd_idx = np.argwhere(close_map[:, 0] == nd)[:, 0][0]
    except:
        nd_idx = len(close_map) - 1
    closes = close_map[:, 1]
    key_closes = closes[pd_idx:nd_idx+1]
    rdf = pds.DataFrame([])
    rdf['code'] = len(key_closes)*[x['code']]
    rdf['p_date'] = len(key_closes) * [pd]
    rdf['n_date'] = len(key_closes) * [nd]
    tws = np.asarray(range(len(key_closes)))
    pv = closes[pd_idx]
    nv = closes[nd_idx]
    w = nd_idx - pd_idx
    h = round((nv - pv) * 100 / pv, 3)
    a = 1 if h > 0 else -1
    ao = Angle.from_atan2(x=w, y=abs(h))
    std_h = a * np.round(ao.tan()*tws,3)
    d_h = np.round(((key_closes - pv)*100/pv).astype(float),3)
    #h/w = ao.tan()*w
    tag = ao.to_degrees()
    ag = round(a * tag, 3)
    std_c = np.round(pv*(1+(std_h/100)),3)
    rdf['ag'] = len(key_closes) * [ag]
    rdf['h'] =  len(key_closes) * [h ]
    rdf['w'] =  len(key_closes) * [w ]
    rdf['std_h'] = std_h
    rdf['d_h'] = d_h
    rdf['std_c'] = std_c
    rdf['d_c'] = key_closes
    rdf['tws'] = tws
    rdf['d_ag'] = rdf.apply(lambda x:round(a*Angle.from_atan2(x=x['tws'], y=abs(x['d_h'])).to_degrees(),3),axis=1).values
    return rdf

def getKmeansDailyRawData():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    try:
        sql = '''
        select max(n_date) as md from raw_kmeans_kpi_sum where n_date not in (select distinct today from raw_kmeans_kpi_sum_close_daily)
        '''
        df = query(sql,RAW_HLS_WORK_CONN)
        work_date = df['md'].values[0]
    except:
        work_date = '2022-04-08'
        pass
    #work_date = '2022-04-01'
    sql = '''
    select a.*,b.hl_date,b.cls_13,b.ec_13 from
(select a.*,c.g_key as g_t_key from
(select a.*,c.g_key from
(select a.code,a.p_date,a.n_date,b.n_date as e_date,'{work_date}' as today,a.key,t_key,a.h,b.n_h ,a.w,b.n_w,a.ag,b.n_ag from raw_kmeans_hl_merge_close_summary a,
(select code,max(n_date) as n_date,p_date,key as t_key,h as n_h,ag as n_ag,w as n_w  from raw_kmeans_hl_merge_close_summary where date(n_date) <= date('2022-04-08') group by code) b
where a.code = b.code and date() and a.n_date = b.p_date) a
left outer join
(raw_kmeans_gkey_kv) c
on a.key = c.key) a left outer join
(raw_kmeans_gkey_kv) c
on a.t_key = c.key) a,
(select distinct code,cls as cls_13,work_date as hl_date, close as ec_13
from raw_data_d_hl_wave13 where date(work_date) <= date('{work_date}')) b
where a.code = b.code and date(b.hl_date) > date(a.n_date)
order by code,hl_date
    '''.format(work_date=work_date)
    #print(sql)
    df = query(sql,RAW_HLS_WORK_CONN)
    insert(df,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_daily')
    #return
def getKmeansDailyRawDataDetail():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    sql = '''
    select code, p_date, n_date, e_date, today, h,n_h, w,n_w, ag,n_ag, g_key, g_t_key, key, t_key, hl_date, cls_13, ec_13 from raw_kmeans_hl_merge_close_daily
    where code = 'sh.600004' or 1=1
    '''
    df = query(sql,RAW_HLS_WORK_CONN)
    print("------------%s" %(len(df)))
    sql = '''
            select code,date,close,pctchg,
            (high - max(close,open))*100/(close/(1+pctchg/100)) as hcl,
            (low  - min(close,open))*100/(close/(1+pctchg/100)) as lcl
            from raw_data_d
            '''
    df_close = query(sql, RAW_HLS_WORK_CONN)
    df_closees = df_close.groupby('code')
    close_maps = {}
    pct_maps = {}
    lcl_maps = {}
    hcl_maps = {}

    for code, idf in df_closees:
        idf = idf.sort_values(by=['date'])
        close_maps[code] = idf[['date', 'close']].values
        pct_maps[code]   = idf[['date', 'pctchg']].values
        lcl_maps[code]   = idf[['date', 'lcl']].values
        hcl_maps[code]   = idf[['date', 'hcl']].values

    dfs = df.groupby('code')
    rdfs = []
    for code,idf in dfs:
        try:
            idf = idf.sort_values(by=['e_date'])
            wave_cnt = len(idf)
            code, p_date, n_date, e_date, today, h,n_h, w,n_w, ag,n_ag, g_key, g_t_key = idf[['code', 'p_date', 'n_date', 'e_date', 'today', 'h','n_h', 'w','n_w', 'ag','n_ag', 'g_key', 'g_t_key']].iloc[0].values
            #code, p_date, n_date, e_date, today, h,n_h, w,n_w, ag,n_ag, g_key, g_t_key = line
            close_map = close_maps[code]
            pct_map = pct_maps[code]
            lcl_map = lcl_maps[code]
            hcl_map = hcl_maps[code]
            ec = close_map[-1][1]
            max_13 = max(close_map[-13:][:,1])
            min_13 = min(close_map[-13:][:,1])
            ucl_rate = round((max_13 - ec) * 100 / ec,3)
            lcl_rate = round((min_13 - ec) * 100 / ec,3)
            pct = round(pct_map[-1][1],3)
            lr  = round(lcl_map[-1][1],3)
            ur  = round(hcl_map[-1][1],3)
            #wave_cnt = len(idf)
            wave_line  = {'code':code, 's_date':p_date, 'e_date':n_date, 'p_date':n_date, 'n_date':e_date,'today':today,
                     'h':h,'n_h':n_h, 'w':w,'n_w':n_w, 'ag':ag,'n_ag':n_ag, 'g_key':g_key, 'g_t_key':g_t_key,'wave_cnt':wave_cnt,'type':'waves'}
            daily_line = {'code':code, 's_date': p_date, 'e_date': n_date, 'p_date': e_date, 'n_date': today,'today':today,
                      'h': h, 'n_h': n_h, 'w': w, 'n_w': n_w, 'ag': ag, 'n_ag': n_ag, 'g_key': g_key, 'g_t_key': g_t_key,
                      'wave_cnt': wave_cnt,'type':'daily'}
            all_line = {'code':code,'p_date':n_date, 'n_date': today}
            df_sum = _getOOCInfos(all_line,close_map)
            lines = []
            o_w_line = _getOOCInfos(wave_line,close_map)
            o_w_line['type'] = 'waves'
            lines.append(o_w_line)
            if daily_line['p_date'] != daily_line['n_date']:
                try:
                    o_d_line = _getOOCInfos(daily_line, close_map)
                    o_d_line['type'] = 'daily'
                    #print(dict(o_d_line.iloc[0]))
                    lines.append(o_d_line[1:])
                except:
                    pass
            df = pd.concat(lines)
            df['sub_h'] = df['d_h'].values
            df['sub_std_h'] = df['std_h'].values
            df['s_ag']   = df_sum['ag'].values
            df['s_h']    = df_sum['h'].values
            df['s_w']    = df_sum['w'].values
            df['std_h']  = df_sum['std_h'].values
            df['d_h']    = df_sum['d_h'].values
            df['std_c']  = df_sum['std_c'].values
            df['d_c']    = df_sum['d_c'].values
            df['tws']    = df_sum['tws'].values
            df['d_ag']   = df_sum['d_ag'].values
            df['sdate'] = p_date
            df['today'] = today
            df['p_h'] = h
            df['c_h'] = n_h
            df['p_w'] = w
            df['c_w'] = n_w
            df['p_ag'] = ag
            df['c_ag'] = n_ag
            df['g_key'] = g_key
            df['g_t_key'] = g_t_key
            df['wave_cnt'] = wave_cnt
            df['lcl'] = lcl_rate
            df['ucl'] = ucl_rate
            df['pct'] = pct
            df['lr'] = lr
            df['ur'] = ur
            df['c'] = ec
            df['min'] = max_13
            df['max'] = min_13
            rdfs.append(df)
            print("%s---------%s" %(code,len(rdfs)))
        except:
            pass
    fdf = pd.concat(rdfs)
    insert(fdf, RAW_HLS_WORK_CONN, 'raw_kmeans_hl_merge_close_daily_summary',opType='append')
    print("---Done")
def getHLSummaryPNDays():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    sql = '''
    select code,p_date,n_date,key,h,w,ag from raw_kmeans_hl_merge_close_summary
    '''
    df = query(sql,RAW_HLS_WORK_CONN)
    dfs = df.groupby('code')
    for n in [5]:
        odfs = []
        for code,idf in dfs:
            idf = idf.sort_values(by=['p_date','n_date'])
            rdf = pd.DataFrame()
            rdf['code'] = len(idf)*[code]
            rdf['p_date'] = idf['p_date'].values
            rdf['n_date'] = idf['n_date'].values
            rdf['key']    = idf['key'].values
            rdf['h']      = idf['h']  .values
            rdf['w']      = idf['w']  .values
            rdf['ag']     = idf['ag'] .values
            for i in range(1,n):
                rdf['n_date_p%s' %(i)]  = idf['n_date'].shift(i).values
                rdf['key_p%s' % (i)] = idf['key'].shift(i).values
                rdf['h_p%s' % (i)] = idf['h'].shift(i).values
                rdf['w_p%s' % (i)] = idf['w'].shift(i).values
                rdf['ag_p%s' % (i)] = idf['ag'].shift(i).values
            rdf =rdf.dropna()
            odfs.append(rdf)
            print("%s %s %s" %(code,len(odfs),len(dfs)))
        fdf = pd.concat(odfs)
        insert(fdf, RAW_HLS_WORK_CONN, 'raw_kmeans_hl_merge_close_summary_pns')


if __name__ == '__main__':
    #getKmeansDailyRawData()
    #getKmeansDailyRawDataDetail()
    getHLSummaryPNDays()