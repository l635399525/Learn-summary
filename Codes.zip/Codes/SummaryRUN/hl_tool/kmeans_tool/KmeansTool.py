#from sklearn.cluster import KMeans

from PyAngle import Angle
from com.DbTool import getConn, query, insert, delete
from com.RunConf import RAW_NET_WORK_FILE,RAW_HLS_WORK_FILE
import pandas as pd
import numpy as np
def _getOOCInfos(x, close_map):
    pd = x['p_date']
    nd = x['n_date']
    import pandas as pds
    pd_idx = np.argwhere(close_map[:, 0] == pd)[:, 0][0]
    try:
        nd_idx = np.argwhere(close_map[:, 0] == nd)[:, 0][0]
    except:
        nd_idx = len(close_map) - 1
    closes = close_map[:, 1]
    key_closes = closes[pd_idx:nd_idx+1]
    rdf = pds.DataFrame([])
    rdf['code'] = len(key_closes)*[x['code']]
    rdf['p_date'] = len(key_closes) * [pd]
    rdf['n_date'] = len(key_closes) * [nd]
    tws = np.asarray(range(len(key_closes)))
    pv = closes[pd_idx]
    nv = closes[nd_idx]
    w = nd_idx - pd_idx
    h = round((nv - pv) * 100 / pv, 3)
    a = 1 if h > 0 else -1
    ao = Angle.from_atan2(x=w, y=abs(h))
    std_h = a * np.round(ao.tan()*tws,3)
    d_h = np.round(((key_closes - pv)*100/pv).astype(float),3)
    #h/w = ao.tan()*w
    tag = ao.to_degrees()
    ag = round(a * tag, 3)
    std_c = np.round(pv*(1+(std_h/100)),3)
    rdf['ag'] = len(key_closes) * [ag]
    rdf['h'] =  len(key_closes) * [h ]
    rdf['w'] =  len(key_closes) * [w ]
    rdf['std_h'] = std_h
    rdf['d_h'] = d_h
    rdf['std_c'] = std_c
    rdf['d_c'] = key_closes
    rdf['tws'] = tws
    rdf['d_ag'] = rdf.apply(lambda x:round(a*Angle.from_atan2(x=x['tws'], y=abs(x['d_h'])).to_degrees(),3),axis=1).values
    return rdf
def getOOCData():
    # sql = '''
    #     select a.code,p_date,n_date from raw_data_d_hl_wave13_pn_merge a where code ='sh.600089' or 1 = 1
    #     union all
    #     select a.code,p_date,n_date from raw_data_d_zs_hl_wave13_pn_merge a
    # '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)

    sql = '''
    delete from raw_kmeans_hl_merge_close where date(p_date) > date('2020-01-01')
    '''
    print("###########delete nearly data start##############")
    delete(RAW_HLS_WORK_CONN,sql)
    print("###########delete nearly data end  ##############")

    sql = '''
    select * from
(select a.code,p_date,n_date from raw_data_d_hl_wave13_pn_merge a where code ='sh.600089' or 1 = 1
        union all
        select a.code,p_date,n_date from raw_data_d_zs_hl_wave13_pn_merge a)
where date(p_date) > date('2020-01-01')
    '''
    df = query(sql, RAW_HLS_WORK_CONN)
    dfs = df.groupby('code')
    sql = '''
        select code,date,close from raw_data_d
        UNION ALL
        select DISTINCT code,date,close from raw_data_d_xq_zs
        '''
    df_close = query(sql, RAW_HLS_WORK_CONN)
    df_closees = df_close.groupby('code')
    close_maps = {}
    for code, idf in df_closees:
        idf = idf.sort_values(by=['date'])
        close_maps[code] = idf[['date', 'close']].values
    rdfs= []
    for code, idf in dfs:
        close_map = close_maps[code]
        idf = idf.sort_values(by=['n_date'])
        for i in range(len(idf)):
            ldf = idf.iloc[i]
            try:
                rdf = _getOOCInfos(ldf,close_map)
                rdfs.append(rdf)
            except:
                pass
        print("--------%s %s" %(code,len(rdfs)))
    fdf = pd.concat(rdfs)
    insert(fdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close')
import os
import pickle
def getKPIKmeans():
    from sklearn.cluster import KMeans
    def _getModel(X, model_name, cls=9, rs=170):
        if not os.path.exists(model_name):
            kmeans = KMeans(cls, random_state=rs)
            kmeans.fit(X)
            with open(model_name, 'wb') as f:
                pickle.dump(kmeans, f)
        with open(model_name, 'rb') as f:
            kmeans = pickle.load(f)
            # kmeans = pickle.loads(s2)
        return kmeans
    sql = '''
    select  distinct code, p_date, n_date, ag, h, w from raw_kmeans_hl_merge_close
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql,RAW_HLS_WORK_CONN)
    X = df[['h','ag']].values
    kmeans = _getModel(X,r'D:\code_center\TmpProject\agtest\models\kmean_LV1')
    # 训练模型
    labels = kmeans.predict(X)  # 预测分类
    df['lb_1'] = labels
    dfs = df.groupby('lb_1')
    odfs = []
    for lb,idf in dfs:
        X = idf[['w', 'ag']].values
        kmeans = _getModel(X, r'D:\code_center\TmpProject\agtest\models\kmean_LV2_%s' %(lb),5,170)
        #kmeans = KMeans(5, random_state=170)
        kmeans.fit(X)  # 训练模型
        labels = kmeans.predict(X)
        idf['lb_2'] = labels
        odfs.append(idf)
    rdf = pd.concat((odfs))
    dfs = rdf.groupby('code')
    odfs = []
    for code, idf in dfs:
        idf = idf.sort_values(by=['n_date'])
        idf['p_n_date'] = idf.n_date.shift(1)
        idf['p_lb1'] = idf.lb_1.shift(1)
        idf['p_lb2'] = idf.lb_2.shift(1)
        idf['p_ag'] = idf.ag.shift(1)
        idf['p_h'] = idf.h.shift(1)
        idf['p_w'] = idf.w.shift(1)
        odfs.append(idf)
    rdf = pd.concat(odfs)
    insert(rdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_cls')
def getKmeansSummary():
    sql = '''
select a.code, p_date, a.n_date,b.key, ag, h, w, std_h, d_h, std_c, d_c, tws, d_ag from raw_kmeans_hl_merge_close a,
(select distinct code,n_date,lb_1 ||'-'|| lb_2 as key from raw_kmeans_hl_merge_close_cls) b
where a.code = b.code and a.n_date = b.n_date
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql,RAW_HLS_WORK_CONN)
    dfs = df.groupby(['code','p_date','n_date','key','h','w','ag'])
    rlines = []
    for line,idf in dfs:
        code,p_date,n_date,key,h,w,ag = line
        rline = {'code':code,'p_date':p_date,'n_date':n_date,'key':key,'h':h,'w':w,'ag':ag}
        a = Angle.from_atan2(x=w,y=h)
        degress = a.to_degrees()
        d_h   = idf.d_h.values
        std_h = idf.std_h.values
        d_gap = d_h - std_h
        distances = d_gap * a.cos()
        distances_a_idx = np.argwhere(distances >   0)[:, 0]
        distances_b_idx = np.argwhere(distances <=  0)[:, 0]
        distances_a = distances[distances_a_idx]
        distances_b = distances[distances_b_idx]
        dist_stds  = np.round(np.std(distances)    ,3)
        dist_avgs  = np.round(np.average(distances),3)
        dist_sum_a = np.round(np.sum(distances_a),3)
        dist_sum_b = np.round(np.sum(distances_b),3)
        dist_a_idx = np.sum(distances_a_idx)
        dist_b_idx = np.sum(distances_b_idx)
        dist_a_cnt = np.count_nonzero(distances > 0)
        dist_b_cnt = np.count_nonzero(distances <= 0)
        dist_max = round(np.max(distances),3)
        dist_min = round(np.min(distances),3)
        rline['degress'] = degress
        rline['dist_stds'] = dist_stds
        rline['dist_avgs'] = dist_avgs
        rline['dist_sum_a'] = dist_sum_a
        rline['dist_sum_b'] = dist_sum_b
        rline['dist_a_idx'] = dist_a_idx
        rline['dist_b_idx'] = dist_b_idx
        rline['dist_a_cnt'] = dist_a_cnt
        rline['dist_b_cnt'] = dist_b_cnt
        rline['dist_max']   = dist_max
        rline['dist_min']   = dist_min
        rlines.append(rline)
        print("%s------------%s" %(code,len(rlines)))
    rdf = pd.DataFrame(rlines)
    rdf['p_key'] = rdf.key.shift(1).values
    rdf = rdf.dropna()
    rdf['j_key'] = rdf.apply(lambda x:'%s#%s' %(x['key'],x['p_key']),axis=1).values
    rdf['n_h']  = rdf.h.shift(-1).values
    rdf['n_ag'] = rdf.ag.shift(-1).values
    rdf['n_w']  = rdf.w.shift(-1).values
    insert(rdf,RAW_HLS_WORK_CONN,'raw_kmeans_hl_merge_close_summary')
def _genGLevelMapping():
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    sql = '''
    select code,p_date,n_date,key as g_key from raw_kmeans_hl_merge_close_summary
    '''
    df = query(sql,RAW_HLS_WORK_CONN)
    insert(df,RAW_HLS_WORK_CONN,'raw_kmeans_gkey')
def genGLevelMappingDaily():
    init =False
    if init:
        _genGLevelMapping()
    sql = '''
    select code||p_date||n_date as j_key,g_key from raw_kmeans_gkey
where code in ('sh.600231','sh.600076','sh.600078','sh.600563','sz.002356','sh.600011','sz.002201','sz.002565','sh.600031')
group by g_key
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql, RAW_HLS_WORK_CONN)
    insert(df, RAW_HLS_WORK_CONN, 'raw_kmeans_gkey_mapping')
    sql = '''
    select key,g_key from (select code||p_date||n_date as j_key, key from raw_kmeans_hl_merge_close_summary) a,
(select distinct j_key,g_key from raw_kmeans_gkey_mapping) b where a.j_key = b.j_key
    '''
    df = query(sql, RAW_HLS_WORK_CONN)
    insert(df, RAW_HLS_WORK_CONN, 'raw_kmeans_gkey_kv')
def genGLevelMapping():
    sql = '''
select key,g_key,max(cnt) as cnt from
(select key,g_key,count(*) as cnt from
(select * from (select code,p_date,n_date,g_key from raw_kmeans_gkey) a,
(select code,p_date,n_date,key from raw_kmeans_hl_merge_close_summary) b
where a.code = b.code and a.n_date = b.n_date and a.p_date = b.p_date) group by key,g_key) group by key
    '''
    RAW_HLS_WORK_CONN = getConn(RAW_HLS_WORK_FILE)
    df = query(sql,RAW_HLS_WORK_CONN)
    insert(df, RAW_HLS_WORK_CONN, 'raw_kmeans_gkey_kv')

if __name__ == '__main__':
    if True:
        print("################ooc close data----------")
        #getOOCData()
        print("################close kmeas data----------")
        #getKPIKmeans()
        print("################close summary data----------")
        #getKmeansSummary()
        print("################Kmeans mapping vs----------")
        #genGLevelMappingDaily()
        genGLevelMapping()