from com.DbTool import query,getConn,insert


def getWorkRun():
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    sql = "select distinct date as work_date from raw_data_d order by date desc limit 50"
    df = query(sql,conn)
    work_dates = list(df['work_date'].values)
    for idx,work_date in enumerate(work_dates):
        sql = '''
        select a.code,a.work_date,b.date13,c.date17,date25,a.ny_close,b.ny13,c.ny17,d.ny25
     ,a.pv_ny_close,b.pv_ny_13,c.pv_ny_17,d.pv_ny_25
     ,a.pv_2cls_close,b.pv_2cls_13,c.pv_2cls_17,d.pv_2cls_25
from
(select a.code,a.work_date,a.ny as ny_close,a.pv_ny as pv_ny_close,b.pv_2cls as pv_2cls_close from
(select code, work_date, ny, type, pv as pv_ny, av as av_ny, m_type, m_yt, m_cls from test_close a where m_yt = 'y' and work_date  in ('{work_date}')) a,
(select code, work_date, ny, type, pv as pv_2cls, av as av_2cls, m_type, m_yt, m_cls from test_close a where m_yt = 'ycls2'  and work_date  in ('{work_date}')) b
where a.code = b.code and a.work_date = b.work_date and a.m_type = b.m_type and a.m_cls = b.m_cls) a,
(select a.code,a.work_date as date13,a.ny as ny13,a.pv_ny as pv_ny_13,b.pv_2cls as pv_2cls_13
from
(select code, max(work_date) as work_date, ny, type, pv as pv_ny, av as av_ny, m_type, m_yt, m_cls from test_hl
where m_yt = 'y' and m_type = '13' and date(work_date) <= date('{work_date}')
group by code) a,
 (select code, max(work_date) as work_date, ny, type, pv as pv_2cls, av as av_2cls, m_type, m_yt, m_cls from test_hl
where m_yt = 'ycls2' and m_type = '13' and date(work_date) <= date('{work_date}')
group by code) b
where a.code = b.code and a.work_date = b.work_date and a.m_type = b.m_type and a.m_cls = b.m_cls) b,
(select a.code,a.work_date as date17,a.ny as ny17,a.pv_ny_17,b.pv_2cls_17
from
(select code, max(work_date) as work_date, ny, type, pv as pv_ny_17, av as av_ny, m_type, m_yt, m_cls from test_hl
where m_yt = 'y' and m_type = '17' and date(work_date) <= date('{work_date}')
group by code) a,
 (select code, max(work_date) as work_date, ny, type, pv as pv_2cls_17, av as av_2cls, m_type, m_yt, m_cls from test_hl
where m_yt = 'ycls2' and m_type = '17' and date(work_date) <= date('{work_date}')
group by code) b
where a.code = b.code and a.work_date = b.work_date and a.m_type = b.m_type and a.m_cls = b.m_cls) c,
(select a.code,a.work_date  as date25,a.ny as ny25,a.m_cls,a.m_type,a.pv_ny_25,b.pv_2cls_25
from
(select code, max(work_date) as work_date, ny, type, pv as pv_ny_25, av as av_ny, m_type, m_yt, m_cls from test_hl
where m_yt = 'y' and m_type = '25' and date(work_date) <= date('{work_date}')
group by code) a,
 (select code, max(work_date) as work_date, ny, type, pv as pv_2cls_25, av as av_2cls, m_type, m_yt, m_cls from test_hl
where m_yt = 'ycls2' and m_type = '25' and date(work_date) <= date('{work_date}')
group by code) b
where a.code = b.code and a.work_date = b.work_date and a.m_type = b.m_type and a.m_cls = b.m_cls) d
where a.code = b.code
and   a.code = c.code
and   a.code = d.code
        '''.format(work_date=work_date)
        df = query(sql,conn_train)
        insert(df,conn_train,'raw_analysis',opType='append')
        print("%s----%s %s" %(idx,work_date,len(df)))
def getWorkRunMin():
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    sql = "select distinct date as work_date from raw_data_d order by date desc limit 50"
    df = query(sql, conn)
    work_dates = list(df['work_date'].values)
    for idx, work_date in enumerate(work_dates):
        sql = '''
            select a.code,a.work_date,ny_min,pv_ny_min,pv_2cls_min
    from
    (select a.code,a.work_date,a.ny as ny_min,a.pv_ny as pv_ny_min,b.pv_2cls as pv_2cls_min from
    (select code, work_date, ny, type, pv as pv_ny, av as av_ny, m_type, m_yt, m_cls from test_min a where m_yt = 'y' and work_date  in ('{work_date}')) a,
    (select code, work_date, ny, type, pv as pv_2cls, av as av_2cls, m_type, m_yt, m_cls from test_min a where m_yt = 'ycls2'  and work_date  in ('{work_date}')) b
    where a.code = b.code and a.work_date = b.work_date and a.m_type = b.m_type and a.m_cls = b.m_cls) a
            '''.format(work_date=work_date)
        df = query(sql, conn_train)
        insert(df, conn_train, 'raw_analysis_min', opType='append')
        print("%s----%s %s" % (idx, work_date, len(df)))
if __name__ == '__main__':
    getWorkRun()