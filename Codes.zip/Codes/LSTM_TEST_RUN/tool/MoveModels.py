from com.DbTool import getConn,insert,query
import pandas as pd
def getModelByLastSteptData():
    #types = ['y','ycls2']
    import glob
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    conf_file_map = {  '13':'raw_hl_summary_cls13_v1.json'
                      ,'17':'raw_hl_summary_cls17_v1.json'
                      ,'25':'raw_hl_summary_cls25_v1.json'
                      ,'close': 'raw_close_summary_cls5_n1.json'
                      ,'min': 'raw_close_min_summary_cls5.json'
               }
    conf_file_map = {
         'hlangle'     : 'raw_hl_all_y_5_full_n1.json'
        , 'closeangle': 'raw_close_all_y_5_full_n1.json'
                     }
    conf_folder = r'D:\code_center\LSTM_TEST_RUN\conf_files'
    files = glob.glob(r'D:\code_center\LSTM_TEST_RUN\run_train\saved_models\*.h5')
    rlines = []
    for idx,file in enumerate(files):
        hfn = file.split("\\")[-1]
        fn = hfn.replace("%s#" % (hfn.split("#")[0]), "")
        if fn.startswith('-'):
            cls = fn[:2]
            tfn = fn[2:]
        else:
            cls = fn[:1]
            tfn = fn[1:]
        stepts  = int(tfn.split("-")[1])
        acc     = tfn.split("-")[2]
        val_acc = tfn.split("-")[3]
        #folder = file.split("\\")[-2]
        type,y_type = hfn.split("#")[0] .split("_")
        conf_file = conf_folder + "\\" + conf_file_map[type]
        rline = {'type': type, 'cls': cls, 'y_type': y_type, 'conf_file': conf_file,'stepts': stepts, 'acc': acc, 'val_acc': val_acc, 'src_file': file}
        rlines.append(rline)
        print("%s %s" %(idx,rline))
    df = pd.DataFrame(rlines)
    insert(df,conn,'raw_model_tmp')
import shutil
def getModelByLastSteptDataMove():
    sql_a = 'select type, cls, y_type, conf_file, max(stepts) as max_stepts, acc, val_acc, src_file from raw_model_tmp group by type, cls, y_type'
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    df = query(sql_a,conn)
    lines = df.to_dict("records")
    olines = []
    out_f = r'D:\code_center\LSTM_TEST_RUN\run_train\saved_models\golden_models'
    for line in lines:
        src_file = line['src_file']
        y_type = line['y_type']
        type = line['type']
        cls = line['cls']
        mstept = line['max_stepts']
        dest_fn = "%s#%s#%s#%s.h5" %( y_type,type, cls, mstept)
        dest_file = out_f + "\\" + dest_fn
        shutil.copy(src_file,dest_file)
        line['gold_file'] = dest_file
        olines.append(line)
    rdf = pd.DataFrame(olines)
    insert(rdf, conn, 'raw_model_lst_news')

if __name__ == '__main__':
    getModelByLastSteptData()
    getModelByLastSteptDataMove()