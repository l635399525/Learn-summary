import numpy as np
from sklearn import preprocessing

from com.DbTool import getConn, query


class DataLoaderTestDaily():
    """A class for loading and transforming data for the lstm model"""

    def __init__(self, df, cols):
        self.dataframe = df
        self.cols = cols
        # i_split = int(len(self.dataframe) * split)
        self.data_train = self.dataframe.get(self.cols).values
        self.len_train_windows = None

    def get_test_data_y2(self, seq_len, normalise, column='work_date',
                         col_lst=['code', 'work_date', 'model_t', 'model_c', 'model_yt', 'ny', 'model_gf']):
        '''
        Create x, y test data windows
        Warning: batch method, not generative, make sure you have enough memory to
        load data, otherwise reduce size of the training split.
        '''
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_t = []
        data_h = []

        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 100:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=[column])
                data_heads = idf[col_lst].values
                data_train = idf
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                if len_train < seq_len:
                    continue
                for i in range(seq_len, len_train + 1):
                    data_head = data_heads[i - seq_len:i][-1]
                    window = data_train[i - seq_len:i]
                    type = window[-1, [0]]
                    x = window[:, :-1]
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        y = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_t.append(type)
                        data_h.append(data_head)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h)

    def normalise_windows(self, window_data, single_window=False):
        '''Normalise window with a base value of zero'''
        normalised_data = []
        window_data = [window_data] if single_window else window_data
        for window in window_data:
            normalised_window = []
            for col_i in range(window.shape[1]):
                arrs = window[:, col_i]
                arrs = arrs[:, np.newaxis]
                scaler = preprocessing.StandardScaler().fit(arrs)
                normalised_col = scaler.transform(arrs)
                normalised_col = normalised_col.reshape((normalised_col.shape[0]))
                # normalised_col = [((float(p) / float(window[0, col_i])) - 1) for p in window[:, col_i]]
                normalised_window.append(normalised_col)
            normalised_window = np.array(
                normalised_window).T  # reshape and transpose array back into original multidimensional format
            normalised_data.append(normalised_window)
        return np.array(normalised_data)


class DataLoaderTrainDaily():
    """A class for loading and transforming data for the lstm model"""

    def __init__(self, df, cols):
        self.dataframe = df
        self.cols = cols
        self.data_train = self.dataframe.get(self.cols).values
        self.len_train_windows = None

    def get_train_data(self, seq_len, normalise, column=['work_date'], col_lst=['code', 'work_date', 'ny', 'type'],yt='ycls2'):
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_y2 = []

        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 50 and False:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                #test_num = int(len_train * 0.05)
                if len_train < seq_len:
                    continue
                for i in range(seq_len,len_train + 1):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        #if yt == 'ycls2':
                        y2 = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_y2.append(y2)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h), np.asarray(data_y2)

    def normalise_windows(self, window_data, single_window=False):
        '''Normalise window with a base value of zero'''
        normalised_data = []
        window_data = [window_data] if single_window else window_data
        for window in window_data:
            normalised_window = []
            for col_i in range(window.shape[1]):
                arrs = window[:, col_i]
                arrs = arrs[:, np.newaxis]
                scaler = preprocessing.StandardScaler().fit(arrs)
                normalised_col = scaler.transform(arrs)
                normalised_col = normalised_col.reshape((normalised_col.shape[0]))
                # normalised_col = [((float(p) / float(window[0, col_i])) - 1) for p in window[:, col_i]]
                normalised_window.append(normalised_col)
            normalised_window = np.array(
                normalised_window).T  # reshape and transpose array back into original multidimensional format
            normalised_data.append(normalised_window)
        return np.array(normalised_data)

def getWorkLst():
    types_conf = {
        'min'  : ['y','ycls2']#,
        #'13': ['y', 'ycls2'],
        # '17': ['y', 'ycls2'],
        # '25': ['y', 'ycls2']
        # ,'close': ['y', 'ycls2']

    }
    out_path = r'D:\code_center\LSTM_TEST_RUN\conf_files'
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    lstm_conf = {
          'y_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'y_13'   : out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'y_17'   : out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'y_25'   : out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'y_min'  : out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'
        , 'ycls2_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'ycls2_13'   : out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'ycls2_17'   : out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'ycls2_25'   : out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'ycls2_min'  : out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'

    }
    for key,values in types_conf.items():
        type = key
        if type == 'close':
            src_table = 'raw_{t}_wave_N_5_clses_daily'.format(t=type)
            sql = '''
                select a.*,a.n1y as ny from {src_table} a order by code,work_date
                '''.format(src_table=src_table)
        elif type == 'min':
            src_table = 'raw_close_min_wave_N_5_clses_data_daily'
            sql = '''
                select a.*,a.nny as ny from {src_table} a    order by code,work_date
                '''.format(src_table=src_table)
        else:
            src_table = 'raw_hl9close_wave{n}_daily'.format(n=type)
            sql = '''
                select a.* from {src_table} a order by code,work_date
                '''.format(src_table=src_table)
            # print(sql)

        #for yt in values:
        yt = 'y'
        conf_file = lstm_conf['%s_%s' % (yt, key)]
        df = query(sql, conn)
        import json
        configs = json.load(open(conf_file, 'r'))
        data = DataLoaderTrainDaily(df,configs['data']['columns'])
        if key == 'min':
            # x_test, y_test, t_test, h_test, y_test2 = data.get_test_data(
            #     seq_len=configs['data']['sequence_length'],
            #     normalise=configs['data']['normalise']
            #     , col_lst=['code', 'work_date', 'dt', 'ny', 'type', 'times']
            #     , column=['work_date', 'dt']
            # )
            x_train, y_train, t_train, h_train, y_train2 = data.get_train_data(
                seq_len=configs['data']['sequence_length'],
                normalise=configs['data']['normalise']
                , col_lst=['code', 'work_date', 'dt', 'ny', 'type', 'times']
                , column=['work_date', 'dt']
            )
        else:
            # x_test, y_test, t_test, h_test, y_test2 = data.get_test_data(
            #     seq_len=configs['data']['sequence_length'],
            #     normalise=configs['data']['normalise']
            # )
            x_train, y_train, t_train, h_train, y_train2 = data.get_train_data(
                seq_len=configs['data']['sequence_length'],
                normalise=configs['data']['normalise']
            )
        #np.savez('%s_%s_%s_%s_full'%(key,yt,configs['data']['sequence_length'],'test'),x_test=x_test, y_test=y_test, t_test=t_test, h_test=h_test, y_test2=y_test2,allow_pickle=False)
        np.savez('%s_%s_%s_%s_full'%(key,yt,configs['data']['sequence_length'],'train'),x_train=x_train, y_train=y_train, t_train=t_train, h_train=h_train, y_train2=y_train2,allow_pickle=False)
        print("%s %s --Save_Done")
def loadData():
    data = np.load('close_y_21_train.npz',allow_pickle=True)
    print(len(data['x_train']))
    print(len(data['y_train']))
    print(len(data['h_train']))
    print(len(data['t_train']))
    print(len(data['y_train2']))

if __name__ == '__main__':
    getWorkLst()
    #loadData()