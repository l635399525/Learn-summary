from com.DbTool import getConn, query,insert
import numpy as np
import pandas as pd
def getCloseV1():
    sql = '''
    select code,date,close,pctchg
from raw_data_d where date(date) <= date('2022-01-01') and date(date) >= date('2020-01-01')
    '''
    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_CLOSE')
    df = query(sql,conn)
    dfs = df.groupby('code')
    for code,idf in dfs:
        idf = idf.sort_values(by=['date'])
        n_max = 34
        rlines = []
        for i in range(n_max,len(idf)):
            rline = dict(idf.iloc[i])
            hs = np.zeros(5)
            ls = np.zeros(5)
            ldf = idf.iloc[i-n_max+1:i+1]
            ldf = ldf.sort_values(by=['date'])
            lcloses = ldf.close.values
            for idx,n in enumerate([5,8,13,21,34]):
                tdf = ldf.iloc[n_max-n :n_max + 1]
                pcts = round(sum(tdf['pctchg'].values),3)
                closes = tdf.close.values
                max     = np.max(closes)
                min     = np.min(closes)
                max_idx = np.argwhere(lcloses == max)[:, 0][0]
                min_idx = np.argwhere(lcloses == min)[:, 0][0]
                hs[idx] = max_idx
                ls[idx] = min_idx
                rline['er_%s' %(n)] = pcts
            h_score = 5 - len(list(set(list(hs))))
            l_score = 5 - len(list(set(list(ls))))
            rline['h_score'] = h_score
            rline['l_score'] = l_score
            rline["hs"] = ",".join(list(hs.astype(int).astype(str)))
            rline["ls"] = ",".join(list(ls.astype(int).astype(str)))
            #print(rline)
            rlines.append(rline)
        fdf = pd.DataFrame(rlines)
        if len(rlines) > 0:
            insert(fdf,conn,'raw_close_ers',opType='append')
        print("%s---------------%s %s" %(idx,code,len(rlines)))
def getCloseV2():
    sql = '''
select distinct code, date, close, pctchg, er_5, er_8, er_13, er_21, er_34, h_score, l_score, hs, ls from raw_close_ers
    '''
    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_CLOSE')
    df = query(sql,conn)
    dfs = df.groupby('code')
    for code,idf in dfs:
        idf = idf.sort_values(by=['date'])
        rdf = idf.iloc[1:].copy()
        pdf = idf.iloc[:-1]
        h_scores_gap = rdf['h_score'].values - pdf['h_score'].values
        l_scores_gap = rdf['l_score'].values - pdf['l_score'].values
        rdf['h_scores_gap'] = h_scores_gap
        rdf['l_scores_gap'] = l_scores_gap
        ns = [5,8,13,21,34]
        m_n = max(ns)
        rlines = []
        for i in range(m_n,len(rdf)):
            rline = dict(rdf.iloc[i])
            for n in ns:
                tdf = rdf.iloc[i-n+1:i+1]
                rline['hs_%s'%(n)] = sum(tdf['h_scores_gap'].values)
                rline['ls_%s'%(n)] = sum(tdf['l_scores_gap'].values)
            rlines.append(rline)
        if len(rlines) > 0:
            fdf = pd.DataFrame(rlines)
            insert(fdf,conn,'raw_close_ers_sum',opType='append')
        print("%s %s" %(code,len(rlines)))
if __name__ == '__main__':
    #getCloseV1()
    getCloseV2()