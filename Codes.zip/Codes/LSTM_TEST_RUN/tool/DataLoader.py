import numpy as np
import pandas as pd
from sklearn import preprocessing

class DataLoaderTestDaily():
    """A class for loading and transforming data for the lstm model"""
    def _getClose(self):
        sql = '''
        
        '''
    def __init__(self, df, cols):
        self.dataframe = df
        self.cols = cols
        #i_split = int(len(self.dataframe) * split)
        self.data_train = self.dataframe.get(self.cols).values
        self.len_train_windows = None

    def get_test_data_y2(self, seq_len, normalise,column='work_date',col_lst=['code','work_date','model_t','model_c','model_yt','ny','model_gf']):
        '''
        Create x, y test data windows
        Warning: batch method, not generative, make sure you have enough memory to
        load data, otherwise reduce size of the training split.
        '''
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_t = []
        data_h = []

        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 100:
                continue
            print("%s-------%s" % (num,code))
            try:
                idf = idf.sort_values(by=[column])
                data_heads = idf[col_lst].values
                data_train = idf
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                if len_train < seq_len:
                    continue
                for i in range(seq_len,len_train + 1):
                    window = data_train[i-seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        y = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" %(len(data_y)))
        return np.asarray(data_x),np.asarray(data_y),np.asarray(data_t),np.asarray(data_h)
    def get_train_npz_data(self,seq_len,type):
        print("------------%s" %(r'D:\code_center\LSTM_TEST_RUN\tool\%s_y_%s_train_full.npz' %(type,seq_len)))
        data = np.load(r'D:\code_center\LSTM_TEST_RUN\tool\%s_y_%s_train.npz' %(type,seq_len), allow_pickle=True)
        return data['x_train'], data['y_train'], data['t_train'], data['h_train'],data['y_train2']
    def normalise_windows(self, window_data, single_window=False):
        '''Normalise window with a base value of zero'''
        normalised_data = []
        window_data = [window_data] if single_window else window_data
        for window in window_data:
            normalised_window = []
            for col_i in range(window.shape[1]):
                arrs = window[:, col_i]
                arrs = arrs[:, np.newaxis]
                scaler = preprocessing.StandardScaler().fit(arrs)
                normalised_col = scaler.transform(arrs)
                normalised_col = normalised_col.reshape((normalised_col.shape[0]))
                #normalised_col = [((float(p) / float(window[0, col_i])) - 1) for p in window[:, col_i]]
                normalised_window.append(normalised_col)
            normalised_window = np.array(normalised_window).T # reshape and transpose array back into original multidimensional format
            normalised_data.append(normalised_window)
        return np.array(normalised_data)
class DataLoaderTrainDaily():
    """A class for loading and transforming data for the lstm model"""

    def __init__(self, df, cols):
        self.dataframe = df
        self.cols = cols
        self.data_train = self.dataframe.get(self.cols).values
        self.len_train_windows = None

    def get_test_data(self, seq_len, normalise, column=['work_date'],col_lst=['code','work_date','ny','type'],yt='ycls2'):
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 50 and True:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                test_num = int(len_train * 0.25)
                if len_train - test_num < seq_len:
                    continue
                for i in range(len_train - test_num, len_train):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        if yt == 'ycls2':
                            y = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h)
    def get_train_data(self, seq_len, normalise, column=['work_date'],col_lst=['code','work_date','ny','type'],yt='ycls2'):
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 50 and True:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                test_num = int(len_train * 0.05)
                if len_train - test_num < seq_len:
                    continue
                for i in range(len_train - test_num, len_train):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        if yt == 'ycls2':
                            y = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h)
    def get_train_npz_data(self,seq_len,type):
        print("------------%s" %(r'D:\code_center\LSTM_TEST_RUN\tool\%s_y_%s_train.npz' %(type,seq_len)))
        data = np.load(r'D:\code_center\LSTM_TEST_RUN\tool\%s_y_%s_train.npz' %(type,seq_len), allow_pickle=True)
        return data['x_train'], data['y_train'], data['t_train'], data['h_train'],data['y_train2']
    def get_test_npz_data(self,seq_len,type):
        print("------------%s" %(r'D:\code_center\LSTM_TEST_RUN\tool\%s_y_%s_test.npz' %(type,seq_len)))
        data = np.load(r'D:\code_center\LSTM_TEST_RUN\tool\%s_y_%s_test.npz' %(type,seq_len), allow_pickle=True)
        return data['x_test'], data['y_test'], data['t_test'], data['h_test'],data['y_test2']
    def get_daily_test_data(self, seq_len, normalise, column=['work_date'],col_lst=['code','work_date','ny','type'],yt='ycls2',file_name=None):
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_y2 = []
        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 50 and False:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                #test_num = int(len_train * 0.05)
                if len_train < seq_len:
                    continue
                for i in range(seq_len, len_train + 1):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        y2 = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_y2.append(y2)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        if file_name is not None:
            np.savez(file_name,x_train=np.asarray(data_x), y_train=np.asarray(data_y), t_train=np.asarray(data_t), h_train=np.asarray(data_h), y_train2=np.asarray(data_y2),allow_pickle=False)
        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h), np.asarray(data_y2)
    def get_daily_test_data_test(self, seq_len, normalise, column=['work_date'],col_lst=['code','work_date','ny','type'],yt='ycls2',file_name=None):
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_y2 = []
        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 50 and False:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                test_num = int(len_train * 0.25)
                if len_train - test_num < seq_len:
                    continue
                for i in range(len_train - test_num, len_train):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        y2 = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_y2.append(y2)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        if file_name is not None:
            np.savez(file_name,x_train=np.asarray(data_x), y_train=np.asarray(data_y), t_train=np.asarray(data_t), h_train=np.asarray(data_h), y_train2=np.asarray(data_y2),allow_pickle=False)
        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h), np.asarray(data_y2)


    def normalise_windows(self, window_data, single_window=False):
        '''Normalise window with a base value of zero'''
        normalised_data = []
        window_data = [window_data] if single_window else window_data
        for window in window_data:
            normalised_window = []
            for col_i in range(window.shape[1]):
                arrs = window[:, col_i]
                arrs = arrs[:, np.newaxis]
                scaler = preprocessing.StandardScaler().fit(arrs)
                normalised_col = scaler.transform(arrs)
                normalised_col = normalised_col.reshape((normalised_col.shape[0]))
                # normalised_col = [((float(p) / float(window[0, col_i])) - 1) for p in window[:, col_i]]
                normalised_window.append(normalised_col)
            normalised_window = np.array(
                normalised_window).T  # reshape and transpose array back into original multidimensional format
            normalised_data.append(normalised_window)
        return np.array(normalised_data)
class DataLoaderAnalysisDaily():
    """A class for loading and transforming data for the lstm model"""

    def __init__(self, df, cols):
        self.dataframe = df
        self.cols = cols
        self.data_train = self.dataframe.get(self.cols).values
        self.len_train_windows = None

    def get_daily_test_data(self,data, seq_len, normalise, column=['work_date'],col_lst=['code','work_date','ny','type']):
        if data is not None:
            x_train, y_train, t_train, h_train, y_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'], data['y_train']
            df = pd.DataFrame(data=h_train,columns=col_lst)
            dfs = df.groupby('code')
            data_map = {}
            for code, idf in dfs:
                try:
                    dates = list(idf['work_date'].values)
                    data_map[code] = dates
                except:
                    data_map[code] = []
            df = self.dataframe
        else:
            df =self.dataframe
            data_map = {}
        #df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_y2 = []
        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            try:
                edates = data_map[code]
            except:
                edates = []
            num = num + 1
            # if num > 2300 and True:
            #     continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                #test_num = int(len_train * 0.05)
                if len_train < seq_len:
                    continue
                for i in range(seq_len, len_train + 1):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    work_date = h_line[1]
                    if work_date in edates:
                        continue
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        y2 = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_y2.append(y2)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        # if file_name is not None:
        #     np.savez(file_name, x_train=np.asarray(data_x), y_train=np.asarray(data_y), t_train=np.asarray(data_t),h_train=np.asarray(data_h), y_train2=np.asarray(data_y2), allow_pickle=False)

        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h), np.asarray(data_y2)

    def get_daily_train_data(self,data, seq_len, normalise, column=['work_date'],col_lst=['code','work_date','ny','type']):
        if data is not None:
            x_train, y_train, t_train, h_train, y_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'], data['y_train']
            df = pd.DataFrame(data=h_train,columns=col_lst)
        else:
            df =self.dataframe
        dfs = df.groupby('code')
        data_map = {}
        for code,idf in dfs:
            try:
                dates = list(idf['work_date'].values)
                data_map[code] = dates
            except:
                data_map[code] = []
        data_map = {}
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_y2 = []
        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            try:
                edates = data_map[code]
            except:
                edates = []
            num = num + 1
            if num > 5000 and True:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                test_num = int(len_train * 0.08)
                test_num = -1
                if len_train - test_num < seq_len:
                    continue
                for i in range(seq_len, len_train - test_num):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    work_date = h_line[1]
                    if work_date in edates:
                        continue
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        y2 = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_y2.append(y2)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        # if file_name is not None:
        #     np.savez(file_name, x_train=np.asarray(data_x), y_train=np.asarray(data_y), t_train=np.asarray(data_t),h_train=np.asarray(data_h), y_train2=np.asarray(data_y2), allow_pickle=False)

        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h), np.asarray(data_y2)

    def get_daily_val_data(self,data, seq_len, normalise, column=['work_date'],col_lst=['code','work_date','ny','type']):
        if data is not None:
            x_train, y_train, t_train, h_train, y_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'], data['y_train']
            df = pd.DataFrame(data=h_train,columns=col_lst)
        else:
            df =self.dataframe
        dfs = df.groupby('code')
        data_map = {}
        for code,idf in dfs:
            try:
                dates = list(idf['work_date'].values)
                data_map[code] = dates
            except:
                data_map[code] = []
        data_map = {}
        df = self.dataframe
        dfs = df.groupby('code')
        data_x = []
        data_y = []
        data_y2 = []
        data_t = []
        data_h = []
        num = 0
        for code, idf in dfs:
            try:
                edates = data_map[code]
            except:
                edates = []
            num = num + 1
            if num > 2500 and True:
                continue
            print("%s-------%s" % (num, code))
            try:
                idf = idf.sort_values(by=column)
                data_train = idf
                data_heads = data_train[col_lst].values
                data_train = data_train[self.cols].values
                len_train = len(data_train)
                test_num = int(len_train * 0.8)
                if test_num < seq_len:
                    continue
                for i in range(test_num, len_train + 1):
                    window = data_train[i - seq_len:i]
                    x = window[:, :-1]
                    type = window[-1, [0]]
                    h_window = data_heads[i - seq_len:i]
                    h_line = h_window[-1]
                    work_date = h_line[1]
                    if work_date in edates:
                        continue
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        y = window[-1, [-1]]
                        y2 = 1 if y > 0 else 0
                        data_x.append(x)
                        data_y.append(y)
                        data_y2.append(y2)
                        data_t.append(type)
                        data_h.append(h_line)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" % (len(data_y)))
        # if file_name is not None:
        #     np.savez(file_name, x_train=np.asarray(data_x), y_train=np.asarray(data_y), t_train=np.asarray(data_t),h_train=np.asarray(data_h), y_train2=np.asarray(data_y2), allow_pickle=False)

        return np.asarray(data_x), np.asarray(data_y), np.asarray(data_t), np.asarray(data_h), np.asarray(data_y2)

    def normalise_windows(self, window_data, single_window=False):
        '''Normalise window with a base value of zero'''
        normalised_data = []
        window_data = [window_data] if single_window else window_data
        for window in window_data:
            normalised_window = []
            for col_i in range(window.shape[1]):
                arrs = window[:, col_i]
                arrs = arrs[:, np.newaxis]
                scaler = preprocessing.StandardScaler().fit(arrs)
                normalised_col = scaler.transform(arrs)
                normalised_col = normalised_col.reshape((normalised_col.shape[0]))
                # normalised_col = [((float(p) / float(window[0, col_i])) - 1) for p in window[:, col_i]]
                normalised_window.append(normalised_col)
            normalised_window = np.array(
                normalised_window).T  # reshape and transpose array back into original multidimensional format
            normalised_data.append(normalised_window)
        return np.array(normalised_data)
if __name__ == '__main__':
    import json,os
    conf_file = r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls13_v1.json'
    configs = json.load(open(conf_file, 'r'))
    if not os.path.exists(configs['model']['save_dir']):
        os.makedirs(configs['model']['save_dir'])
        #data = DataLoaderTrainDaily(df,configs['data']['columns'])