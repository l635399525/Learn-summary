import json

from com.DbTool import query, getConn
from tool.DataLoader import DataLoaderAnalysisDaily, DataLoaderTrainDaily

data_conf = {
    '13':r'D:\data\data_file\13_y_21_full.npz'
   ,'17':r'D:\data\data_file\17_y_21_full.npz'
   ,'25':r'D:\data\data_file\25_y_21_full.npz'
   ,'close':r'D:\data\data_file\close_y_21_full.npz'
   ,'min':r'D:\data\data_file\min_y_21_full.npz'
   ,'hl_all': r'D:\data\data_file\hl_all_y_5_full.npz'
   ,'closeangle': r'D:\data\data_file\close_angle_all_y_5_full.npz'
}

data_conf = {
   #'hl_all': r'D:\data\data_file\hl_all_y_5_full.npz'
    'closeangle': r'D:\data\data_file\close_angle_all_y_5_full.npz'
}

train_conf = {
    '13':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls13_v1.json'
   ,'17':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls17_v1.json'
   ,'25':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls25_v1.json'
   ,'close':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_summary_cls5_n1.json'
   ,'min':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_min_summary_cls5_1500_n1.json'
   ,'hl_all': r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_all_y_5_full_n1.json'
   ,'closeangle': r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_all_y_5_full_n1.json'

}
sql_conf = {
         '13':'select * from raw_hl9close_wave13_daily'
        ,'17':'select * from raw_hl9close_wave17_daily'
        ,'25':'select * from raw_hl9close_wave25_daily'
     ,'close':'select *,n1y as ny from raw_close_wave_N_5_clses_daily'
       ,'min':'select *,nny as ny from raw_close_min_wave_N_5_clses_data_daily'
    ,'hl_all':'''select distinct a.code,sdate,edate as work_date,case when cls_13 + cls_17 + cls_25 > 0 then 1 else 0 end as t_cls,
       sclose,eclose,h,cls_13 + cls_17 + cls_25 as type,w as x_w,pctchg as x_pct,angles as x_angle,cls_13,cls_17,cls_25
 ,volume as x_volume,n_angles as ny,n_h from raw_hl_angles a,raw_data_d b where a.code = b.code and a.edate = b.date and n_angles is not null and x_angle is not null'''
    ,'closeangle':'''
    select code, date as work_date,clsv_55 as type,
       edate_5, edate_13, edate_34, edate_55, close, volume,
       clsv_5, clsv_8, clsv_13, clsv_21, clsv_34, clsv_55,
       ag1_5, ag2_5, ag3_5, agt_5, agb_5,
       ag1_8, ag2_8, ag3_8, agt_8, agb_8,
       ag1_13,ag2_13, ag3_13, agt_13, agb_13,
       ag1_21, ag2_21, ag3_21, agt_21, agb_21,
       ag1_34, ag2_34, ag3_34, agt_34, agb_34,
       ag1_55, ag2_55, ag3_55, agt_55, agb_55,
       w1_5, w1_8, w1_13, w1_21, w1_34, w1_55,
       w2_5, w2_8, w2_13, w2_21, w2_34, w2_55,
       w3_5, w3_8, w3_13, w3_21, w3_34, w3_55,
       days_55, days_34, pctchg, ec_55, ec_34, ny from raw_close_angle_train
order by code,work_date
    '''
}
col_conf = {
         '13':['code', 'work_date', 'ny', 'type']
        ,'17':['code', 'work_date', 'ny', 'type']
        ,'25':['code', 'work_date', 'ny', 'type']
     ,'close':['code', 'work_date', 'ny', 'type']
       ,'min':['code', 'work_date', 'dt', 'ny', 'type', 'times']
    ,'hl_all':['code', 'work_date', 'ny', 'type']
    ,'closeangle': ['code', 'work_date', 'ny', 'type']

}
sort_conf = {
         '13':['work_date']
        ,'17':['work_date']
        ,'25':['work_date']
     ,'close':['work_date']
       ,'min':['work_date', 'dt']
    ,'hl_all':['work_date']
    ,'closeangle': ['work_date']

}
dest_table = {
         '13':'test_hl_daily'
        ,'17':'test_hl_daily'
        ,'25':'test_hl_daily'
     ,'close':'test_close_daily'
       ,'min':'test_min_daily'
    ,'hl_all':'test_hl_angle_daily'
    ,'closeangle': 'test_close_angle_daily'

}

import numpy as np
import pandas as pd
if __name__ == '__main__':
    conn_raw_close   = getConn(r"D:\data\RAW_FINAL_FORMAT_CLOSE")
    conn_raw_min     = getConn(r"D:\data\RAW_FINAL_FORMAT_MIN")
    conn_raw_hl      = getConn(r"D:\data\RAW_FINAL_FORMAT_HL")
    conn_train       = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    conn_analysis    = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")

    for type,file in data_conf.items():
        if type == 'close':
            conn_raw = conn_raw_close
            print("----close")
        elif type == 'min':
            conn_raw = conn_raw_min
            print("---min")
        elif type == 'hl_all':
            conn_raw = conn_analysis
        elif type == 'closeangle':
            conn_raw = conn_train
        else:
            conn_raw = conn_raw_hl
            print(type)
        conf_file = train_conf[type]
        configs = json.load(open(conf_file, 'r'))
        sql       = sql_conf[type]
        cols      = col_conf[type]
        column    = sort_conf[type]
        df        = query(sql,conn_raw)
        data = DataLoaderAnalysisDaily(df,cols = configs['data']['columns'])
        #data_hist = np.load(file, allow_pickle=True)
        data_hist = None
        # x_train, y_train, t_train, h_train, y2_train = \
        #     data.get_daily_test_data(data=data_hist,column=column,col_lst=cols,seq_len=configs['data']['sequence_length'],normalise=configs['data']['normalise'])
        x_train, y_train, t_train, h_train, y2_train = \
            data.get_daily_train_data(data=data_hist, column=column, col_lst=cols,
                                     seq_len=configs['data']['sequence_length'], normalise=configs['data']['normalise'])
        x_test, y_test, t_test, h_test, y2_test = \
            data.get_daily_val_data(data=data_hist, column=column, col_lst=cols,
                                     seq_len=configs['data']['sequence_length'], normalise=configs['data']['normalise'])

        if data_hist is not None:
            x_hist  = np.vstack((data_hist['x_train'] , x_train))
            y_hist  = np.vstack((data_hist['y_train'] , y_train))
            t_hist  = np.vstack((data_hist['t_train'] , t_train))
            h_hist  = np.vstack((data_hist['h_train'] , h_train))
            #y2_hist = np.vstack((data_hist['y_train2'], y2_train))
            a = data_hist['y_train2'].reshape((len(data_hist['y_train2']), 1))
            b = y2_train.reshape((len(y2_train), 1))
            y2_hist = np.vstack((a, b))[:, 0]
        else:
            x_hist  = x_train
            y_hist  = y_train
            t_hist  = t_train
            h_hist  = h_train
            y2_hist = y2_train.reshape((len(y2_train), 1))
            y2_test = y2_test.reshape((len(y2_test), 1))

            #y2_hist = np.vstack((data_hist['y_train2'], y2_train))
        # a = data_hist['y_train2'].reshape((len(data_hist['y_train2']),1))
        # b = y2_train.reshape((len(y2_train),1))
        # y2_hist = np.vstack((a,b))[:,0]
        np.savez(file.replace("_full.npz","_train.npz"), x_train=np.asarray(x_hist), y_train=np.asarray(y_hist), t_train=np.asarray(t_hist),h_train=np.asarray(h_hist), y_train2=np.asarray(y2_hist), allow_pickle=False)
        np.savez(file.replace("_full.npz","_tests.npz"), x_train=np.asarray(x_test), y_train=np.asarray(y_test), t_train=np.asarray(t_test),h_train=np.asarray(h_test), y_train2=np.asarray(y2_test), allow_pickle=False)

        #np.savez(file.replace("full","daily"), x_train=np.asarray(x_train), y_train=np.asarray(y_train), t_train=np.asarray(t_train),h_train=np.asarray(h_train), y_train2=np.asarray(y2_train), allow_pickle=False)
        print(file)
