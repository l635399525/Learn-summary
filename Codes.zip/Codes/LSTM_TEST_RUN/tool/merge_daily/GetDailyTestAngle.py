import json

from com.DbTool import query, getConn, insert, drop
#from tool.DataLoader import DataLoaderAnalysisDaily
from keras.utils import np_utils



data_conf = {
   'closeangle':r'D:\data\data_file\close_angle_all_y_5_daily.npz',
   'hlangle':r'D:\data\data_file\hl_all_y_5_full.npz'
}
#data_conf = {
#    '13':r'D:\data\data_file\13_y_21_full.npz'
#   ,'17':r'D:\data\data_file\17_y_21_full.npz'
#   ,'25':r'D:\data\data_file\25_y_21_full.npz'
#,'close':r'D:\data\data_file\close_y_21_full.npz'
#  ,'min':r'D:\data\data_file\min_y_21_full.npz'
#}
# data_conf = {
#     '13':r'D:\data\data_file\13_y_21_full.npz'
#    ,'17':r'D:\data\data_file\17_y_21_full.npz'
#    ,'25':r'D:\data\data_file\25_y_21_full.npz'
# }
train_conf = {
    'closeangle':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_all_y_5_full_n1.json',
   'hlangle':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_all_y_5_full_n1.json'
}
col_conf = {
         'closeangle':['code', 'work_date', 'ny', 'type']
        ,'hlangle':['code', 'work_date', 'ny', 'type']
}
sort_conf = {
         'closeangle':['work_date']
        ,'hlangle':['work_date']
}

cls_conf = {
 'closeangle'   :[-4, -3, -2, -1, 1, 2, 3, 4]
,'hlangle'   :['a']
}
dest_table = {
         'closeangle':'test_closeangle_daily'
        ,'hlangle':'test_hlangle_daily'
}
import numpy as np
import pandas as pd
from core.model import Model
def runAngleDailyLSTM():
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    for type, file in data_conf.items():
        cols = col_conf[type]
        time_str = '15:00'
        print("----------------%s loaded" %(file))
        data = np.load(file, allow_pickle=True)
        x_train, y_train, t_train, h_train, y2_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'], data['y_train2']
        d_table = dest_table[type]
        if d_table == 'test_hlangle_daily':
            drop(conn_raw,d_table)
        model = Model()
        clses = cls_conf[type]
        for ycls in ['y','ycls2']:
            if ycls == 'ycls2':
                y_train = y2_train
                y_train = np_utils.to_categorical(y_train, 2)
            for cls in clses:
                if type == 'hlangle':
                    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
                    src_file = query("select gold_file from raw_model_lst_news where cls = '%s' and type = '%s' and y_type = '%s'"
                                 % (cls, type, ycls), conn)['gold_file'].values[0]
                else:
                    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
                    src_file = query("select gold_file from raw_model_lst_news where cls = %s and type = '%s' and y_type = '%s'"
                          % (int(cls), type, ycls), conn)['gold_file'].values[0]
                model.load_model(src_file)
                if type == 'min':
                    time_train = h_train[:, -1]
                    idxes_train_a = np.argwhere(t_train == cls)[:, 0]
                    idxes_train_b = np.argwhere(time_train[idxes_train_a] == time_str)[:, 0]
                    idxes_train = idxes_train_a[idxes_train_b]
                else:
                    if type != 'hlangle':
                        idxes_train = np.argwhere(t_train == cls)[:, 0]
                if type == 'hlangle':
                    x_tr = x_train
                    y_tr = y_train
                    h_tr = h_train
                else:
                    x_tr = x_train[idxes_train]
                    y_tr = y_train[idxes_train]
                    h_tr = h_train[idxes_train]
                rdf = pd.DataFrame(data=h_tr, columns=cols)
                print("-----------------%s %s" % (cls, len(x_tr)))
                try:
                    predicted = model.predict_point_by_point(x_tr)
                    # pv = np.argmax(predicted, axis=1)
                    pv = np.argmax(predicted, axis=1) if ycls == 'ycls2' else predicted[:, 0]
                    av = y_tr[:, 0]
                    a_rate = np.count_nonzero(pv * av > 0)
                    f_rate = np.count_nonzero(pv * av <= 0)
                    rdf['pv'] = pv
                    #rdf['av'] = av
                    rdf['m_type'] = type
                    rdf['m_yt'] = ycls
                    rdf['m_cls'] = cls
                    print("%s %s %s %s" % (type,src_file, a_rate, f_rate + a_rate))
                    insert(rdf, conn_raw, d_table, opType='append')
                except:
                    import traceback
                    traceback.print_exc()
                    pass
if __name__ == '__main__':
    runAngleDailyLSTM()