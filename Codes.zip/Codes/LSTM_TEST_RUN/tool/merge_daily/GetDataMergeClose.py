import json

from com.DbTool import query, getConn
from tool.DataLoader import DataLoaderAnalysisDaily

data_conf = {
    '13':r'D:\data\data_file\13_y_21_full.npz'
   ,'17':r'D:\data\data_file\17_y_21_full.npz'
   ,'25':r'D:\data\data_file\25_y_21_full.npz'
,'close':r'D:\data\data_file\close_y_21_full.npz'
  ,'min':r'D:\data\data_file\min_y_21_full.npz'
}

# data_conf = {
#    'close':r'D:\data\data_file\close_y_21_full.npz'
#   ,'min':r'D:\data\data_file\min_y_21_full.npz'}

train_conf = {
    '13':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls13_v1.json'
   ,'17':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls17_v1.json'
   ,'25':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls25_v1.json'
   ,'close':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_summary_cls5_n1.json'
   ,'min':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_min_summary_cls5_1500_n1.json'
   ,'hlangle': r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_all_y_5_full_n1.json'
   ,'closeangle': r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_all_y_5_full_n1.json'
}

sql_conf = {
         '13':'select * from raw_hl9close_wave13_daily'
        ,'17':'select * from raw_hl9close_wave17_daily'
        ,'25':'select * from raw_hl9close_wave25_daily'
     ,'close':'select *,n1y as ny from raw_close_wave_N_5_clses_daily'
       ,'min':'select *,nny as ny from raw_close_min_wave_N_5_clses_data_daily'
}
col_conf = {
         '13':['code', 'work_date', 'ny', 'type']
        ,'17':['code', 'work_date', 'ny', 'type']
        ,'25':['code', 'work_date', 'ny', 'type']
     ,'close':['code', 'work_date', 'ny', 'type']
       ,'min':['code', 'work_date', 'dt', 'ny', 'type', 'times']
}
sort_conf = {
         '13':['work_date']
        ,'17':['work_date']
        ,'25':['work_date']
     ,'close':['work_date']
       ,'min':['work_date', 'dt']
}
dest_table = {
         '13':'test_hl_daily'
        ,'17':'test_hl_daily'
        ,'25':'test_hl_daily'
     ,'close':'test_close_daily'
       ,'min':'test_min_daily'
}
def runCloseDataMerge():
    conn_raw_close = getConn(r"D:\data\RAW_FINAL_FORMAT_CLOSE")
    conn_raw_min = getConn(r"D:\data\RAW_FINAL_FORMAT_MIN")
    conn_raw_hl = getConn(r"D:\data\RAW_FINAL_FORMAT_HL")
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")

    for type, file in data_conf.items():
        if type == 'close':
            conn_raw = conn_raw_close
            print("----close")
        elif type == 'min':
            conn_raw = conn_raw_min
            print("---min")
            # continue
        else:
            # continue
            conn_raw = conn_raw_hl
            print(type)
        conf_file = train_conf[type]
        configs = json.load(open(conf_file, 'r'))
        sql = sql_conf[type]
        cols = col_conf[type]
        column = sort_conf[type]
        df = query(sql, conn_raw)
        data = DataLoaderAnalysisDaily(df, cols=configs['data']['columns'])
        data_hist = np.load(file, allow_pickle=True)
        x_train, y_train, t_train, h_train, y2_train = \
            data.get_daily_test_data(data=data_hist, column=column, col_lst=cols,
                                     seq_len=configs['data']['sequence_length'], normalise=configs['data']['normalise'])
        x_hist = np.vstack((data_hist['x_train'], x_train))
        y_hist = np.vstack((data_hist['y_train'], y_train))
        t_hist = np.vstack((data_hist['t_train'], t_train))
        h_hist = np.vstack((data_hist['h_train'], h_train))
        # y2_hist = np.vstack((data_hist['y_train2'], y2_train))
        a = data_hist['y_train2'].reshape((len(data_hist['y_train2']), 1))
        b = y2_train.reshape((len(y2_train), 1))
        y2_hist = np.vstack((a, b))[:, 0]
        np.savez(file, x_train=np.asarray(x_hist), y_train=np.asarray(y_hist), t_train=np.asarray(t_hist),
                 h_train=np.asarray(h_hist), y_train2=np.asarray(y2_hist), allow_pickle=False)
        np.savez(file.replace("full", "daily"), x_train=np.asarray(x_train), y_train=np.asarray(y_train),
                 t_train=np.asarray(t_train), h_train=np.asarray(h_train), y_train2=np.asarray(y2_train),
                 allow_pickle=False)
        print(file)

import numpy as np
import pandas as pd
if __name__ == '__main__':
    runCloseDataMerge()
