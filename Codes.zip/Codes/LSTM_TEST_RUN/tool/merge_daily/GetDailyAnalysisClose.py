from com.DbTool import query, getConn, insert

def get_analysi_d():
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    codes = list(query('select distinct code from test_close_daily',conn_raw)['code'].values)
    for idx,code in enumerate(codes):
        sql = '''
        select a.*,b.pv_d_2,b.pv_d_y,b.t_d from
        (select a.*,pv_m_2 from
        (select code,work_date,type as t_m,ny,pv as pv_m_y from test_min_daily where m_yt = 'y' and code='{code}') a
        left outer join
        (select code,work_date,ny,pv as pv_m_2 from test_min_daily where m_yt = 'ycls2' and code='{code}') b
        on a.code = b.code and a.work_date = b.work_date) a
        left outer join
        (select a.*,pv_d_2 from
        (select code,work_date,type as t_d,ny,pv as pv_d_y from test_close_daily where m_yt = 'y' and code='{code}') a
        left outer join
        (select code,work_date,ny,pv as pv_d_2 from test_close_daily where m_yt = 'ycls2' and code='{code}') b
        on a.code = b.code and a.work_date = b.work_date) b
        on a.code = b.code and a.work_date = b.work_date
        '''.format(code=code)
        df = query(sql,conn_raw)
        insert(df,conn_raw,'test_analysis_d',opType='append')
        print("%s-----------------%s" %(idx,code))
        sql = '''
        select a.*,b.pv_25_2,b.pv_25_y,b.t_25 from
(select a.*,b.pv_17_2,b.pv_17_y,b.t_17 from
(select a.*,pv_13_2 from
(select code,work_date,type as t_13,ny,pv as pv_13_y from test_hl_daily where m_type = '13' and m_yt = 'y' and code='{code}') a
left outer join
(select code,work_date,ny,pv as pv_13_2 from test_hl_daily where m_type = '13' and m_yt = 'ycls2' and code='{code}') b
on a.code = b.code and a.work_date = b.work_date) a left outer join
(select a.*,pv_17_2 from
(select code,work_date,type as t_17,ny,pv as pv_17_y from test_hl_daily where m_type = '17' and m_yt = 'y' and code='{code}') a
left outer join
(select code,work_date,ny,pv as pv_17_2 from test_hl_daily where m_type = '17' and m_yt = 'ycls2' and code='{code}') b
on a.code = b.code and a.work_date = b.work_date) b on a.code = b.code and a.work_date = b.work_date) a left outer join
(select a.*,pv_25_2 from
(select code,work_date,type as t_25,ny,pv as pv_25_y from test_hl_daily where m_type = '25' and m_yt = 'y' and code='{code}') a
left outer join
(select code,work_date,ny,pv as pv_25_2 from test_hl_daily where m_type = '25' and m_yt = 'ycls2' and code='{code}') b
on a.code = b.code and a.work_date = b.work_date) b on a.code = b.code and a.work_date = b.work_date
        '''.format(code=code)
        df = query(sql,conn_raw)
        insert(df,conn_raw,'test_analysis_w',opType='append')
        print("%s-----------------%s" %(idx,code))
def get_analysis_show_Analysis():
    sql = '''
    select a.code,a.t_d,a.t_m,a.t_13,a.t_17,a.t_25,c.sdate,a.work_date,c.day_13,c.pctchg as pctchg,c.pctchg13
       ,a.pv_m_y,a.pv_m_2,a.pv_d_y,a.pv_d_2
       ,a.pv_13_2,a.pv_13_y,a.pv_17_2,a.pv_17_y,a.pv_25_2,a.pv_25_y
       ,c.ny13s as ny13s,c.ny as ny from
(select a.code,a.work_date,a.t_d,t_m,b.t_13,b.t_17,b.t_25
     ,a.pv_m_2,round(a.pv_m_y,3) as pv_m_y
     ,a.pv_d_2,round(a.pv_d_y,3) as pv_d_y
    ,b.pv_13_2,round(b.pv_13_y,3) as pv_13_y
    ,b.pv_17_2,round(b.pv_17_y,3) as pv_17_y
    ,b.pv_25_2,round(b.pv_25_y,3) as pv_25_y
from test_analysis_d a left outer join test_analysis_w b
on a.code = b.code and a.work_date = b.work_date) a
left outer join raw_data_ny c
on a.code = c.code and a.work_date = c.date
order by a.code,a.work_date
    '''
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    df = query(sql,conn_raw)
    insert(df,conn_raw,'fine_bi_raw_hl_dm')
def get_analysis_show_Daily():
    sql = '''
    select a.code,a.t_d,a.t_m,a.t_13,a.t_17,a.t_25,c.sdate,a.work_date,c.day_13,c.pctchg as pctchg,c.pctchg13
       ,a.pv_m_y,a.pv_m_2,a.pv_d_y,a.pv_d_2
       ,a.pv_13_2,a.pv_13_y,a.pv_17_2,a.pv_17_y,a.pv_25_2,a.pv_25_y
       ,c.ny13s as ny13s,c.ny as ny from
(select a.code,a.work_date,a.t_d,t_m,b.t_13,b.t_17,b.t_25
     ,a.pv_m_2,round(a.pv_m_y,3) as pv_m_y
     ,a.pv_d_2,round(a.pv_d_y,3) as pv_d_y
    ,b.pv_13_2,round(b.pv_13_y,3) as pv_13_y
    ,b.pv_17_2,round(b.pv_17_y,3) as pv_17_y
    ,b.pv_25_2,round(b.pv_25_y,3) as pv_25_y
from test_analysis_d a left outer join test_analysis_w b
on a.code = b.code and a.work_date = b.work_date) a
left outer join raw_data_ny c
on a.code = c.code and a.work_date = c.date
order by a.code,a.work_date
    '''
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")

    df = query(sql,conn_raw)
    insert(df,conn_raw,'fine_bi_raw_hl_dm_daily')

def genCloseDailyData():
    sql = '''
    select distinct work_date from test_close_daily where date(work_date) > (select date(max(work_date)) as md from test_analysis_d)
    '''
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    df = query(sql,conn_raw)
    work_dates = sorted(list(df['work_date'].values))
    for work_date in work_dates:
        sql = '''
        select a.*,b.pv_d_2,b.pv_d_y,b.t_d from
        (select a.*,pv_m_2 from
        (select code,work_date,type as t_m,ny,pv as pv_m_y from test_min_daily where m_yt = 'y' and work_date='{work_date}') a
        left outer join
        (select code,work_date,ny,pv as pv_m_2 from test_min_daily where m_yt = 'ycls2' and work_date='{work_date}') b
        on a.code = b.code and a.work_date = b.work_date) a
        left outer join
        (select a.*,pv_d_2 from
        (select code,work_date,type as t_d,ny,pv as pv_d_y from test_close_daily where m_yt = 'y' and work_date='{work_date}') a
        left outer join
        (select code,work_date,ny,pv as pv_d_2 from test_close_daily where m_yt = 'ycls2' and work_date='{work_date}') b
        on a.code = b.code and a.work_date = b.work_date) b
        on a.code = b.code and a.work_date = b.work_date
        '''.format(work_date=work_date)
        df = query(sql,conn_raw)
        insert(df,conn_raw,'test_analysis_d',opType='append')
        print(work_date)
def genHLDailyData():
    sql = '''
 select distinct work_date from test_hl_daily where date(work_date) > (select date(max(work_date)) as md from test_analysis_w)
     '''
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    df = query(sql,conn_raw)
    work_dates = sorted(list(df['work_date'].values))
    for work_date in work_dates:
        sql = '''
        select a.*,b.pv_25_2,b.pv_25_y,b.t_25 from
(select a.*,b.pv_17_2,b.pv_17_y,b.t_17 from
(select a.*,pv_13_2 from
(select code,work_date,type as t_13,ny,pv as pv_13_y from test_hl_daily where m_type = '13' and m_yt = 'y' and work_date='{work_date}') a
left outer join
(select code,work_date,ny,pv as pv_13_2 from test_hl_daily where m_type = '13' and m_yt = 'ycls2' and work_date='{work_date}') b
on a.code = b.code and a.work_date = b.work_date) a left outer join
(select a.*,pv_17_2 from
(select code,work_date,type as t_17,ny,pv as pv_17_y from test_hl_daily where m_type = '17' and m_yt = 'y' and work_date='{work_date}') a
left outer join
(select code,work_date,ny,pv as pv_17_2 from test_hl_daily where m_type = '17' and m_yt = 'ycls2' and work_date='{work_date}') b
on a.code = b.code and a.work_date = b.work_date) b on a.code = b.code and a.work_date = b.work_date) a left outer join
(select a.*,pv_25_2 from
(select code,work_date,type as t_25,ny,pv as pv_25_y from test_hl_daily where m_type = '25' and m_yt = 'y' and work_date='{work_date}') a
left outer join
(select code,work_date,ny,pv as pv_25_2 from test_hl_daily where m_type = '25' and m_yt = 'ycls2' and  work_date='{work_date}') b
on a.code = b.code and a.work_date = b.work_date) b on a.code = b.code and a.work_date = b.work_date
        '''.format(work_date=work_date)
        df = query(sql,conn_raw)
        insert(df,conn_raw,'test_analysis_w',opType='append')
        print(work_date)

def genCloseAngleDailyData():
    sql = '''
    select distinct work_date from test_closeangle_daily where date(work_date) > (select date(max(work_date)) as md from test_analysis_d_angle)
    '''
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    try:
        df = query(sql,conn_raw)
        work_dates = sorted(list(df['work_date'].values))
    except:
        work_dates = ['2000-01-01']
    for work_date in work_dates:
        sql = '''
        select a.*,pv2 from
(select distinct code,work_date,type,pv from test_closeangle_daily where m_yt = 'y') a,
(select distinct code,work_date,type,pv as pv2 from test_closeangle_daily where m_yt = 'ycls2') b
where a.code = b.code and a.work_date = b.work_date
and date(a.work_date) = date('{work_date}')
        '''.format(work_date=work_date)
        df = query(sql,conn_raw)
        insert(df,conn_raw,'test_analysis_d_angle',opType='append')
        print(work_date)
def genHLAngleDailyData():
    sql = '''
    select distinct work_date from test_hlangle_daily where date(work_date) > (select date(max(work_date)) as md from test_analysis_w_angle)
    '''
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    try:
        df = query(sql,conn_raw)
        work_dates = sorted(list(df['work_date'].values))
    except:
        work_dates = ['2000-01-01']
    for work_date in work_dates:
        sql = '''
        select distinct a.*,b.pv2 from
(select code,work_date,type,pv from test_hlangle_daily where m_yt = 'y') a,
(select code,work_date,pv as pv2 from test_hlangle_daily where m_yt = 'ycls2') b
where a.code = b.code and a.work_date = b.work_date and date(a.work_date) >= date('{work_date}')
        '''.format(work_date=work_date)
        df = query(sql,conn_raw)
        insert(df,conn_raw,'test_analysis_w_angle',opType='append')
        print(work_date)
def genBiData():
    sql = '''
    select a.*,pv_ag_dhl, p2_ag_dhl, pv_ag_whl, p2_ag_whl from
(select a.code,a.t_d,a.t_m,a.t_13,a.t_17,a.t_25,c.sdate,a.work_date,c.day_13,c.pctchg as pctchg,c.pctchg13
       ,a.pv_m_y,a.pv_m_2,a.pv_d_y,a.pv_d_2
       ,a.pv_13_2,a.pv_13_y,a.pv_17_2,a.pv_17_y,a.pv_25_2,a.pv_25_y
       ,c.ny13s as ny13s,c.ny as ny from
(select a.code,a.work_date,a.t_d,t_m,b.t_13,b.t_17,b.t_25
     ,a.pv_m_2,round(a.pv_m_y,3) as pv_m_y
     ,a.pv_d_2,round(a.pv_d_y,3) as pv_d_y
    ,b.pv_13_2,round(b.pv_13_y,3) as pv_13_y
    ,b.pv_17_2,round(b.pv_17_y,3) as pv_17_y
    ,b.pv_25_2,round(b.pv_25_y,3) as pv_25_y
from test_analysis_d a left outer join test_analysis_w b
on a.code = b.code and a.work_date = b.work_date) a
left outer join raw_data_ny c
on a.code = c.code and a.work_date = c.date) a
left outer join
(select a.*,pv_ag_whl, p2_ag_whl from
(select distinct code,work_date,pv  as pv_ag_dhl,pv2 as p2_ag_dhl from test_analysis_d_angle) a
left outer join
(select distinct code,work_date,pv  as pv_ag_whl,pv2 as p2_ag_whl from test_analysis_w_angle) b
on a.code = b.code and a.work_date = b.work_date) b on a.code = b.code and a.work_date = b.work_date
order by code,work_date
    '''
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    df = query(sql,conn_raw)
    insert(df,conn_raw,'fine_bi_raw_hl_dm')
def runFineBIDailyData():
    genCloseDailyData()
    genHLDailyData()
    genCloseAngleDailyData()
    genHLAngleDailyData()
    genBiData()
if __name__ == '__main__':
    #get_analysi_d()
    #get_analysis_show_Daily()
    #genCloseDailyData()
    print("######start#########")
    genBiData()