import json

from com.DbTool import query, getConn, insert
#from tool.DataLoader import DataLoaderAnalysisDaily
from keras.utils import np_utils


data_conf = {
    '13':r'D:\data\data_file\13_y_21_daily.npz'
   ,'17':r'D:\data\data_file\17_y_21_daily.npz'
   ,'25':r'D:\data\data_file\25_y_21_daily.npz'
,'close':r'D:\data\data_file\close_y_21_daily.npz'
  ,'min':r'D:\data\data_file\min_y_21_daily.npz'
}
#data_conf = {
#    '13':r'D:\data\data_file\13_y_21_full.npz'
#   ,'17':r'D:\data\data_file\17_y_21_full.npz'
#   ,'25':r'D:\data\data_file\25_y_21_full.npz'
#,'close':r'D:\data\data_file\close_y_21_full.npz'
#  ,'min':r'D:\data\data_file\min_y_21_full.npz'
#}
# data_conf = {
#     '13':r'D:\data\data_file\13_y_21_full.npz'
#    ,'17':r'D:\data\data_file\17_y_21_full.npz'
#    ,'25':r'D:\data\data_file\25_y_21_full.npz'
# }
train_conf = {
    '13':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls13_v1.json'
   ,'17':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls17_v1.json'
   ,'25':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_hl_summary_cls25_v1.json'
,'close':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_summary_cls5_n1.json'
  ,'min':r'D:\code_center\LSTM_TEST_RUN\conf_files\raw_close_min_summary_cls5_1500_n1.json'
}
sql_conf = {
         '13':'select * from raw_hl9close_wave13_daily'
        ,'17':'select * from raw_hl9close_wave17_daily'
        ,'25':'select * from raw_hl9close_wave25_daily'
     ,'close':'select *,n1y as ny from raw_close_wave_N_5_clses_daily'
       ,'min':'select *,nny as ny from raw_close_min_wave_N_5_clses_data_daily'
}
col_conf = {
         '13':['code', 'work_date', 'ny', 'type']
        ,'17':['code', 'work_date', 'ny', 'type']
        ,'25':['code', 'work_date', 'ny', 'type']
     ,'close':['code', 'work_date', 'ny', 'type']
       ,'min':['code', 'work_date', 'dt', 'ny', 'type', 'times']
}
sort_conf = {
         '13':['work_date']
        ,'17':['work_date']
        ,'25':['work_date']
     ,'close':['work_date']
       ,'min':['work_date', 'dt']
}
dest_table = {
         '13':'test_hl_daily'
        ,'17':'test_hl_daily'
        ,'25':'test_hl_daily'
     ,'close':'test_close_daily'
       ,'min':'test_min_daily'
}
cls_conf = {
 '13'   :[-9,-8,-7,-6,-5,-4,-3,-2,-1,1,2,3,4,5,6,7,8,9]
,'17'   :[-9,-8,-7,-6,-5,-4,-3,-2,-1,1,2,3,4,5,6,7,8,9]
,'25'   :[-9,-8,-7,-6,-5,-4,-3,-2,-1,1,2,3,4,5,6,7,8,9]
,'close':[-4, -3, -2, -1, 1, 2, 3, 4]
,'min'  :[-4, -3, -2, -1, 1, 2, 3, 4]
}
import numpy as np
import pandas as pd
from core.model import Model
def runCloseDailyLSTM():
    conn_raw = getConn(r"D:\data\RAW_FINAL_FORMAT_ANALYSIS")
    #conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    for type, file in data_conf.items():
        #conf_file = train_conf[type]
        #configs = json.load(open(conf_file, 'r'))
        sql = sql_conf[type]
        cols = col_conf[type]
        #column = sort_conf[type]
        #df = query(sql, conn_raw)
        time_str = '15:00'
        print("----------------%s loaded" %(file))
        data = np.load(file, allow_pickle=True)
        x_train, y_train, t_train, h_train, y2_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'], data['y_train2']
        d_table = dest_table[type]
        model = Model()
        clses = cls_conf[type]
        for ycls in ['y','ycls2']:
            if ycls == 'ycls2':
                y_train = y2_train
                y_train = np_utils.to_categorical(y_train, 2)
            for cls in clses:
                src_file = query("select gold_file from raw_model_lst where cls = %s and type = '%s' and y_type = '%s'"
                                 % (int(cls), type, ycls), conn_raw)['gold_file'].values[0]
                model.load_model(src_file)
                if type == 'min':
                    time_train = h_train[:, -1]
                    idxes_train_a = np.argwhere(t_train == cls)[:, 0]
                    idxes_train_b = np.argwhere(time_train[idxes_train_a] == time_str)[:, 0]
                    idxes_train = idxes_train_a[idxes_train_b]
                else:
                    idxes_train = np.argwhere(t_train == cls)[:, 0]
                x_tr = x_train[idxes_train]
                y_tr = y_train[idxes_train]
                h_tr = h_train[idxes_train]
                rdf = pd.DataFrame(data=h_tr, columns=cols)
                print("-----------------%s %s" % (cls, len(idxes_train)))
                try:
                    predicted = model.predict_point_by_point(x_tr)
                    # pv = np.argmax(predicted, axis=1)
                    pv = np.argmax(predicted, axis=1) if ycls == 'ycls2' else predicted[:, 0]
                    av = y_tr[:, 0]
                    a_rate = np.count_nonzero(pv * av > 0)
                    f_rate = np.count_nonzero(pv * av <= 0)
                    rdf['pv'] = pv
                    #rdf['av'] = av
                    rdf['m_type'] = type
                    rdf['m_yt'] = ycls
                    rdf['m_cls'] = cls
                    print("%s %s %s %s" % (type,src_file, a_rate, f_rate + a_rate))
                    insert(rdf, conn_raw, d_table, opType='append')
                except:
                    import traceback
                    traceback.print_exc()
                    pass
if __name__ == '__main__':
    runCloseDailyLSTM()