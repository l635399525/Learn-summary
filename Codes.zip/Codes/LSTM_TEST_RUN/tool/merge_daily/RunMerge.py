from tool.merge_daily.GetDailyAnalysisClose import runFineBIDailyData
from tool.merge_daily.GetDailyTestAngle import runAngleDailyLSTM
from tool.merge_daily.GetDailyTestClose import runCloseDailyLSTM
from tool.merge_daily.GetDataMergeClose import runCloseDataMerge
from tool.merge_daily.GetDataMergeAngle import runAngleDataMerge

if __name__ == '__main__':
    print("####################close data gen#################")
    runCloseDataMerge()
    print("####################angle data gen#################")
    runAngleDataMerge()
    print("####################close lstm gen#################")
    runCloseDailyLSTM()
    print("####################angle lstm gen#################")
    runAngleDailyLSTM()
    print("####################daily finebi gen#################")
    runFineBIDailyData()

