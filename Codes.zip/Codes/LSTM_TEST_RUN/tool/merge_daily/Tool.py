import numpy as np
file = r'D:\data\data_file\13_y_21_full.npz'
data_hist = np.load(file, allow_pickle=True)
print(data_hist)
