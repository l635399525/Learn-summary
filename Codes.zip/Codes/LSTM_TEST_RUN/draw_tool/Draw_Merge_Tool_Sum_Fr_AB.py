from sklearn.ensemble import RandomForestClassifier

from com.DbTool import getConn, query, insert

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['work_date'] = list(df_close['work_date'])
    st_data['c_date'] = list(df_close['c_date'])
    st_data['code'] = [st] * len(st_data)
    st_data['type'] = list(df_close['type'])

    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data['y'] = df_close['y'].values
    #st_data['tp'] = df_close['ny13s'].shift(1).values
    #st_data['ny'] = st_data.apply(lambda x:1 if x['tn'] > x['tp'] else 0,axis=1)
    #st_data = st_data.drop('tn',axis=1)
    #st_data = st_data.drop('tp',axis=1)
    st_data = st_data.dropna()
    return np.array(st_data)
import pandas as pd
def genRfData(


        n=1):
    conn = getConn(r'D:\data\summary_db\RAW_HLWAVES_DATA')
    sql = 'select distinct code from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_0 order by random()'
    codes = list(query(sql,conn)['code'].values)
    train_codes = codes[:2499]
    for type in [0,1]:
        sql ='''
        select code, work_date, c_date, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt, y_dt, a_ag, y_ag, lb, avg_dt, ar
    ,case when y_dt > ar*a_dt then 1 else 0 end as y
    ,case when ar == 1 then 'A'
        when ar > 0.5 and ar < 1 then 'B'
        else 'C'
        end as type
    from
    (select  a.code, work_date, c_date,
           x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag,
           a_dt, y_dt, a_ag, y_ag, y, a.lb, avg_dt,
           case when avg_dt < 100 then 1
                when avg_dt >= 100 and avg_dt <= 200 then 0.618
                else 0.382
               end as ar
           from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_{type} a,
    (select lb,round(avg(a_dt)) as avg_dt from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_{type} group by lb) b
    where a.lb = b.lb)
        '''.format(type=type)
        trains = []
        tests = []
        df = query(sql,conn)
        dfs = df.groupby('code')
        for code,idf in dfs:
            try:
                if len(idf) < n:
                    continue
                idf = idf.sort_values(by=['c_date'])
                data = create_stock_data(idf,
                                         {'x_a_l': list(range(0, n)), 'x_b_l': list(range(0, n)), 'x_c_l': list(range(0, n)),
                                          'x_d_l': list(range(0, n)), 'x_e_l': list(range(0, n)), 'x_ab_ag': list(range(0, n)),
                                          'x_bc_ag': list(range(0, n)), 'x_cd_ag': list(range(0, n)), 'x_de_ag': list(range(0, n))
                                             , 'x_ea_ag': list(range(0, n))},code)
                if code in train_codes:
                    trains.append(data)
                else:
                    tests.append(data)
                print("%s %s--- Done" %(len(trains),code))
            except:
                pass
        train_data = np.concatenate([x for x in trains])
        test_data = np.concatenate([x for x in tests])
        np.savez('raw_hl_draw_merge_%s_fr_%s.npz' %(n,type),train = train_data,test=test_data)
        #print('raw_hl_merge_%s.npz')

import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
def tester(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        test_x, test_y = test_data[:, 4:-1], test_data[:, -1]
        res = clf2.predict(test_x)
        nres = clf2.predict_proba(test_x)
        res_1 = np.argmax(nres,axis=1)
        gap = np.round(np.abs(nres[:,0] - nres[:,1]),3)
        return res,test_y,res_1,gap
def trainer(model_name,train_data, test_data):
    random.seed(SEED)
    np.random.seed(SEED)

    train_x, train_y = train_data[:, 4:-1], train_data[:, -1]
    train_y = train_y.astype('int')
    print('Started training')
    clf = RandomForestClassifier(n_estimators=2999,
                                 max_depth=15,
                                 random_state=SEED,
                                 n_jobs=-1)
    #s = pickle.dumps(clf)
    clf.fit(train_x, train_y)
    print('Completed ', clf.score(train_x, train_y))
    with open(model_name, 'wb') as f:
        pickle.dump(clf, f)
    # dates = list(set(test_data[:, 0]))
    # predictions = {}
    # for day in dates:
    #     test_d = test_data[test_data[:, 0] == day]
    #     test_d = test_d[:, 2:-2]
    #     predictions[day] = clf.predict_proba(test_d)[:, 1]
    # return predictions


if __name__ == '__main__':
    conn = getConn(r'D:\data\summary_db\RAW_HLWAVES_DATA')
    Flag = False
    if Flag:
        for n in [1]:
            #for type in [0,1]:
            genRfData(n)
    if Flag:
        for n in [1]:
            for type in [0,1]:
                data = np.load('raw_hl_draw_merge_%s_fr_%s.npz' %(n,type),allow_pickle=True)
                train_x = data['train']
                test_x = data['test']
                for cls in ['A','B','C']:
                    #np.argwhere(train_x[:,3] == type)
                    x_train = train_x[np.argwhere(train_x[:, 3] == cls)[:,0]]
                    x_test  = test_x[np.argwhere(test_x[:, 3] == cls)[:,0]]
                    print("--------start %s %s %s" %(len(train_x),len(test_x),type))
                    trainer('hl_draw_fr_%s_%s_%s' %(n,cls,type),x_train,x_test)
    if not Flag:
        # st_data['work_date'] = list(df_close['work_date'])
        # st_data['c_date'] = list(df_close['c_date'])
        # st_data['code'] = [st] * len(st_data)
        # st_data['type'] = list(df_close['type'])
        for n in [1]:
            for type in [0,1]:
                data = np.load('raw_hl_draw_merge_%s_fr_%s.npz' %(n,type),allow_pickle=True)
                train = data['train']
                test = data['test']
                for cls in ['A','B','C']:
                    x_train = train[np.argwhere(train[:, 3] == cls)[:,0]]
                    x_test  = test[np.argwhere(test[:, 3] == cls)[:,0]]
                    st_data_train = pd.DataFrame([])
                    st_data_train['code'] = x_train[:, 2]
                    st_data_train['type'] = x_train[:, 3]
                    st_data_train['work_date'] = x_train[:, 0]
                    st_data_train['c_date'] = x_train[:, 1]
                    st_data_train['y'] = x_train[:, -1]
                    st_data_train['dt'] = 'train'
                    st_data_test = pd.DataFrame([])
                    st_data_test['code'] = x_test[:, 2]
                    st_data_test['type'] = x_test[:, 3]
                    st_data_test['work_date'] = x_test[:, 0]
                    st_data_test['c_date'] = x_test[:, 1]
                    st_data_test['y'] = x_test[:, -1]
                    st_data_test['dt'] = 'tests'
                    st_data = pd.concat([st_data_train,st_data_test])
                    data = np.vstack([x_train,x_test])
                    model = 'hl_draw_fr_%s_%s_%s' %(n,cls,type)
                    pv, av, pv1, gap = tester(model, data)
                    st_data['pv'] = pv
                    st_data['pv_t'] = pv1
                    st_data['gap'] = gap
                    st_data['av'] = av
                    st_data['mtype'] = 'fr'
                    st_data['model'] = model
                    st_data['cls'] = type

                    print("--------start %s %s %s" %(len(x_train),len(x_test),type))
                    insert(st_data, conn, 'test_merge_result_v1', opType='append')

