from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import OneHotEncoder,LabelEncoder

from com.DbTool import getConn, query, insert

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['work_date'] = list(df_close['work_date'])
    st_data['code'] = [st] * len(st_data)
    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data['tn'] = df_close['ny13s'].shift(-1).values
    st_data['tp'] = df_close['ny13s'].shift(1).values
    st_data['ny'] = st_data.apply(lambda x:1 if x['tn'] > x['tp'] else 0,axis=1)
    st_data = st_data.drop('tn',axis=1)
    st_data = st_data.drop('tp',axis=1)
    st_data = st_data.dropna()
    return np.array(st_data)
import pandas as pd
def genRfData(n=1):
    conn = getConn(r'D:\data\summary_db\RAW_HLWAVES_DATA')
    sql = 'select distinct code from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_0 order by random()'
    codes = list(query(sql,conn)['code'].values)
    train_codes = codes[:2499]
    for type in [0,1]:
        sql ='''
        select code, work_date, c_date, x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag, a_dt, y_dt, a_ag, y_ag, lb, avg_dt, ar
    ,case when y_ag > 111 then 2
          when y_ag > 68 and y_ag <= 111 then 1 
        else 0 end as y
    ,case when ar == 1 then 'A'
        when ar > 0.5 and ar < 1 then 'B'
        else 'C'
        end as type
    from
    (select  a.code, work_date, c_date,
           x_a_l, x_b_l, x_c_l, x_d_l, x_e_l, x_ab_ag, x_bc_ag, x_cd_ag, x_de_ag, x_ea_ag,
           a_dt, y_dt, a_ag, y_ag, y, a.lb, avg_dt,
           case when avg_dt < 100 then 1
                when avg_dt >= 100 and avg_dt <= 200 then 0.618
                else 0.382
               end as ar
           from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_{type} a,
    (select lb,round(avg(a_dt)) as avg_dt from raw_kmeans_hl_merge_close_summary_drawline_train_data_kmeans_{type} group by lb) b
    where a.lb = b.lb)
        '''.format(type=type)
        trains = []
        tests = []
        df = query(sql,conn)
        dfs = df.groupby('code')
        for code,idf in dfs:
            try:
                if len(idf) < n:
                    continue
                idf = idf.sort_values(by=['c_date'])
                data = create_stock_data(idf,
                                         {'x_a_l': list(range(0, n)), 'x_b_l': list(range(0, n)), 'x_c_l': list(range(0, n)),
                                          'x_d_l': list(range(0, n)), 'x_e_l': list(range(0, n)), 'x_ab_ag': list(range(0, n)),
                                          'x_bc_ag': list(range(0, n)), 'x_cd_ag': list(range(0, n)), 'x_de_ag': list(range(0, n))
                                             , 'x_ea_ag': list(range(0, n))},code)
                if code in train_codes:
                    trains.append(data)
                else:
                    tests.append(data)
                print("%s %s--- Done" %(len(trains),code))
            except:
                pass
        train_data = np.concatenate([x for x in trains])
        test_data = np.concatenate([x for x in tests])
        np.savez('raw_hl_draw_merge_%s_fr_%s_ag.npz' %(n,type),train = train_data,test=test_data)
        #print('raw_hl_merge_%s.npz')

import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
def tester(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        test_x, test_y = test_data[:, 4:-1], test_data[:, -1]
        test_x = xgb.DMatrix(test_x)
        y_pred = clf2.predict(test_x)
        predictions = [round(value) for value in y_pred]
        #p_test = clf2.predict(test_x, ntree_limit=clf2.best_ntree_limit)
        from sklearn.metrics import accuracy_score
        accuracy = accuracy_score(list(test_y), predictions)
        print(accuracy)
        return np.asarray(predictions),test_y,np.asarray(predictions),y_pred
import xgboost as xgb

def trainer(model_name,train_data, test_data):
    random.seed(SEED)
    np.random.seed(SEED)
    from sklearn.preprocessing import MinMaxScaler
    fit = MinMaxScaler()

    train_x, train_y = train_data[:, 4:-2], train_data[:, -1]
    test_x, test_y = test_data[:, 4:-2], test_data[:, -1]

    fit.fit(train_y.reshape(len(train_y), 1))
    train_y = fit.transform(train_y.reshape(len(train_y), 1))[:, 0]
    test_y = fit.transform(test_y.reshape(len(test_y), 1))[:, 0]

    train_y = train_y.astype('float')
    test_y = test_y.astype('float')

    params = {
        'min_child_weight': 10.0,
        'objective': 'binary:logistic',
        'max_depth': 7,
        'max_delta_step': 1.8,
        'colsample_bytree': 0.4,
        'subsample': 0.8,
        'eta': 0.025,
        'gamma': 0.65,
        'num_boost_round': 700
    }
    from sklearn.metrics import mean_squared_error

    def myFeval(preds, xgbtrain):
        label = xgbtrain.get_label()
        score = mean_squared_error(label, preds) * 0.5
        return 'myFeval', score

    #train_y = np.reshape(train_y, (-1, 1))
    #test_y = np.reshape(test_y, (-1, 1))
    # lbl = LabelEncoder()
    # trainy = lbl.fit_transform(train_y)
    # enc = OneHotEncoder(handle_unknown='ignore')
    # #enc.fit(train_y)
    # train_enc_y = enc.transform(train_y).toarray()
    # enc.fit(test_y)
    # test_enc_y = enc.transform(test_y).toarray()
    # #train_y = train_y.astype('int')
    print('Started training')
    d_train = xgb.DMatrix(train_x, train_y)
    d_valid = xgb.DMatrix(test_x, test_y)
    # d_test = xgb.DMatrix(test.values)
    watchlist = [(d_train, 'train'), (d_valid, 'valid')]
    clf = xgb.train(params, d_train, 3999, watchlist, early_stopping_rounds=399, feval=myFeval, maximize=True,
                    verbose_eval=100)
    with open(model_name, 'wb') as f:
        pickle.dump(clf, f)


if __name__ == '__main__':
    conn = getConn(r'D:\data\summary_db\RAW_HLWAVES_DATA')

    Flag = False
    if Flag:
        for n in [5,8,11,13]:
            genRfData(n)
    if Flag:
        for n in [1]:
            for type in [0,1]:
                data = np.load('raw_hl_draw_merge_%s_fr_%s_ag.npz' %(n,type),allow_pickle=True)
                #data = np.load('raw_hl_draw_merge_%s_fr.npz' % (n), allow_pickle=True)
                train_x = data['train']
                test_x = data['test']
                for cls in ['A', 'B', 'C']:
                    # np.argwhere(train_x[:,3] == type)
                    x_train = train_x[np.argwhere(train_x[:, 3] == cls)[:, 0]]
                    x_test = test_x[np.argwhere(test_x[:, 3] == cls)[:, 0]]
                    print("--------start %s %s %s" % (len(x_train), len(x_test), type))
                    trainer('hl_draw_xgb_%s_%s_%s_ag' % (n, cls,type), x_train, x_test)
    if not Flag:
        for n in [1]:
            for type in [0, 1]:
                data = np.load('raw_hl_draw_merge_%s_fr_%s_ag.npz' % (n, type), allow_pickle=True)
                train = data['train']
                test = data['test']
                for cls in ['A', 'B', 'C']:
                    x_train = train[np.argwhere(train[:, 3] == cls)[:, 0]]
                    x_test = test[np.argwhere(test[:, 3] == cls)[:, 0]]
                    st_data_train = pd.DataFrame([])
                    st_data_train['code'] = x_train[:, 2]
                    st_data_train['type'] = x_train[:, 3]
                    st_data_train['work_date'] = x_train[:, 0]
                    st_data_train['c_date'] = x_train[:, 1]
                    st_data_train['y'] = x_train[:, -1]
                    st_data_train['dt'] = 'train'
                    st_data_test = pd.DataFrame([])
                    st_data_test['code'] = x_test[:, 2]
                    st_data_test['type'] = x_test[:, 3]
                    st_data_test['work_date'] = x_test[:, 0]
                    st_data_test['c_date'] = x_test[:, 1]
                    st_data_test['y'] = x_test[:, -1]
                    st_data_test['dt'] = 'tests'
                    st_data = pd.concat([st_data_train, st_data_test])
                    data = np.vstack([x_train, x_test])
                    #pv, av, pv1, gap = tester('hl_draw_xgb_%s_%s' % (n, type), data)
                    model = 'hl_draw_xgb_%s_%s_%s_ag' % (n, cls, type)
                    pv, av, pv1, gap = tester(model, data)
                    st_data['pv'] = pv
                    st_data['pv_t'] = pv1
                    st_data['gap'] = gap
                    st_data['av'] = av
                    st_data['mtype'] = 'xgb'
                    st_data['model'] = model
                    st_data['cls'] = type

                    print("--------start %s %s %s" % (len(x_train), len(x_test), type))
                    insert(st_data, conn, 'test_merge_result_v1', opType='append')
