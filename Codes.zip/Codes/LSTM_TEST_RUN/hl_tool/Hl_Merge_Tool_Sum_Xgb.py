from sklearn.ensemble import RandomForestClassifier

from com.DbTool import getConn, query, insert

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['work_date'] = list(df_close['work_date'])
    st_data['code'] = [st] * len(st_data)
    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data['tn'] = df_close['ny13s'].shift(-1).values
    st_data['tp'] = df_close['ny13s'].shift(1).values
    st_data['ny'] = st_data.apply(lambda x:1 if x['tn'] > x['tp'] else 0,axis=1)
    st_data = st_data.drop('tn',axis=1)
    st_data = st_data.drop('tp',axis=1)
    st_data = st_data.dropna()
    return np.array(st_data)
import pandas as pd
def genRfData(n):

    sql = 'select distinct code from raw_daily_hl_y_pn_merge order by random()'
    codes = list(query(sql,conn)['code'].values)
    train_codes = codes[:2399]
    sql = 'select code, work_date, ny_13, cls_13, ec_13, sdate, ny13s, gap, ag from raw_daily_hl_y_pn_merge where sdate is not null'
    trains = []
    tests = []
    df = query(sql,conn)
    dfs = df.groupby('code')
    for code,idf in dfs:
        try:
            if len(idf) < n:
                continue
            idf = idf.sort_values(by=['work_date'])
            data = create_stock_data(idf,{'ag': list(range(0, n)),'ny13s': list(range(0, n))},code)
            if code in train_codes:
                trains.append(data)
            else:
                tests.append(data)
            print("%s %s--- Done" %(len(trains),code))
        except:
            pass
    train_data = np.concatenate([x for x in trains])
    test_data = np.concatenate([x for x in tests])
    np.savez('raw_hl_merge_%s.npz' %(n),train = train_data,test=test_data)
    #print('raw_hl_merge_%s.npz')

import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
def tester(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        test_x, test_y = test_data[:, 2:-1], test_data[:, -1]
        test_x = xgb.DMatrix(test_x)
        y_pred = clf2.predict(test_x)
        predictions = [round(value) for value in y_pred]
        #p_test = clf2.predict(test_x, ntree_limit=clf2.best_ntree_limit)
        from sklearn.metrics import accuracy_score
        accuracy = accuracy_score(list(test_y), predictions)
        print(accuracy)
        return np.asarray(predictions),test_y,np.asarray(predictions),y_pred
import xgboost as xgb

def trainer(model_name,train_data, test_data):
    random.seed(SEED)
    np.random.seed(SEED)
    train_x, train_y = train_data[:, 2:-1], train_data[:, -1]
    test_x, test_y = test_data[:, 2:-1], test_data[:, -1]

    train_y = train_y.astype('int')
    test_y = test_y.astype('int')

    params = {
        'min_child_weight': 10.0,
        'objective': 'binary:logistic',
        'max_depth': 7,
        'max_delta_step': 1.8,
        'colsample_bytree': 0.4,
        'subsample': 0.8,
        'eta': 0.025,
        'gamma': 0.65,
        'num_boost_round': 700
    }
    from sklearn.metrics import mean_squared_error

    def myFeval(preds, xgbtrain):
        label = xgbtrain.get_label()
        score = mean_squared_error(label, preds) * 0.5
        return 'myFeval', score

    #train_y = train_y.astype('int')
    print('Started training')
    d_train = xgb.DMatrix(train_x, train_y)
    d_valid = xgb.DMatrix(test_x, test_y)
    # d_test = xgb.DMatrix(test.values)
    watchlist = [(d_train, 'train'), (d_valid, 'valid')]
    clf = xgb.train(params, d_train, 1600, watchlist, early_stopping_rounds=70, feval=myFeval, maximize=True,
                    verbose_eval=100)
    with open(model_name, 'wb') as f:
        pickle.dump(clf, f)


if __name__ == '__main__':
    Flag = True
    if not Flag:
        for n in [5,8,11,13]:
            genRfData(n)
    if not Flag:
        for n in [11,13]:
            data = np.load('raw_hl_merge_%s.npz' %(n),allow_pickle=True)
            train_x = data['train']
            test_x = data['test']
            print("--------start %s %s" %(len(train_x),len(test_x)))
            trainer('hl_fr_%s_xgb' %(n),train_x,test_x)
    if Flag:
        for n in [11,13]:
            data = np.load('raw_hl_merge_%s.npz' % (n), allow_pickle=True)
            train = data['train']
            test = data['test']
            st_data = pd.DataFrame([])
            st_data['code'] = train[:, 1]
            st_data['work_date'] = train[:, 0]
            st_data['type'] = ['%s_%s' %('train',n)]*len(train)
            pv, av,pv1,gap = tester('hl_fr_%s_xgb' % (n), train)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av

            insert(st_data, conn, 'test_merge_result_tmp', opType='append')
            print("-------------------------%s" %(n))
            st_data = pd.DataFrame([])
            st_data['code'] = test[:, 1]
            st_data['work_date'] = test[:, 0]
            st_data['type'] = ['%s_%s' % ('test', n)] * len(test)
            pv, av,pv1,gap = tester('hl_fr_%s_xgb' % (n), test)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av
            insert(st_data, conn, 'test_merge_result_tmp', opType='append')
            print("-------------------------%s" %(n))

