from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor

from com.DbTool import getConn, query, insert
import xgboost as xgb
conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, train_test_split, GridSearchCV

def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['work_date'] = list(df_close['work_date'])
    st_data['code'] = [st] * len(st_data)
    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data['ny'] = df_close['ny_13'].shift(-1).values

    st_data['ny2'] = st_data.apply(lambda x:1 if x['ny'] > 0 else 0,axis=1).values
    #st_data = st_data.drop('tn',axis=1)
    #st_data = st_data.drop('tp',axis=1)
    st_data = st_data.dropna()
    return np.array(st_data)
import pandas as pd
def genDetailRfData(n):

    sql = 'select distinct code from raw_daily_hl_y_pn_merge order by random()'
    codes = list(query(sql,conn)['code'].values)
    train_codes = codes[:2399]
    sql = 'select code, work_date, ec_13, n_ec_13, ny_13, ndate, w, ag, ny13s, ws, ags from raw_daily_hl_y_pn_detail_merge'
    trains = []
    tests = []
    df = query(sql,conn)
    dfs = df.groupby('code')
    for code,idf in dfs:
        try:
            if len(idf) < n:
                continue
            idf = idf.sort_values(by=['work_date'])
            data = create_stock_data(idf,{'ag': list(range(0, n)),'ny_13': list(range(0, n)),'ags': list(range(0, n))},code)
            if code in train_codes:
                trains.append(data)
            else:
                tests.append(data)
            print("%s %s--- Done" %(len(trains),code))
        except:
            pass
    train_data = np.concatenate([x for x in trains])
    test_data = np.concatenate([x for x in tests])
    np.savez('raw_hl_detail_merge_%s.npz' %(n),train = train_data,test=test_data)
    #print('raw_hl_merge_%s.npz')

import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
def tester(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        if 'y2#' in model_name:
            test_x, test_y = test_data[:, 2:-2], test_data[:, -1]
        else:
            test_x, test_y = test_data[:, 2:-2], test_data[:, -2]
        test_x = xgb.DMatrix(test_x)
        y_pred = clf2.predict(test_x)
        predictions = [round(value) for value in y_pred]
        #p_test = clf2.predict(test_x, ntree_limit=clf2.best_ntree_limit)
        from sklearn.metrics import accuracy_score
        accuracy = accuracy_score(list(test_y), predictions)
        print(accuracy)
        return np.asarray(predictions),test_y,np.asarray(predictions),y_pred
from numpy import loadtxt
from xgboost import XGBClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import StratifiedKFold
def trainer(model_name,train_data, test_data,type='y2'):
    random.seed(SEED)
    np.random.seed(SEED)
    if type == 'y2':
        train_x, train_y = train_data[:, 2:-2], train_data[:, -1]
        test_x, test_y = test_data[:, 2:-2], test_data[:, -1]
    else:
        train_x, train_y = train_data[:, 2:-2], train_data[:, -2]
        test_x, test_y = test_data[:, 2:-2], test_data[:, -1]

    params = {
        'min_child_weight': 10.0,
        'objective': 'binary:logistic',
        'max_depth': 7,
        'max_delta_step': 1.8,
        'colsample_bytree': 0.4,
        'subsample': 0.8,
        'eta': 0.025,
        'gamma': 0.65,
        'num_boost_round': 700
    }
    from sklearn.metrics import mean_squared_error

    def myFeval(preds, xgbtrain):
        label = xgbtrain.get_label()
        score = mean_squared_error(label, preds) * 0.5
        return 'myFeval', score
    train_y = train_y.astype('int')
    print('Started training')
    d_train = xgb.DMatrix(train_x, train_y)
    d_valid = xgb.DMatrix(test_x, test_y)
    #d_test = xgb.DMatrix(test.values)
    watchlist = [(d_train, 'train'), (d_valid, 'valid')]

    # Train the model! We pass in a max of 1,600 rounds (with early stopping after 70)
    # and the custom metric (maximize=True tells xgb that higher metric is better)
    clf = xgb.train(params, d_train, 1600, watchlist, early_stopping_rounds=70, feval=myFeval, maximize=True,
                    verbose_eval=100)

    #clf.fit(train_x, train_y)
    #print(clf.best_score_)
    #print(clf.best_params_)
    #print('Completed ', clf.score(train_x, train_y))
    with open("%s#" %(type) + model_name, 'wb') as f:
        pickle.dump(clf, f)
    # dates = list(set(test_data[:, 0]))
    # predictions = {}
    # for day in dates:
    #     test_d = test_data[test_data[:, 0] == day]
    #     test_d = test_d[:, 2:-2]
    #     predictions[day] = clf.predict_proba(test_d)[:, 1]
    # return predictions


if __name__ == '__main__':
    Flag = False
    if Flag:
        for n in [5,8,11,13]:
            genDetailRfData(n)
    if Flag:
        for n in [11,13]:
            data = np.load('raw_hl_detail_merge_%s.npz' %(n),allow_pickle=True)
            train_x = data['train']
            test_x = data['test']
            print("--------start %s %s" %(len(train_x),len(test_x)))
            trainer('hl_xgb_detail_fr_%s' %(n),train_x,test_x,type='y2')
    if not Flag:
        for n in [11,13]:
            data = np.load('raw_hl_detail_merge_%s.npz' % (n), allow_pickle=True)
            train = data['train']
            test = data['test']
            st_data = pd.DataFrame([])
            st_data['code'] = train[:, 1]
            st_data['work_date'] = train[:, 0]
            st_data['type'] = ['%s_%s' %('train_detail_xgb',n)]*len(train)
            model_f = r'D:\code_center\LSTM_TEST_RUN\hl_tool\final_model\data\y2#hl_xgb_detail_fr_%s' %(n)
            pv, av,pv1,gap = tester(model_f, train)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av
            insert(st_data, conn, 'test_merge_result', opType='append')
            print("-------------------------%s" %(n))
            st_data = pd.DataFrame([])
            st_data['code'] = test[:, 1]
            st_data['work_date'] = test[:, 0]
            st_data['type'] = ['%s_%s' % ('test_detail_xgb', n)] * len(test)
            pv, av,pv1,gap = tester(model_f, test)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av
            insert(st_data, conn, 'test_merge_result', opType='append')
            print("-------------------------%s" %(n))

