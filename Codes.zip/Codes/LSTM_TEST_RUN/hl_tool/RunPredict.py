import glob

from sklearn.preprocessing import RobustScaler

from com.DbTool import getConn, query, insert, drop

import numpy as np
import pickle

from hl_tool.Intraday2403LSTM import reshaper, scalar_normalize


def tester_sum_fr(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        test_x = test_data[:, 2:]
        test_x = test_x.astype('float64')
        res = clf2.predict(test_x)
        nres = clf2.predict_proba(test_x)
        res_1 = np.argmax(nres,axis=1)
        gap = np.round(np.abs(nres[:,0] - nres[:,1]),3)
        return res,res_1,gap
import xgboost as xgb

def tester_sum_xgb(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        test_x = test_data[:, 2:]
        test_x = xgb.DMatrix(test_x)
        y_pred = clf2.predict(test_x)
        predictions = [round(value) for value in y_pred]
        #p_test = clf2.predict(test_x, ntree_limit=clf2.best_ntree_limit)
        #from sklearn.metrics import accuracy_score
        #accuracy = accuracy_score(list(test_y), predictions)
        #print(accuracy)
        return np.asarray(predictions),np.asarray(predictions),y_pred
def scalar_normalize(train_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:, 2:])
    train_data = scaler.transform(train_data[:, 2:])
    return train_data
def tester_sum_lstm(model_name,test_data):
    from keras.models import Sequential, load_model
    model = load_model(model_name)
    test_data = scalar_normalize(test_data)

    test_x = test_data
    test_x = reshaper(test_x)
    test_x = test_x.astype('float64')
    try:
        nres = model.predict(test_x)
        res_1 = np.argmax(nres, axis=1)
        gap = np.round(np.abs(nres[:, 0] - nres[:, 1]), 3)
    except:
        res_1 = [None] * len(test_x)
        gap = [None] * len(test_x)

    return res_1, res_1, gap
def getSumDataRf(n):
    dest_conn = getConn(r'D:\data\RAW_FINAL_FORMAT_HL')
    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
    sql = '''
    select * from raw_daily_hl_y_pn_merge_predict_daily%s
    ''' %(n)
    model_file = r'D:\code_center\LSTM_TEST_RUN\hl_tool\final_model\data\hl_fr_%s' %(n)
    df = query(sql,dest_conn)
    df = df.dropna()
    if n == 11:
        datas = df[['code','l_date','ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10', 'ny13s0', 'ny13s1', 'ny13s2', 'ny13s3', 'ny13s4', 'ny13s5', 'ny13s6', 'ny13s7', 'ny13s8', 'ny13s9', 'ny13s10']].values
    elif n == 13:
        datas = df[['code','l_date','ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10', 'ag11', 'ag12', 'ny13s0', 'ny13s1', 'ny13s2', 'ny13s3', 'ny13s4', 'ny13s5', 'ny13s6', 'ny13s7', 'ny13s8', 'ny13s9', 'ny13s10', 'ny13s11', 'ny13s12']].values
    res,res_1,gap = tester_sum_fr(model_file,test_data=datas)
    rdf = df[['code','l_date','work_date']].copy()
    rdf['pv_1'] = res
    rdf['pv_2'] = res_1
    rdf['gap'] = gap
    rdf['type'] = 'sum_%s_frs' %(n)
    insert(rdf,conn,'raw_predict_daily_sumhl',opType='append')
    model_file = r'D:\code_center\LSTM_TEST_RUN\hl_tool\final_model\data\hl_fr_%s_xgb' %(n)
    res, res_1, gap = tester_sum_xgb(model_file, test_data=datas)
    rdf = df[['code', 'l_date', 'work_date']].copy()
    rdf['pv_1'] = res
    rdf['pv_2'] = res_1
    rdf['gap'] = gap
    rdf['type'] = 'sum_%s_xgb' % (n)
    insert(rdf,conn,'raw_predict_daily_sumhl',opType='append')
    print("%s--Done" %(n))
def getDetailRf(n):
    dest_conn = getConn(r'D:\data\RAW_FINAL_FORMAT_HL')
    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
    sql = '''
        select * from raw_daily_hl_y_pn_detail_merge_predict_daily%s
        ''' % (n)
    model_file = r'D:\code_center\LSTM_TEST_RUN\hl_tool\final_model\data\y2#hl_detail_fr_%s' % (n)
    df = query(sql, conn)
    df = df.dropna()
    if n == 11:
        datas = df[['code', 'l_date',
             'ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10',
             'ny_130', 'ny_131', 'ny_132', 'ny_133', 'ny_134', 'ny_135', 'ny_136', 'ny_137', 'ny_138', 'ny_139', 'ny_1310',
             'ags0', 'ags1', 'ags2', 'ags3', 'ags4', 'ags5', 'ags6', 'ags7', 'ags8', 'ags9', 'ags10'
             ]].values
    elif n == 13:
        datas = df[['code', 'l_date',
                    'ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10','ag11', 'ag12',
                    'ny_130', 'ny_131', 'ny_132', 'ny_133', 'ny_134', 'ny_135', 'ny_136', 'ny_137', 'ny_138', 'ny_139','ny_1310','ny_1311','ny_1312',
                    'ags0', 'ags1', 'ags2', 'ags3', 'ags4', 'ags5', 'ags6', 'ags7', 'ags8', 'ags9', 'ags10', 'ags11', 'ags12'
                    ]].values
    res, res_1, gap = tester_sum_fr(model_file, test_data=datas)
    rdf = df[['code', 'l_date', 'sdate']].copy()
    rdf['pv_1'] = res
    rdf['pv_2'] = res_1
    rdf['gap'] = gap
    rdf['type'] = 'detail_%s_frs' % (n)
    insert(rdf, conn, 'raw_predict_daily_dethl', opType='append')
    model_file = r'D:\code_center\LSTM_TEST_RUN\hl_tool\final_model\data\y2#hl_xgb_detail_fr_%s' % (n)
    res, res_1, gap = tester_sum_xgb(model_file, test_data=datas)
    rdf = df[['code', 'l_date', 'sdate']].copy()
    rdf['pv_1'] = res
    rdf['pv_2'] = res_1
    rdf['gap'] = gap
    rdf['type'] = 'detail_%s_xgb' % (n)
    insert(rdf, conn, 'raw_predict_daily_dethl', opType='append')
    print("%s--Done" % (n))
def getLSTMData(n):
    dest_conn = getConn(r'D:\data\RAW_FINAL_FORMAT_HL')
    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
    sql = '''
            select * from raw_daily_hl_y_pn_detail_merge_predict_daily%s
            ''' % (n)
    model_file = glob.glob(r'D:\code_center\LSTM_TEST_RUN\hl_tool\final_model\data\%s#model-LSTM*' %(n))[0]
    df = query(sql, conn)
    df = df.dropna()
    if n == 11:
        datas = df[['code','l_date',
             'ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10',
             'ny_130', 'ny_131', 'ny_132', 'ny_133', 'ny_134', 'ny_135', 'ny_136', 'ny_137', 'ny_138', 'ny_139', 'ny_1310',
             'ags0', 'ags1', 'ags2', 'ags3', 'ags4', 'ags5', 'ags6', 'ags7', 'ags8', 'ags9', 'ags10'
             ]].values
    elif n == 13:
        datas = df[['code', 'l_date',
                    'ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10','ag11', 'ag12',
                    'ny_130', 'ny_131', 'ny_132', 'ny_133', 'ny_134', 'ny_135', 'ny_136', 'ny_137', 'ny_138', 'ny_139','ny_1310','ny_1311','ny_1312',
                    'ags0', 'ags1', 'ags2', 'ags3', 'ags4', 'ags5', 'ags6', 'ags7', 'ags8', 'ags9', 'ags10', 'ags11', 'ags12'
                    ]].values
    elif n == 21:
        datas = df[['code', 'l_date',
                    'ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10', 'ag11', 'ag12',
                    'ag13', 'ag14', 'ag15', 'ag16', 'ag17', 'ag18', 'ag19', 'ag20',
                    'ny_130', 'ny_131', 'ny_132', 'ny_133', 'ny_134', 'ny_135', 'ny_136', 'ny_137', 'ny_138', 'ny_139',
                    'ny_1310', 'ny_1311', 'ny_1312','ny_1313', 'ny_1314', 'ny_1315', 'ny_1316', 'ny_1317', 'ny_1318', 'ny_1319', 'ny_1320',
                    'ags0', 'ags1', 'ags2','ags3', 'ags4', 'ags5', 'ags6', 'ags7', 'ags8', 'ags9', 'ags10', 'ags11', 'ags12',
                    'ags13', 'ags14', 'ags15', 'ags16', 'ags17', 'ags18', 'ags19', 'ags20'
                    ]].values
    elif n == 34:
        datas = df[['code', 'l_date',
                    'ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10', 'ag11', 'ag12',
                    'ag13', 'ag14', 'ag15',
                    'ag16', 'ag17', 'ag18', 'ag19', 'ag20', 'ag21', 'ag22', 'ag23', 'ag24', 'ag25', 'ag26', 'ag27',
                    'ag28', 'ag29', 'ag30', 'ag31', 'ag32', 'ag33',
                    'ny_130', 'ny_131', 'ny_132', 'ny_133', 'ny_134', 'ny_135', 'ny_136', 'ny_137', 'ny_138', 'ny_139',
                    'ny_1310', 'ny_1311', 'ny_1312', 'ny_1313', 'ny_1314', 'ny_1315',
                    'ny_1316', 'ny_1317', 'ny_1318', 'ny_1319', 'ny_1320', 'ny_1321', 'ny_1322', 'ny_1323', 'ny_1324',
                    'ny_1325', 'ny_1326', 'ny_1327', 'ny_1328', 'ny_1329', 'ny_1330', 'ny_1331', 'ny_1332', 'ny_1333',
                                                                                                            'ags0',
                    'ags1', 'ags2', 'ags3', 'ags4', 'ags5', 'ags6', 'ags7', 'ags8', 'ags9', 'ags10', 'ags11', 'ags12',
                    'ags13', 'ags14', 'ags15',
                    'ags16', 'ags17', 'ags18', 'ags19', 'ags20', 'ags21', 'ags22', 'ags23', 'ags24', 'ags25', 'ags26',
                    'ags27', 'ags28', 'ags29', 'ags30', 'ags31', 'ags32', 'ags33'
                    ]].values
    elif n == 55:
        datas = df[['code', 'l_date',
                    'ag0', 'ag1', 'ag2', 'ag3', 'ag4', 'ag5', 'ag6', 'ag7', 'ag8', 'ag9', 'ag10', 'ag11', 'ag12',
                    'ag13', 'ag14', 'ag15', 'ag16', 'ag17',
                    'ag18', 'ag19', 'ag20', 'ag21', 'ag22', 'ag23', 'ag24', 'ag25', 'ag26', 'ag27', 'ag28', 'ag29',
                    'ag30', 'ag31', 'ag32', 'ag33', 'ag34',
                    'ag35', 'ag36', 'ag37', 'ag38', 'ag39', 'ag40', 'ag41', 'ag42', 'ag43', 'ag44', 'ag45', 'ag46',
                    'ag47', 'ag48', 'ag49', 'ag50', 'ag51', 'ag52', 'ag53',
                    'ny_130', 'ny_131', 'ny_132', 'ny_133', 'ny_134', 'ny_135', 'ny_136', 'ny_137', 'ny_138', 'ny_139',
                    'ny_1310', 'ny_1311', 'ny_1312', 'ny_1313', 'ny_1314',
                    'ny_1315', 'ny_1316', 'ny_1317', 'ny_1318', 'ny_1319', 'ny_1320', 'ny_1321', 'ny_1322', 'ny_1323',
                    'ny_1324', 'ny_1325', 'ny_1326', 'ny_1327', 'ny_1328',
                    'ny_1329', 'ny_1330', 'ny_1331', 'ny_1332', 'ny_1333', 'ny_1334', 'ny_1335', 'ny_1336', 'ny_1337',
                    'ny_1338', 'ny_1339', 'ny_1340', 'ny_1341', 'ny_1342',
                    'ny_1343', 'ny_1344', 'ny_1345', 'ny_1346', 'ny_1347', 'ny_1348', 'ny_1349', 'ny_1350', 'ny_1351',
                    'ny_1352', 'ny_1353',
                    'ags0', 'ags1', 'ags2', 'ags3', 'ags4', 'ags5', 'ags6', 'ags7', 'ags8', 'ags9', 'ags10',
                    'ags11', 'ags12', 'ags13', 'ags14', 'ags15', 'ags16', 'ags17',
                    'ags18', 'ags19', 'ags20', 'ags21', 'ags22', 'ags23', 'ags24', 'ags25', 'ags26', 'ags27', 'ags28',
                    'ags29', 'ags30', 'ags31', 'ags32', 'ags33', 'ags34',
                    'ags35', 'ags36', 'ags37', 'ags38', 'ags39', 'ags40', 'ags41', 'ags42', 'ags43', 'ags44', 'ags45',
                    'ags46', 'ags47', 'ags48', 'ags49', 'ags50', 'ags51', 'ags52', 'ags53'
                    ]].values
    res, res_1, gap = tester_sum_lstm(model_file, test_data=datas)
    rdf = df[['code', 'l_date', 'sdate']].copy()
    rdf['pv_1'] = res
    rdf['pv_2'] = res_1
    rdf['gap'] = gap
    rdf['type'] = 'lstm_%s' % (n)
    insert(rdf, conn, 'raw_predict_daily_lstm', opType='append')
    print('---%s' %(n))
if __name__ == '__main__':
    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')

    if True:
        drop(conn, 'raw_predict_daily_sumhl')
        for n in [11,13]:
            getSumDataRf(n)
    if True:
        drop(conn, 'raw_predict_daily_dethl')
        for n in [11, 13]:
            getDetailRf(n)
    if True:
        drop(conn, 'raw_predict_daily_lstm')
        for n in [11,13,21,34,55]:
            getLSTMData(n)
            print("%s Done"%(n))
