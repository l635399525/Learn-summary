import glob

from keras.models import Model
from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor
from sklearn.preprocessing import RobustScaler, OneHotEncoder

from com.DbTool import getConn, query, insert
import xgboost as xgb

from hl_tool.Intraday2403LSTM import trainer_lstm, reshaper

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, train_test_split, GridSearchCV

def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['work_date'] = list(df_close['work_date'])
    st_data['code'] = [st] * len(st_data)
    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data['ny'] = df_close['ny_13'].shift(-1).values

    st_data['ny2'] = st_data.apply(lambda x:1 if x['ny'] > 0 else 0,axis=1).values
    #st_data = st_data.drop('tn',axis=1)
    #st_data = st_data.drop('tp',axis=1)
    st_data = st_data.dropna()
    return np.array(st_data)
import pandas as pd
def genDetailRfData(n):

    sql = 'select distinct code from raw_daily_hl_y_pn_merge order by random()'
    codes = list(query(sql,conn)['code'].values)
    train_codes = codes[:2399]
    sql = 'select code, work_date, ec_13, n_ec_13, ny_13, ndate, w, ag, ny13s, ws, ags from raw_daily_hl_y_pn_detail_merge'
    trains = []
    tests = []
    df = query(sql,conn)
    dfs = df.groupby('code')
    for code,idf in dfs:
        try:
            if len(idf) < n:
                continue
            idf = idf.sort_values(by=['work_date'])
            data = create_stock_data(idf,{'ag': list(range(0, n)),'ny_13': list(range(0, n)),'ags': list(range(0, n))},code)
            if code in train_codes:
                trains.append(data)
            else:
                tests.append(data)
            print("%s %s--- Done" %(len(trains),code))
        except:
            pass
    train_data = np.concatenate([x for x in trains])
    test_data = np.concatenate([x for x in tests])
    np.savez('raw_hl_detail_merge_%s.npz' %(n),train = train_data,test=test_data)
    #print('raw_hl_merge_%s.npz')

import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
def tester(model_name,test_data):
    #model = Model()
    from keras.models import Sequential, load_model
    #model = Sequential()
    #load_model(model_name)
    model = load_model(model_name)

    test_x, test_y = test_data[:, 2:-2], test_data[:, -1]
    test_x = reshaper(test_x)
    train_y = np.reshape(test_y, (-1, 1))
    #train_ret = np.reshape(train_ret, (-1, 1))
    enc = OneHotEncoder(handle_unknown='ignore')
    enc.fit(train_y)
    enc_y = enc.transform(train_y).toarray()
    test_x = test_x.astype('float64')
    #result = model.predict(test_x)
    try:
        nres = model.predict(test_x)
        res_1 = np.argmax(nres, axis=1)
        gap = np.round(np.abs(nres[:, 0] - nres[:, 1]), 3)
    except:
        res_1 = [None] * len(test_x)
        gap = [None] * len(test_x)

    return res_1, test_y, res_1, gap
    # print(result)
    #
    #
    # with open(model_name, 'rb') as f:
    #     clf2 = pickle.load(f)
    #     # 测试读取后的Model
    #     if 'y2#' in model_name:
    #         test_x, test_y = test_data[:, 2:-2], test_data[:, -1]
    #     else:
    #         test_x, test_y = test_data[:, 2:-2], test_data[:, -2]
    #     test_x = xgb.DMatrix(test_x)
    #     y_pred = clf2.predict(test_x)
    #     predictions = [round(value) for value in y_pred]
    #     #p_test = clf2.predict(test_x, ntree_limit=clf2.best_ntree_limit)
    #     from sklearn.metrics import accuracy_score
    #     accuracy = accuracy_score(list(test_y), predictions)
    #     print(accuracy)
    #     return np.asarray(predictions),test_y,np.asarray(predictions),y_pred
from numpy import loadtxt
from xgboost import XGBClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import StratifiedKFold
def scalar_normalize(train_data,test_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:,2:-2])
    train_data[:,2:-2] = scaler.transform(train_data[:,2:-2])
    test_data[:,2:-2] = scaler.transform(test_data[:,2:-2])
    return train_data,test_data
if __name__ == '__main__':
    Flag = True
    if not Flag:
        for n in [21,34,55,89]:
            genDetailRfData(n)
    if not Flag:
        for n in [21,34,55]:
            data = np.load('raw_hl_detail_merge_%s.npz' %(n),allow_pickle=True)
            train_x = data['train']
            test_x = data['test']
            print("--------start %s %s" %(len(train_x),len(test_x)))
            train_x,test_x = scalar_normalize(train_x,test_x)
            #trainer('hl_xgb_detail_lstm_%s' %(n),train_x,test_x,type='y2')
            trainer_lstm(train_x,test_x,n)
    if Flag:
        for n in [11,13,21,34,55]:
            data = np.load('raw_hl_detail_merge_%s.npz' % (n), allow_pickle=True)
            train = data['train']
            test = data['test']
            st_data = pd.DataFrame([])
            st_data['code'] = train[:, 1]
            st_data['work_date'] = train[:, 0]
            st_data['type'] = ['%s_%s' %('train_detail_lstm',n)]*len(train)
            model_f = glob.glob(r'D:\code_center\LSTM_TEST_RUN\hl_tool\final_model\data\%s#model-LSTM-2015-*.h5' %(n))[0]
            train,test = scalar_normalize(train,test)
            pv, av,pv1,gap = tester(model_f, train)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av
            insert(st_data, conn, 'test_merge_lstm_result', opType='append')
            print("-------------------------%s" %(n))
            st_data = pd.DataFrame([])
            st_data['code'] = test[:, 1]
            st_data['work_date'] = test[:, 0]
            st_data['type'] = ['%s_%s' % ('test_detail_lstm', n)] * len(test)
            pv, av,pv1,gap = tester(model_f, test)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av
            insert(st_data, conn, 'test_merge_lstm_result', opType='append')
            print("-------------------------%s" %(n))

