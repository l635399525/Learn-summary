def _getAngle(h,w):
    import numpy as np
    a = np.array([h, w])
    b = np.array([0, w])
    # 计算a的范数（长度）
    a_norm = np.linalg.norm(a)
    # 计算b的范数（长度）
    b_norm = np.linalg.norm(b)
    # 计算a和b的点积（相应位置相乘再把结果相加）
    a_dot_b = a.dot(b)
    # 使用余弦定理计算cos_there的弧度值
    cos_theta = np.arccos(a_dot_b / (a_norm * b_norm))
    # 将弧度转化为度
    angle = np.rad2deg(cos_theta)
    l = 1 if h > 0 else -1
    return round(angle*l,3)
#################################
#raw_hl_daily_datas             #
#raw_daily_hl_y_pn              #
#raw_daily_hl_y_pn_detail_merge #
#raw_daily_hl_y_pn_merge        #
#################################
#Hl_Merge_Tool_Sum_Fr.py        #
#Hl_Waves_Tool_Fr.py            #
#Hl_Waves_Tool_lstm.py          #
#Hl_Waves_Tool_xgb.py           #
#################################
