from keras.utils import np_utils

from com.DbTool import getConn,query,insert
import json
import numpy as np
import pandas as pd
from core.model import Model
from tool.DataLoader import DataLoaderTestDaily


def getTestData(df,conf_file,folder_type,yt):
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")

    configs = json.load(open(conf_file, 'r'))
    data = DataLoaderTestDaily(
        df,
        configs['data']['columns']
    )
    #col_lst = ['code','work_date','model_t','model_c','model_yt','ny','model_gf']
    #x_test, y_test,t_test,h_test = data.get_test_data_y2(seq_len=configs['data']['sequence_length'],normalise=configs['data']['normalise'],col_lst=col_lst)
    x_test, y_test,t_test,h_test,y2_test = data.get_train_npz_data(seq_len=configs['data']['sequence_length'],type=folder_type)
    clses = list(set(list(t_test[:,0])))
    if folder_type == 'min':
        col_lst=['code', 'work_date', 'dt', 'ny', 'type', 'times']
    else:
        col_lst = ['code', 'work_date', 'ny', 'type']
    for cls in clses:
        src_file = query("select src_file from raw_model_lst where cls = %s and type = '%s' and y_type = '%s'" %(int(cls),folder_type,yt),conn)['src_file'].values[0]
        idxes = np.argwhere(t_test[:,-1] == cls)[:, 0]
        h_values = h_test[idxes]
        x_te     = x_test[idxes]
        model = Model()
        model.load_model(src_file)
        result = model.model.predict(x_te)
        rdf = pd.DataFrame(data=h_values,columns=col_lst).copy()
        if yt == 'ycls2':
            p_values = np.argmax(result, axis=1)
            y_values = y2_test[idxes]
            rdf['av'] = y_values
        else:
            p_values = np.round(result[:,0],3)
            y_values = y_test[idxes]
            rdf['av'] = y_values[:, 0]
        rdf['pv'] = p_values
        rdf['m_type'] = folder_type
        rdf['m_yt'] = yt
        rdf.rename(columns={'type':'m_cls'},inplace=True)
        insert(rdf,conn_train,'test_%s' %(folder_type),opType='append')

def runDailyTest():
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    types_conf = {
        #'y': ['close','min','13'],
         'ycls2': [ 'close','min','13']
    }
    types_conf = {
        'ycls2': ['close'],
        #'y': ['close']
        #'ycls2': ['13', '17', '25', 'close']
    }

    out_path = r'D:\code_center\LSTM_TEST_RUN\conf_files'
    lstm_conf = {
        'y_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'y_13': out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'y_17': out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'y_25': out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'y_min': out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'
        , 'ycls2_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'ycls2_13': out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'ycls2_17': out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'ycls2_25': out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'ycls2_min': out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'

    }
    for yt, types in types_conf.items():
        for type in types:
            if type == 'close':
                src_table = 'raw_{t}_wave_N_5_clses_daily'.format(t=type)
                sql = '''
                    select a.*,a.n1y as ny, b.type as model_t, b.cls as model_c,  b.y_type as model_yt, b.conf_file as model_cf,
                   b.max_stepts as model_st, b.gold_file as model_gf, b.acc as model_acc, b.val_acc as model_val_acc from {src_table} a,raw_model_lst b
                where a.type = b.cls and b.type = '{type}' and b.y_type = '{yt}'
                order by code,work_date
                --and date(a.work_date) > date('2021-01-01')
                    '''.format(yt=yt, src_table=src_table, type=type)
            elif type == 'min':
                src_table = 'raw_close_min_wave_N_5_clses_data_daily'
                sql = '''
                    select a.*,a.nny as ny, b.type as model_t, b.cls as model_c,  b.y_type as model_yt, b.conf_file as model_cf,
                   b.max_stepts as model_st, b.gold_file as model_gf, b.acc as model_acc, b.val_acc as model_val_acc from {src_table} a,raw_model_lst b
                where a.type = b.cls and b.type = '{type}' and b.y_type = '{yt}' and date(a.work_date) > date('2021-01-01')
                and date(a.work_date) <= date('2022-02-01')
                order by code,work_date
                                --and date(a.work_date) > date('2021-01-01')
                    '''.format(yt=yt, src_table=src_table, type=type)
            else:
                src_table = 'raw_hl9close_wave{n}_daily'.format(n=type)
                sql = '''
                    select a.*, b.type as model_t, b.cls as model_c , b.y_type as model_yt, b.conf_file as model_cf,
                   b.max_stepts as model_st, b.gold_file as model_gf, b.acc as model_acc, b.val_acc as model_val_acc from {src_table} a,raw_model_lst b
                where a.type = b.cls and b.type = '{type}' and b.y_type = '{yt}'
                --and date(a.work_date) > date('2021-01-01')
                                order by code,work_date
                    '''.format(yt=yt, src_table=src_table, type=type)
                #print(sql)
            conf_file = lstm_conf['%s_%s' % (yt, type)]
            df = query(sql, conn)
            getTestData(df, conf_file, type,yt)
            print("%s %s %s" % (yt, type, len(df)))
if __name__ == '__main__':
    runDailyTest()
