__author__ = "Jakob Aungiers"
__copyright__ = "Jakob Aungiers 2018"
__version__ = "2.0.0"
__license__ = "MIT"

import os
import json
from core.model import Model
from keras.utils import np_utils
import numpy as np
from tool.DataLoader import DataLoaderTrainDaily


def main_close5_day_cls2(df,conf_file,folder_type):
    configs = json.load(open(conf_file, 'r'))
    if not os.path.exists(configs['model']['save_dir']): os.makedirs(configs['model']['save_dir'])
    data = DataLoaderTrainDaily(df,
        configs['data']['columns']
    )
    model = Model()
    model.build_model(configs,ycls_n=2)

    x_test, y_test,t_test,h_test = data.get_test_data(
        seq_len=configs['data']['sequence_length'],
        normalise=configs['data']['normalise']
    )
    x_train, y_train,t_train,h_train = data.get_train_data(
        seq_len=configs['data']['sequence_length'],
        normalise=configs['data']['normalise']
    )
    y_test = np_utils.to_categorical(y_test, 2)
    y_train = np_utils.to_categorical(y_train, 2)
    ns = [-4,-3,-2,-1,1,2,3,4]
    for n in ns:
        idxes_test  = np.argwhere(t_test  == n)[:,0]
        idxes_train = np.argwhere(t_train  == n)[:,0]
        x_te =  x_test[idxes_test]
        y_te =  y_test[idxes_test]
        x_tr = x_train[idxes_train]
        y_tr = y_train[idxes_train]
        print("-----------------%s %s %s" %(n,len(x_te),len(y_tr)))
        try:
            model.train(x_tr, y_tr, configs['training']['epochs'], configs['training']['batch_size'], save_dir=configs['model']['save_dir'],val_data=(x_te, y_te),cls="%s#%s" %(folder_type,n),ycls_n=2)
        except:
            pass

if __name__ == '__main__':
    print(1)