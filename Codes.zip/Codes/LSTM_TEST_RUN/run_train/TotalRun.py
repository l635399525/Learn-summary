from com.DbTool import query,getConn
from run_train.run_close5_angle_dataframe import main_close5_angle_day_clsy
from run_train.run_close5_angle_dataframe_ycls2 import main_close5_angle_day_cls2
from run_train.run_close5_dataframe import main_close5_day_clsy
from run_train.run_close5_dataframe_ycls2 import main_close5_day_cls2
from run_train.run_close_min1500_dataframe import main_close5_min1500_clsy
from run_train.run_close_min1500_dataframe_ycls2 import main_close5_min1500_cls2
from run_train.run_hlclose_angles_dataframe import main_hlclose_angle_day_clsy
from run_train.run_hlclose_angles_dataframe_ycls2 import main_hlclose_angle_day_cls2
from run_train.run_hlclose_dataframe import main_hlclose_day_clsy
from run_train.run_hlclose_dataframe_ycls2 import main_hlclose_day_cls2


def getWorkLst():
    types_conf = {
        #'close':['y','ycls2'],
        #'min': ['y','ycls2']
        #'13': ['y'],
        #'17': ['y', 'ycls2'],
        #'25': ['y', 'ycls2']
        #'hlangle': ['y','ycls2']
        'closeangle': ['y','ycls2']

    }
    out_path = r'D:\code_center\LSTM_TEST_RUN\conf_files'
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    lstm_conf = {
          'y_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'y_13'   : out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'y_17'   : out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'y_25'   : out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'y_min'  : out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'
        , 'y_hlangle': out_path + "\\" + 'raw_hl_all_y_5_full_n1.json'
        , 'y_closeangle': out_path + "\\" + 'raw_close_all_y_5_full_n1.json'

        , 'ycls2_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'ycls2_13'   : out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'ycls2_17'   : out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'ycls2_25'   : out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'ycls2_min'  : out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'
        , 'ycls2_hlangle': out_path + "\\" + 'raw_hl_all_y_5_full_n1.json'
        , 'ycls2_closeangle': out_path + "\\" + 'raw_close_all_y_5_full_n1.json'

    }
    for key,values in types_conf.items():
        type = key
        if key == 'close':
            src_table = 'train_{t}_wave_N_5_clses'.format(t=type)
            sql = '''
                select *,n1y as ny from {src_table} where date(work_date) < date('2022-01-01')
            '''.format(src_table=src_table)
        elif key == 'min':
            src_table = 'train_raw_close_{t}_wave_N_5_clses_data'.format(t=type)
            sql = '''
                select *,nny as ny from {src_table} where date(work_date) < date('2022-01-01')
            '''.format(src_table=src_table)
        elif key == 'hlangle':
            src_table = 'train_raw_close_{t}'.format(t=type)
            sql = '''
                select a.code,sdate,edate as work_date,case when cls_13 + cls_17 + cls_25 > 0 then 1 else 0 end as t_cls,
       sclose,eclose,h,cls_13 + cls_17 + cls_25 as type,w as x_w,pctchg as x_pct,angles as x_angle,cls_13 , cls_17 , cls_25
 ,volume as x_volume,n_angles as ny,n_h from raw_hl_angles a,raw_data_d b where a.code = b.code and a.edate = b.date
            '''.format(src_table=src_table)
            conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
        elif key == 'closeangle':
            src_table = 'raw_close_angle_train'
            src_table = 'raw_close_angle_test'
            sql = '''
              select code, date as work_date,clsv_55 as type,
                       edate_5, edate_13, edate_34, edate_55, close, volume,
                       clsv_5, clsv_8, clsv_13, clsv_21, clsv_34, clsv_55,
                       ag1_5, ag2_5, ag3_5, agt_5, agb_5,
                       ag1_8, ag2_8, ag3_8, agt_8, agb_8,
                       ag1_13,ag2_13, ag3_13, agt_13, agb_13,
                       ag1_21, ag2_21, ag3_21, agt_21, agb_21,
                       ag1_34, ag2_34, ag3_34, agt_34, agb_34,
                       ag1_55, ag2_55, ag3_55, agt_55, agb_55,
                       w1_5, w1_8, w1_13, w1_21, w1_34, w1_55,
                       w2_5, w2_8, w2_13, w2_21, w2_34, w2_55,
                       w3_5, w3_8, w3_13, w3_21, w3_34, w3_55,
                       days_55, days_34, pctchg, ec_55, ec_34, ny from {src_table}
                order by code,work_date
                   '''.format(src_table=src_table)
        else:
            src_table = 'train_hlclose_wave{n}_full'.format(n=type)
            sql = '''
                select * from {src_table} where date(work_date) < date('2022-01-01')
            '''.format(src_table=src_table)
        for yt in values:
            conf_file = lstm_conf['%s_%s' % (yt, key)]
            try:
                df = query(sql, conn)
            except:
                df = None
            if yt == 'ycls2' and type == 'close':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_day_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type == 'close':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_day_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type == 'min':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_min1500_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'ycls2' and type == 'min':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_min1500_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'ycls2' and type in ['13','17','25']:
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_hlclose_day_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type in ['13','17','25']:
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_hlclose_day_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type == 'hlangle':
                try:
                    print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                except:
                    pass
                main_hlclose_angle_day_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'ycls2' and type == 'hlangle':
                try:
                    print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                except:
                    pass
                main_hlclose_angle_day_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type == 'closeangle':
                try:
                    print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                except:
                    pass
                main_close5_angle_day_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'ycls2' and type == 'closeangle':
                try:
                    print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                except:
                    pass
                main_close5_angle_day_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
if __name__ == '__main__':
    getWorkLst()