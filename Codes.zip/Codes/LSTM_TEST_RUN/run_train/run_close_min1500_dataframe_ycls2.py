__author__ = "Jakob Aungiers"
__copyright__ = "Jakob Aungiers 2018"
__version__ = "2.0.0"
__license__ = "MIT"

from core.model import Model
from keras.utils import np_utils
import numpy as np
from tool.DataLoader import DataLoaderTrainDaily
import numpy as np
import json
import os
def main_close5_min1500_cls2(df,conf_file,folder_type):
    configs = json.load(open(conf_file, 'r'))
    if not os.path.exists(configs['model']['save_dir']): os.makedirs(configs['model']['save_dir'])
    data = DataLoaderTrainDaily(df,
        configs['data']['columns']
    )
    model = Model()
    model.build_model(configs,ycls_n=2)
    type, _ = str(folder_type).split("_")
    x_test, y_test, t_test, h_test, y_test2 = data.get_test_npz_data(
        seq_len=configs['data']['sequence_length'], type=type
    )
    x_train, y_train, t_train, h_train, y_train2 = data.get_train_npz_data(
        seq_len=configs['data']['sequence_length'], type=type
    )
    y_test = y_test2
    t_test = t_test[:,0]
    y_train = y_train2
    t_train = t_train[:,0]
    if 'ycls2' in folder_type:
        y_test = np_utils.to_categorical(y_test, 2)
        y_train = np_utils.to_categorical(y_train, 2)
    ns = [-4,-3,-2,-1,1,2,3,4]
    #ns = [3,4]

    time_str = '15:00'
    time_test  = h_test[:,-1]
    time_train = h_train[:,-1]
    for n in ns:
        idxes_test_a = np.argwhere(t_test == n)[:, 0]
        idxes_train_a = np.argwhere(t_train == n)[:, 0]
        idxes_test_b = np.argwhere(time_test[idxes_test_a] == time_str)[:, 0]
        idxes_train_b = np.argwhere(time_train[idxes_train_a] == time_str)[:, 0]
        idxes_test = idxes_test_a[idxes_test_b]
        idxes_train = idxes_train_a[idxes_train_b]
        x_te = x_test[idxes_test]
        y_te = y_test[idxes_test]
        x_tr = x_train[idxes_train]
        y_tr = y_train[idxes_train]
        print("-------------------------%s %s %s" % (n, len(x_te), len(y_tr)))
        try:
            model.train(x_tr, y_tr, 299, configs['training']['batch_size'], save_dir=configs['model']['save_dir'],val_data=(x_te, y_te),cls="%s#%s" %(folder_type,n),ycls_n=2)
        except:
            pass

if __name__ == '__main__':
    print(1)