__author__ = "Jakob Aungiers"
__copyright__ = "Jakob Aungiers 2018"
__version__ = "2.0.0"
__license__ = "MIT"

import os
import json
from core.model import Model
from keras.utils import np_utils
import numpy as np
from tool.DataLoader import DataLoaderTrainDaily


def main_hlclose_angle_day_cls2(df,conf_file,folder_type):
    configs = json.load(open(conf_file, 'r'))
    if not os.path.exists(configs['model']['save_dir']): os.makedirs(configs['model']['save_dir'])
    data = DataLoaderTrainDaily(df,
        configs['data']['columns']
    )
    model = Model()
    model.build_model(configs,ycls_n=2)

    type, _ = str(folder_type).split("_")
    data_train = np.load(r'D:\data\data_file\hl_all_y_5_train.npz', allow_pickle=True)
    x_train, y_train, t_train, h_train, y_train2 = data_train['x_train'], data_train['y_train'], data_train['t_train'], \
                                                   data_train['h_train'], data_train['y_train2']
    data_test = np.load(r'D:\data\data_file\hl_all_y_5_tests.npz', allow_pickle=True)
    x_test, y_test, t_test, h_test, y_test2 = data_test['x_train'], data_test['y_train'], data_test['t_train'], \
                                              data_test['h_train'], data_test['y_train2']


    y_test = y_test2
    t_test = t_test[:, 0]
    y_train = y_train2
    t_train = t_train[:, 0]

    y_test = np_utils.to_categorical(y_test, 2)
    y_train = np_utils.to_categorical(y_train, 2)
    # ns = [-9,-8,-7,-6,-5,-4,-3,-2,-1,1,2,3,4,5,6,7,8,9]
    # for n in ns:
    #     idxes_test  = np.argwhere(t_test  == n)[:,0]
    #     idxes_train = np.argwhere(t_train  == n)[:,0]
    #     x_te =  x_test[idxes_test]
    #     y_te =  y_test[idxes_test]
    #     x_tr = x_train[idxes_train]
    #     y_tr = y_train[idxes_train]
    #     print("-----------------%s %s %s" %(n,len(x_te),len(y_tr)))
    try:
        model.train(x_train, y_train, 499, configs['training']['batch_size'], save_dir=configs['model']['save_dir'],val_data=(x_test, y_test),cls="%s#%s" %(folder_type,'all'),ycls_n=2)
    except:
        pass

if __name__ == '__main__':
    print(1)