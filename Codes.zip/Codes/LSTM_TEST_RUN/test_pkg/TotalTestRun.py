from com.DbTool import query,getConn
from test_pkg.run_close5_dataframe_test import main_close5_day_clsy
from test_pkg.run_close5_dataframe_ycls2_test import main_close5_day_cls2
from test_pkg.run_close_min1500_dataframe_test import main_close5_min1500_clsy
from test_pkg.run_close_min1500_dataframe_ycls2_test import main_close5_min1500_cls2
from test_pkg.run_hlclose_dataframe_test import main_hlclose_day_clsy
from test_pkg.run_hlclose_dataframe_ycls2_test import main_hlclose_day_cls2


def getWorkLst():
    types_conf = {
         'close':['y']
        #,'min':  ['y','ycls2']
        #,'13':   ['y','ycls2']
        #,'17':   ['y','ycls2']
        #,'25':   ['y','ycls2']
    }
    out_path = r'D:\code_center\LSTM_TEST_RUN\conf_files'
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    lstm_conf = {
          'y_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'y_13'   : out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'y_17'   : out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'y_25'   : out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'y_min'  : out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'
        , 'ycls2_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'ycls2_13'   : out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'ycls2_17'   : out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'ycls2_25'   : out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'ycls2_min'  : out_path + "\\" + 'raw_close_min_summary_cls5_1500_n1.json'

    }
    for key,values in types_conf.items():
        type = key
        if key == 'close':
            src_table = 'raw_{t}_wave_N_5f_clses_daily'.format(t=type)
            sql = '''
                select *,n1y as ny from {src_table}
            '''.format(src_table=src_table)
            #src_table = 'train_{t}_wave_N_5_clses'.format(t=type)
            #sql = '''
            #    select *,n1y as ny from {src_table} where date(work_date) < date('2022-01-01')
            #'''.format(src_table=src_table)
        elif key == 'min':
            src_table = 'raw_close_min_wave_N_5_clses_data_daily'
            sql = '''
                select *,nny as ny from {src_table} 
            '''.format(src_table=src_table)
        else:
            src_table = 'raw_hl9close_wave{n}_daily'.format(n=type)
            sql = '''
                select * from {src_table} 
            '''.format(src_table=src_table)
        for yt in values:
            conf_file = lstm_conf['%s_%s' % (yt, key)]
            df = query(sql, conn)
            if yt == 'ycls2' and type == 'close':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_day_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type == 'close':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_day_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type == 'min':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_min1500_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'ycls2' and type == 'min':
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_close5_min1500_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'ycls2' and type in ['13','17','25']:
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_hlclose_day_cls2(df, conf_file, type+"_"+yt)
                print('###################################################')
            elif yt == 'y' and type in ['13','17','25']:
                print("%s %s#####################Train %s#################" %(yt,type,len(df)))
                main_hlclose_day_clsy(df, conf_file, type+"_"+yt)
                print('###################################################')
if __name__ == '__main__':
    getWorkLst()