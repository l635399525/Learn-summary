__author__ = "Jakob Aungiers"
__copyright__ = "Jakob Aungiers 2018"
__version__ = "2.0.0"
__license__ = "MIT"

import os
import json

from com.DbTool import getConn, query, insert
from core.model import Model
from keras.utils import np_utils
import numpy as np
from tool.DataLoader import DataLoaderTrainDaily
import pandas as pd

def main_hlclose_day_cls2(df,conf_file,folder_type):
    configs = json.load(open(conf_file, 'r'))
    if not os.path.exists(configs['model']['save_dir']): os.makedirs(configs['model']['save_dir'])
    data = DataLoaderTrainDaily(df,
        configs['data']['columns']
    )
    file_name = "%s_%s_full" % (folder_type, configs['data']['sequence_length'])
    x_train, y_train, t_train, h_train, y2_train = data.get_daily_test_data(
        seq_len=configs['data']['sequence_length'],
        normalise=configs['data']['normalise']
        , file_name=file_name
    )
    data = np.load('%s_y_21_full.npz' %(folder_type.split("_")[0]), allow_pickle=True)
    x_train, y_train, t_train, h_train, y2_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'], data['y_train2']
    col_lst = ['code', 'work_date', 'ny', 'type']
    y_train = y2_train
    y_train = np_utils.to_categorical(y_train, 2)
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    ns = [-9,-8,-7,-6,-5,-4,-3,-2,-1,1,2,3,4,5,6,7,8,9]
    for n in ns:
        model = Model()
        src_file = query("select gold_file from raw_model_lst where cls = %s and type = '%s' and y_type = '%s'" % (int(n), folder_type.split("_")[0], 'ycls2'), conn)['gold_file'].values[0]
        model.load_model(src_file)
        idxes_train = np.argwhere(t_train == n)[:, 0]
        x_tr = x_train[idxes_train]
        y_tr = y_train[idxes_train]
        h_tr = h_train[idxes_train]
        rdf = pd.DataFrame(data=h_tr, columns=col_lst)
        print("-----------------%s %s %s" % (n, len(x_tr), len(y_tr)))
        try:
            predicted = model.predict_point_by_point(x_tr)
            pv = np.argmax(predicted, axis=1)
            av = np.argmax(y_tr == 1, axis=1)
            a_rate = np.count_nonzero(pv - av == 0)
            f_rate = np.count_nonzero(pv - av != 0)
            rdf['pv'] = pv
            rdf['av'] = av
            rdf['m_type'] = folder_type.split("_")[0]
            rdf['m_yt'] = 'ycls2'
            rdf['m_cls'] = n
            print("%s %s %s %s" % (src_file, a_rate, f_rate + a_rate, a_rate * 1.0 / (f_rate + a_rate)))
            insert(rdf, conn_train, 'test_%s' % ('hl'), opType='append')
            # model.train(x_tr, y_tr, configs['training']['epochs'], configs['training']['batch_size'], save_dir=configs['model']['save_dir'],val_data=(x_te, y_te),cls="%s#%s" %(folder_type,n),ycls_n=2)
        except:
            pass

if __name__ == '__main__':
    print(1)