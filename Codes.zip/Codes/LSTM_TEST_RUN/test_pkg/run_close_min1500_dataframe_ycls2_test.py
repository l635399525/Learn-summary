__author__ = "Jakob Aungiers"
__copyright__ = "Jakob Aungiers 2018"
__version__ = "2.0.0"
__license__ = "MIT"

from com.DbTool import getConn, query, insert
from core.model import Model
from keras.utils import np_utils
from tool.DataLoader import DataLoaderTrainDaily
import numpy as np
import json
import os
import pandas as pd
def main_close5_min1500_cls2(df,conf_file,folder_type):
    configs = json.load(open(conf_file, 'r'))
    if not os.path.exists(configs['model']['save_dir']): os.makedirs(configs['model']['save_dir'])
    data = DataLoaderTrainDaily(df,
        configs['data']['columns']
    )
    model = Model()
    model.build_model(configs,ycls_n=2)
    type, _ = str(folder_type).split("_")
    file_name = "%s_%s_full" % (folder_type, configs['data']['sequence_length'])
    col_lst = ['code', 'work_date', 'dt', 'ny', 'type', 'times']
    # x_train, y_train, t_train, h_train, y2_train = data.get_daily_test_data(
    #     seq_len=configs['data']['sequence_length'],
    #     normalise=configs['data']['normalise']
    #     ,col_lst=col_lst
    #     , column = ['work_date', 'dt']
    #     , file_name=file_name
    # )

    data = np.load('min_y_21_full.npz', allow_pickle=True)
    x_train, y_train, t_train, h_train, y2_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'],data['y_train2']

    y_train = y2_train
    y_train = np_utils.to_categorical(y_train, 2)
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    time_str = '15:00'
    time_train = h_train[:,-1]
    ns = [-4,-3,-2,-1,1,2,3,4]
    for n in ns:
        # idxes_train = np.argwhere(t_train == n)[:, 0]
        # idxes_train = np.argwhere(time_train[idxes_train] == time_str)[:, 0]
        idxes_train_a = np.argwhere(t_train == n)[:, 0]
        idxes_train_b = np.argwhere(time_train[idxes_train_a] == time_str)[:, 0]
        idxes_train = idxes_train_a[idxes_train_b]
        model = Model()
        src_file = query("select gold_file from raw_model_lst where cls = %s and type = '%s' and y_type = '%s'" % (int(n), folder_type.split("_")[0], 'ycls2'), conn)['gold_file'].values[0]
        model.load_model(src_file)
        x_tr = x_train[idxes_train]
        y_tr = y_train[idxes_train]
        h_tr = h_train[idxes_train]
        rdf = pd.DataFrame(data=h_tr, columns=col_lst)
        print("-----------------%s %s %s" % (n, len(x_tr), len(y_tr)))
        try:
            predicted = model.predict_point_by_point(x_tr)
            pv = np.argmax(predicted, axis=1)
            av = np.argmax(y_tr == 1, axis=1)
            a_rate = np.count_nonzero(pv - av == 0)
            f_rate = np.count_nonzero(pv - av != 0)
            rdf['pv'] = pv
            rdf['av'] = av
            rdf['m_type'] = folder_type.split("_")[0]
            rdf['m_yt'] = 'ycls2'
            rdf['m_cls'] = n
            print("%s %s %s %s" % (src_file, a_rate, f_rate + a_rate, a_rate * 1.0 / (f_rate + a_rate)))
            insert(rdf, conn_train, 'test_%s' % ('min'), opType='append')
            # model.train(x_tr, y_tr, configs['training']['epochs'], configs['training']['batch_size'], save_dir=configs['model']['save_dir'],val_data=(x_te, y_te),cls="%s#%s" %(folder_type,n),ycls_n=2)
        except:
            pass

if __name__ == '__main__':
    print(1)