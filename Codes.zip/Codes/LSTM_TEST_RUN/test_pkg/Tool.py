from com.DbTool import query, getConn,insert


def move():
    sql = '''
    select  code, code_name, date, open, close, high, low, pctchg, nt, idx_5, idx_5_v, idx_4, idx_4_v, idx_3, idx_3_v, idx_2, idx_2_v, idx_1, idx_1_v, sdate, spclose, edate, work_date, type, pwdate, cls, cls_v, max_idx, min_dix, s_v, e_v, hcr, lcr, hor, lor, ocr, n1y, score_0, tscores from raw_close_wave_N_5_clses_daily
    '''
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")

    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    df = query(sql,conn)
    insert(df,conn_train,'raw_close_wave_N_5_clses_daily')
def move1():
    sql = '''
    select distinct code,edate as work_date,
       cls_v as type,
        pctchg,
        max_idx,
        min_dix,
        s_v,
        e_v,
        hcr,
        lcr,
        hor,
        lor,
        ocr,
        n1y
from raw_close_wave_N_5_clses_daily
where code || edate not in(
    select distinct code||work_date from train_close_wave_N_5_clses
    )
union
select code, work_date, type, pctchg, max_idx, min_dix, s_v, e_v, hcr, lcr, hor, lor, ocr, n1y from train_close_wave_N_5_clses
    '''
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    df = query(sql, conn_train)
    insert(df, conn, 'raw_close_wave_N_5f_clses_daily')
if __name__ == '__main__':
    move1()