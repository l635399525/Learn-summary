__author__ = "Jakob Aungiers"
__copyright__ = "Jakob Aungiers 2018"
__version__ = "2.0.0"
__license__ = "MIT"

from com.DbTool import query, getConn,insert
from core.model import Model
from keras.utils import np_utils
import numpy as np
from tool.DataLoader import DataLoaderTrainDaily
import numpy as np
import json
import os
import pandas as pd
def main_close5_day_clsy(df,conf_file,folder_type):
    configs = json.load(open(conf_file, 'r'))
    if not os.path.exists(configs['model']['save_dir']): os.makedirs(configs['model']['save_dir'])
    data = DataLoaderTrainDaily(df,
        configs['data']['columns']
    )
    file_name = "%s_%s_full" %(folder_type,configs['data']['sequence_length'])
    # x_train, y_train,t_train,h_train, y2_train = data.get_daily_test_data(
    #     seq_len=configs['data']['sequence_length'],
    #     normalise=configs['data']['normalise']
    #     ,file_name=file_name
    # )
    data = np.load('close_y_21_full.npz',allow_pickle=True)
    x_train, y_train, t_train, h_train, y2_train = data['x_train'], data['y_train'], data['t_train'], data['h_train'],data['y_train2']
    col_lst = ['code', 'work_date', 'ny', 'type']
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    conn_train = getConn(r"D:\data\RAW_FINAL_FORMAT_TRAIN")
    ns = [-4,-3,-2,-1,1,2,3,4]
    ns = [4]
    for n in ns:
        model = Model()
        src_file = query("select gold_file from raw_model_lst where cls = %s and type = '%s' and y_type = '%s'" % (int(n), folder_type.split("_")[0], 'y'), conn)['gold_file'].values[0]
        model.load_model(src_file)
        idxes_train = np.argwhere(t_train == n)[:, 0]
        x_tr = x_train[idxes_train]
        y_tr = y_train[idxes_train]
        h_tr = h_train[idxes_train]
        rdf = pd.DataFrame(data=h_tr, columns=col_lst)
        print("-----------------%s %s %s" % (n, len(x_tr), len(y_tr)))
        try:
            predicted = model.predict_point_by_point(x_tr)
            #pv = np.argmax(predicted, axis=1)
            pv = predicted[:,0]
            av = y_tr[:,0]
            a_rate = np.count_nonzero(pv * av > 0)
            f_rate = np.count_nonzero(pv * av <= 0)
            rdf['pv'] = pv
            rdf['av'] = av
            rdf['m_type'] = 'close'
            rdf['m_yt'] = 'y'
            rdf['m_cls'] = n
            print("%s %s %s %s" % (src_file, a_rate, f_rate + a_rate, a_rate * 1.0 / (f_rate + a_rate)))
            insert(rdf, conn_train, 'test_%s' % ('close'), opType='append')
        except:
            import traceback
            traceback.print_exc()
            pass
if __name__ == '__main__':
    print(1)