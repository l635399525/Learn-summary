import glob

import numpy as np
import shutil

def parseLog():
    with open('log_xgb', 'r') as wr:
        lines = wr.readlines()
        clses = []
        for line in lines:
            line = line.replace("\n", "")
            model = line.split(" ")[0]
            cls = model.split("_")[-1]
            clses.append(cls)
        clses = list(set(clses))
        cls_map = {}
        for cls in clses:
            cls_map[cls] = []
        for line in lines:
            line = line.replace("\n", "")
            model = line.split(" ")[0]
            score = line.split(" ")[1]

            cls = model.split("_")[-1]
            clses = cls_map[cls]
            clses.append([score, model])
        for key, val in cls_map.items():
            val = np.asarray((val))
            line = val[np.argmax(val[:, 0])]
            dest_file = "%s#%s" % (line[0], line[1])
            shutil.copy(line[1], r'D:\data\models\xgb\%s' % (dest_file))
            print(val[:, 0])
        print(cls_map)
def parseCsv():
    from com.DbTool import getConn, query, insert

    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
    import pandas as pd
    csvs = glob.glob(r'D:\data\models\lstm\*\*.csv')
    rlines = []
    for csv in csvs:
        sub_folder = "\\".join(csv.split("\\")[:-1])
        folder = csv.split("\\")[-2]
        n = folder.split("_")[0]
        key = folder.split("_")[-1]
        df = pd.read_csv(csv)
        #file = r'hl_lstm_%s#model-LSTM-2015-E01.h5' %(folder)
        for i in range(len(df)):
            rline = dict(df.iloc[i])
            epoch = rline['epoch']
            if epoch >9:
                file = r'%s\hl_lstm_%s#model-LSTM-2015-E%s.h5' %(sub_folder,folder,int(epoch+1))
                rline['file']   = file
                rline['key']    = key
                rline['n']      = n
                rline['folder'] = folder
                rlines.append(rline)
    df = pd.DataFrame(rlines)
    insert(df,conn,'raw_tmp_lstm_data')
def parseCsv2():
    from com.DbTool import getConn, query, insert

    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
    import pandas as pd
    csvs = glob.glob(r'D:\data\models\cnn\*\*.csv')
    rlines = []
    for csv in csvs:
        sub_folder = "\\".join(csv.split("\\")[:-1])
        folder = csv.split("\\")[-2]
        n = folder.split("_")[0]
        key = folder.split("_")[-1]
        df = pd.read_csv(csv)
        #file = r'hl_lstm_%s#model-LSTM-2015-E01.h5' %(folder)
        for i in range(len(df)):
            rline = dict(df.iloc[i])
            epoch = rline['epoch']
            if epoch >9:
                file = r'%s\hl_cnn_%s#model-CNN-2022-E%s.h5' %(sub_folder,folder,int(epoch+1))
                rline['file']   = file
                rline['key']    = key
                rline['n']      = n
                rline['folder'] = folder
                rlines.append(rline)
    df = pd.DataFrame(rlines)
    insert(df,conn,'raw_tmp_cnn_data')

def parseXgbFr():
    from com.DbTool import getConn, query, insert

    conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
    import pandas as pd
    frs = glob.glob(r'D:\data\models\fr\*')
    xgbs = glob.glob(r'D:\data\models\xgb\*')
    rlines = []
    for fr in frs:
        fn = fr.split("\\")[-1]
        score = fn.split("#")[0]
        rline = {}
        rline['file']   = fr
        rline['score']    = score
        key = fn.split("_")[-1]
        n = fn.split("_")[-2]
        rline['key'] = key
        rline['type'] = 'fr'
        rline['n'] = n
        rlines.append(rline)
    for fr in xgbs:
        fn = fr.split("\\")[-1]
        score = fn.split("#")[0]
        rline = {}
        rline['file'] = fr
        rline['score'] = score
        key = fn.split("_")[-1]
        n   = fn.split("_")[-2]
        rline['key'] = key
        rline['type'] = 'xgb'
        rline['n'] = n
        rlines.append(rline)
    df = pd.DataFrame(rlines)
    insert(df,conn,'raw_tmp_xgb_fr_data')

if __name__ == '__main__':
    #parseCsv()
    parseCsv2()
    #parseXgbFr()