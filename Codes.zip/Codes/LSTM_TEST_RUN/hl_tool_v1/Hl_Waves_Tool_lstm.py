import glob

from keras.models import Model
from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor
from sklearn.preprocessing import RobustScaler, OneHotEncoder

from com.DbTool import getConn, query, insert
import xgboost as xgb

from hl_tool.Intraday2403LSTM import trainer_lstm, reshaper, build_model, callbacks_req

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, train_test_split, GridSearchCV

import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
from numpy import loadtxt
from xgboost import XGBClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import StratifiedKFold


def trainer_lstm(model_name,train_data,test_data):
    np.random.shuffle(train_data)

    test_x, test_y = test_data[:, 4:-1], test_data[:, -1]
    x_train, y_train = train_data[:, 4:-1], train_data[:, -1]
    train_x = reshaper(x_train)
    train_y = np.reshape(y_train,(-1, 1))
    enc = OneHotEncoder(handle_unknown='ignore')
    enc.fit(train_y)
    enc_y = enc.transform(train_y).toarray()
    #train_ret = np.hstack((np.zeros((len(train_data),1)),train_ret))

    test_x =   reshaper(test_x)
    test_y = np.reshape(test_y, (-1, 1))
    #train_ret = np.reshape(train_ret, (-1, 1))
    test_enc = OneHotEncoder(handle_unknown='ignore')
    test_enc.fit(test_y)
    test_enc_y = test_enc.transform(test_y).toarray()
    #model = makeLSTM(240)
    model = build_model(n,6)
    callbacks = callbacks_req(model_name)
    train_x = train_x.astype('float64')
    test_x = test_x.astype('float64')

    model.fit(train_x,
              enc_y,
              epochs=1500,
              #validation_split=0.2,
              #validation_data=(test_x,test_enc_y),
              validation_data=(test_x,test_enc_y),

              callbacks=callbacks,
              #batch_size=23
              batch_size = 64

    )

    # dates = list(set(test_data[:,0]))
    # predictions = {}
    # for day in dates:
    #     test_d = test_data[test_data[:,0]==day]
    #     test_d = reshaper(test_d[:,2:-2])
    #     predictions[day] = model.predict(test_d)[:,1]
    # return model,predictions

def scalar_normalize(train_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:, 4:-1])
    train_data[:, 4:-1] = scaler.transform(train_data[:, 4:-1])
    #test_data[:, 2:-2] = scaler.transform(test_data[:, 2:-2])
    return train_data
if __name__ == '__main__':
    Flag = False
    sql = '''
            select key from
        (select key,count(*) as cnt from raw_kmeans_kpi_sum group by key) where cnt > 200
            '''
    keys = list(query(sql, conn)['key'].values)
    efiles = glob.glob(r'D:\data\models\lstm\*')
    e_keys = list(map(lambda x:x.split("\\")[-1],efiles))
    if not Flag:
        # for n in [2,3,5]:
        #     trainer(n)
        with open('log_lstm', 'w') as wr:
            for n in [3, 5,6,7]:
                data = np.load('raw_hl_merge_%s.npz' % (n), allow_pickle=True)
                h_train_x = data['train']
                h_train_x = scalar_normalize(h_train_x)
                h_test_x = data['test']
                h_test_x = scalar_normalize(h_test_x)
                # train_x = scalar_normalize(train_x)
                # train_x = data['train']
                for key in keys:
                    # if key == '0-0':
                    #     continue
                    # if '%s_%s' %(n, key) in e_keys:
                    #     continue
                    try:
                        train_idx = np.argwhere((h_train_x[:, 3] == key))[:, 0]
                        train_x = h_train_x[train_idx]
                        test_idx = np.argwhere((h_test_x[:, 3] == key))[:, 0]
                        test_x = h_test_x[test_idx]
                        print("--------start %s %s" % (len(train_x), len(test_x)))
                        log = trainer_lstm('hl_lstm_%s_%s' % (n, key), train_x, test_x)
                        #wr.write('hl_lstm_%s_%s' % (n, key) + " " + log + "\n")
                        #wr.flush()
                    except:
                        import traceback
                        traceback.print_exc()
                        # import tra
                        pass

