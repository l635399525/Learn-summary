import numpy as np
import keras
from keras.callbacks import ModelCheckpoint
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
#from keras.optimizers import SGD
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import SGD
from com.DbTool import query, getConn, insert, delete
from gegu.analysis import RAW_DATE_CONN,RAW_YLZC_CONN,RAW_HYGN_CONN,RAW_ALLPN_CONN
import pandas as pd
from keras.utils import np_utils

def getTrainData_V2(type):
    num_classes = 18
    cols_a = [
        'cls_0_9_v', 'cls_1_8_v', 'cls_2_7_v', 'cls_3_6_v', 'cls_4_5_v',
        'cls_5_4_v', 'cls_6_3_v', 'cls_7_2_v', 'cls_8_1_v', 'cls_9_0_v'
    ]
    cols_b = [
         'cn_cnts_0_9', 'cn_cnts_1_8', 'cn_cnts_2_7', 'cn_cnts_3_6', 'cn_cnts_4_5'
        ,'cn_cnts_5_4', 'cn_cnts_6_3', 'cn_cnts_7_2', 'cn_cnts_8_1', 'cn_cnts_9_0'
    ]
    cols_c = [
         'cn_pcts_0_9', 'cn_pcts_1_8', 'cn_pcts_2_7', 'cn_pcts_3_6', 'cn_pcts_4_5'
        , 'cn_pcts_5_4', 'cn_pcts_6_3', 'cn_pcts_7_2', 'cn_pcts_8_1', 'cn_pcts_9_0'
    ]
    cols_d = [
       'pw_cnts_0_9', 'pw_cnts_1_8', 'pw_cnts_2_7', 'pw_cnts_3_6', 'pw_cnts_4_5'
     , 'pw_cnts_5_4', 'pw_cnts_6_3', 'pw_cnts_7_2', 'pw_cnts_8_1', 'pw_cnts_9_0'
    ]
    cols_e = [
        'pw_pcts_0_9', 'pw_pcts_1_8', 'pw_pcts_2_7', 'pw_pcts_3_6', 'pw_pcts_4_5'
      , 'pw_pcts_5_4', 'pw_pcts_6_3', 'pw_pcts_7_2', 'pw_pcts_8_1', 'pw_pcts_9_0'
    ]
    def _getTrainX(df):
        x_train_a = df[cols_a].values
        x_train_b = df[cols_b].values
        x_train_c = df[cols_c].values
        x_train_d = df[cols_d].values
        x_train_e = df[cols_e].values
        x_train = np.zeros((len(df),1,10,5))
        for i in range(len(df)):
            for j in range(10):
                x_train[i][0][j][0] = x_train_a[i][j]
                x_train[i][0][j][1] = x_train_b[i][j]
                x_train[i][0][j][2] = x_train_c[i][j]
                x_train[i][0][j][3] = x_train_d[i][j]
                x_train[i][0][j][4] = x_train_e[i][j]
        return x_train

    sql = 'select distinct code from raw_peak_points_cls_ma10_{type}_v3'.format(type=type)
    df = query(sql,RAW_YLZC_CONN)
    codes = df['code'].values

    rt = 0.1 if type == 'gegu' else 0.15
    rt_num = 333 if type == 'gegu' else 111
    train_codes, val_codes, _, _ = train_test_split(codes, codes, test_size=rt, random_state=rt_num)

    sql = '''
    select code, last_date, y, y_cls,y_cls_v,
       cls_0_9_v,cls_1_8_v,cls_2_7_v,cls_3_6_v,cls_4_5_v,
       cls_5_4_v,cls_6_3_v,cls_7_2_v,cls_8_1_v,cls_9_0_v,
       cn_cnts_0_9, cn_cnts_1_8, cn_cnts_2_7, cn_cnts_3_6, cn_cnts_4_5,
       cn_cnts_5_4, cn_cnts_6_3, cn_cnts_7_2, cn_cnts_8_1, cn_cnts_9_0,
       cn_pcts_0_9, cn_pcts_1_8, cn_pcts_2_7, cn_pcts_3_6, cn_pcts_4_5,
       cn_pcts_5_4, cn_pcts_6_3, cn_pcts_7_2, cn_pcts_8_1, cn_pcts_9_0,
       pw_cnts_0_9, pw_cnts_1_8, pw_cnts_2_7, pw_cnts_3_6, pw_cnts_4_5,
       pw_cnts_5_4, pw_cnts_6_3, pw_cnts_7_2, pw_cnts_8_1, pw_cnts_9_0,
       pw_pcts_0_9, pw_pcts_1_8, pw_pcts_2_7, pw_pcts_3_6, pw_pcts_4_5,
       pw_pcts_5_4, pw_pcts_6_3, pw_pcts_7_2, pw_pcts_8_1, pw_pcts_9_0
        from raw_peak_points_cls_ma10_{type}_v3
    '''.format(type = type)
    df = query(sql,RAW_YLZC_CONN)
    df = df[df.code.isin(train_codes)]

    df_train, df_test, _, _ = train_test_split(df, df, test_size=0.1, random_state=rt_num)

    df_train['type'] = 'train'
    df_test['type'] = 'test'
    tmp_df = pd.concat([df_train,df_test])
    insert(tmp_df,RAW_YLZC_CONN,'raw_cnn_train_codes_lst_v2_{type}'.format(type=type))
    y_label = list(df_train['y_cls_v'].values)
    #label_map = dict(list(zip(sorted(list(set(list(y_label)))),range(18))))
    y_test_t = list(df_test['y_cls_v'].values)
    y_train_t = list(y_label)

    y_test = np.asarray(list(map(lambda x:1 if x > 0 else 0,y_test_t)))
    y_train = np.asarray(list(map(lambda x:1 if x > 0 else 0,y_train_t)))
    #y_test = np.asarray(list(map(lambda x:label_map[x],y_test_t)))
    #y_train = np.asarray(list(map(lambda x:label_map[x],y_train_t)))
    num_classes = 2
    y_train = np_utils.to_categorical(y_train, num_classes)
    y_test = np_utils.to_categorical(y_test, num_classes)
    x_train = _getTrainX(df_train)
    x_test  = _getTrainX(df_test)
    train(type,x_train,y_train,x_test,y_test)
def train(type,x_train,y_train,x_test,y_test):

    print("#############start train###########")

    model = Sequential()
    # 输入: 3 通道 100x100 像素图像 -> (100, 100, 3) 张量。
    # 使用 32 个大小为 3x3 的卷积滤波器。
    model.add(Conv2D(32, (1, 3), activation='relu', input_shape=(1, 10, 5)))
    model.add(Conv2D(32, (1, 3), activation='relu'))
    #model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Conv2D(64, (1, 3), activation='relu'))
    model.add(Conv2D(64, (1, 3), activation='relu'))
    #model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Flatten())
    model.add(Dense(256, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(2, activation='softmax'))
    #model.load_weights('cnn_v1-18cls-improvement-44-0.5055.hdf5')

    sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
    #model.compile(loss='categorical_crossentropy', optimizer=sgd)
    model.compile(loss='binary_crossentropy', optimizer=sgd,metrics=['accuracy'])
    file_path = type +"#" + "cnn_v2-02cls-improvement-{epoch:02d}-{accuracy:.4f}.hdf5"
    #checkpoint = ModelCheckpoint(file_path, monitor='val_acc', verbose=1, save_best_only=True, mode='max', period=1)
    checkpoint = ModelCheckpoint(file_path,
                                 monitor='val_accuracy',
                                 verbose=0,
                                 save_best_only=False,
                                 save_weights_only=False,
                                 mode='max'
                                 #mode='auto',
                                 #period=1
                                 )
    call_backs = [checkpoint]
    model.fit(x_train, y_train,validation_data=(x_test,y_test), batch_size=90, epochs=19000,callbacks=call_backs,verbose=1)
    #score = model.evaluate(x_test, y_test, batch_size=32)
def tepredict():
    sql = ''
if __name__ == '__main__':
    types = ['gegu','hygn']
    types = ['gegu']
#types = ['hygn']
    for type in types:
        getTrainData_V2(type)