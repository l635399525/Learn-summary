from sklearn.preprocessing import RobustScaler

from com.DbTool import getConn, query, insert

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
def scalar_normalize(train_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:, 4:-1])
    train_data[:, 4:-1] = scaler.transform(train_data[:, 4:-1])
    #test_data[:, 2:-2] = scaler.transform(test_data[:, 2:-2])
    return train_data
def getModels():
    sql = '''
    select a.*,b.cnn_acc,b.cnn_val_acc,cnn_file from
(select a.*,b.lstm_val_acc,lstm_acc,lstm_file
from
(select a.key,a.fr_s,b.xgb_s,fr_f,xgb_f from
(select key,score as fr_s,file as fr_f from raw_tmp_xgb_fr_data where type = 'fr') a
left outer join
(select key,score as xgb_s,file as xgb_f from raw_tmp_xgb_fr_data where type = 'xgb') b
on a.key = b.key) a left outer join
(select epoch, accuracy as lstm_acc, max(val_accuracy) as lstm_val_acc,file as lstm_file,key from raw_tmp_lstm_data where epoch> 100
group by key) b on a.key = b.key) a left outer join
(select epoch, accuracy as cnn_acc, max(val_accuracy) as cnn_val_acc,file as cnn_file,key from raw_tmp_cnn_data where epoch > 200
group by key) b on a.key = b.key
    '''
    import numpy as np
    df = query(sql,conn)
    data1 = np.load('raw_hl_merge_%s.npz' % (1), allow_pickle=True)
    data2 = np.load('raw_hl_merge_%s.npz' % (2), allow_pickle=True)
    data3 = np.load('raw_hl_merge_%s.npz' % (3), allow_pickle=True)
    data5 = np.load('raw_hl_merge_%s.npz' % (5), allow_pickle=True)
    data6 = np.load('raw_hl_merge_%s.npz' % (6), allow_pickle=True)
    data7 = np.load('raw_hl_merge_%s.npz' % (7), allow_pickle=True)

    datas_tests = {
        '1': data1['test']
       ,'2': data2['test']
       ,'3': data3['test']
       ,'5': data5['test']
       ,'6': data6['test']
       ,'7': data7['test']
    }
    datas_train = {
          '1': data1['train']
        , '2': data2['train']
        , '3': data3['train']
        , '5': data5['train']
        , '6': data6['train']
        , '7': data7['train']
    }
    e_keys = [
         '0-0'
        ,'3-0'
        ,'0-2'
        ,'8-3'
        ,'1-3'
        ,'0-4'
        ,'7-2'
        ,'6-4'
        ,'3-2'
        ,'1-2'
        ,'1-1'
        ,'2-3'
        ,'2-0'
        ,'2-4'
        ,'7-3'
        ,'7-1'
        ,'7-4'
        ,'2-1'
        ,'7-0'
        ,'1-0'
        ,'0-1'
        ,'8-0'
        ,'6-3'
        ,'1-4'
        ,'8-1'
        ,'8-2'
        ,'6-0'
        ,'3-4'
        ,'8-4'
        ,'3-1'
        ,'6-2'
        ,'2-2'
        ,'4-4'
        ,'4-0'

    ]
    import pickle
    import os
    from keras.models import Sequential, load_model
    import pandas as pd
    fdfs = []
    for i in range(len(df)):
        try:
            print("%s ----------" %(i))
            idf = df.iloc[i]
            xgb_info = idf['xgb_f']
            os.path.exists(xgb_info)
            fr_info  = idf['fr_f']
            cnn_info  = idf['cnn_file']
            lstm_info  = idf['lstm_file']
            key = idf['key']
            # if key in e_keys:
            #     continue
            xgb_n    = xgb_info.split("_")[-2]
            fr_n     = fr_info.split("_")[-2]
            try:
                cnn_n    = cnn_info.split("_")[-2]
            except:
                cnn_n = None
            try:
                lstm_n   = lstm_info.split("_")[-2]
            except:
                lstm_n = None
            dfs = []
            if xgb_n is not None:
                xgb_train = datas_train[xgb_n]
                xgb_test  = datas_tests[xgb_n]
                xgb_data = np.concatenate((xgb_train,xgb_test))
                train_idx = np.argwhere((xgb_data[:, 3] == key))[:, 0]
                train_x = xgb_data[train_idx][:,4:-1]
                y = xgb_data[train_idx][:,-1]
                head_xgb = pd.DataFrame(data=xgb_data[train_idx][:,:4],columns=['n_date','code','p_date','key'])
                head_xgb['y'] = y
                #clf_xgb = pickle.load(xgb_info)
                with open(xgb_info, 'rb') as f:
                    clf_xgb = pickle.load(f)
                pvs = clf_xgb.predict_proba(train_x)
                xgb_std =  np.std(pvs,axis=1)
                xgb_y = np.argmax(pvs,axis=1)
                head_xgb['p_std'] = xgb_std
                head_xgb['p_y'] = xgb_y
                head_xgb['type']  = 'xgb'
                head_xgb['a'] = pvs[:,0]
                head_xgb['b'] = pvs[:,1]
                try:
                    head_xgb['c'] = pvs[:,2]
                except:
                    head_xgb['c'] = None
                try:
                    head_xgb['d'] = pvs[:,3]
                except:
                    head_xgb['d'] = None
                dfs.append(head_xgb)
            if fr_n is not None:
                fr_train = datas_train[fr_n]
                fr_test = datas_tests[fr_n]
                fr_data = np.concatenate((fr_train,fr_test))
                train_idx = np.argwhere((fr_data[:, 3] == key))[:, 0]
                train_x = fr_data[train_idx][:, 4:-1]
                y = fr_data[train_idx][:,-1]
                head_fr = pd.DataFrame(data=fr_data[train_idx][:, :4], columns=['n_date', 'code', 'p_date', 'key'])
                head_fr['y'] = y
                with open(fr_info, 'rb') as f:
                    clf_fr = pickle.load(f)
                pvs = clf_fr.predict_proba(train_x)
                fr_std = np.std(pvs, axis=1)
                fr_y = np.argmax(pvs, axis=1)
                head_fr['p_std'] = fr_std
                head_fr['p_y'] = fr_y
                head_fr['type']  = 'fr'
                head_fr['a'] = pvs[:, 0]
                head_fr['b'] = pvs[:, 1]
                try:
                    head_fr['c'] = pvs[:, 2]
                except:
                    head_fr['c'] = None
                try:
                    head_fr['d'] = pvs[:, 3]
                except:
                    head_fr['d'] = None

                dfs.append(head_fr)
            if cnn_n is not None:
                cnn_train = datas_train[cnn_n]
                cnn_test = datas_tests[cnn_n]
                cnn_data = np.concatenate((cnn_train,cnn_test))
                cnn_data = scalar_normalize(cnn_data)
                train_idx = np.argwhere((cnn_data[:, 3] == key))[:, 0]
                train_x = cnn_data[train_idx][:, 4:-1]
                y = cnn_data[train_idx][:, -1]
                head_cnn = pd.DataFrame(data=cnn_data[train_idx][:, :4], columns=['n_date', 'code', 'p_date', 'key'])
                head_cnn['y'] = y
                model = load_model(cnn_info)
                train_x = train_x.reshape((len(train_x), 1, train_x.shape[1], 1))
                pvs = model.predict(train_x.astype(float))
                cnn_std = np.std(pvs, axis=1)
                cnn_y = np.argmax(pvs, axis=1)
                head_cnn['p_std'] = cnn_std
                head_cnn['p_y'] = cnn_y
                head_cnn['type']  = 'cnn'
                head_cnn['a'] = pvs[:, 0]
                head_cnn['b'] = pvs[:, 1]
                try:
                    head_cnn['c'] = pvs[:, 2]
                except:
                    head_cnn['c'] = None
                try:
                    head_cnn['d'] = pvs[:, 3]
                except:
                    head_cnn['d'] = None
                dfs.append(head_cnn)
            if lstm_n is not None:
                def reshaper(arr):
                    arr = np.array(np.split(arr, 6, axis=1))
                    arr = np.swapaxes(arr, 0, 1)
                    arr = np.swapaxes(arr, 1, 2)
                    return arr
                lstm_train = datas_train[lstm_n]
                lstm_test = datas_tests[lstm_n]
                lstm_data = np.concatenate((lstm_train,lstm_test))
                lstm_data = scalar_normalize(lstm_data)
                train_idx = np.argwhere((lstm_data[:, 3] == key))[:, 0]
                train_x = lstm_data[train_idx][:, 4:-1]
                train_x = reshaper(train_x)
                y = lstm_data[train_idx][:, -1]
                head_lstm = pd.DataFrame(data=lstm_data[train_idx][:, :4], columns=['n_date', 'code', 'p_date', 'key'])
                head_lstm['y'] = y
                model = load_model(lstm_info)

                pvs = model.predict(train_x.astype(float))
                lstm_std = np.std(pvs, axis=1)
                lstm_y = np.argmax(pvs, axis=1)
                head_lstm['p_std'] = lstm_std
                head_lstm['p_y']   = lstm_y
                head_lstm['type'] = 'lstm'
                head_lstm['a'] = pvs[:, 0]
                head_lstm['b'] = pvs[:, 1]
                try:
                    head_lstm['c'] = pvs[:, 2]
                except:
                    head_lstm['c'] = None
                try:
                    head_lstm['d'] = pvs[:, 3]
                except:
                    head_lstm['d'] = None
                dfs.append(head_lstm)
            rdf = pd.concat(dfs)
            rdf['key'] = key
            fdfs.append(rdf)
        except:
            pass
    rdf = pd.concat(fdfs)
    insert(rdf,conn,'raw_perdict_hlwave')
if __name__ == '__main__':
    getModels()