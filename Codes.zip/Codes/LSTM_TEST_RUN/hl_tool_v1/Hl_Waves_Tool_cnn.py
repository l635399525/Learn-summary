import glob

from keras.models import Model
from keras.utils import np_utils
from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor
from sklearn.preprocessing import RobustScaler, OneHotEncoder
from tensorflow.python.keras import Input
from tensorflow.python.keras.callbacks import CSVLogger

from com.DbTool import getConn, query, insert
import xgboost as xgb
from hl_tool.Intraday2403LSTM import trainer_lstm, reshaper
import keras

from keras.callbacks import ModelCheckpoint
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
#from keras.optimizers import SGD
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import SGD
conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, train_test_split, GridSearchCV
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, CSVLogger
import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
from numpy import loadtxt
from xgboost import XGBClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import StratifiedKFold
import os
def callbacks_req(n,model_type='CNN'):
    fd = str(n).replace("hl_cnn_","")
    test_year = '2022'
    model_folder = r'D:\data\models\cnn\%s' %(fd)
    if not os.path.exists(model_folder):
        os.makedirs(model_folder)
    csv_logger = CSVLogger(model_folder+'/%s#training-log-' %(n)+model_type+'-'+str(test_year)+'.csv')
    filepath = model_folder+"/%s#model-"%(n) + model_type + '-' + str(test_year) + "-E{epoch:02d}.h5"
    model_checkpoint = ModelCheckpoint(filepath, monitor='val_loss',save_best_only=False, period=1)
    earlyStopping = EarlyStopping(monitor='val_loss',mode='min',patience=299,restore_best_weights=True)
    return [csv_logger,earlyStopping,model_checkpoint]

def build_model(a):
    # 11 0.4 0.1
    datas = {
         3: {'dr_1':(1,3),'dr_2':(1,3*6,1)}
        ,5: {'dr_1':(1,5),'dr_2':(1,5*6,1)}
        ,6: {'dr_1': (1,5), 'dr_2': (1,6*6,1)}
        ,7: {'dr_1': (1,5), 'dr_2': (1,7*6,1)}
    }
    dr_1 = datas[a]['dr_1']
    dr_2 = datas[a]['dr_2']

    from tensorflow.keras import optimizers

    print("#############start train###########")

    model = Sequential()
    # 输入: 3 通道 100x100 像素图像 -> (100, 100, 3) 张量。
    # 使用 32 个大小为 3x3 的卷积滤波器。
    model.add(Conv2D(32, dr_1, activation='relu', input_shape=dr_2))
    model.add(Conv2D(32, dr_1, activation='relu'))
    # model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Conv2D(64, dr_1, activation='relu'))
    model.add(Conv2D(64, dr_1, activation='relu'))
    # model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Flatten())
    model.add(Dense(256, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(4, activation='softmax'))


    #model.add(Dense(4, activation='sigmoid'))

    #model.compile(loss='categorical_crossentropy', optimizer=optimizers.RMSprop(),
    #              metrics=['accuracy'])
    #sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)

    #model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['accuracy'])
    sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
    # model.compile(loss='categorical_crossentropy', optimizer=sgd)
    model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['accuracy'])
    return model
    # {'type': 'lstm', 'neurons': 100, 'input_timesteps': 21, 'input_dim': 11, 'return_seq': True}
    # {'type': 'dropout', 'rate': 0.2}
    # {'type': 'lstm', 'neurons': 100, 'return_seq': True}
    # {'type': 'lstm', 'neurons': 100, 'return_seq': False}
    # {'type': 'dropout', 'rate': 0.2}
    # {'type': 'dense', 'neurons': 1, 'activation': 'linear'}

def trainer_lstm(model_name,train_data,test_data):
    np.random.shuffle(train_data)
    n = int(model_name.split("_")[-2])
    test_x, test_y = test_data[:, 4:-1], test_data[:, -1]
    x_train, y_train = train_data[:, 4:-1], train_data[:, -1]
    #train_x = reshaper(x_train)
    train_x = x_train
    train_y = np.reshape(y_train,(-1, 1))
    enc = OneHotEncoder(handle_unknown='ignore')
    enc.fit(train_y)
    enc_y = enc.transform(train_y).toarray()
    #train_ret = np.hstack((np.zeros((len(train_data),1)),train_ret))

    #test_x =   reshaper(test_x)
    test_y = np.reshape(test_y, (-1, 1))
    #train_ret = np.reshape(train_ret, (-1, 1))
    test_enc = OneHotEncoder(handle_unknown='ignore')
    test_enc.fit(test_y)
    test_enc_y = test_enc.transform(test_y).toarray()
    #model = makeLSTM(240)
    #model = build_model(n)
    callbacks = callbacks_req(model_name)
    train_x = train_x.astype('float64')
    test_x = test_x.astype('float64')
    train_x = train_x.reshape((len(train_x), 1,train_x.shape[1],1))
    test_x  = test_x.reshape((len(test_x), 1,test_x.shape[1],1))
    model = build_model(n)
    #score = model.evaluate(test_x, test_enc_y, batch_size=128)
    #print(score)
    model.fit(train_x,
              enc_y,
              epochs=1500,
              #validation_split=0.2,
              #validation_data=(test_x,test_enc_y),
              validation_data=(test_x,test_enc_y),
              callbacks=callbacks,
              #batch_size=23
              batch_size = 64
    )

    # dates = list(set(test_data[:,0]))
    # predictions = {}
    # for day in dates:
    #     test_d = test_data[test_data[:,0]==day]
    #     test_d = reshaper(test_d[:,2:-2])
    #     predictions[day] = model.predict(test_d)[:,1]
    # return model,predictions

def scalar_normalize(train_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:, 4:-1])
    train_data[:, 4:-1] = scaler.transform(train_data[:, 4:-1])
    #test_data[:, 2:-2] = scaler.transform(test_data[:, 2:-2])
    return train_data
if __name__ == '__main__':
    Flag = False
    sql = '''
            select key from
        (select key,count(*) as cnt from raw_kmeans_kpi_sum group by key) where cnt > 200
            '''
    keys = list(query(sql, conn)['key'].values)
    efiles = glob.glob(r'D:\data\models\lstm\*')
    e_keys = list(map(lambda x:x.split("\\")[-1],efiles))
    if not Flag:
        # for n in [2,3,5]:
        #     trainer(n)
        with open('log_lstm', 'w') as wr:
            for n in [3, 5,6,7]:
                data = np.load('raw_hl_merge_%s.npz' % (n), allow_pickle=True)
                h_train_x = data['train']
                h_train_x = scalar_normalize(h_train_x)
                h_test_x = data['test']
                h_test_x = scalar_normalize(h_test_x)
                # train_x = scalar_normalize(train_x)
                # train_x = data['train']
                for key in keys:
                    # if key == '0-0':
                    #     continue
                    # if '%s_%s' %(n, key) in e_keys:
                    #     continue
                    try:
                        train_idx = np.argwhere((h_train_x[:, 3] == key))[:, 0]
                        train_x = h_train_x[train_idx]
                        test_idx = np.argwhere((h_test_x[:, 3] == key))[:, 0]
                        test_x = h_test_x[test_idx]
                        print("--------start %s %s" % (len(train_x), len(test_x)))
                        log = trainer_lstm('hl_cnn_%s_%s' % (n, key), train_x, test_x)
                        #wr.write('hl_lstm_%s_%s' % (n, key) + " " + log + "\n")
                        #wr.flush()
                    except:
                        import traceback
                        traceback.print_exc()
                        # import tra
                        pass

