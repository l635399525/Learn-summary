from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import RobustScaler

from com.DbTool import getConn, query, insert

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['n_date'] = list(df_close['n_date'])
    st_data['code'] = [st] * len(st_data)
    st_data['p_date'] = list(df_close['p_date'])
    st_data['key'] = list(df_close['key'])

    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data['ny'] = df_close['y'].values
    st_data = st_data.dropna()
    return np.array(st_data)
import pandas as pd
def genRfData(n):

    sql = 'select distinct code from raw_kmeans_kpi_sum where code in  (select code from raw_kmeans_code_cls where lv_1 in (0,1,2)) order by random()'
    codes = list(query(sql,conn)['code'].values)
    #train_codes = codes[:1499]
    train_codes = codes[:2399]

    sql = '''
    select code,p_date,n_date,key,h as xh,w as xw,ag as x_ag,dist_stds as xstd,dist_avgs as xavg,
       case when (abs(dist_sum_a)*1.0/(abs(dist_sum_a) + abs(dist_sum_b))) is null then 0 else
           (abs(dist_sum_a)*1.0/(abs(dist_sum_a) + abs(dist_sum_b))) end
           as xdsums,
       case when (abs(dist_a_idx)*1.0/(abs(dist_a_idx) + abs(dist_b_idx))) is null then 0 else
           (abs(dist_a_idx)*1.0/(abs(dist_a_idx) + abs(dist_b_idx))) end
           as xcsums,
       case when abs(n_h)/abs(h) >= 0.382 and abs(n_h)/abs(h) < 0.618 then 1
            when abs(n_h)/abs(h) >= 0.618 and abs(n_h)/abs(h) < 1     then 2
            when abs(n_h)/abs(h) >= 1 then 3
           else 0 end as y
from raw_kmeans_kpi_sum  where code in (select code from raw_kmeans_code_cls where lv_1 in (0,1,2))
    '''
    trains = []
    tests = []
    df = query(sql,conn)
    dfs = df.groupby('code')

    for code,idf in dfs:
        try:
            if len(idf) < n:
                continue
            idf = idf.sort_values(by=['n_date'])
            data = create_stock_data(idf,{'xh':list(range(0, n)),  'x_ag':list(range(0, n)), 'xstd':list(range(0, n))
                , 'xavg':list(range(0, n)), 'xdsums':list(range(0, n)), 'xcsums': list(range(0, n))},code)
            #data = create_stock_data(idf, {'xh': list(range(0, n)),  'x_ag': list(range(0, n))
            #    , 'xdsums': list(range(0, n))}, code)

            if code in train_codes:
                trains.append(data)
            else:
                tests.append(data)
            print("%s %s--- Done" %(len(trains),code))
        except:
            pass
    train_data = np.concatenate([x for x in trains])
    test_data = np.concatenate([x for x in tests])
    np.savez('raw_hl_merge_%s.npz' %(n),train = train_data,test=test_data)
    #print('raw_hl_merge_%s.npz')

import random
SEED = 7
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
def tester(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        test_x, test_y = test_data[:, 2:-1], test_data[:, -1]
        res = clf2.predict(test_x)
        nres = clf2.predict_proba(test_x)
        res_1 = np.argmax(nres,axis=1)
        gap = np.round(np.abs(nres[:,0] - nres[:,1]),3)
        return res,test_y,res_1,gap
def trainer(model_name,train_data, test_data):
    random.seed(SEED)
    np.random.seed(SEED)

    train_x, train_y = train_data[:, 4:-1], train_data[:, -1]
    test_x, test_y   = test_data[:, 4:-1], test_data[:, -1]
    train_y = train_y.astype('int')
    print('Started training')
    clf = RandomForestClassifier(n_estimators=2999,
                                 max_depth=13,
                                 random_state=SEED,
                                 n_jobs=-1)
    #s = pickle.dumps(clf)

    clf.fit(train_x, train_y)
    print('Completed ', clf.score(train_x, train_y))
    #print('Completed ', clf.score(test_x, test_y))

    with open(model_name, 'wb') as f:
        pickle.dump(clf, f)
    pvs = clf.predict_proba(test_x)
    # dates = list(set(test_data[:, 0]))
    # predictions = {}
    # for day in dates:
    #     test_d = test_data[test_data[:, 0] == day]
    #     test_d = test_d[:, 2:-2]
    #     predictions[day] = clf.predict_proba(test_d)[:, 1]
    acnt = np.count_nonzero(np.argmax(pvs, axis=1) - test_y == 0)
    cnt = len(pvs)
    print('%s Test result' %(acnt/cnt))
    log = '%s Test result' %(acnt/cnt)
    return log


def scalar_normalize(train_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:, 4:-1])
    train_data[:, 4:-1] = scaler.transform(train_data[:, 4:-1])
    #test_data[:, 2:-2] = scaler.transform(test_data[:, 2:-2])
    return train_data
if __name__ == '__main__':
    Flag = True
    sql = '''
    select key from
(select key,count(*) as cnt from raw_kmeans_kpi_sum group by key) where cnt > 200
    '''
    keys = list(query(sql,conn)['key'].values)
    if Flag:
        #for n in [1,2,3,5]:
        for n in [1,2,3,5,6,7]:
            genRfData(n)
    if not Flag:
        # for n in [2,3,5]:
        #     trainer(n)
        with open('log','w') as wr:
            for n in [1,2,3,5]:
                data = np.load('raw_hl_merge_%s.npz' %(n),allow_pickle=True)
                #train_x = scalar_normalize(train_x)
                #train_x = data['train']
                for key in keys:
                    try:
                        train_x = data['train']
                        train_idx = np.argwhere((train_x[:,3] == key))[:,0]
                        train_x = train_x[train_idx]
                        test_x = data['test']
                        #test_x = scalar_normalize(test_x)

                        test_idx = np.argwhere((test_x[:,3] == key))[:,0]
                        test_x = test_x[test_idx]
                        print("--------start %s %s" %(len(train_x),len(test_x)))
                        log = trainer('hl_fr_%s_%s' %(n,key),train_x,test_x)
                        wr.write('hl_fr_%s_%s' %(n,key)+ " " + log + "\n")
                        wr.flush()
                    except:
                        pass

#0-0 不行