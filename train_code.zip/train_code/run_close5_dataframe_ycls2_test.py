__author__ = "Jakob Aungiers"
__copyright__ = "Jakob Aungiers 2018"
__version__ = "2.0.0"
__license__ = "MIT"

import os
import json
import time
import math
import matplotlib.pyplot as plt

from com.DbTool import query, getConn
from core_enhance.data_processor_myself_34 import DataLoader
from core_enhance.data_processor_myself_34_train_close import DataLoaderTrain
from core_enhance.model import Model
from keras.utils import np_utils


def plot_results(predicted_data, true_data):
    fig = plt.figure(facecolor='white')
    ax = fig.add_subplot(111)
    ax.plot(true_data, label='True Data')
    plt.plot(predicted_data, label='Prediction')
    plt.legend()
    plt.show()


def plot_results_multiple(predicted_data, true_data, prediction_len):
    fig = plt.figure(facecolor='white')
    ax = fig.add_subplot(111)
    ax.plot(true_data, label='True Data')
	# Pad the list of predictions to shift it in the graph to it's correct start
    for i, data in enumerate(predicted_data):
        padding = [None for p in range(i * prediction_len)]
        plt.plot(padding + data, label='Prediction')
        plt.legend()
    plt.show()

import numpy as np
def main():
    folder_type = 'close'
    configs = json.load(open(r'D:\code_center\stock_analysis\LSTM-Neural-Network-for-Time-Series-Prediction-master\raw_close_summary_cls5_n1.json', 'r'))
    if not os.path.exists(configs['model']['save_dir']): os.makedirs(configs['model']['save_dir'])

    data = DataLoaderTrain('close',
        os.path.join('data', configs['data']['filename']),
        configs['data']['train_test_split'],
        configs['data']['columns']
    )

    #model.load_model('/Users/lili/PycharmProjects/LSTM-Neural-Network-for-Time-Series-Prediction-master/saved_models/18012022-000043-e333.h5')
    # x, y = data.get_train_data(
    #     seq_len=configs['data']['sequence_length'],
    #     normalise=configs['data']['normalise']
    # )

    '''
	# in-memory training
	model.train(
		x,
		y,
		epochs = configs['training']['epochs'],
		batch_size = configs['training']['batch_size'],
		save_dir = configs['model']['save_dir']
	)
	'''
    x_test, y_test,t_test = data.get_test_data_y2(
        seq_len=configs['data']['sequence_length'],
        normalise=configs['data']['normalise']
    )
    # x_train, y_train,t_train = data.get_train_data_y2(
    #     seq_len=configs['data']['sequence_length'],
    #     normalise=configs['data']['normalise']
    # )

    y_test = np_utils.to_categorical(y_test, 2)
    #y_train = np_utils.to_categorical(y_train, 2)


    ns = [-4,-3,-2,-1,1,2,3,4]
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    for n in ns:
        gold_file = query("select gold_file from raw_model_lst where y_type = 'ycls2' and type = 'close' and cls = %s" % (n), conn)['gold_file'].values[0]

        x_te =  x_test[np.argwhere(t_test  == n)[:,0]]
        y_te =  y_test[np.argwhere(t_test  == n)[:,0]]
        model = Model()
        model.load_model(gold_file)
        resutl = model.model.predict(x_te)
        yy = np.argwhere(y_te[:,0] == 1)[:,0]
        py = np.argwhere(resutl[:,0] == 1)[:,0]


        print(resutl)
        #x_tr = x_train[np.argwhere(t_train == n)[:,0]]
        #y_tr = y_train[np.argwhere(t_train == n)[:,0]]
        #print("%s %s %s" %(n,len(x_te),len(y_tr)))
        # try:
        #     model.train(x_tr, y_tr, configs['training']['epochs'], configs['training']['batch_size'], save_dir=configs['model']['save_dir'],val_data=(x_te, y_te),cls="%s#%s" %(folder_type,n),ycls_n=2)
        # except:
        #     pass
    #x_test,y_test = None,None
    # out-of memory generative training
    # steps_per_epoch = math.ceil((data.len_train - configs['data']['sequence_length']) / configs['training']['batch_size'])
    # model.train_generator(
    #     data_gen=data.generate_train_batch(
    #         seq_len=configs['data']['sequence_length'],
    #         batch_size=configs['training']['batch_size'],
    #         normalise=configs['data']['normalise']
    #     ),
    #     epochs=configs['training']['epochs'],
    #     batch_size=configs['training']['batch_size'],
    #     steps_per_epoch=steps_per_epoch,
    #     save_dir=configs['model']['save_dir']
    #     ,val_data=(x_test,y_test)
    # )
if __name__ == '__main__':
    # keys = {'ab':[-9,-8],'bb':[-7,-6],'cb':[-5,-4],'db':[-3,-2],
    #  'aa':[9,8],'ba':[7,6],'ca':[5,4],'da':[3,2],'aa':[-1,1]}
    # for key,values in keys.items():
    #for n in [13,17,25]:
    main()