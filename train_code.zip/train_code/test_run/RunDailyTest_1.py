from keras.utils import np_utils

from com.DbTool import getConn,query,insert
#from test_run.data_tool.DataToolTest import DataLoaderTestDaily
from core_enhance.data_processor_myself_34_train_close import DataLoaderTrain

import json
import numpy as np
import pandas as pd
from core_enhance.model import Model
import os
def getTestData(df,configs,t_cls):
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    data = DataLoaderTrain('close',
                           os.path.join('data', configs['data']['filename']),
                           configs['data']['train_test_split'],
                           configs['data']['columns']
                           )
    col_lst = ['code','work_date','model_t','model_c','model_yt','ny','model_gf']
    x_test, y_test, t_test = data.get_test_data_y2(
        seq_len=configs['data']['sequence_length'],
        normalise=configs['data']['normalise'],df=df
    )
    y_test_2 = np_utils.to_categorical(y_test, 2)
    if 'close' in t_cls:
        ns = [-4, -3, -2, -1, 1, 2, 3, 4]
    else:
        ns = [-9, -8, -7, -6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for n in ns:
        gold_file = query("select gold_file from raw_model_lst where y_type = 'ycls2' and type = 'close' and cls = %s" % (n), conn)['gold_file'].values[0]
        x_te = x_test[np.argwhere(t_test == n)[:, 0]]
        y_te = y_test[np.argwhere(t_test == n)[:, 0]]
        model = Model()
        model.load_model(gold_file)
        resutl = model.model.predict(x_te)
        py = np.argmax(resutl,axis=1)
        #py = np.argwhere(resutl[:, 0] == 1)[:, 0]
        print("---------")
        # yy = np.argwhere(y_te[:, 0] == 1)[:, 0]
        # py = np.argwhere(result[:, 0] == 1)[:, 0]
        # #for idx, model_file in enumerate(model_files):
        # idxes = np.argwhere(tms == model_file)[:, 0]
        # ths = h_test[idxes]
        # tdf = pd.DataFrame(data=ths, columns=col_lst)
        # xs = x_test[idxes]
        # model = Model()
        # model.load_model(model_file)
        # reses = model.model.predict(xs)
        # tdf['n_ycls2'] = tdf.ny.apply(lambda x: 1 if x > 0 else 0).values
        # tdf['t_cls'] = t_cls
        # if 'ycls2' in t_cls:
        #     tdf['pv'] = np.argmax(reses, axis=1)
        # else:
        #     tdf['pv'] = np.round(reses[:, 0], 4)
        # # for i in range(len(pre_res)):
        # #     rline = pre_res[i]
        # #     max_idx = np.argmax(rline)
        # #     pre_reses.append(max_idx
        # insert(tdf, conn, 'test_%s' % (src_table), opType='append')
        # print("%s %s %s" % (idx, model_file, len(tdf)))
def runDailyTest():
    def _getData1():
        conn = getConn(r'D:\data\RAW_FINAL_FORMAT')
        sql = '''
        select * from raw_close_wave_N_5_clses_daily
        '''
        df = query(sql,conn)
        return df
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    types_conf = {
        'y': ['13', '17', '25', 'close']
        , 'ycls2': ['13', '17', '25', 'close']
    }
    types_conf = {
        'ycls2': ['close'],
        #'ycls2': ['13', '17', '25', 'close']
    }
    out_path = r'D:\code_center\stock_analysis\LSTM-Neural-Network-for-Time-Series-Prediction-master'
    lstm_conf = {
          'y_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'y_13': out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'y_17': out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'y_25': out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'ycls2_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'ycls2_13': out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'ycls2_17': out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'ycls2_25': out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
    }
    configs = json.load(open(r'D:\code_center\stock_analysis\LSTM-Neural-Network-for-Time-Series-Prediction-master\raw_close_summary_cls5_n1.json', 'r'))
    for yt, types in types_conf.items():
        df = _getData1()
        getTestData(df, configs,types[0])
        print("%s %s %s" % (yt, type, len(df)))
if __name__ == '__main__':
    runDailyTest()
