import math
import numpy as np
import pandas as pd
from sklearn import preprocessing

from com.DbTool import query,insert,getConn

class DataLoaderTestDaily():
    """A class for loading and transforming data for the lstm model"""

    def __init__(self, df, split, cols):
        self.dataframe = df
        self.cols = cols[:-1]
        i_split = int(len(self.dataframe) * split)
        self.data_train = self.dataframe.get(self.cols).values[:i_split]
        self.data_test  = self.dataframe.get(self.cols).values[i_split:]
        self.len_train  = len(self.data_train)
        self.len_test   = len(self.data_test)
        self.len_train_windows = None

    def get_test_data_day_final(self,df, seq_len, normalise,column='work_date',col_lst=['code','work_date','model_t','model_c','model_yt','ny','model_gf']):
        '''
        Create x, y test data windows
        Warning: batch method, not generative, make sure you have enough memory to
        load data, otherwise reduce size of the training split.
        '''
        dfs = df.groupby('code')
        data_x = []
        data_h = []
        data_t = []

        num = 0
        for code, idf in dfs:
            num = num + 1
            if num > 100:
                continue
            print("%s-------%s" % (num,code))
            try:
                idf = idf.sort_values(by=[column])
                data_train = idf
                data_train = data_train[self.cols].values
                types = idf['type'].values

                data_heads = idf[col_lst].values
                len_train = len(data_train)
                for i in range(seq_len,len_train):
                    head_line = data_heads[i]
                    type = types[i]
                    window = data_train[i-seq_len:i]
                    x = window
                    try:
                        x = self.normalise_windows(x, single_window=True)[0] if normalise else x
                        data_x.append(x)
                        data_h.append(head_line)
                        data_t.append(type)
                    except:
                        pass
            except:
                import traceback
                traceback.print_exc()
        print(">>>>>>>>><<<<<<<<<%s" %(len(data_h)))
        return np.asarray(data_x),np.asarray(data_h),np.asarray(data_t)

    def _next_window(self, i, seq_len, normalise,tdata=None):
        '''Generates the next data window from the given index location i'''
        if tdata is None:
            window = self.data_train[i:i+seq_len]
        else:
            window = tdata[i:i+seq_len]

        x = window[:,:-1]
        x = self.normalise_windows(x, single_window=True)[0] if normalise else x

        #window = self.normalise_windows(window, single_window=True)[0] if normalise else window
        # x = window[:-1]
        # y = window[-1, [0]]
        #x = window[:,:,:-1]
        y = window[-1, [-1]]
        return x, y

    def normalise_windows(self, window_data, single_window=False):
        '''Normalise window with a base value of zero'''
        normalised_data = []
        window_data = [window_data] if single_window else window_data
        for window in window_data:
            normalised_window = []
            for col_i in range(window.shape[1]):
                arrs = window[:, col_i]
                arrs = arrs[:, np.newaxis]
                scaler = preprocessing.StandardScaler().fit(arrs)
                normalised_col = scaler.transform(arrs)
                normalised_col = normalised_col.reshape((normalised_col.shape[0]))
                #normalised_col = [((float(p) / float(window[0, col_i])) - 1) for p in window[:, col_i]]
                normalised_window.append(normalised_col)
            normalised_window = np.array(normalised_window).T # reshape and transpose array back into original multidimensional format
            normalised_data.append(normalised_window)
        return np.array(normalised_data)