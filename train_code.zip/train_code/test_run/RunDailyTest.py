from keras.utils import np_utils

from com.DbTool import getConn,query,insert
from test_run.data_tool.DataToolTest import DataLoaderTestDaily
import json
import numpy as np
import pandas as pd
from core_enhance.model import Model

def getTestData(df,conf_file,t_cls,src_table):
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    configs = json.load(open(conf_file, 'r'))
    data = DataLoaderTestDaily(
        df,
        configs['data']['train_test_split'],
        configs['data']['columns']
    )
    col_lst = ['code','work_date','model_t','model_c','model_yt','ny','model_gf']
    x_test, h_test,t_test = data.get_test_data_day_final(df,seq_len=configs['data']['sequence_length'],normalise=configs['data']['normalise'],col_lst=col_lst)
    model_files = list(set(h_test[:, -1]))
    if 'close' in t_cls:
        ns = [-4, -3, -2, -1, 1, 2, 3, 4]
    else:
        ns = [-9, -8, -7, -6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    #tms = h_test[:, -1]
    for n in ns:
        gold_file = query("select gold_file from raw_model_lst where y_type = 'ycls2' and type = 'close' and cls = %s" % (n), conn)['gold_file'].values[0]
        x_te = x_test[np.argwhere(t_test == n)[:, 0]]
        x_heads = h_test[np.argwhere(t_test == n)[:, 0]]
        ny = x_heads[:,-2]
        mask = np.zeros(ny.shape)
        mask[ny > 0]  = 1

        y_te = np_utils.to_categorical(mask, 2)
        model = Model()
        model.load_model(gold_file)
        result = model.model.predict(x_te)
        print(result)
        yy = np.argwhere(y_te[:, 0] == 1)[:, 0]
        py = np.argwhere(result[:, 0] == 1)[:, 0]
        print("---------")
        # yy = np.argwhere(y_te[:, 0] == 1)[:, 0]
        # py = np.argwhere(result[:, 0] == 1)[:, 0]
        # #for idx, model_file in enumerate(model_files):
        # idxes = np.argwhere(tms == model_file)[:, 0]
        # ths = h_test[idxes]
        # tdf = pd.DataFrame(data=ths, columns=col_lst)
        # xs = x_test[idxes]
        # model = Model()
        # model.load_model(model_file)
        # reses = model.model.predict(xs)
        # tdf['n_ycls2'] = tdf.ny.apply(lambda x: 1 if x > 0 else 0).values
        # tdf['t_cls'] = t_cls
        # if 'ycls2' in t_cls:
        #     tdf['pv'] = np.argmax(reses, axis=1)
        # else:
        #     tdf['pv'] = np.round(reses[:, 0], 4)
        # # for i in range(len(pre_res)):
        # #     rline = pre_res[i]
        # #     max_idx = np.argmax(rline)
        # #     pre_reses.append(max_idx
        # insert(tdf, conn, 'test_%s' % (src_table), opType='append')
        # print("%s %s %s" % (idx, model_file, len(tdf)))
def runDailyTest():
    conn = getConn(r"D:\data\RAW_FINAL_FORMAT")
    types_conf = {
        'y': ['13', '17', '25', 'close']
        , 'ycls2': ['13', '17', '25', 'close']
    }
    types_conf = {
        'ycls2': ['close'],
        #'ycls2': ['13', '17', '25', 'close']
    }

    out_path = r'D:\code_center\stock_analysis\LSTM-Neural-Network-for-Time-Series-Prediction-master'
    lstm_conf = {
        'y_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'y_13': out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'y_17': out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'y_25': out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
        , 'ycls2_close': out_path + "\\" + 'raw_close_summary_cls5_n1.json'
        , 'ycls2_13': out_path + "\\" + 'raw_hl_summary_cls13_v1.json'
        , 'ycls2_17': out_path + "\\" + 'raw_hl_summary_cls17_v1.json'
        , 'ycls2_25': out_path + "\\" + 'raw_hl_summary_cls25_v1.json'
    }
    for yt, types in types_conf.items():
        # if yt == 'y':
        #     continue
        for type in types:
            if type == 'close':
                src_table = 'raw_{t}_wave_N_5_clses_daily'.format(t=type)
                sql = '''
                    select a.*,a.n1y as ny, b.type as model_t, b.cls as model_c, b.version as model_v, b.y_type as model_yt, b.conf_file as model_cf,
                   b.mstept as model_st, b.gold_file as model_gf, b.acc as model_acc, b.val_acc as model_val_acc from {src_table} a,raw_model_lst b
                where a.type = b.cls and b.type = '{type}' and b.y_type = '{yt}'
                order by code,work_date
                --and date(a.work_date) > date('2021-01-01')
                    '''.format(yt=yt, src_table=src_table, type=type)
            else:
                src_table = 'raw_hl9close_wave{n}_daily'.format(n=type)
                sql = '''
                    select a.*, b.type as model_t, b.cls as model_c, b.version as model_v, b.y_type as model_yt, b.conf_file as model_cf,
                   b.mstept as model_st, b.gold_file as model_gf, b.acc as model_acc, b.val_acc as model_val_acc from {src_table} a,raw_model_lst b
                where a.type = b.cls and b.type = '{type}' and b.y_type = '{yt}'
                --and date(a.work_date) > date('2021-01-01')
                                order by code,work_date

                    '''.format(yt=yt, src_table=src_table, type=type)
            conf_file = lstm_conf['%s_%s' % (yt, type)]
            df = query(sql, conn)
            getTestData(df, conf_file, '%s_%s' % (yt, type), src_table)
            print("%s %s %s" % (yt, type, len(df)))
if __name__ == '__main__':
    runDailyTest()
