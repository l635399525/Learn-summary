from sklearn.ensemble import RandomForestClassifier

from com.DbTool import getConn, query, insert

conn = getConn(r'D:\data\RAW_FINAL_FORMAT_ANALYSIS')
import pandas as pd
import numpy as np
def create_stock_data(df_close, columns, st):
    st_data = pd.DataFrame([])
    st_data['work_date'] = list(df_close['work_date'])
    st_data['code'] = [st] * len(st_data)
    for key,val in columns.items():
        for k in val:
            st_data['%s' %(key) + str(k)] = df_close[key].shift(k).values
    st_data['tn'] = df_close['ny13s'].shift(-1).values
    st_data['tp'] = df_close['ny13s'].shift(1).values
    st_data['ny'] = st_data.apply(lambda x:1 if x['tn'] > x['tp'] else 0,axis=1)
    st_data = st_data.drop('tn',axis=1)
    st_data = st_data.drop('tp',axis=1)
    st_data = st_data.dropna()
    return np.array(st_data)
import pandas as pd
def genRfData(n):

    sql = 'select distinct code from raw_daily_hl_y_pn_merge order by random()'
    codes = list(query(sql,conn)['code'].values)
    train_codes = codes[:2399]
    sql = 'select code, work_date, ny_13, cls_13, ec_13, sdate, ny13s, gap, ag from raw_daily_hl_y_pn_merge where sdate is not null'
    trains = []
    tests = []
    df = query(sql,conn)
    dfs = df.groupby('code')
    for code,idf in dfs:
        try:
            if len(idf) < n:
                continue
            idf = idf.sort_values(by=['work_date'])
            data = create_stock_data(idf,{'ag': list(range(0, n)),'ny13s': list(range(0, n))},code)
            if code in train_codes:
                trains.append(data)
            else:
                tests.append(data)
            print("%s %s--- Done" %(len(trains),code))
        except:
            pass
    train_data = np.concatenate([x for x in trains])
    test_data = np.concatenate([x for x in tests])
    np.savez('raw_hl_merge_%s.npz' %(n),train = train_data,test=test_data)
    #print('raw_hl_merge_%s.npz')

import random
SEED = 21
import pickle

'''
import pickle #pickle模块

#保存Model(注:save文件夹要预先建立，否则会报错)
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)

#读取Model
with open('save/clf.pickle', 'rb') as f:
    clf2 = pickle.load(f)
    #测试读取后的Model
    print(clf2.predict(X[0:1]))
'''
def tester(model_name,test_data):
    with open(model_name, 'rb') as f:
        clf2 = pickle.load(f)
        # 测试读取后的Model
        test_x, test_y = test_data[:, 2:-1], test_data[:, -1]
        res = clf2.predict(test_x)
        nres = clf2.predict_proba(test_x)
        res_1 = np.argmax(nres,axis=1)
        gap = np.round(np.abs(nres[:,0] - nres[:,1]),3)
        return res,test_y,res_1,gap
def trainer(model_name,train_data, test_data):
    random.seed(SEED)
    np.random.seed(SEED)

    train_x, train_y = train_data[:, 2:-1], train_data[:, -1]
    train_y = train_y.astype('int')
    print('Started training')
    clf = RandomForestClassifier(n_estimators=2999,
                                 max_depth=15,
                                 random_state=SEED,
                                 n_jobs=-1)
    #s = pickle.dumps(clf)

    clf.fit(train_x, train_y)
    print('Completed ', clf.score(train_x, train_y))
    with open(model_name, 'wb') as f:
        pickle.dump(clf, f)
    # dates = list(set(test_data[:, 0]))
    # predictions = {}
    # for day in dates:
    #     test_d = test_data[test_data[:, 0] == day]
    #     test_d = test_d[:, 2:-2]
    #     predictions[day] = clf.predict_proba(test_d)[:, 1]
    # return predictions


if __name__ == '__main__':
    Flag = False
    if not Flag:
        for n in [5,8,11,13]:
            genRfData(n)
    if Flag:
        for n in [11,13]:
            data = np.load('raw_hl_merge_%s.npz' %(n),allow_pickle=True)
            train_x = data['train']
            test_x = data['test']
            print("--------start %s %s" %(len(train_x),len(test_x)))
            trainer('hl_fr_%s' %(n),train_x,test_x)
    if Flag:
        for n in [11,13]:
            data = np.load('raw_hl_merge_%s.npz' % (n), allow_pickle=True)
            train = data['train']
            test = data['test']
            st_data = pd.DataFrame([])
            st_data['code'] = train[:, 1]
            st_data['work_date'] = train[:, 0]
            st_data['type'] = ['%s_%s' %('train',n)]*len(train)
            pv, av,pv1,gap = tester('hl_fr_%s' % (n), train)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av

            insert(st_data, conn, 'test_merge_result', opType='append')
            print("-------------------------%s" %(n))
            st_data = pd.DataFrame([])
            st_data['code'] = test[:, 1]
            st_data['work_date'] = test[:, 0]
            st_data['type'] = ['%s_%s' % ('test', n)] * len(test)
            pv, av,pv1,gap = tester('hl_fr_%s' % (n), test)
            st_data['pv'] = pv
            st_data['pv_t'] = pv1
            st_data['gap'] = gap
            st_data['av'] = av
            insert(st_data, conn, 'test_merge_result', opType='append')
            print("-------------------------%s" %(n))

